import { cookies } from "next/headers";
import type { Metadata } from "next";
import { LOCALE_COOKIE, resolveLocale } from "@/lib/i18n/messages";
import { pageTitle, type PageTitleName } from "@/lib/i18n/page-titles";

export function pageMetadata(name: PageTitleName) {
  return async (): Promise<Metadata> => {
    const locale = resolveLocale((await cookies()).get(LOCALE_COOKIE)?.value);
    return { title: pageTitle(name, locale) };
  };
}
