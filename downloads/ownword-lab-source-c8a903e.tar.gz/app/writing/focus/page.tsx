import { WritingPage } from "../writing-page";
import "./focus.css";
import { pageMetadata } from "@/app/localized-metadata";

export const dynamic = "force-dynamic";
export const generateMetadata = pageMetadata("focus");

export default function Page() {
  return <WritingPage screen="focus" />;
}
