import { WritingPage } from "./writing-page";
import { pageMetadata } from "@/app/localized-metadata";

export const dynamic = "force-dynamic";
export const generateMetadata = pageMetadata("home");

export default function Page() {
  return <WritingPage screen="home" />;
}
