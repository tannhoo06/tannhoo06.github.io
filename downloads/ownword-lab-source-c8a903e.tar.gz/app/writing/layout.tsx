import type { ReactNode } from "react";
import "./writing-module.css";

export default function WritingLayout({ children }: { children: ReactNode }) {
  return children;
}
