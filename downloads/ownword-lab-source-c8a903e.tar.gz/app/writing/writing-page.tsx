import { notFound } from "next/navigation";
import { requireChatGPTUser } from "@/app/chatgpt-auth";
import { writingModuleEnabled, writingLiveEvaluationEnabled } from "@/lib/server/composition";
import { writingInterests } from "@/lib/writing/prompt-bank";
import { writingRegistry } from "@/lib/writing/registry";
import { LocalizedPageTitle } from "@/components/localized-page-title";
import { AppShell } from "@/components/app-navigation";
import { WritingDiagnostic } from "@/components/writing/diagnostic";
import { WritingHome, WritingResults } from "@/components/writing/report";
import { RevisionWorkspace } from "@/components/writing/revision-workspace";
import { WritingPractice } from "@/components/writing/personalized-practice";
import { WritingProfile } from "@/components/writing/profile";
import { WritingFocus } from "@/components/writing/focus";
import { writingPracticeHref } from "@/lib/writing/practice-path";

const skillLabels = Object.fromEntries(writingRegistry.trainable_skills.map(({ id, name_en, name_vi }) => [
  id, { en: name_en, vi: name_vi },
]));

type WritingPageProps = { screen: "home" } | { screen: "diagnostic" } | { screen: "profile" } | { screen: "focus" }
  | { screen: "submission" | "revision"; submissionId: string }
  | { screen: "practice"; submissionId: string; observationIndex: number };

export async function WritingPage(props: WritingPageProps) {
  if (!writingModuleEnabled()) notFound();
  const { screen } = props;
  const submissionId = "submissionId" in props ? props.submissionId : undefined;
  const returnTo = screen === "practice" ? writingPracticeHref(props.submissionId, props.observationIndex)
    : screen === "home" ? "/writing" : submissionId
      ? `/writing/submissions/${encodeURIComponent(submissionId)}${screen === "revision" ? "/revise" : ""}` : `/writing/${screen}`;
  const user = await requireChatGPTUser(returnTo);
  return (
    <AppShell activeModule="writing" writingView={screen === "revision" || screen === "practice" ? "submission" : screen}
      writingEnabled account={{ id: user.userId, name: user.displayName, email: user.email, avatarUrl: user.avatarUrl }}>
      <LocalizedPageTitle name={screen} />
      <main id="main-content" className="writing-main" tabIndex={-1}>
        {screen === "home" ? <WritingHome /> : screen === "diagnostic"
          ? <WritingDiagnostic interests={writingInterests} ownerId={user.userId} liveEvaluation={writingLiveEvaluationEnabled()} />
          : screen === "revision" ? <RevisionWorkspace id={props.submissionId} ownerId={user.userId} canCheck={writingLiveEvaluationEnabled()} />
          : screen === "practice" ? <WritingPractice id={props.submissionId} observationIndex={props.observationIndex} />
          : screen === "profile" ? <WritingProfile ownerId={user.userId} />
          : screen === "focus" ? <WritingFocus key={user.userId} liveEvaluation={writingLiveEvaluationEnabled()} />
          : <WritingResults id={props.submissionId} labels={skillLabels} ownerId={user.userId} />}
      </main>
    </AppShell>
  );
}
