import { WritingPage } from "../../writing-page";
import { pageMetadata } from "@/app/localized-metadata";

export const dynamic = "force-dynamic";
export const generateMetadata = pageMetadata("submission");

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  return <WritingPage screen="submission" submissionId={(await params).id} />;
}
