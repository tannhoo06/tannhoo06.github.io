import { notFound } from "next/navigation";
import { WritingPage } from "../../../../writing-page";
import { pageMetadata } from "@/app/localized-metadata";

export const dynamic = "force-dynamic";
export const generateMetadata = pageMetadata("practice");

export default async function PracticeWritingPage({ params }: { params: Promise<{ id: string; observation: string }> }) {
  const { id, observation } = await params;
  if (!/^(0|[1-9]\d{0,2})$/.test(observation)) notFound();
  return <WritingPage screen="practice" submissionId={id} observationIndex={Number(observation)} />;
}
