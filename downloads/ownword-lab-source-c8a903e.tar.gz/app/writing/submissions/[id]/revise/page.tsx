import { WritingPage } from "../../../writing-page";
import { pageMetadata } from "@/app/localized-metadata";

export const dynamic = "force-dynamic";
export const generateMetadata = pageMetadata("revision");

export default async function ReviseWritingPage({ params }: { params: Promise<{ id: string }> }) {
  return <WritingPage screen="revision" submissionId={(await params).id} />;
}
