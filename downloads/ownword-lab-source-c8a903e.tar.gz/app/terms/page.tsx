import { LegalPage } from "@/components/legal-page";
import { pageMetadata } from "@/app/localized-metadata";

export const generateMetadata = pageMetadata("terms");

export default function TermsPage() {
  return <LegalPage kind="terms" />;
}
