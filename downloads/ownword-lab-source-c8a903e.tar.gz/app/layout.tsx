import type { Metadata } from "next";
import { cookies } from "next/headers";
import { LanguageProvider } from "@/components/language-provider";
import { OwnwordMotionProvider } from "@/components/motion-provider";
import { ConfirmProvider } from "@/components/lucian-269-confirmation";
import { StreakCelebration } from "@/components/lucian-379-streak";
import { LOCALE_COOKIE, resolveLocale } from "@/lib/i18n/messages";
import "./globals.css";
import "./product-design.css";

export const metadata: Metadata = {
  title: "Ownword — Học từ để dùng tự nhiên",
  description:
    "Viết bằng tiếng Anh, khám phá từ hữu ích và luyện tập để sử dụng từ tự nhiên hơn.",
  icons: {
    icon: { url: "/favicon.svg", type: "image/svg+xml", sizes: "any" },
    shortcut: "/favicon.svg",
    apple: { url: "/apple-touch-icon.png", type: "image/png", sizes: "180x180" },
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const locale = resolveLocale((await cookies()).get(LOCALE_COOKIE)?.value);
  return (
    <html lang={locale}>
      <body className="antialiased">
        <LanguageProvider initialLocale={locale}><OwnwordMotionProvider><ConfirmProvider>{children}<StreakCelebration /></ConfirmProvider></OwnwordMotionProvider></LanguageProvider>
      </body>
    </html>
  );
}
