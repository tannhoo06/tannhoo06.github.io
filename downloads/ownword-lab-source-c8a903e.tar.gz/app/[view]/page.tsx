import { notFound } from "next/navigation";
import { requireChatGPTUser } from "../chatgpt-auth";
import { Studio } from "@/components/studio";
import type { View } from "@/components/shared";
import { writingModuleEnabled } from "@/lib/server/composition";
export const dynamic = "force-dynamic";
export default async function Page({
  params,
}: {
  params: Promise<{ view: string }>;
}) {
  const { view } = await params;
  if (
    !["board", "start", "write", "discover", "idea", "practice", "insights", "settings"].includes(
      view,
    )
  )
    notFound();
  const user = await requireChatGPTUser(`/${view}`);
  return <Studio initialView={view as View} signedIn writingEnabled={writingModuleEnabled()}
    account={{ id: user.userId, name: user.displayName, email: user.email, avatarUrl: user.avatarUrl }} />;
}
