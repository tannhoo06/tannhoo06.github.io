import { NextRequest, NextResponse } from "next/server";
import { cognitoConfig, LOGIN_COOKIE, SESSION_COOKIE, publicOrigin, safeReturnTo, verifyIdToken } from "@/lib/auth/cognito";

export async function GET(request: NextRequest) {
  if (process.env.AUTH_PROVIDER !== "cognito") return NextResponse.redirect(new URL("/", request.url));
  const code = request.nextUrl.searchParams.get("code");
  const state = request.nextUrl.searchParams.get("state");
  const raw = request.cookies.get(LOGIN_COOKIE)?.value;
  let login: { state: string; verifier: string; returnTo: string } | null = null;
  try { login = raw ? JSON.parse(raw) : null; } catch { /* Invalid transient cookie. */ }
  if (!code || !state || !login || state !== login.state || !/^[A-Za-z0-9_-]{40,128}$/.test(login.verifier))
    return new NextResponse("Sign-in could not be completed. Please try again.", { status: 400 });

  const config = cognitoConfig();
  const origin = publicOrigin(request.url);
  const callback = new URL("/auth/callback", origin);
  const tokenResponse = await fetch(new URL("/oauth2/token", config.domain), {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "authorization_code", client_id: config.clientId,
      code, redirect_uri: callback.toString(), code_verifier: login.verifier }),
    cache: "no-store",
  });
  if (!tokenResponse.ok) return new NextResponse("Sign-in could not be completed. Please try again.", { status: 400 });
  const tokens = await tokenResponse.json() as { id_token?: string; expires_in?: number };
  if (!tokens.id_token || !(await verifyIdToken(tokens.id_token)))
    return new NextResponse("Sign-in could not be verified.", { status: 400 });
  const response = NextResponse.redirect(new URL(safeReturnTo(login.returnTo), origin));
  response.cookies.delete(LOGIN_COOKIE);
  response.cookies.set(SESSION_COOKIE, tokens.id_token, {
    httpOnly: true, secure: callback.protocol === "https:", sameSite: "lax", path: "/",
    maxAge: Math.min(Math.max(tokens.expires_in ?? 3600, 1), 86400),
  });
  return response;
}
