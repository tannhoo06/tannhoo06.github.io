import { randomBytes, createHash } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { cognitoConfig, LOGIN_COOKIE, publicOrigin, safeReturnTo } from "@/lib/auth/cognito";

export async function GET(request: NextRequest) {
  const returnTo = safeReturnTo(request.nextUrl.searchParams.get("return_to"));
  if (process.env.AUTH_PROVIDER !== "cognito")
    return NextResponse.redirect(new URL(`/signin-with-chatgpt?return_to=${encodeURIComponent(returnTo)}`, request.url));

  if (process.env.CUSTOM_AUTH_ENABLED === "true" && request.nextUrl.searchParams.get("provider") !== "Google" && request.nextUrl.searchParams.get("hosted") !== "1")
    return NextResponse.redirect(new URL(`/account?return_to=${encodeURIComponent(returnTo)}`, publicOrigin(request.url)));

  const config = cognitoConfig();
  const state = randomBytes(32).toString("base64url");
  const verifier = randomBytes(32).toString("base64url");
  const challenge = createHash("sha256").update(verifier).digest("base64url");
  const callback = new URL("/auth/callback", publicOrigin(request.url));
  const authorize = new URL("/oauth2/authorize", config.domain);
  authorize.searchParams.set("response_type", "code");
  authorize.searchParams.set("client_id", config.clientId);
  authorize.searchParams.set("redirect_uri", callback.toString());
  authorize.searchParams.set("scope", "openid email profile");
  authorize.searchParams.set("state", state);
  authorize.searchParams.set("code_challenge_method", "S256");
  authorize.searchParams.set("code_challenge", challenge);
  if (process.env.GOOGLE_SIGN_IN_ENABLED === "true" && request.nextUrl.searchParams.get("provider") === "Google") authorize.searchParams.set("identity_provider", "Google");
  const response = NextResponse.redirect(authorize);
  response.cookies.set(LOGIN_COOKIE, JSON.stringify({ state, verifier, returnTo }), {
    httpOnly: true, secure: callback.protocol === "https:", sameSite: "lax", path: "/auth", maxAge: 600,
  });
  return response;
}
