import { NextRequest, NextResponse } from "next/server";
import { cognitoConfig, SESSION_COOKIE, publicOrigin, safeReturnTo } from "@/lib/auth/cognito";

export async function GET(request: NextRequest) {
  const returnTo = safeReturnTo(request.nextUrl.searchParams.get("return_to"));
  if (process.env.AUTH_PROVIDER !== "cognito")
    return NextResponse.redirect(new URL(`/signout-with-chatgpt?return_to=${encodeURIComponent(returnTo)}`, request.url));
  const config = cognitoConfig();
  const logout = new URL("/logout", config.domain);
  logout.searchParams.set("client_id", config.clientId);
  // Cognito requires an exact match with a registered sign-out URL.
  logout.searchParams.set("logout_uri", new URL("/", publicOrigin(request.url)).toString());
  const response = NextResponse.redirect(logout);
  response.cookies.delete(SESSION_COOKIE);
  return response;
}
