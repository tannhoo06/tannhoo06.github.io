"use client";

import Link from "next/link";
import { LocalizedPageTitle } from "@/components/localized-page-title";
import { useI18n } from "@/components/language-provider";
import "./landing.css";

export default function NotFound() {
  const { locale } = useI18n();
  const vi = locale === "vi";
  return (
    <div className="ow-landing ow-legal">
      <LocalizedPageTitle name="notFound" />
      <main className="ow-public-width">
        <h1>{vi ? "Không tìm thấy trang" : "Page not found"}</h1>
        <Link href="/">{vi ? "Về Ownword" : "Back to Ownword"}</Link>
      </main>
    </div>
  );
}
