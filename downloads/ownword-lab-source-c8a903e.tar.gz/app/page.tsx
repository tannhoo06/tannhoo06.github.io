import { getChatGPTUser } from "./chatgpt-auth";
import { Landing } from "@/components/landing";
import { redirect } from "next/navigation";
export const dynamic = "force-dynamic";
export default async function Home() {
  const user = await getChatGPTUser();
  if (user) redirect("/discover");
  return <Landing />;
}
