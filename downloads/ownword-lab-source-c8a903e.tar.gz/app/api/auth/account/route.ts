import { NextRequest, NextResponse } from "next/server";
import { cognitoConfig, publicOrigin, safeReturnTo, SESSION_COOKIE, verifyIdToken } from "@/lib/auth/cognito";

export const runtime = "nodejs";

type CognitoReply = {
  __type?: string;
  message?: string;
  Message?: string;
  AuthenticationResult?: { IdToken?: string; ExpiresIn?: number };
  ChallengeName?: string;
  ChallengeParameters?: Record<string, string>;
  Session?: string;
  UserConfirmed?: boolean;
};

const challenges = new Set(["SMS_MFA", "SOFTWARE_TOKEN_MFA", "EMAIL_OTP", "SMS_OTP", "NEW_PASSWORD_REQUIRED"]);

async function cognito(operation: string, payload: Record<string, unknown>): Promise<CognitoReply> {
  const config = cognitoConfig();
  const endpoint = new URL(config.issuer).origin;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-amz-json-1.1",
      "X-Amz-Target": `AWSCognitoIdentityProviderService.${operation}`,
    },
    body: JSON.stringify(payload),
    cache: "no-store",
    signal: AbortSignal.timeout(10000),
  });
  const result = await response.json() as CognitoReply;
  if (!response.ok) {
    const code = (result.__type ?? "Error").split("#").pop() ?? "Error";
    throw new CognitoError(code, result.message ?? result.Message ?? "Account request failed");
  }
  return result;
}

class CognitoError extends Error {
  constructor(readonly code: string, message: string) { super(message); }
}

function errorMessage(error: unknown, action: string): string {
  if (!(error instanceof CognitoError)) return "serviceUnavailable";
  if (error.code === "CodeMismatchException") return "invalidCode";
  if (error.code === "ExpiredCodeException") return "expiredCode";
  if (error.code === "InvalidPasswordException") return "passwordPolicy";
  if (error.code === "UsernameExistsException") return "accountExists";
  if (error.code === "LimitExceededException" || error.code === "TooManyRequestsException") return "tooManyAttempts";
  if (error.code === "UserNotConfirmedException") return "confirmAccount";
  if (error.code === "NotAuthorizedException") return action === "signIn" ? "invalidCredentials" : "invalidRequest";
  if (error.code === "UserNotFoundException") return action === "signIn" ? "invalidCredentials" : "invalidRequest";
  if (error.code === "InvalidParameterException" && action === "signIn") return "passwordAuthUnavailable";
  return "invalidRequest";
}

function text(value: unknown, max: number): string {
  return typeof value === "string" && value.length <= max ? value.trim() : "";
}

function secret(value: unknown, max: number): string {
  return typeof value === "string" && value.length <= max ? value : "";
}

export async function POST(request: NextRequest) {
  if (process.env.AUTH_PROVIDER !== "cognito" || process.env.CUSTOM_AUTH_ENABLED !== "true")
    return NextResponse.json({ error: "serviceUnavailable" }, { status: 404 });
  const origin = publicOrigin(request.url);
  if (request.headers.get("origin") !== origin.origin)
    return NextResponse.json({ error: "invalidRequest" }, { status: 403 });
  if (Number(request.headers.get("content-length") ?? 0) > 12000)
    return NextResponse.json({ error: "invalidRequest" }, { status: 413 });

  let body: Record<string, unknown>;
  try {
    const parsed: unknown = await request.json();
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Invalid body");
    body = parsed as Record<string, unknown>;
  }
  catch { return NextResponse.json({ error: "invalidRequest" }, { status: 400 }); }

  const action = text(body.action, 30);
  const email = text(body.email, 320).toLowerCase();
  const password = secret(body.password, 256);
  const code = text(body.code, 32);
  const returnTo = safeReturnTo(text(body.returnTo, 2048));
  const config = cognitoConfig();
  const clientId = config.clientId;

  try {
    let result: CognitoReply;
    switch (action) {
      case "signIn":
        if (!email || !password) return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
        result = await cognito("InitiateAuth", {
          ClientId: clientId, AuthFlow: "USER_PASSWORD_AUTH",
          AuthParameters: { USERNAME: email, PASSWORD: password },
        });
        break;
      case "signUp":
        if (!email.includes("@") || password.length < 8) return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
        result = await cognito("SignUp", {
          ClientId: clientId, Username: email, Password: password,
          UserAttributes: [{ Name: "email", Value: email }],
        });
        return NextResponse.json({ status: result.UserConfirmed ? "confirmed" : "confirm" }, { headers: { "Cache-Control": "no-store" } });
      case "confirm":
        if (!email || !code) return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
        await cognito("ConfirmSignUp", { ClientId: clientId, Username: email, ConfirmationCode: code });
        return NextResponse.json({ status: "confirmed" }, { headers: { "Cache-Control": "no-store" } });
      case "resend":
        if (!email) return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
        await cognito("ResendConfirmationCode", { ClientId: clientId, Username: email });
        return NextResponse.json({ status: "sent" }, { headers: { "Cache-Control": "no-store" } });
      case "forgot":
        if (!email) return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
        await cognito("ForgotPassword", { ClientId: clientId, Username: email });
        return NextResponse.json({ status: "sent" }, { headers: { "Cache-Control": "no-store" } });
      case "reset":
        if (!email || !code || !password) return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
        await cognito("ConfirmForgotPassword", { ClientId: clientId, Username: email, ConfirmationCode: code, Password: password });
        return NextResponse.json({ status: "reset" }, { headers: { "Cache-Control": "no-store" } });
      case "challenge": {
        const challengeName = text(body.challengeName, 40);
        const session = text(body.session, 4096);
        const username = text(body.username, 320);
        if (!challenges.has(challengeName) || !session || !username)
          return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
        const key = challengeName === "NEW_PASSWORD_REQUIRED" ? "NEW_PASSWORD" : `${challengeName}_CODE`;
        const answer = challengeName === "NEW_PASSWORD_REQUIRED" ? password : code;
        if (!answer) return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
        result = await cognito("RespondToAuthChallenge", {
          ClientId: clientId, ChallengeName: challengeName, Session: session,
          ChallengeResponses: { USERNAME: username, [key]: answer },
        });
        break;
      }
      default:
        return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
    }

    if (result.AuthenticationResult?.IdToken) {
      const verified = await verifyIdToken(result.AuthenticationResult.IdToken);
      if (!verified) return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
      const response = NextResponse.json({ status: "signedIn", returnTo }, { headers: { "Cache-Control": "no-store" } });
      response.cookies.set(SESSION_COOKIE, result.AuthenticationResult.IdToken, {
        httpOnly: true, secure: origin.protocol === "https:", sameSite: "lax", path: "/",
        maxAge: Math.min(Math.max(result.AuthenticationResult.ExpiresIn ?? 3600, 1), 86400),
      });
      return response;
    }
    if (result.ChallengeName && result.Session) {
      if (!challenges.has(result.ChallengeName))
        return NextResponse.json({ error: "unsupportedChallenge" }, { status: 400 });
      return NextResponse.json({
        status: "challenge", challengeName: result.ChallengeName, session: result.Session,
        username: result.ChallengeParameters?.USER_ID_FOR_SRP ?? email,
      }, { headers: { "Cache-Control": "no-store" } });
    }
    return NextResponse.json({ error: "invalidRequest" }, { status: 400 });
  } catch (error) {
    if (action === "forgot" && error instanceof CognitoError && ["UserNotFoundException", "NotAuthorizedException"].includes(error.code))
      return NextResponse.json({ status: "sent" }, { headers: { "Cache-Control": "no-store" } });
    return NextResponse.json({ error: errorMessage(error, action) }, { status: 400, headers: { "Cache-Control": "no-store" } });
  }
}
