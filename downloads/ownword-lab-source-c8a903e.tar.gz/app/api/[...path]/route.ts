import { z } from "zod";
import { after } from "next/server";
import { services } from "@/lib/server/composition";
import { AppError } from "@/lib/services/vocabulary";
import { jsonResponse as json, readApiJson } from "@/lib/server/api-request";
import { withLearningCredit } from "@/lib/server/streak-response";
import { nextUtcDay } from "@/lib/domain/request-limits";
import { DiscoveryLimitExceeded, vocabularyFailure } from "@/lib/server/vocabulary-errors";

export const dynamic = "force-dynamic";
const id = z.string().min(1).max(150);
const writing = z.object({
  text: z
    .string()
    .max(5000)
    .refine(
      (text) => text.trim().length >= 10,
      "Write a little more so there is enough context.",
    ),
  prompt: z.string().max(500).default(""),
});
async function handle(request: Request) {
  const started = Date.now();
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\//, "");
  try {
    const context = await services();
    const app = context.vocabulary;
    const activity = (result: unknown, completed: boolean) =>
      withLearningCredit(json(result), completed ? context.streak : undefined);
    if (request.method === "GET") {
      if (path === "discovery/quotas") {
        const day = context.clock.now().toISOString().slice(0, 10);
        const [concept, writing] = await Promise.all([
          context.repository.discoveryCount(context.identity.id, day, "concept"),
          context.repository.discoveryCount(context.identity.id, day, "writing"),
        ]);
        return json({ concept: Math.max(0, context.discoveryLimits.concept - concept), writing: Math.max(0, context.discoveryLimits.writing - writing), limits: context.discoveryLimits });
      }
      if (path === "discovery/concept/latest") return json(await app.latestConceptDiscovery());
      if (path === "writing/review")
        return json(
          await app.review(id.parse(url.searchParams.get("sampleId"))),
        );
      if (path === "state") return json(await app.state());
      if (path === "learning/journey") return json(await app.learningJourney());
      if (path === "learning/streak") return json(await context.streak.current());
      if (path === "practice")
        return json(
          await app.session(id.parse(url.searchParams.get("sessionId"))),
        );
      throw new AppError("This endpoint does not exist.", 404);
    }
    const body = await readApiJson(request);
    if (
      [
        "analyze",
        "discovery/concept",
        "discovery/concept/translate",
        "words/manual",
        "practice/start",
        "practice/quick-rate",
        "practice/answer",
        "practice/skip",
      ].includes(path)
    ) {
      if (
        !(await context.repository.consumeRateLimit(
          context.identity.id,
          context.clock.now().toISOString(),
          80,
        ))
      )
        throw new AppError(
          "You’ve made quite a few requests. Please take a break and try again next hour.",
          429,
        );
    }
    if (path === "analyze") {
      const data = writing.parse(body);
      const cached = await app.recentWritingReview(data.text, data.prompt);
      if (cached) return activity(cached, !!(cached.suggestions.length || cached.opportunities.length));
      const day = context.clock.now().toISOString().slice(0, 10);
      if (await context.repository.discoveryCount(context.identity.id, day, "writing") >= context.discoveryLimits.writing)
        throw new DiscoveryLimitExceeded("writing", nextUtcDay(new Date(day + "T00:00:00Z")));
      const review = await app.analyze(data.text, data.prompt);
      if (review.suggestions.length || review.opportunities.length) {
        if (!(await context.repository.consumeDiscovery(context.identity.id, day, "writing", context.discoveryLimits.writing)))
          throw new DiscoveryLimitExceeded("writing", nextUtcDay(new Date(day + "T00:00:00Z")));
      }
      return activity(review, !!(review.suggestions.length || review.opportunities.length));
    }
    if (path === "words/manual") {
      const data = z.object({ word: z.string().max(45), override: z.boolean().optional() }).parse(body);
      const result = await app.addManual(data.word, data.override);
      if (process.env.AUTH_PROVIDER === "cognito" && result.status !== "review") {
        const userWordId = result.userWordId;
        after(async () => {
          try {
            const { enrichManualWord } = await import("@/lib/server/manual-word-enrichment");
            await enrichManualWord(userWordId);
          } catch (error) {
            console.error("Post-response word enrichment failed:", error);
          }
        });
      }
      return activity(result, result.status === "added");
    }
    if (path === "discovery/concept") {
      const data = z.object({ concept: z.string().trim().min(3).max(500) }).parse(body);
      const cached = await app.recentConceptDiscovery(data.concept);
      if (cached) return activity(cached, cached.candidates.length > 0);
      const day = context.clock.now().toISOString().slice(0, 10);
      if (await context.repository.discoveryCount(context.identity.id, day, "concept") >= context.discoveryLimits.concept)
        throw new DiscoveryLimitExceeded("concept", nextUtcDay(new Date(day + "T00:00:00Z")));
      const candidates = await app.discoverConcept(data.concept);
      if (candidates.length && !(await context.repository.consumeDiscovery(context.identity.id, day, "concept", context.discoveryLimits.concept)))
        throw new DiscoveryLimitExceeded("concept", nextUtcDay(new Date(day + "T00:00:00Z")));
      const discovery = await app.saveConceptDiscovery(data.concept, candidates);
      return activity(discovery, candidates.length > 0);
    }
    if (path === "discovery/concept/save") {
      const data = z.object({ discoveryId: id, candidateId: id }).parse(body);
      const result = await app.addConceptCandidate(data.discoveryId, data.candidateId);
      return activity(result, result.status === "added");
    }
    if (path === "discovery/concept/translate") {
      const data = z.object({ discoveryId: id, candidateId: id }).parse(body);
      const result = await app.translateConceptCandidate(data.discoveryId, data.candidateId);
      return activity(result, !!result.meaning);
    }
    if (path === "suggestions/decide") {
      const data = z
        .object({
          id,
          decision: z.enum(["pending", "added", "dismissed", "already"]),
        })
        .parse(body);
      const { addedWord, ...result } = await app.decide(data.id, data.decision);
      return activity(result, addedWord);
    }
    if (path === "insights/add") {
      const data = z.object({ word: z.string().min(2).max(50) }).parse(body);
      const { addedWord, ...result } = await app.addInsight(data.word);
      return activity(result, addedWord);
    }
    if (path === "words/remove") {
      const data = z.object({ id }).parse(body);
      return json(await app.removeWord(data.id));
    }
    if (path === "practice/start") {
      const data = z
        .object({
          wordId: id.optional(),
          quick: z.boolean().default(false),
          quickSessionId: id.optional(),
          wordIds: z.array(id).min(1).max(20).optional(),
        })
        .parse(body);
      return json(
        await app.startPractice(data.wordId, data.quick, data.quickSessionId, data.wordIds),
      );
    }
    if (path === "practice/quick-rate") {
      const data = z
        .object({ exerciseId: id, rating: z.enum(["got", "forgot", "skip"]) })
        .parse(body);
      const { completedActivity, ...result } = await app.quickRate(data.exerciseId, data.rating);
      return activity(result, completedActivity);
    }
    if (path === "practice/hint") {
      const data = z
        .object({
          exerciseId: id,
          level: z.enum(["semantic", "letter", "partial", "revealed"]),
        })
        .parse(body);
      return json(await app.hint(data.exerciseId, data.level));
    }
    if (path === "practice/answer") {
      const data = z
        .object({ exerciseId: id, answer: z.string().trim().min(1).max(2000) })
        .parse(body);
      const result = await app.answer(data.exerciseId, data.answer);
      if (result.retry) return json(result);
      const { completedActivity, ...answer } = result;
      return activity(answer, completedActivity === true);
    }
    if (path === "practice/skip") {
      const data = z.object({ exerciseId: id }).parse(body);
      const { completedActivity, ...result } = await app.skip(data.exerciseId);
      return activity(result, completedActivity);
    }
    if (path === "settings")
      return json(
        await app.settings(
          z
            .object({
              name: z.string().trim().min(1).max(60).optional(),
              dailyLimit: z
                .union([
                  z.literal(5),
                  z.literal(6),
                  z.literal(7),
                  z.literal(8),
                  z.literal(10),
                ])
                .optional(),
            })
            .parse(body),
        ),
      );
    if (path === "demo/seed") return json(await app.seed());
    if (path === "demo/clear") return json(await app.clearDemo());
    throw new AppError("This endpoint does not exist.", 404);
  } catch (error) {
    const { status, body } = error instanceof z.ZodError
      ? { status: 400, body: { error: path === "analyze" && error.issues[0]?.code === "custom"
        ? "Write a little more so there is enough context." : "Please check your input." } }
      : vocabularyFailure(path, error);
    // Structured operational logs contain no writing, answers, credentials or personal identifiers.
    console.error(
      JSON.stringify({
        event: "api_error",
        route: path,
        status,
        durationMs: Date.now() - started,
        errorType: error instanceof Error ? error.name : "unknown",
      }),
    );
    return json(body, status);
  }
}
export const GET = handle;
export const POST = handle;
