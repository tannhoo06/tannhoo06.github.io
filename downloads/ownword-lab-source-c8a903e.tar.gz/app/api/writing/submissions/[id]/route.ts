import { writingServices } from "@/lib/server/composition";
import { createWritingApi } from "@/lib/server/writing-api";

export const dynamic = "force-dynamic";
const writingApi = createWritingApi(writingServices);
export const GET = writingApi.submission;
