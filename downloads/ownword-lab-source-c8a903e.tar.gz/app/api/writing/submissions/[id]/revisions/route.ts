import { writingServices } from "@/lib/server/composition";
import { createWritingApi } from "@/lib/server/writing-api";

export const dynamic = "force-dynamic";
export const GET = createWritingApi(writingServices).revisions;
