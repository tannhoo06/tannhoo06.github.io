import { writingServices } from "@/lib/server/composition";
import { createWritingApi } from "@/lib/server/writing-api";

export const dynamic = "force-dynamic";
const api = createWritingApi(writingServices);
export const GET = api.revisionCheck;
export const POST = api.checkRevision;
