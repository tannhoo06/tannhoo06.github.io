import { LegalPage } from "@/components/legal-page";
import { pageMetadata } from "@/app/localized-metadata";

export const generateMetadata = pageMetadata("privacy");

export default function PrivacyPage() {
  return <LegalPage kind="privacy" />;
}
