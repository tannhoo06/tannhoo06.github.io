import { redirect } from "next/navigation";
import { safeReturnTo } from "@/lib/auth/cognito";
import { AccountScreen } from "./screen";
import { pageMetadata } from "@/app/localized-metadata";

export const generateMetadata = pageMetadata("account");

export default async function AccountPage({ searchParams }: {
  searchParams: Promise<{ mode?: string; return_to?: string }>;
}) {
  const params = await searchParams;
  const returnTo = safeReturnTo(params.return_to ?? null);
  if (process.env.AUTH_PROVIDER !== "cognito" || process.env.CUSTOM_AUTH_ENABLED !== "true")
    redirect(`/auth/signin?return_to=${encodeURIComponent(returnTo)}`);
  const mode = params.mode === "register" ? "register" : params.mode === "forgot" ? "forgot" : "signin";
  return <AccountScreen key={mode} initialMode={mode} returnTo={returnTo} googleEnabled={process.env.GOOGLE_SIGN_IN_ENABLED === "true"} />;
}
