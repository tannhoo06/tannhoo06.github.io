// Lucian UX/UI Prompt #382 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#382
"use client";

import { useEffect, useId, useRef } from "react";

const words = "tenacious  ·  resilient  ·  diligent  ·  industrious  ·  persevering  ·  ";
const repeats = 6;

export function AccountWordWave() {
  const pathId = useId().replaceAll(":", "");
  const root = useRef<HTMLDivElement>(null);
  const svg = useRef<SVGSVGElement>(null);
  const line = useRef<SVGPathElement>(null);
  const fill = useRef<SVGPathElement>(null);
  const text = useRef<SVGTextElement>(null);
  const textPath = useRef<SVGTextPathElement>(null);

  useEffect(() => {
    const element = root.current;
    if (!element || !svg.current || !line.current || !fill.current || !text.current || !textPath.current) return;
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    let reduceMotion = media.matches;
    let width = element.clientWidth;
    let phase = 0;
    let offset = 0;
    let unit = 0;
    let last = 0;
    let frame = 0;

    const resize = () => {
      width = element.clientWidth;
      svg.current?.setAttribute("viewBox", `0 0 ${width} 150`);
      if (reduceMotion) draw(performance.now());
    };
    const draw = (now: number) => {
      if (!element.isConnected) return;
      const dt = Math.max(0, Math.min(50, now - (last || now))) / 1000;
      last = now;
      phase += dt * 0.8;
      const points: string[] = [];
      for (let x = -60; x <= width + 80; x += 8) {
        const y = 90 + 6 * Math.sin(x / 100 + phase) + 1.5 * Math.sin(x / 46 - phase * 1.4);
        points.push(`${x.toFixed(1)} ${y.toFixed(1)}`);
      }
      const d = `M${points.join(" L")}`;
      line.current?.setAttribute("d", d);
      fill.current?.setAttribute("d", `${d} L${width + 80} 150 L-60 150 Z`);
      if (!unit) {
        try { unit = (text.current?.getComputedTextLength() ?? 0) / repeats; }
        catch { unit = 300; }
      }
      offset = (offset + dt * 30) % (unit || 300);
      textPath.current?.setAttribute("startOffset", (-offset).toFixed(1));
      if (!reduceMotion) frame = window.requestAnimationFrame(draw);
    };
    const changeMotion = () => {
      reduceMotion = media.matches;
      window.cancelAnimationFrame(frame);
      last = 0;
      frame = window.requestAnimationFrame(draw);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(element);
    media.addEventListener("change", changeMotion);
    resize();
    frame = window.requestAnimationFrame(draw);
    return () => {
      window.cancelAnimationFrame(frame);
      observer.disconnect();
      media.removeEventListener("change", changeMotion);
    };
  }, []);

  return <div ref={root} className="account-word-wave u382" aria-hidden="true">
    <div className="u382-sea">
      <svg ref={svg} viewBox="0 0 340 150" aria-hidden="true">
        <path ref={fill} className="u382-fill" />
        <path ref={line} id={pathId} className="u382-ln" />
        <text ref={text} className="u382-tx"><textPath ref={textPath} href={`#${pathId}`}>{words.repeat(repeats)}</textPath></text>
      </svg>
    </div>
  </div>;
}
