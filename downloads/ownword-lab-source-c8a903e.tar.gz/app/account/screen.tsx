// Lucian UX/UI Prompt #062 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#062
// Lucian UX/UI Prompt #066 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#066
"use client";

import { useEffect, useState, type CSSProperties, type FormEvent } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowLeft, Check, Eye, EyeOff } from "lucide-react";
import { useI18n } from "@/components/language-provider";
import { AccountColourfulText } from "./colourful-text";
import { AccountWordWave } from "./word-wave";
import "./account.css";

type Mode = "signin" | "register" | "confirm" | "forgot" | "reset" | "challenge";
type Challenge = { challengeName: string; session: string; username: string };
type Reply = { status?: string; error?: string; returnTo?: string; challengeName?: string; session?: string; username?: string };
const REMEMBERED_EMAIL_KEY = "ownword-remembered-email";

export function AccountScreen({ initialMode, returnTo, googleEnabled }: {
  initialMode: "signin" | "register" | "forgot";
  returnTo: string;
  googleEnabled: boolean;
}) {
  const { locale } = useI18n();
  const copy = (vi: string, en: string) => locale === "vi" ? vi : en;
  const [mode, setMode] = useState<Mode>(initialMode);
  const [email, setEmail] = useState("");
  const [rememberEmail, setRememberEmail] = useState(false);
  const [rememberReady, setRememberReady] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [code, setCode] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [capsLock, setCapsLock] = useState(false);
  const [busy, setBusy] = useState(false);
  const [googleBusy, setGoogleBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  const [shake, setShake] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [challenge, setChallenge] = useState<Challenge | null>(null);

  useEffect(() => {
    let active = true;
    queueMicrotask(() => {
      if (!active) return;
      try {
        const saved = window.localStorage.getItem(REMEMBERED_EMAIL_KEY);
        if (saved) {
          setEmail(saved);
          setRememberEmail(true);
        }
      } catch { /* Storage may be unavailable in private browsing. */ }
      setRememberReady(true);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!rememberReady) return;
    try {
      if (rememberEmail && email.trim()) window.localStorage.setItem(REMEMBERED_EMAIL_KEY, email.trim());
      else window.localStorage.removeItem(REMEMBERED_EMAIL_KEY);
    } catch { /* The form remains usable without local storage. */ }
  }, [email, rememberEmail, rememberReady]);

  const accountHref = (next: string) => `/account?mode=${next}&return_to=${encodeURIComponent(returnTo)}`;
  const googleHref = `/auth/signin?provider=Google&return_to=${encodeURIComponent(returnTo)}`;
  const hostedHref = `/auth/signin?hosted=1&return_to=${encodeURIComponent(returnTo)}`;
  const switchMode = (next: Mode) => {
    setMode(next);
    setError("");
    setNotice("");
    setPassword("");
    setConfirmPassword("");
    setCode("");
    setChallenge(null);
  };
  const title = mode === "register" ? copy("Tạo tài khoản", "Create an account")
    : mode === "confirm" ? copy("Xác nhận email", "Verify your email")
    : mode === "forgot" ? copy("Quên mật khẩu?", "Forgot your password?")
    : mode === "reset" ? copy("Đặt mật khẩu mới", "Set a new password")
    : mode === "challenge" ? copy("Thêm một bước nữa", "One more step")
    : copy("Chào mừng trở lại", "Welcome back");
  const subtitle = mode === "register" ? copy("Bắt đầu lưu và luyện những từ của riêng bạn.", "Start saving and practicing your own words.")
    : mode === "confirm" ? copy("Nhập mã được gửi đến email của bạn.", "Enter the code sent to your email.")
    : mode === "forgot" ? copy("Chúng tôi sẽ gửi mã đặt lại đến email của bạn.", "We'll send a reset code to your email.")
    : mode === "reset" ? copy("Nhập mã và chọn mật khẩu mới.", "Enter the code and choose a new password.")
    : mode === "challenge" ? copy("Hoàn tất bước xác minh để đăng nhập.", "Complete verification to sign in.")
    : copy("Tiếp tục hành trình học từ của bạn.", "Continue your word learning journey.");
  const submitLabel = mode === "register" ? copy("Tạo tài khoản", "Create account")
    : mode === "confirm" ? copy("Xác nhận", "Verify email")
    : mode === "forgot" ? copy("Gửi mã", "Send code")
    : mode === "reset" ? copy("Đặt lại mật khẩu", "Reset password")
    : mode === "challenge" ? copy("Tiếp tục", "Continue")
    : copy("Đăng nhập", "Sign in");

  const message = (key: string) => ({
    invalidCredentials: copy("Email hoặc mật khẩu chưa đúng.", "Email or password is incorrect."),
    invalidCode: copy("Mã chưa đúng. Hãy thử lại.", "That code is incorrect. Try again."),
    expiredCode: copy("Mã đã hết hạn. Hãy yêu cầu mã mới.", "That code expired. Request a new one."),
    passwordPolicy: copy("Mật khẩu chưa đáp ứng yêu cầu của tài khoản.", "Password does not meet the account requirements."),
    accountExists: copy("Email này đã có tài khoản. Hãy đăng nhập.", "This email already has an account. Sign in instead."),
    tooManyAttempts: copy("Có quá nhiều lần thử. Hãy chờ một chút.", "Too many attempts. Please wait a little."),
    confirmAccount: copy("Bạn cần xác nhận email trước khi đăng nhập.", "Verify your email before signing in."),
    passwordAuthUnavailable: copy("Đăng nhập bằng mật khẩu chưa sẵn sàng. Hãy dùng trang đăng nhập dự phòng.", "Password sign-in is not ready. Use the backup sign-in page."),
    unsupportedChallenge: copy("Tài khoản này cần một bước xác minh khác. Hãy dùng trang đăng nhập dự phòng.", "This account needs another verification step. Use the backup sign-in page."),
    serviceUnavailable: copy("Không thể kết nối lúc này. Hãy thử lại.", "Could not connect right now. Please try again."),
    invalidRequest: copy("Không thể hoàn tất yêu cầu. Hãy kiểm tra và thử lại.", "Could not complete the request. Check your details and try again."),
  } as Record<string, string>)[key] ?? copy("Hãy thử lại.", "Please try again.");

  async function submit(action: string, extra: Record<string, string> = {}) {
    const response = await fetch("/api/auth/account", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, email, password, code, returnTo, ...extra }),
      credentials: "same-origin",
      cache: "no-store",
    });
    return await response.json() as Reply;
  }

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    if ((mode === "register" || mode === "reset" || (mode === "challenge" && challenge?.challengeName === "NEW_PASSWORD_REQUIRED")) && password !== confirmPassword) {
      setError(copy("Hai mật khẩu chưa khớp.", "Passwords do not match."));
      setShake(true);
      return;
    }
    setError("");
    setNotice("");
    setShake(false);
    setBusy(true);
    try {
      const action = mode === "register" ? "signUp" : mode === "signin" ? "signIn" : mode === "confirm" ? "confirm" : mode === "forgot" ? "forgot" : mode === "reset" ? "reset" : "challenge";
      const reply = await submit(action, mode === "challenge" && challenge ? { ...challenge } : {});
      if (reply.error) {
        setError(message(reply.error));
        setShake(true);
        if (reply.error === "confirmAccount") setMode("confirm");
        return;
      }
      if (reply.status === "signedIn") {
        setSuccess(true);
        window.setTimeout(() => window.location.assign(reply.returnTo ?? returnTo), 450);
      } else if (reply.status === "challenge" && reply.challengeName && reply.session && reply.username) {
        setChallenge({ challengeName: reply.challengeName, session: reply.session, username: reply.username });
        setCode("");
        setPassword("");
        setMode("challenge");
      } else if (reply.status === "confirm") {
        setPassword("");
        setConfirmPassword("");
        setCode("");
        setMode("confirm");
        setNotice(copy("Mã xác nhận đã được gửi đến email của bạn.", "We sent a verification code to your email."));
      } else if (reply.status === "confirmed" || reply.status === "reset") {
        setMode("signin");
        setCode("");
        setPassword("");
        setNotice(reply.status === "confirmed" ? copy("Email đã được xác nhận. Giờ bạn có thể đăng nhập.", "Email verified. You can sign in now.") : copy("Mật khẩu đã được đặt lại. Giờ bạn có thể đăng nhập.", "Password reset. You can sign in now."));
      } else if (reply.status === "sent") {
        setCode("");
        setMode("reset");
        setNotice(copy("Nếu email có tài khoản, mã đặt lại đã được gửi.", "If the email has an account, a reset code has been sent."));
      }
    } catch {
      setError(message("serviceUnavailable"));
      setShake(true);
    } finally {
      setBusy(false);
    }
  }

  async function resend() {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const reply = await submit("resend");
      if (reply.error) setError(message(reply.error));
      else setNotice(copy("Mã mới đã được gửi.", "A new code has been sent."));
    } catch { setError(message("serviceUnavailable")); }
    finally { setBusy(false); }
  }

  return <main className="account-page ux">
    <Link className="account-home" href="/" aria-label={copy("Về trang chủ Ownword", "Ownword home")}><ArrowLeft size={17} /> <span>ownword<span className="account-dot">.</span></span></Link>
    <div className="account-layout">
      <div className="account-intro">
        <span className="account-eyebrow">{copy("TỪ VỰNG THEO CÁCH CỦA BẠN", "WORDS, YOUR WAY")}</span>
        <h1 className="account-headline">
          <span className="account-headline-before">
            {copy("từ bạn gặp", "words you notice")}
            <svg viewBox="0 0 420 32" preserveAspectRatio="none" aria-hidden="true">
              <path d="M4 25 C 58 14, 106 25, 157 17 S 258 22, 314 13 S 385 19, 416 9" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
            </svg>
          </span>
          <span className="account-headline-after"><AccountColourfulText text={copy("từ bạn dùng", "words you use")} locale={locale} /></span>
        </h1>
        <p>{copy("Lưu những từ bạn bắt gặp, luyện tập trong ngữ cảnh, và biến chúng thành vốn từ bạn thật sự dùng được.", "Save the words you encounter, practice them in context, and make them part of the vocabulary you actually use.")}</p>
      </div>
      <div className="account-forms">
        <section className={`u062 account-card${shake ? " shake" : ""}`} onAnimationEnd={() => setShake(false)} aria-label={title}>
          <form className="u062-pane u062-login" onSubmit={onSubmit}>
            <span className="u062-logo" aria-hidden="true"><Image src="/images/ownword-brand.svg" width={44} height={44} alt="" unoptimized /></span>
            <h2>{title}</h2>
            <p>{subtitle}</p>
            {notice && <div className="account-notice" role="status">{notice}</div>}
            {mode !== "challenge" && <div className="u062-f"><label htmlFor="account-email">{copy("Email", "Email")}</label><div className="u062-box"><input id="account-email" type="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="you@example.com" autoComplete="username" required disabled={busy} /></div></div>}
            {(mode === "confirm" || mode === "reset" || (mode === "challenge" && challenge?.challengeName !== "NEW_PASSWORD_REQUIRED")) && <div className="u062-f"><label htmlFor="account-code">{copy("Mã xác nhận", "Verification code")}</label><div className="u062-box"><input id="account-code" type="text" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={event => setCode(event.target.value)} required disabled={busy} /></div></div>}
            {(mode === "signin" || mode === "register" || mode === "reset" || (mode === "challenge" && challenge?.challengeName === "NEW_PASSWORD_REQUIRED")) && <div className={`u062-f u062-pw${error ? " bad" : ""}`}>
              <label htmlFor="account-password">{mode === "challenge" ? copy("Mật khẩu mới", "New password") : copy("Mật khẩu", "Password")}</label>
              <span className={`u062-caps${capsLock ? " on" : ""}`} aria-live="polite">{copy("Caps Lock đang bật", "Caps Lock is on")}</span>
              <div className="u062-box"><input id="account-password" type={showPassword ? "text" : "password"} value={password} onChange={event => setPassword(event.target.value)} onKeyUp={event => setCapsLock(event.getModifierState("CapsLock"))} autoComplete={mode === "signin" ? "current-password" : "new-password"} required disabled={busy} aria-invalid={!!error} /><button className="u062-eye" type="button" aria-pressed={showPassword} aria-label={showPassword ? copy("Ẩn mật khẩu", "Hide password") : copy("Hiện mật khẩu", "Show password")} onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={20} /> : <Eye size={20} />}</button></div>
            </div>}
            {(mode === "register" || mode === "reset" || (mode === "challenge" && challenge?.challengeName === "NEW_PASSWORD_REQUIRED")) && <div className="u062-f"><label htmlFor="account-password-confirm">{copy("Nhập lại mật khẩu", "Confirm password")}</label><div className="u062-box"><input id="account-password-confirm" type={showPassword ? "text" : "password"} value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)} autoComplete="new-password" required disabled={busy} /></div></div>}
            {mode === "signin" && <div className="u062-row">
              <label className="account-remember" htmlFor="account-remember-email"><input id="account-remember-email" type="checkbox" checked={rememberEmail} aria-describedby="account-remember-note" onChange={event => setRememberEmail(event.target.checked)} /><span>{copy("Ghi nhớ tôi", "Remember me")}</span></label>
              <span id="account-remember-note" className="sr-only">{copy("Chỉ lưu email trên thiết bị này", "Only saves your email on this device")}</span>
              <a href={accountHref("forgot")}>{copy("Quên mật khẩu?", "Forgot password?")}</a>
            </div>}
            {error && <div className="account-error" role="alert">{error}{(error.includes("dự phòng") || error.includes("backup")) && <> <a href={hostedHref}>{copy("Mở trang dự phòng", "Open backup sign-in")}</a></>}</div>}
            <button className={`u062-go${busy ? " busy" : ""}${success ? " ok" : ""}`} type="submit" disabled={busy || success} aria-label={busy ? copy("Đang xử lý", "Working") : undefined}><span>{submitLabel}</span><i aria-hidden="true" /><Check size={26} aria-hidden="true" /></button>
            {googleEnabled && (mode === "signin" || mode === "register") && <div className="u066 account-google">
              <div className="u066-or">{copy("hoặc đăng nhập với", "or sign in with")}</div>
              <div className="u066-list"><div className="u066-it"><div><button type="button" className={`u066-b${googleBusy ? " busy" : ""}`} style={{ "--bg": "var(--ux-surface)", "--fg": "var(--ux-ink)", "--bd": "inset 0 0 0 1.5px var(--ux-line-2)" } as CSSProperties} aria-label={copy("Đăng nhập với Google", "Sign in with Google")} aria-busy={googleBusy} disabled={googleBusy} onClick={() => { setGoogleBusy(true); window.setTimeout(() => window.location.replace(googleHref), 250); }}><span className="u066-ic" aria-hidden="true"><GoogleIcon /></span><span className="u066-tx">Google</span><span className="u066-st" aria-hidden="true"><i /></span></button></div></div></div>
            </div>}
            {mode === "signin" ? <p className="account-switch">{copy("Chưa có tài khoản?", "New to Ownword?")} <Link href={accountHref("register")} onClick={() => switchMode("register")}>{copy("Tạo tài khoản", "Create an account")}</Link></p> : mode === "register" ? <p className="account-switch">{copy("Đã có tài khoản?", "Already have an account?")} <Link href={accountHref("signin")} onClick={() => switchMode("signin")}>{copy("Đăng nhập", "Sign in")}</Link></p> : <div className="account-switch"><Link href={accountHref("signin")} onClick={() => switchMode("signin")}>{copy("Quay lại đăng nhập", "Back to sign in")}</Link>{mode === "confirm" && <button type="button" onClick={resend} disabled={busy}>{copy("Gửi lại mã", "Resend code")}</button>}</div>}
          </form>
        </section>

      </div>
    </div>
    <AccountWordWave />
  </main>;
}

function GoogleIcon() {
  return <svg viewBox="0 0 24 24"><path d="M21.6 12.2c0-.7-.1-1.3-.2-1.9H12v3.7h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3z" fill="#4285F4"/><path d="M12 22c2.7 0 5-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.8-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22z" fill="#34A853"/><path d="M6.4 14c-.2-.6-.3-1.3-.3-2s.1-1.4.3-2V7.4H3.1A10 10 0 0 0 2 12c0 1.6.4 3.1 1.1 4.6z" fill="#FBBC05"/><path d="M12 6c1.5 0 2.8.5 3.8 1.5l2.9-2.9A10 10 0 0 0 3.1 7.4L6.4 10C7.2 7.7 9.4 6 12 6z" fill="#EA4335"/></svg>;
}
