// Adapted from Aceternity UI Colourful Text: https://ui.aceternity.com/components/colourful-text
"use client";

import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import { motion } from "motion/react";
import type { Locale } from "@/lib/i18n/messages";

const colors = [
  "#087bc7", "#d63b78", "#8b4de5", "#007f8f", "#d84a45",
  "#9b43d0", "#1585c6", "#ba3fae", "#007f74", "#db4563",
];

function subscribeReducedMotion(onChange: () => void) {
  const media = window.matchMedia("(prefers-reduced-motion: reduce)");
  media.addEventListener("change", onChange);
  return () => media.removeEventListener("change", onChange);
}

function getReducedMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function AccountColourfulText({ text, locale }: { text: string; locale: Locale }) {
  const reduceMotion = useSyncExternalStore(subscribeReducedMotion, getReducedMotion, () => false);
  const [cycle, setCycle] = useState(0);
  const letters = useMemo(
    () => Array.from(new Intl.Segmenter(locale, { granularity: "grapheme" }).segment(text), ({ segment }) => segment),
    [locale, text],
  );

  useEffect(() => {
    if (reduceMotion) return;
    const interval = window.setInterval(() => setCycle((value) => value + 1), 5000);
    return () => window.clearInterval(interval);
  }, [reduceMotion]);

  if (reduceMotion) return <span className="account-colourful-text">{text}</span>;

  return <span className="account-colourful-text" role="text" aria-label={text}>
    {letters.map((letter, index) => <motion.span
      key={`${cycle}-${index}`}
      aria-hidden="true"
      initial={{ y: 0 }}
      animate={{
        color: colors[(index + cycle * 3) % colors.length],
        y: [0, -3, 0],
        scale: [1, 1.01, 1],
        filter: ["blur(0px)", "blur(5px)", "blur(0px)"],
        opacity: [1, 0.8, 1],
      }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
    >{letter}</motion.span>)}
  </span>;
}
