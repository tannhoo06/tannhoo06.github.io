# Ownword Lightsail pilot

The 2–3 user pilot runs the Next.js app and PostgreSQL on one 2 GB Lightsail Linux instance in `ap-southeast-1`. Caddy terminates HTTPS. Cognito handles new user accounts, and OpenRouter serves Gemini. The database starts empty; the Sites/D1 accounts and data are not transferred.

The public IPv4 bundle is currently listed at $12/month, including 60 GB disk and 3 TB transfer. Two months of instance time are about $24. Snapshots cost $0.05/GB-month; 20 GB of billed snapshot storage adds about $1/month. OpenRouter and any domain purchase are separate. Confirm current pricing and credit expiry before provisioning. No load balancer, RDS database, or NAT gateway is part of this deployment. If memory pressure persists after launch, resize to 4 GB at $24/month.

## Before provisioning

1. Sign in to AWS CLI v2 and check `aws sts get-caller-identity`. If local `aws login` fails with `TOKEN_EXPIRED`, use Singapore AWS CloudShell, which is pre-authenticated through the Console. The original pilot was provisioned using CloudShell.
2. For this pilot, use a temporary `ownword.<static-ip>.sslip.io` hostname after attaching the static IPv4. For example, IP `203.0.113.10` gives `ownword.203.0.113.10.sslip.io`. `sslip.io` resolves the embedded IP and Caddy obtains a certificate for that hostname; this relies on third-party DNS. `ownword.com` is listed for resale as a premium domain and is not assumed here. A domain you control can replace the temporary name later, but its DNS record, `APP_DOMAIN`, and Cognito callback/sign-out URLs must all change together.
3. Create a 2 GB Lightsail Ubuntu 24.04 instance in Singapore, attach a static IPv4, and permit TCP 80 and 443. Limit SSH access to your own IP. Do not publish PostgreSQL port 5432. Set `APP_DOMAIN` in `.env` to the temporary hostname from step 2.
4. Run `bash deploy/lightsail/bootstrap-ubuntu.sh` on the instance to add a 2 GB swap file, apply Ubuntu updates, and install Docker Engine and Compose from the [official Docker repository](https://docs.docker.com/engine/install/ubuntu/). Sign out of SSH and reconnect so the `ubuntu` user's Docker group membership takes effect. Enable automatic instance snapshots after deployment. Keep enough credit for the rest of the trial.
5. Create a Cognito user pool with public email self-registration and verification. The Lite feature plan with Hosted UI (classic) and the default Essentials plan with managed login both support this pilot; a pool already created with Essentials can be kept. Create a public app client without a secret (the Single-page application preset); the Traditional web application preset creates a client secret and does not work with this pilot's token exchange. Enable authorization-code grant and PKCE with `openid`, `email`, and `profile` scopes. Register `https://<domain>/auth/callback` as a callback URL and `https://<domain>/` as a sign-out URL. Set up a Cognito prefix domain. The Cognito region may differ from the Lightsail region; use the pool's actual region in `COGNITO_ISSUER` and `COGNITO_DOMAIN`. Google federation is optional; leave `GOOGLE_SIGN_IN_ENABLED=false` until its identity provider and OAuth client are configured.

The bootstrap script is safe to rerun if the swap file and Docker repository already exist.

## Deploy from the instance

Copy the reviewed source to the instance. For a private repository, use an authenticated clone or transfer a Git archive over SSH; do not place a personal GitHub token on the server. Then create the server-only configuration:

```bash
cd ownword
cp deploy/lightsail/.env.example deploy/lightsail/.env
chmod 600 deploy/lightsail/.env
```

Fill in `APP_DOMAIN`, the Cognito values, a unique PostgreSQL password, and the OpenRouter key. Do not commit `.env`. The shared vocabulary AI budget defaults to 1,000 calls per day across the site and 30 per account. The daily feature limits are 20 idea searches, 10 vocabulary suggestions from writing, and 8 essay assessments per account. The app uses the configured HTTPS origin for Cognito redirects, so the reverse proxy's internal HTTP address is never sent to Cognito.

Run:

```bash
bash deploy/lightsail/deploy.sh
curl -fsSI "https://<domain>/"
```

`deploy.sh` checks the Compose configuration, builds the image, starts PostgreSQL, applies the committed PostgreSQL migrations, then starts the app and Caddy. The database is reachable only on the private Compose network. Check the home page, native Cognito sign-in, writing, discovery, practice, and WordBoard. Enable and test Google sign-in separately if required.

## Backups and updates

The daily 23:00 UTC cron runs `bash deploy/lightsail/backup-postgres.sh` before the 00:00 UTC Lightsail snapshot window. It writes a PostgreSQL custom-format dump to `deploy/lightsail/backups/`, verifies it, uploads it to the private S3 bucket configured in `.secrets/backup.env`, and verifies the remote size. Only after successful upload does it prune local dumps older than 14 days. S3 lifecycle retains current daily dumps for 30 days and noncurrent versions for 7 days. Run `verify-restore.sh [dump-file]` to restore into a disposable database without replacing production data. An hourly cron runs `backup-health.sh`; a zero or missing `BackupFresh` metric triggers the CloudWatch alarm and SNS operator email. See [SYSTEM_ARCHITECTURE.md](../../docs/SYSTEM_ARCHITECTURE.md) for the deployed resource names and [CLEANUP.md](../../CLEANUP.md) for retirement.

Manual words are saved after the existing spelling check, then their definitions are generated on the server after the response. `deploy.sh` also installs a once-per-minute worker cron that picks up unfinished words, including older blank entries and interrupted requests. The worker retries failures with backoff and uses the existing global and per-user model-call budgets. WordBoard displays a pending message until the definition arrives; practice skips pending words. Inspect worker failures with `journalctl -t ownword-word-enrichment` on the VM.

For an update, pull the reviewed commit and rerun `bash deploy/lightsail/deploy.sh`. Test the database migration against a backup before applying future schema changes. To roll back application code, check out the previous reviewed commit and redeploy it; database migrations need their own restore or forward fix.

For a manual dump restore on a fresh pilot database, stop the app, then use `pg_restore` with `--clean --if-exists` against the fresh database. Verify the writing and practice history before reopening traffic. Restoring over a live database replaces data, so keep the app stopped and retain a separate snapshot first.

## Current status

The Node production build and TypeScript check pass locally. The Lightsail instance, static IP, restricted SSH firewall, and automatic snapshot add-on are provisioned. Ubuntu and Docker are bootstrapped; the application and migrations run, and the public HTTPS home page returned 200. The pilot owner confirmed sign-up and learning flows. A new S3 dump was downloaded and restored into a disposable database with real learner data. CloudWatch reported a successful alarm action and the owner received its SNS email. The reminder SNS topic has no subscribers or sending job. The old `infra/` CDK stack provisions Fargate/RDS and must not be run for this pilot.
