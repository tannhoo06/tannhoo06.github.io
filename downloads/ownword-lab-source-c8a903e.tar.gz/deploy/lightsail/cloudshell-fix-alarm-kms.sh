#!/usr/bin/env bash
set -euo pipefail

# Run in Singapore CloudShell after the operator alarm's AWS-managed SNS key
# prevents CloudWatch from publishing. A customer-managed KMS key costs extra.
export AWS_PAGER=""
region=ap-southeast-1
account=378600556289
topic="arn:aws:sns:$region:$account:ownword-pilot-operator-alerts"
alarm="arn:aws:cloudwatch:$region:$account:alarm:ownword-pilot-backup-stale"
alias_name=alias/ownword-pilot-operator-alerts
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT

[[ "$(aws sts get-caller-identity --query Account --output text)" == "$account" ]] || {
  echo 'Wrong AWS account.' >&2
  exit 1
}
aws sns get-topic-attributes --topic-arn "$topic" --region "$region" >/dev/null
if aws kms describe-key --key-id "$alias_name" --region "$region" >/dev/null 2>&1; then
  echo "KMS alias $alias_name exists; stop to review it." >&2
  exit 1
fi

cat >"$work/key-policy.json" <<JSON
{"Version":"2012-10-17","Id":"ownword-operator-alert-key","Statement":[
  {"Sid":"EnableAccountAdministration","Effect":"Allow","Principal":{"AWS":"arn:aws:iam::$account:root"},"Action":"kms:*","Resource":"*"},
  {"Sid":"AllowOwnwordCloudWatchAlarm","Effect":"Allow","Principal":{"Service":"cloudwatch.amazonaws.com"},"Action":["kms:GenerateDataKey*","kms:Decrypt"],"Resource":"*","Condition":{"StringEquals":{"aws:SourceAccount":"$account"},"ArnEquals":{"aws:SourceArn":"$alarm"}}},
  {"Sid":"AllowSNSForOwnwordOperatorTopic","Effect":"Allow","Principal":{"Service":"sns.amazonaws.com"},"Action":["kms:GenerateDataKey*","kms:Decrypt"],"Resource":"*","Condition":{"StringEquals":{"kms:EncryptionContext:aws:sns:topicArn":"$topic"}}}
]}
JSON
python3 -m json.tool "$work/key-policy.json" >/dev/null
key_arn="$(aws kms create-key --region "$region" \
  --description 'Ownword pilot CloudWatch alarm to encrypted SNS topic' \
  --policy "file://$work/key-policy.json" \
  --tags TagKey=Project,TagValue=Ownword TagKey=Environment,TagValue=Pilot \
  --query KeyMetadata.Arn --output text)"
aws kms create-alias --alias-name "$alias_name" --target-key-id "$key_arn" --region "$region"
aws sns set-topic-attributes --topic-arn "$topic" --region "$region" \
  --attribute-name KmsMasterKeyId --attribute-value "$key_arn"
configured="$(aws sns get-topic-attributes --topic-arn "$topic" --region "$region" \
  --query Attributes.KmsMasterKeyId --output text)"
[[ "$configured" == "$key_arn" ]] || { echo 'SNS KMS key verification failed.' >&2; exit 1; }
echo "Encrypted operator topic now uses customer-managed key $key_arn"
echo 'Retest the CloudWatch alarm action; the learner reminder topic remains on alias/aws/sns.'
