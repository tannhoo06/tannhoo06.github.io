#!/usr/bin/env bash
set -euo pipefail

# Run in Singapore CloudShell after the VM publishes BackupFresh and the
# operator email subscription is confirmed.
export AWS_PAGER=""
region=ap-southeast-1
account=378600556289
alarm=ownword-pilot-backup-stale
topic="arn:aws:sns:$region:$account:ownword-pilot-operator-alerts"

[[ "$(aws sts get-caller-identity --query Account --output text)" == "$account" ]] || {
  echo "Wrong AWS account." >&2
  exit 1
}

aws sns get-topic-attributes --topic-arn "$topic" --region "$region" >/dev/null
subscriptions="$(aws sns list-subscriptions-by-topic --topic-arn "$topic" --region "$region" --output json)"
python3 -c 'import json,sys; s=json.load(sys.stdin)["Subscriptions"]; assert any(x["Protocol"] == "email" and x["SubscriptionArn"].startswith("arn:") for x in s), "Confirm the SNS operator email subscription first"' <<<"$subscriptions"

existing="$(aws cloudwatch describe-alarms --alarm-names "$alarm" --region "$region" \
  --query 'length(MetricAlarms)' --output text)"
[[ "$existing" == 0 ]] || { echo "Alarm $alarm already exists; review it before changing." >&2; exit 1; }

aws cloudwatch put-metric-alarm --region "$region" \
  --alarm-name "$alarm" \
  --alarm-description 'Ownword S3 database backup missing, stale, or unreachable' \
  --namespace 'Ownword/Pilot' --metric-name BackupFresh \
  --dimensions Name=Instance,Value=ownword-pilot \
  --statistic Minimum --period 3600 --evaluation-periods 1 \
  --comparison-operator LessThanThreshold --threshold 1 \
  --treat-missing-data breaching --actions-enabled \
  --alarm-actions "$topic"

aws cloudwatch describe-alarms --alarm-names "$alarm" --region "$region" \
  --query 'MetricAlarms[0].[AlarmName,StateValue,TreatMissingData,AlarmActions[0]]' --output table
echo 'Backup alarm created. Run the alarm delivery test only after the operator email is confirmed.'
