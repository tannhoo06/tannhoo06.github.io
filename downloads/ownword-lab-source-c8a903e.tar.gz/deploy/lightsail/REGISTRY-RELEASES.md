# Ownword releases on Lightsail

Push application changes to `release/lightsail` to run the release workflow. GitHub
checks types and the learning rules, builds `Dockerfile.aws`, and publishes the
image to the private `ownword-pilot` ECR repository with an immutable commit tag.
The Lightsail job polls ECR every two minutes and pulls the published digest.

The runner uses short-lived AWS credentials from GitHub OIDC. The VM uses its
existing AWS identity with read-only access to the image repository. The VM owns
the Compose and runtime environment files. GitHub and ECR receive the build source
and image, while database credentials and the RDS CA configuration stay on the VM.

## VM operation

Install `registry-release.sh` under `~/.local/bin/ownword-deploy-release`. The
local `~/.config/ownword-release/settings.sh` sets `OWNWORD_COMPOSE_ARGS` as a Bash
array with every active `--env-file` and `-f` in order. Use the running container's
Compose labels to capture those paths before the first release. The job keeps
those settings when it overrides the image used by the app and migrations.

The job runs the new image's migrations, recreates only the app container, and
checks the home and account routes. On a startup failure it reinstates the prior
image. Schema changes remain in place after application rollback, so releases
need migrations compatible with the preceding app. Failed digests are recorded
under `~/.local/state/ownword-release/` so the job can deploy a later fixed image.

The cron entry uses the marker `# ownword-registry-release`. Its output is in
`journalctl -t ownword-registry-release`. The last successful digest is in
`~/.local/state/ownword-release/active-image`. After reviewing a transient
failure, remove only that digest's `failed-…` file to retry it.
