#!/usr/bin/env bash
set -euo pipefail

# Run in AWS CloudShell in ap-southeast-1. This creates only the two approved
# private buckets; it does not create access keys or alter the Lightsail VM.
export AWS_PAGER=""
region=ap-southeast-1
account=378600556289
backup_bucket=ownword-pilot-backups-378600556289-ap-southeast-1-an
log_bucket=ownword-pilot-access-logs-378600556289-ap-southeast-1-an

actual_account="$(aws sts get-caller-identity --query Account --output text)"
if [[ "$actual_account" != "$account" ]]; then
  echo "Wrong AWS account: expected $account, got $actual_account." >&2
  exit 1
fi

work="$(mktemp -d)"
create_new_bucket() {
  local bucket="$1"
  local error_file="$work/$bucket-head.err"
  if aws s3api head-bucket --bucket "$bucket" --expected-bucket-owner "$account" \
    --region "$region" >/dev/null 2>"$error_file"; then
    echo "Bucket $bucket already exists; stopping before modifying it." >&2
    exit 1
  fi
  if ! grep -Eq '404|Not Found|NoSuchBucket' "$error_file"; then
    cat "$error_file" >&2
    exit 1
  fi
  aws s3api create-bucket --bucket "$bucket" --bucket-namespace account-regional \
    --create-bucket-configuration "LocationConstraint=$region" --region "$region" >/dev/null
  echo "Created $bucket"
}

cat >"$work/encryption.json" <<'JSON'
{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"},"BucketKeyEnabled":true,"BlockedEncryptionTypes":{"EncryptionType":["SSE-C"]}}]}
JSON
cat >"$work/backup-lifecycle.json" <<'JSON'
{"Rules":[{"ID":"ExpireDailyDumpsAfter30Days","Status":"Enabled","Filter":{"Prefix":"daily/"},"Expiration":{"Days":30},"NoncurrentVersionExpiration":{"NoncurrentDays":7}}]}
JSON
cat >"$work/log-lifecycle.json" <<'JSON'
{"Rules":[{"ID":"ExpireAccessLogsAfter30Days","Status":"Enabled","Filter":{"Prefix":"access/"},"Expiration":{"Days":30},"NoncurrentVersionExpiration":{"NoncurrentDays":7}}]}
JSON

create_new_bucket "$log_bucket"
create_new_bucket "$backup_bucket"

for bucket in "$log_bucket" "$backup_bucket"; do
  aws s3api put-bucket-versioning --bucket "$bucket" --region "$region" \
    --versioning-configuration Status=Enabled
  aws s3api put-bucket-encryption --bucket "$bucket" --region "$region" \
    --server-side-encryption-configuration "file://$work/encryption.json"
  aws s3api put-bucket-tagging --bucket "$bucket" --region "$region" \
    --tagging 'TagSet=[{Key=Project,Value=Ownword},{Key=Environment,Value=Pilot}]'
  block="$(aws s3api get-public-access-block --bucket "$bucket" --region "$region" \
    --query 'PublicAccessBlockConfiguration.[BlockPublicAcls,IgnorePublicAcls,BlockPublicPolicy,RestrictPublicBuckets]' \
    --output text)"
  if [[ "$block" != $'True\tTrue\tTrue\tTrue' ]]; then
    echo "Public access block is not fully enabled on $bucket: $block" >&2
    exit 1
  fi
  policy_error="$work/$bucket-policy.err"
  if aws s3api get-bucket-policy --bucket "$bucket" --region "$region" \
    --query Policy --output text >"$work/$bucket-existing-policy.json" 2>"$policy_error"; then
    echo "Existing policy on $bucket saved at $work/$bucket-existing-policy.json; stopping for review." >&2
    exit 1
  fi
  if ! grep -q 'NoSuchBucketPolicy' "$policy_error"; then
    cat "$policy_error" >&2
    exit 1
  fi
done

cat >"$work/log-policy.json" <<JSON
{"Version":"2012-10-17","Statement":[
  {"Sid":"DenyInsecureTransport","Effect":"Deny","Principal":"*","Action":"s3:*","Resource":["arn:aws:s3:::$log_bucket","arn:aws:s3:::$log_bucket/*"],"Condition":{"Bool":{"aws:SecureTransport":"false"}}},
  {"Sid":"AllowBackupAccessLogs","Effect":"Allow","Principal":{"Service":"logging.s3.amazonaws.com"},"Action":"s3:PutObject","Resource":"arn:aws:s3:::$log_bucket/access/*","Condition":{"ArnLike":{"aws:SourceArn":"arn:aws:s3:::$backup_bucket"},"StringEquals":{"aws:SourceAccount":"$account"}}}
]}
JSON
cat >"$work/backup-policy.json" <<JSON
{"Version":"2012-10-17","Statement":[
  {"Sid":"DenyInsecureTransport","Effect":"Deny","Principal":"*","Action":"s3:*","Resource":["arn:aws:s3:::$backup_bucket","arn:aws:s3:::$backup_bucket/*"],"Condition":{"Bool":{"aws:SecureTransport":"false"}}}
]}
JSON
python3 -m json.tool "$work/log-policy.json" >/dev/null
python3 -m json.tool "$work/backup-policy.json" >/dev/null
aws s3api put-bucket-policy --bucket "$log_bucket" --region "$region" \
  --policy "file://$work/log-policy.json"
aws s3api put-bucket-policy --bucket "$backup_bucket" --region "$region" \
  --policy "file://$work/backup-policy.json"
aws s3api put-bucket-lifecycle-configuration --bucket "$log_bucket" --region "$region" \
  --lifecycle-configuration "file://$work/log-lifecycle.json"
aws s3api put-bucket-lifecycle-configuration --bucket "$backup_bucket" --region "$region" \
  --lifecycle-configuration "file://$work/backup-lifecycle.json"
cat >"$work/logging.json" <<JSON
{"LoggingEnabled":{"TargetBucket":"$log_bucket","TargetPrefix":"access/"}}
JSON
aws s3api put-bucket-logging --bucket "$backup_bucket" --region "$region" \
  --bucket-logging-status "file://$work/logging.json"

aws s3api get-bucket-encryption --bucket "$backup_bucket" --region "$region" \
  --query 'ServerSideEncryptionConfiguration.Rules[0].ApplyServerSideEncryptionByDefault.SSEAlgorithm' --output text
aws s3api get-bucket-versioning --bucket "$backup_bucket" --region "$region" \
  --query Status --output text
aws s3api get-bucket-logging --bucket "$backup_bucket" --region "$region" \
  --query 'LoggingEnabled.TargetBucket' --output text
echo "S3 backup bucket ready: $backup_bucket"
echo "Private access-log bucket ready: $log_bucket"
