#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
env_file="$repo_root/deploy/lightsail/.env"
compose_file="$repo_root/deploy/lightsail/compose.yaml"
backup_dir="$repo_root/deploy/lightsail/backups"
backup_env="$repo_root/deploy/lightsail/.secrets/backup.env"

if [[ ! -f "$env_file" ]]; then
  echo "Missing $env_file" >&2
  exit 1
fi

umask 077
mkdir -p "$backup_dir"
if [[ -f "$backup_env" ]]; then
  # This file is outside the Docker build context and may select a private AWS profile.
  chmod 600 "$backup_env"
  # shellcheck disable=SC1090
  source "$backup_env"
fi
backup_file="$backup_dir/ownword-$(date -u +%Y%m%dT%H%M%SZ).dump"
partial_file="$backup_file.partial"
trap 'rm -f "$partial_file"' EXIT
cd "$repo_root"
rds_env="$repo_root/deploy/lightsail/.secrets/rds-backup.env"
if [[ -f "$rds_env" ]]; then
  rds_client=(docker run --rm --network ownword_private
    --env-file "$rds_env" -e PGSSLMODE=verify-full -e PGSSLROOTCERT=/rds-ca.pem
    --mount "type=bind,source=$repo_root/deploy/lightsail/.secrets/rds-ca.pem,target=/rds-ca.pem,readonly"
    postgres:16-alpine)
  "${rds_client[@]}" pg_dump -Fc > "$partial_file"
  docker run --rm -i --network none postgres:16-alpine pg_restore --list < "$partial_file" >/dev/null
else
  docker compose --env-file "$env_file" -f "$compose_file" exec -T db \
    pg_dump -U ownword -d ownword -Fc > "$partial_file"
  docker compose --env-file "$env_file" -f "$compose_file" exec -T db \
    pg_restore --list < "$partial_file" > /dev/null
fi
mv "$partial_file" "$backup_file"
trap - EXIT
echo "Database backup saved to $backup_file"

if [[ -n "${S3_BACKUP_BUCKET:-}" ]]; then
  command -v aws > /dev/null || { echo "AWS CLI is required for off-instance backups." >&2; exit 1; }
  region="${AWS_REGION:-ap-southeast-1}"
  key="daily/$(basename "$backup_file")"
  aws s3api put-object --region "$region" --bucket "$S3_BACKUP_BUCKET" \
    --key "$key" --body "$backup_file" --checksum-algorithm SHA256 \
    --server-side-encryption AES256 > /dev/null
  local_bytes="$(stat -c %s "$backup_file")"
  remote_bytes="$(aws s3api head-object --region "$region" --bucket "$S3_BACKUP_BUCKET" \
    --key "$key" --query ContentLength --output text)"
  if [[ "$remote_bytes" != "$local_bytes" ]]; then
    echo "S3 backup size verification failed for $key." >&2
    exit 1
  fi
  echo "Verified off-instance backup in s3://$S3_BACKUP_BUCKET/$key"
  # Retain local dumps for 14 days only after S3 upload and verification succeed.
  find "$backup_dir" -maxdepth 1 -type f -name 'ownword-*.dump' -mtime +13 -delete
fi
