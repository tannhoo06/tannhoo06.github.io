#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
env_file="$repo_root/deploy/lightsail/.env"
compose_file="$repo_root/deploy/lightsail/compose.yaml"
backup_dir="$repo_root/deploy/lightsail/backups"

if [[ ! -f "$env_file" ]]; then
  echo "Missing $env_file" >&2
  exit 1
fi

backup_file="${1:-$(find "$backup_dir" -maxdepth 1 -type f -name 'ownword-*.dump' -print | sort | tail -n 1)}"
if [[ ! -f "$backup_file" ]]; then
  echo "No PostgreSQL backup found." >&2
  exit 1
fi

cd "$repo_root"
compose=(docker compose --env-file "$env_file" -f "$compose_file")
database="ownword_restore_check_$(date -u +%Y%m%d%H%M%S)_$$"
created=false
cleanup() {
  if [[ "$created" == true ]]; then
    "${compose[@]}" exec -T db dropdb -U ownword --if-exists "$database"
  fi
}
trap cleanup EXIT

"${compose[@]}" exec -T db createdb -U ownword "$database"
created=true
"${compose[@]}" exec -T db pg_restore -U ownword -d "$database" < "$backup_file"
"${compose[@]}" exec -T db psql -U ownword -d "$database" -v ON_ERROR_STOP=1 -At \
  -c "SELECT 'users=' || count(*) FROM app_user" \
  -c "SELECT 'user_words=' || count(*) FROM user_word" \
  -c "SELECT 'practice_sessions=' || count(*) FROM practice_session"
echo "Restored and queried a disposable database from $(basename "$backup_file")."
