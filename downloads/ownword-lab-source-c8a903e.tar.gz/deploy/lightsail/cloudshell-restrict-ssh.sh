#!/usr/bin/env bash
set -euo pipefail

# Keep web ports public. Restrict SSH to the current administrator connection
# and the Lightsail browser SSH service. Run only in Singapore CloudShell.
export AWS_PAGER=""
region=ap-southeast-1
instance=ownword-pilot
admin_ip=146.70.199.232
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT

aws lightsail get-instance-port-states --instance-name "$instance" --region "$region" \
  --output json >"$work/before.json"
python3 - "$work/before.json" "$work/ports.json" "$admin_ip" <<'PY'
import ipaddress, json, sys
source, destination, admin_ip = sys.argv[1:]
ipaddress.IPv4Address(admin_ip)
ports = json.load(open(source))['portStates']
observed = {(p['protocol'], p['fromPort'], p['toPort']) for p in ports}
expected = {('tcp', 22, 22), ('tcp', 80, 80), ('tcp', 443, 443)}
if observed != expected:
    raise SystemExit(f'Unexpected firewall rules {observed}; stopping without changing ports')
proposed = [
    {'fromPort': 22, 'toPort': 22, 'protocol': 'tcp',
     'cidrs': [admin_ip + '/32'], 'cidrListAliases': ['lightsail-connect']},
    {'fromPort': 80, 'toPort': 80, 'protocol': 'tcp',
     'cidrs': ['0.0.0.0/0'], 'ipv6Cidrs': ['::/0']},
    {'fromPort': 443, 'toPort': 443, 'protocol': 'tcp',
     'cidrs': ['0.0.0.0/0']},
]
with open(destination, 'w') as output:
    json.dump(proposed, output)
PY

aws lightsail put-instance-public-ports --instance-name "$instance" --region "$region" \
  --port-infos "file://$work/ports.json" >/dev/null
aws lightsail get-instance-port-states --instance-name "$instance" --region "$region" \
  --query 'portStates[].[fromPort,toPort,cidrs,ipv6Cidrs,cidrListAliases]' --output json
echo 'SSH rule updated. Test SSH before ending CloudShell; it can reopen port 22 if needed.'
