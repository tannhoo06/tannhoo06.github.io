#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
env_file="$repo_root/deploy/lightsail/.env"
compose_file="$repo_root/deploy/lightsail/compose.yaml"

if [[ ! -f "$env_file" ]]; then
  echo "Create $env_file from .env.example and set the deployment values." >&2
  exit 1
fi

if grep -Eq '(^APP_DOMAIN=app\.example\.com$|REPLACE)' "$env_file"; then
  echo "Replace the example domain and placeholder credentials in $env_file." >&2
  exit 1
fi

chmod 600 "$env_file"
cd "$repo_root"
compose=(docker compose --env-file "$env_file" -f "$compose_file")
"${compose[@]}" config --quiet
"${compose[@]}" build app
"${compose[@]}" up -d db
"${compose[@]}" --profile tools run --rm migrate
"${compose[@]}" up -d app web
cron_marker="# ownword-word-enrichment"
cron_line="* * * * * /usr/bin/flock -n /tmp/ownword-word-enrichment.lock /bin/bash '$repo_root/deploy/lightsail/enrich-manual-words.sh' 2>&1 | /usr/bin/logger -t ownword-word-enrichment $cron_marker"
existing_cron="$(crontab -l 2>/dev/null || true)"
if ! grep -Fq "$cron_marker" <<<"$existing_cron"; then
  printf '%s\n%s\n' "$existing_cron" "$cron_line" | crontab -
fi
"${compose[@]}" ps
