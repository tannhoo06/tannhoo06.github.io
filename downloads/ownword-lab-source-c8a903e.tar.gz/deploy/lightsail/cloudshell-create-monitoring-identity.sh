#!/usr/bin/env bash
set -euo pipefail

# Run in AWS CloudShell after cloudshell-create-s3-backups.sh succeeds.
# This creates topics and a scoped IAM user, but no access key or alarm yet.
export AWS_PAGER=""
region=ap-southeast-1
account=378600556289
backup_bucket=ownword-pilot-backups-378600556289-ap-southeast-1-an
operator_topic=ownword-pilot-operator-alerts
reminder_topic=ownword-pilot-learner-reminders
alarm_name=ownword-pilot-backup-stale
iam_user=ownword-pilot-vm
work="$(mktemp -d)"

if [[ "$(aws sts get-caller-identity --query Account --output text)" != "$account" ]]; then
  echo "Wrong AWS account." >&2
  exit 1
fi
aws s3api head-bucket --bucket "$backup_bucket" --expected-bucket-owner "$account" \
  --region "$region" >/dev/null
if aws iam get-user --user-name "$iam_user" >/dev/null 2>&1; then
  echo "IAM user $iam_user already exists; stopping before changing its permissions." >&2
  exit 1
fi

operator_arn="$(aws sns create-topic --name "$operator_topic" --region "$region" \
  --attributes KmsMasterKeyId=alias/aws/sns --query TopicArn --output text)"
reminder_arn="$(aws sns create-topic --name "$reminder_topic" --region "$region" \
  --attributes KmsMasterKeyId=alias/aws/sns --query TopicArn --output text)"
for arn in "$operator_arn" "$reminder_arn"; do
  aws sns set-topic-attributes --topic-arn "$arn" --region "$region" \
    --attribute-name KmsMasterKeyId --attribute-value alias/aws/sns
  encryption="$(aws sns get-topic-attributes --topic-arn "$arn" --region "$region" \
    --query 'Attributes.KmsMasterKeyId' --output text)"
  [[ "$encryption" == alias/aws/sns ]] || { echo "SNS encryption check failed for $arn." >&2; exit 1; }
done

aws sns get-topic-attributes --topic-arn "$operator_arn" --region "$region" \
  --query 'Attributes.Policy' --output text >"$work/operator-policy-original.json"
python3 - "$work/operator-policy-original.json" "$work/operator-policy-updated.json" \
  "$account" "$region" "$operator_arn" "$alarm_name" <<'PY'
import json, sys
source, target, account, region, topic, alarm = sys.argv[1:]
with open(source) as file:
    policy = json.load(file)
sid = 'AllowOwnwordBackupAlarm'
policy['Statement'] = [s for s in policy.get('Statement', []) if s.get('Sid') != sid]
policy['Statement'].append({
    'Sid': sid, 'Effect': 'Allow',
    'Principal': {'Service': 'cloudwatch.amazonaws.com'},
    'Action': 'sns:Publish', 'Resource': topic,
    'Condition': {
        'ArnEquals': {'aws:SourceArn': f'arn:aws:cloudwatch:{region}:{account}:alarm:{alarm}'},
        'StringEquals': {'aws:SourceAccount': account},
    },
})
with open(target, 'w') as file:
    json.dump(policy, file)
PY
aws sns set-topic-attributes --topic-arn "$operator_arn" --region "$region" \
  --attribute-name Policy --attribute-value "file://$work/operator-policy-updated.json"

aws iam create-user --user-name "$iam_user" \
  --tags Key=Project,Value=Ownword Key=Environment,Value=Pilot >/dev/null
cat >"$work/vm-policy.json" <<JSON
{"Version":"2012-10-17","Statement":[
  {"Sid":"WriteAndVerifyDailyBackups","Effect":"Allow","Action":["s3:PutObject","s3:GetObject"],"Resource":"arn:aws:s3:::$backup_bucket/daily/*"},
  {"Sid":"PublishOwnwordBackupHealth","Effect":"Allow","Action":"cloudwatch:PutMetricData","Resource":"*","Condition":{"StringEquals":{"cloudwatch:namespace":"Ownword/Pilot"}}},
  {"Sid":"PublishLearnerReminders","Effect":"Allow","Action":"sns:Publish","Resource":"$reminder_arn"}
]}
JSON
python3 -m json.tool "$work/vm-policy.json" >/dev/null
aws iam put-user-policy --user-name "$iam_user" --policy-name OwnwordPilotScopedAccess \
  --policy-document "file://$work/vm-policy.json"

read -r -p 'Operator email address for backup alerts: ' operator_email
if [[ ! "$operator_email" =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]]; then
  echo "Invalid email; no subscription was created. Re-run subscription manually." >&2
  exit 1
fi
aws sns subscribe --topic-arn "$operator_arn" --region "$region" \
  --protocol email --notification-endpoint "$operator_email" \
  --return-subscription-arn >/dev/null

echo "S3 backup IAM user created without access keys: $iam_user"
echo "Operator topic: $operator_arn"
echo "Reminder topic (no subscribers yet): $reminder_arn"
echo "Confirm the SNS subscription email before enabling the alarm."
