#!/usr/bin/env bash
set -euo pipefail

if command -v aws >/dev/null 2>&1; then
  aws --version
  exit 0
fi

work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
curl --fail --show-error --silent --location --retry 3 \
  https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip -o "$work/awscliv2.zip"
python3 -m zipfile -e "$work/awscliv2.zip" "$work"
chmod +x "$work/aws/install" "$work/aws/dist/aws" "$work/aws/dist/aws_completer"
sudo "$work/aws/install"
aws --version
