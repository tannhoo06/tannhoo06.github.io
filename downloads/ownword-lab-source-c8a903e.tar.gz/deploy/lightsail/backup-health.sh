#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
backup_dir="$repo_root/deploy/lightsail/backups"
backup_env="$repo_root/deploy/lightsail/.secrets/backup.env"
if [[ ! -f "$backup_env" ]]; then
  echo "Missing private S3 backup configuration." >&2
  exit 1
fi
# shellcheck disable=SC1090
source "$backup_env"
: "${S3_BACKUP_BUCKET:?Set S3_BACKUP_BUCKET in backup.env}"
region="${AWS_REGION:-ap-southeast-1}"
latest="$(find "$backup_dir" -maxdepth 1 -type f -name 'ownword-*.dump' -print | sort | tail -n 1)"
fresh=0
if [[ -n "$latest" && -f "$latest" ]]; then
  age_seconds="$(( $(date -u +%s) - $(stat -c %Y "$latest") ))"
  if (( age_seconds >= 0 && age_seconds <= 26 * 3600 )); then
    key="daily/$(basename "$latest")"
    remote_bytes="$(aws s3api head-object --region "$region" --bucket "$S3_BACKUP_BUCKET" \
      --key "$key" --query ContentLength --output text 2>/dev/null || true)"
    if [[ "$remote_bytes" == "$(stat -c %s "$latest")" ]]; then
      fresh=1
    fi
  fi
fi

aws cloudwatch put-metric-data --region "$region" --namespace 'Ownword/Pilot' \
  --metric-name BackupFresh --unit Count --value "$fresh" \
  --dimensions "Instance=${BACKUP_METRIC_INSTANCE:-ownword-pilot}"
echo "BackupFresh=$fresh"
[[ "$fresh" == 1 ]]
