"""Install the scoped VM IAM key from JSON on stdin without printing it."""

import configparser
import json
import os
import pathlib
import sys
import tempfile

document = json.load(sys.stdin)
key = document.get("AccessKey", document)
if key.get("UserName") != "ownword-pilot-vm" or key.get("Status") != "Active":
    raise SystemExit("Expected an active ownword-pilot-vm access key")
access_id = key["AccessKeyId"]
secret = key["SecretAccessKey"]
if not access_id or not secret or "\n" in access_id + secret:
    raise SystemExit("Invalid access key file")

directory = pathlib.Path.home() / ".aws"
directory.mkdir(mode=0o700, exist_ok=True)
os.chmod(directory, 0o700)
config = configparser.ConfigParser()
config["default"] = {
    "aws_access_key_id": access_id,
    "aws_secret_access_key": secret,
}
with tempfile.NamedTemporaryFile(mode="w", dir=directory, delete=False) as temporary:
    os.chmod(temporary.name, 0o600)
    config.write(temporary)
    temporary_path = temporary.name
os.replace(temporary_path, directory / "credentials")
os.chmod(directory / "credentials", 0o600)
print("Installed private AWS credentials for ownword-pilot-vm")
