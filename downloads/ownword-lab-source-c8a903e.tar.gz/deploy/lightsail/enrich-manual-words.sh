#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
env_file="$repo_root/deploy/lightsail/.env"
compose_file="$repo_root/deploy/lightsail/compose.yaml"
cd "$repo_root"
exec docker compose --env-file "$env_file" -f "$compose_file" exec -T app \
  node /app/word-enrichment-worker.mjs
