# Ownword product polish — implementation handoff

## Mission

Implement the approved Ownword UI/UX improvements described here. The goal is a more alive, coherent vocabulary-learning product while preserving Ownword's quiet, editorial, muted green/cream identity. This is **not** a component-library migration or a redesign into a flashy learning game.

The user has approved the audit recommendations, including:

- a subtle animated public landing hero using the Shape Hero idea;
- a clear learning-oriented landing hierarchy inspired by the Duolingo reference;
- the responsive navigation, Discover, WordBoard, writing, practice, result, insight, account, and shared-motion recommendations below.

## Working rules

1. Start by inspecting the current codebase and live UI. The worktree is intentionally dirty from earlier Ownword work. Preserve existing changes; do not reset, discard, or overwrite work you did not author.
2. Reuse working business logic and routes. Do not perform an unrelated shadcn migration.
3. Visual fidelity to Ownword's established typography, muted greens, cream surfaces, fine borders, low shadow, and generous breathing room outranks library consistency.
4. Do not add large blocky cards, heavy shadows, dashboard clutter, excessive pills, gradients, neon, gamification, or generic AI-chat styling.
5. Animation must explain a state change or reinforce a successful action. Do not add motion merely to fill space.
6. Respect keyboard navigation, focus states, touch interactions, `prefers-reduced-motion`, and narrow layouts from 375px upward.
7. Do not remove existing practice modes, flashcards, routes, localization, semantic/LLM guards, WordBoard behavior, or quota behavior.
8. Keep the user-visible product copy consistent with the selected locale. Do not leave unexplained English strings in Vietnamese review states.

## Required skills

Read each selected skill's `SKILL.md` completely before implementing.

1. **`ui-ux-pro-max`** — use for responsive layout, information hierarchy, accessibility, spacing, and interaction review. Treat Ownword's current palette/type as the product design system; reject generic output from the skill that conflicts with it. In particular, do not adopt its automatically suggested style, font pairing, color palette, dashboard pattern, or claymorphism unless it independently matches this handoff (it does not here).
2. **`lucian-uxui`** — use the Lucian CLI to inspect/fetch the exact approved components before porting any of them. Preserve the required Lucian license comment in every ported component file. Do not invent Lucian code or IDs.
3. **`animate-ui`** — use Animate UI/Motion for the shared motion system. Read its catalog/recipes before hand-writing an equivalent component. Use motion tokens, `ReducedMotionConfig`, and `AnimatePresence`/layout transitions appropriately.

The project already includes `@animate-ui/react` and `motion`; verify the installed versions before adding anything. Do not install a dependency unless a genuine gap remains after inspection.

## Reference material

### Existing Ownword specification and visual contract

- Product/functional implementation brief:
  `D:\Downloads2\OWNWORD_KHAM_PHA_IMPLEMENTATION_BRIEF.md`
- Sacred Khám phá visual reference:
  `C:\Users\gdkie\Documents\English_learner\ownword-latest\reference_images\Giao diện Ownword tối giản xanh hiện đại.png`
- Earlier reference screenshots supplied in the Codex conversation should be treated as visual requirements for the approved Discover/practice direction.
- User notes/moodboard:
  `C:\Users\gdkie\Documents\English_learner\animation_notes.txt`

### References to inspect and interpret

Use these for interaction behavior and motion, not as visual templates to paste into Ownword.

- Lucian [#224 — traceable AI answer/sources](https://lucianlabs.dev/en/uxui-prompt/#224)
- Lucian [#281 — sweeping highlighter](https://lucianlabs.dev/en/uxui-prompt/#281)
- Lucian [#235 — fold text into an AI summary](https://lucianlabs.dev/en/uxui-prompt/#235)
- Lucian [#255 — drag-to-move Kanban](https://lucianlabs.dev/en/uxui-prompt/#255)
- Lucian [#267 — language switch](https://lucianlabs.dev/en/uxui-prompt/#267)
- Lucian [#321 — curtain page transition](https://lucianlabs.dev/en/uxui-prompt/#321)
- Lucian [#399 — reshuffling word cloud](https://lucianlabs.dev/en/uxui-prompt/#399)
- [UI Recipe — Duolingo style-guide hero](https://uirecipe.dev/gallery?slug=hero-duolingo)
- [Kokonut Shape Hero](https://kokonutui.com/docs/backgrounds/shape-hero)
- [Cult direction-aware tabs](https://www.cult-ui.com/docs/components/direction-aware-tabs)
- [Kokonut account menu](https://kokonutui.com/docs/navigation/profile-dropdown)
- [Kokonut undo button](https://kokonutui.com/docs/buttons/undo-button)
- [React Bits Stepper](https://reactbits.dev/components/stepper)
- [Kokonut Throw Deck/card stack](https://kokonutui.com/docs/cards/card-stack)
- [React Bits Flip Card](https://reactbits.dev/micro/flip-card)
- [Kokonut metric card](https://kokonutui.com/docs/cards/metric-card)
- [Magic UI number ticker](https://magicui.design/docs/components/number-ticker)

## Product decisions already made

### 1. Public landing page

Use the Shape Hero concept **only on the public landing page** as a decorative, attention-grabbing background. It should contain a sparse field of softly drifting C1/C2 word tiles, optionally showing a word class or short meaning.

- The effect must be subtle, non-blocking, pausable/offscreen-aware, and static under reduced motion.
- Do not use it inside authenticated product pages, WordBoard, Practice, or Writing.
- It must never compete with readable hero copy or make the page feel like an arcade.

Use the Duolingo reference for a **clear learning-oriented hero hierarchy only**:

- obvious one-sentence value proposition;
- one primary action and one calm secondary action;
- an immediate visual explanation of the learning loop;
- accessible, direct copy.

Do **not** copy Duolingo's bright palette, chunky typography, dense card system, loud gamification, or button style. The Ownword public landing stays calm, typographic, and mature.

### 2. Global responsive shell and navigation

The current narrow header can wrap navigation labels into broken fragments. Repair this first.

- Desktop may retain the centered primary navigation and moving active indicator.
- On narrow screens, use a compact header with an explicit menu/sheet for destinations rather than squeezing every nav item on one line.
- `Khám phá`, `Luyện tập`, and `WordBoard` remain obvious primary destinations.
- Make locale and account/settings discoverable without an unlabeled, overloaded ellipsis.
- A profile/account trigger may reveal name, email, locale, settings, and sign out. It should not make the desktop header visually busy.
- Locale controls must have correct radio/segmented semantics, not checkbox semantics. Adapt Lucian #267's state clarity/text swap where useful.
- Preserve a shared active selection indicator using Animate UI/Motion shared layout behavior; it should glide quickly, not create a page-sized transition.

### 3. Shared Ownword motion system

Implement a coherent, calm-active motion level:

- press/focus feedback: roughly 120–180ms;
- selection/filter/nav movement: short shared-layout spring;
- popover/drawer/inline disclosure: roughly 220–320ms;
- practice step change: roughly 250–350ms;
- success feedback: one short green pulse/wave, then rest.

Use Animate UI motion tokens and a top-level reduced-motion policy. Avoid custom, unrelated timings scattered through stylesheets.

Rules:

- Never animate initial above-the-fold critical text from hidden state merely for decoration.
- Do not animate layout properties such as `top`, `left`, width, or height when transforms/layout animations work.
- Rapid repeated interactions must retarget cleanly rather than restart.
- Keyboard-triggered interaction must animate like pointer interaction.
- Inspect intermediate animation frames in the browser.
- Do not use Lucian #321's full-screen curtain transition globally. Borrow only its sense of route continuity where appropriate.

### 4. Khám phá / Discover

Preserve the completed functional redesign and sacred visual reference.

- Rename/keep `Viết` as `Khám phá` in navigation.
- Manual word entry is the dominant interaction and must not call the LLM.
- Keep `Tìm từ cho ý này` and `Tìm từ qua bài viết` as distinct secondary paths.
- Maintain server-side authenticated quotas: concept discovery 8 successful uses/day and writing discovery 5 successful uses/day; limits remain configurable.
- A usage is consumed only when at least one validated usable opportunity/word is shown. Failures, timeouts, invalid schemas, rejected output, and zero results consume zero quota. Multiple returned usable words consume one use.
- Keep manual add duplicate behavior and WordBoard integration intact.

Interaction polish:

- Keep the underlined manual-entry row visually dominant.
- Make the two discovery paths quieter; opening concept discovery should reveal its input in place, focus it, and use a brief downward disclosure motion.
- Candidate results appear as compact choices, not a stack of large cards.
- After an add, show a quiet, accessible `Added to WordBoard · Undo` action for approximately five seconds. Adapt Kokonut's reversible-action idea, not its visual style.
- Do not add more desktop containers or remove the approved open whitespace. Tune whitespace only where it obscures hierarchy.

### 5. WordBoard

Keep WordBoard simple. It is a vocabulary collection, not a project-management board.

- Do not implement drag-and-drop stages from Lucian #255. Learning stage is evidence earned through practice/use, not a manual workflow state.
- Make word tiles more typographic and less blocky while retaining definition, part of speech, stage, date/source, and accessible selection.
- The existing detail drawer/sheet is a strong pattern. Improve the handoff: selected word title/class/stage should visually continue into the sheet through a shared-layout or short transform transition.
- Mobile stage filters must not clip; use a horizontally scrollable but visibly discoverable control, a compact select, or another accessible responsive treatment.
- Empty search/empty board states should lead to one contextually appropriate next action: Discover or Writing, not generic dead ends.
- Preserve all WordBoard behavior, including links from insights and writing.

### 6. Practice and flashcards

Practice must remain available even when scheduled/due work is complete. Preserve Quick and Full practice, existing flashcards, and all learning semantics.

Create a connected session flow:

- one sparse progress rail across recall, sentence use, and the next word;
- forward state changes enter with a small forward movement/crossfade; back moves in reverse;
- do not turn the center of the screen into a numbered wizard;
- preserve the existing green verified shaking/wave feedback and incorrect-answer shake;
- preserve the correction that resets the segmented-input pointing/caret to the first cell after a wrong answer;
- long word recall inputs must remain on one horizontal line, with safe horizontal scrolling/active-cell visibility rather than wrapping.

For Quick flashcards:

- make reveal feel like a restrained two-sided card using the Flip Card idea;
- Show answer, Space, and tap should use equivalent behavior;
- after a rating, the card settles and the next card takes its place;
- no swipe-to-dismiss requirement, no zooming stack, and no dramatic 3D under reduced motion.

For completion:

- avoid seven equal large rows dominating the screen;
- summarize recall and sentence use separately without claiming mastery;
- reduce emphasis on skipped sentence tasks;
- make the next action context-aware (`Continue writing` only if relevant);
- a one-time number transition is acceptable, but do not add streaks, ranks, confetti, or score dashboards.

### 7. Writing suggestions

Preserve all existing writing semantic/safety guards and LLM validation. Suggestions are optional lexical discovery, not proof-reading judgment or generic chatbot output.

Fix content integrity before adding motion:

- suggestion counts must agree with visible highlights;
- selected locale must govern all interface copy;
- do not render a result state that says zero suggestions while highlighting multiple spans.

Implement an Ownword-native `InlineSuggestion` interaction:

- selecting a suggestion highlights exactly the related source phrase in the learner's text;
- show a compact anchored explanation: why it fits, definition/nuance, and an optional trustworthy dictionary link;
- keyboard users can navigate suggestion list and source phrase predictably;
- use Lucian #224's traceability concept without pretending that model output has independent citations;
- a single highlighter sweep may occur once after real results arrive (Lucian #281 inspiration), never on every render;
- adapt Lucian #235's text-to-review state continuity without hiding the learner's writing behind a faux AI summary.

### 8. Insights

Insights must present common-word repetition as information, not failure.

- Keep a concise patterns list as the default.
- Add a word field/word cloud inspired by Lucian #399 only after there is sufficient meaningful repeated data. Do not render a visual frequency cloud for one occurrence.
- If implemented, focus/hover must expose count, context, and change; it must be keyboard reachable.
- Use at most a few restrained metric summaries; do not create a dashboard of gauges, badges, charts, and cards.
- Use a number ticker only when a genuinely meaningful total changes, such as at a monthly recap or session completion.

### 9. Settings and account

- Make save/persistence state explicit where needed.
- Keep settings visually quiet and functional.
- Move developer/test tools out of normal customer-facing settings hierarchy unless they are deliberately part of the product.
- Ensure mobile access to account, locale, settings, and sign out through the responsive navigation/account control.

## Explicitly rejected or constrained ideas

- **No product-wide Kokonut Shape Hero.** Public landing only.
- **No direct Duolingo visual copy.** Hero hierarchy only.
- **No drag-and-drop WordBoard.** Lucian #255 is inspiration for physical settling only.
- **No global curtain routes.** Lucian #321 is too slow and disruptive for frequent navigation.
- **No default word cloud with weak data.** Lucian #399 is conditional.
- **No number ticker everywhere.** It is a scarce feedback effect.
- **No generic component-library restyling.** shadcn is optional; use it only where it concretely improves interaction/accessibility without reducing Ownword fidelity.
- **No broad component-library migration.**
- **No performance-heavy always-running effects** in authenticated product areas.

## Suggested implementation sequence

### Phase A — foundations and correctness

1. Inspect the existing local changes and current behavior.
2. Fix mobile header/navigation and responsive filter overflow.
3. Correct writing count/locale inconsistencies and any visual state mismatches.
4. Establish shared reduced-motion-aware Animate UI/Motion tokens and primitives.

### Phase B — core learning loop

1. Polish Discover disclosure, add feedback, and undo.
2. Refine WordBoard tiles, responsive filters, empty states, and detail-sheet handoff.
3. Connect practice step transitions, preserve recall-field feedback, and add restrained flashcard reveal.
4. Improve results/next-action hierarchy.

### Phase C — writing and insight depth

1. Build traceable inline suggestions while preserving all server-side safety logic.
2. Refine insights into a progressive, evidence-based view.
3. Improve account/locale/settings ownership.

### Phase D — public landing

1. Apply the learning-oriented hero hierarchy.
2. Add the lightweight Shape Hero word-field decoration.
3. Verify public landing performance, reduced motion, and mobile behavior independently from the app workspace.

## Required verification

Before handoff, run and report:

- typecheck;
- lint for changed files;
- tests;
- production build;
- desktop and 375px/768px/1024px/1440px manual visual checks;
- reduced-motion checks;
- keyboard/focus checks for every altered interaction;
- rapid repeated interaction tests for animated controls;
- intermediate-frame visual checks for drawer, nav, flashcard, practice, and writing transitions;
- manual add does not invoke the LLM;
- duplicate add behavior;
- concept and writing quota limits;
- failed/zero-result discovery calls do not decrement quota;
- successful discovery decrements exactly once;
- navigation name/route behavior;
- practice retains Quick, Full, flashcard, recall, sentence, pause, and results behavior;
- long recall words stay one line and retry caret/pointing reset works;
- visual comparison of Discover with the sacred reference image.

Capture screenshots of major altered states for the implementation report.

## Final report format

Return a concise report with:

1. files changed;
2. skills used and how they shaped the work;
3. Lucian component IDs actually ported, with links and license-comment locations;
4. whether shadcn was used and why;
5. database/schema changes, if any;
6. quota and manual-add confirmation;
7. animation/motion system summary and reduced-motion behavior;
8. verification results;
9. known deviations from the sacred reference or this handoff.

