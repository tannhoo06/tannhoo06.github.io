CREATE TABLE "writing_revision_check" (
	"revision_id" text PRIMARY KEY NOT NULL,
	"lease_token" text,
	"lease_expires_at" text,
	"result" jsonb,
	CONSTRAINT "writing_revision_check_state" CHECK (
    ("writing_revision_check"."lease_token" is not null and "writing_revision_check"."lease_expires_at" is not null and "writing_revision_check"."result" is null)
    or ("writing_revision_check"."lease_token" is null and "writing_revision_check"."lease_expires_at" is null and "writing_revision_check"."result" is not null)
  )
);
--> statement-breakpoint
ALTER TABLE "writing_revision_check" ADD CONSTRAINT "writing_revision_check_revision_id_writing_submission_id_fk" FOREIGN KEY ("revision_id") REFERENCES "public"."writing_submission"("id") ON DELETE cascade ON UPDATE no action;