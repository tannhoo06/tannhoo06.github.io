CREATE TABLE "practice_attempt" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"user_word_id" text NOT NULL,
	"exercise_id" text NOT NULL,
	"at" text NOT NULL,
	"kind" text NOT NULL,
	"hint" text NOT NULL,
	"answer" text NOT NULL,
	"retrieved" boolean NOT NULL,
	"precise" boolean NOT NULL,
	"major_misuse" boolean NOT NULL,
	"context" text NOT NULL,
	"feedback" text NOT NULL,
	"spelling_correction" text,
	CONSTRAINT "practice_attempt_exercise_id_unique" UNIQUE("exercise_id")
);
--> statement-breakpoint
CREATE TABLE "concept_discovery" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"concept" text NOT NULL,
	"candidates" jsonb NOT NULL,
	"created_at" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "exercise" (
	"id" text PRIMARY KEY NOT NULL,
	"session_id" text NOT NULL,
	"user_id" text NOT NULL,
	"user_word_id" text NOT NULL,
	"kind" text NOT NULL,
	"prompt" text NOT NULL,
	"context" text NOT NULL,
	"semantic_hint" text NOT NULL,
	"hint" text DEFAULT 'none' NOT NULL,
	"sentence_pending" boolean DEFAULT false NOT NULL,
	"position" integer NOT NULL,
	"answered_at" text
);
--> statement-breakpoint
CREATE TABLE "insight" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"phrase" text NOT NULL,
	"count" integer NOT NULL,
	"alternatives" jsonb NOT NULL,
	"updated_at" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "llm_key_rotation" (
	"id" text PRIMARY KEY NOT NULL,
	"position" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "manual_word_check" (
	"user_id" text NOT NULL,
	"word" text NOT NULL,
	"status" text NOT NULL,
	"suggestion" text,
	"checked_at" text NOT NULL,
	CONSTRAINT "manual_word_check_user_id_word_pk" PRIMARY KEY("user_id","word")
);
--> statement-breakpoint
CREATE TABLE "request_limit" (
	"id" text PRIMARY KEY NOT NULL,
	"count" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "practice_session" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"created_at" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "vocabulary_suggestion" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"sample_id" text NOT NULL,
	"word" text NOT NULL,
	"part_of_speech" text NOT NULL,
	"definition" text NOT NULL,
	"nuance" text NOT NULL,
	"collocations" jsonb NOT NULL,
	"examples" jsonb NOT NULL,
	"original_text" text NOT NULL,
	"reason" text NOT NULL,
	"confidence" double precision NOT NULL,
	"source_anchor" jsonb,
	"suggested_sentence" text,
	"saved_word_id" text,
	"queued" boolean,
	"owns_saved_word" boolean,
	"status" text DEFAULT 'pending' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_word" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"word_id" text NOT NULL,
	"stage" text DEFAULT 'new' NOT NULL,
	"added_at" text NOT NULL,
	"introduced_at" text,
	"next_review_at" text NOT NULL,
	"source" text NOT NULL,
	"source_text" text NOT NULL,
	"lexeme_override" jsonb,
	"demo" boolean DEFAULT false NOT NULL,
	"removed_at" text
);
--> statement-breakpoint
CREATE TABLE "app_user" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"created_at" text NOT NULL,
	"daily_limit" integer DEFAULT 6 NOT NULL,
	"onboarded" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE "word" (
	"id" text PRIMARY KEY NOT NULL,
	"word" text NOT NULL,
	"part_of_speech" text NOT NULL,
	"definition" text NOT NULL,
	"nuance" text NOT NULL,
	"collocations" jsonb NOT NULL,
	"examples" jsonb NOT NULL,
	CONSTRAINT "word_word_unique" UNIQUE("word")
);
--> statement-breakpoint
CREATE TABLE "writing_review" (
	"sample_id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"review" jsonb NOT NULL
);
--> statement-breakpoint
CREATE TABLE "writing_sample" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"text" text NOT NULL,
	"prompt" text NOT NULL,
	"created_at" text NOT NULL
);
--> statement-breakpoint
ALTER TABLE "practice_attempt" ADD CONSTRAINT "practice_attempt_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "practice_attempt" ADD CONSTRAINT "practice_attempt_user_word_id_user_word_id_fk" FOREIGN KEY ("user_word_id") REFERENCES "public"."user_word"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "concept_discovery" ADD CONSTRAINT "concept_discovery_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "exercise" ADD CONSTRAINT "exercise_session_id_practice_session_id_fk" FOREIGN KEY ("session_id") REFERENCES "public"."practice_session"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "exercise" ADD CONSTRAINT "exercise_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "exercise" ADD CONSTRAINT "exercise_user_word_id_user_word_id_fk" FOREIGN KEY ("user_word_id") REFERENCES "public"."user_word"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "insight" ADD CONSTRAINT "insight_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "manual_word_check" ADD CONSTRAINT "manual_word_check_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "practice_session" ADD CONSTRAINT "practice_session_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vocabulary_suggestion" ADD CONSTRAINT "vocabulary_suggestion_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vocabulary_suggestion" ADD CONSTRAINT "vocabulary_suggestion_sample_id_writing_sample_id_fk" FOREIGN KEY ("sample_id") REFERENCES "public"."writing_sample"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_word" ADD CONSTRAINT "user_word_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_word" ADD CONSTRAINT "user_word_word_id_word_id_fk" FOREIGN KEY ("word_id") REFERENCES "public"."word"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "writing_review" ADD CONSTRAINT "writing_review_sample_id_writing_sample_id_fk" FOREIGN KEY ("sample_id") REFERENCES "public"."writing_sample"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "writing_review" ADD CONSTRAINT "writing_review_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "writing_sample" ADD CONSTRAINT "writing_sample_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "attempt_word_time" ON "practice_attempt" USING btree ("user_word_id","at");--> statement-breakpoint
CREATE INDEX "concept_discovery_owner_created" ON "concept_discovery" USING btree ("user_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "insight_owner_phrase" ON "insight" USING btree ("user_id","phrase");--> statement-breakpoint
CREATE UNIQUE INDEX "user_word_owner_lexeme" ON "user_word" USING btree ("user_id","word_id");--> statement-breakpoint
CREATE INDEX "user_word_due" ON "user_word" USING btree ("user_id","next_review_at");--> statement-breakpoint
CREATE INDEX "writing_owner" ON "writing_sample" USING btree ("user_id");