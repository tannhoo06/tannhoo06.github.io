CREATE TABLE "writing_focus_state" (
	"user_id" text NOT NULL,
	"problem_key" text NOT NULL,
	"status" text NOT NULL,
	CONSTRAINT "writing_focus_state_user_id_problem_key_pk" PRIMARY KEY("user_id","problem_key"),
	CONSTRAINT "writing_focus_status" CHECK ("writing_focus_state"."status" in ('active', 'dismissed'))
);
--> statement-breakpoint
ALTER TABLE "writing_focus_state" ADD CONSTRAINT "writing_focus_state_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE cascade ON UPDATE no action;