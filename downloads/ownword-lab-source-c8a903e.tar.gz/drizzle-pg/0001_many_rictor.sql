ALTER TABLE "word" ADD COLUMN "enrichment_attempts" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "word" ADD COLUMN "enrichment_next_at" text;