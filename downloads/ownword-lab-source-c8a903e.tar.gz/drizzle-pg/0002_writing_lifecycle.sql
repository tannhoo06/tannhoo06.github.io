CREATE TABLE "writing_run" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"task_id" text NOT NULL,
	"submission_id" text NOT NULL,
	"idempotency_key" text NOT NULL,
	"purpose" text DEFAULT 'diagnostic' NOT NULL,
	"status" text NOT NULL,
	"quota_day" text NOT NULL,
	"lease_expires_at" text NOT NULL,
	"started_at" text NOT NULL,
	"finished_at" text,
	"report" jsonb,
	CONSTRAINT "writing_run_diagnostic" CHECK ("writing_run"."purpose" = 'diagnostic'),
	CONSTRAINT "writing_run_state" CHECK (
    ("writing_run"."status" = 'pending' and "writing_run"."finished_at" is null and "writing_run"."report" is null)
    or ("writing_run"."status" in ('failed', 'expired') and "writing_run"."finished_at" is not null and "writing_run"."report" is null)
    or ("writing_run"."status" = 'succeeded' and "writing_run"."finished_at" is not null and "writing_run"."report" is not null)
  )
);
--> statement-breakpoint
CREATE TABLE "writing_submission" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"task_id" text NOT NULL,
	"client_request_id" text NOT NULL,
	"parent_submission_id" text,
	"text" text NOT NULL,
	"word_count" integer NOT NULL,
	"assistance" text NOT NULL,
	"created_at" text NOT NULL,
	CONSTRAINT "writing_submission_owner_task_id" UNIQUE("user_id","task_id","id"),
	CONSTRAINT "writing_submission_assistance" CHECK ("writing_submission"."assistance" in ('unassisted', 'external_help', 'ownword_hint', 'unknown')),
	CONSTRAINT "writing_submission_word_count" CHECK ("writing_submission"."word_count" >= 0),
	CONSTRAINT "writing_submission_parent_not_self" CHECK ("writing_submission"."parent_submission_id" <> "writing_submission"."id")
);
--> statement-breakpoint
CREATE TABLE "writing_task" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"client_request_id" text NOT NULL,
	"prompt_id" text NOT NULL,
	"prompt_version" text NOT NULL,
	"snapshot" jsonb NOT NULL,
	"created_at" text NOT NULL,
	CONSTRAINT "writing_task_owner_id" UNIQUE("user_id","id")
);
--> statement-breakpoint
ALTER TABLE "writing_run" ADD CONSTRAINT "writing_run_owned_submission_fk" FOREIGN KEY ("user_id","task_id","submission_id") REFERENCES "public"."writing_submission"("user_id","task_id","id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "writing_submission" ADD CONSTRAINT "writing_submission_owned_task_fk" FOREIGN KEY ("user_id","task_id") REFERENCES "public"."writing_task"("user_id","id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "writing_submission" ADD CONSTRAINT "writing_submission_owned_parent_fk" FOREIGN KEY ("user_id","task_id","parent_submission_id") REFERENCES "public"."writing_submission"("user_id","task_id","id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "writing_task" ADD CONSTRAINT "writing_task_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "writing_run_owner_request" ON "writing_run" USING btree ("user_id","idempotency_key");--> statement-breakpoint
CREATE UNIQUE INDEX "writing_run_one_active" ON "writing_run" USING btree ("user_id","submission_id","purpose") WHERE "writing_run"."status" in ('pending', 'succeeded');--> statement-breakpoint
CREATE INDEX "writing_run_submission" ON "writing_run" USING btree ("user_id","task_id","submission_id","started_at");--> statement-breakpoint
CREATE INDEX "writing_run_quota" ON "writing_run" USING btree ("user_id","purpose","quota_day","status","lease_expires_at");--> statement-breakpoint
CREATE UNIQUE INDEX "writing_submission_owner_request" ON "writing_submission" USING btree ("user_id","client_request_id");--> statement-breakpoint
CREATE UNIQUE INDEX "writing_submission_one_original" ON "writing_submission" USING btree ("user_id","task_id") WHERE "writing_submission"."parent_submission_id" is null;--> statement-breakpoint
CREATE INDEX "writing_submission_parent" ON "writing_submission" USING btree ("user_id","task_id","parent_submission_id");--> statement-breakpoint
CREATE UNIQUE INDEX "writing_task_owner_request" ON "writing_task" USING btree ("user_id","client_request_id");