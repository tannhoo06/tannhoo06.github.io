CREATE TABLE "writing_profile_analysis" (
	"user_id" text PRIMARY KEY NOT NULL,
	"evidence_key" text NOT NULL,
	"lease_token" text,
	"next_attempt_at" text NOT NULL,
	"updated_at" text NOT NULL,
	"result" text,
	CONSTRAINT "writing_profile_analysis_result" CHECK ("writing_profile_analysis"."lease_token" is null or "writing_profile_analysis"."result" is null)
);
--> statement-breakpoint
ALTER TABLE "writing_profile_analysis" ADD CONSTRAINT "writing_profile_analysis_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "writing_revision_check" ADD COLUMN "checked_at" text;
