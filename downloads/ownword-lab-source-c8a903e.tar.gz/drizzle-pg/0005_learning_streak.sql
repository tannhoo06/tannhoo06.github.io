CREATE TABLE "learning_activity_day" (
	"user_id" text NOT NULL,
	"day" text NOT NULL,
	CONSTRAINT "learning_activity_day_user_id_day_pk" PRIMARY KEY("user_id","day")
);
--> statement-breakpoint
ALTER TABLE "learning_activity_day" ADD CONSTRAINT "learning_activity_day_user_id_app_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."app_user"("id") ON DELETE cascade ON UPDATE no action;