import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolveSource } from "../lib/domain/anchors";
import { inspectAnalysisProposals, GeminiLlm } from "../lib/llm/gemini";
import {
  validateLexicalRewrite,
  protectedSemanticSlots,
} from "../lib/llm/rewrite-quality";
import { semanticStrength, lexicalBenefit } from "../lib/llm/semantic-policy";
type Fixture = {
  id: string;
  text: string;
  old: string;
  word: string;
  replacement: string;
  pos: string;
  definition?: string;
  retain: boolean;
};
function raw(f: Fixture) {
  return {
    suggestions: [
      {
        word: f.word,
        canonicalForm: f.word,
        partOfSpeech: f.pos,
        replacementText: f.replacement,
        originalText: f.old,
        source: { sentence: f.text, before: "", after: "" },
        definition:
          f.definition ?? "To express the stated contextual meaning precisely.",
        nuance: "",
        reason: "Names the stated concept.",
        confidence: 0.9,
        examples: ["A natural contextual example."],
        collocations: [],
      },
    ],
    opportunities: [],
    usages: [],
    summary: "",
  };
}
const fixtures: Fixture[] = JSON.parse(
  readFileSync("evals/unknown-frame-v5.json", "utf8"),
);
test("source plural noun cannot impersonate a same-shape verb", () => {
  const f = {
    id: "U21",
    text: "She likes cats.",
    old: "cats",
    word: "yearn",
    replacement: "yearns",
    pos: "verb",
    retain: false,
  };
  const r = inspectAnalysisProposals(f.text, raw(f));
  assert.equal(r.suggestions.length, 0);
  assert.equal(r.audit[0].reason, "unknown-frame-risk");
});
for (const f of fixtures)
  test(`adversarial unknown frame ${f.id}: ${f.word}`, () => {
    const r = inspectAnalysisProposals(f.text, raw(f));
    assert.equal(r.suggestions.length > 0, f.retain, JSON.stringify(r.audit));
    if (["U02", "U04", "U09", "U10", "U11", "U20"].includes(f.id))
      assert.equal(r.audit[0].frameConfidence, "unknown-frame");
  });
for (const [source, rewrite, explanation] of [
  [
    "had a very big effect",
    "had a transformative effect",
    "A fundamental alteration.",
  ],
  ["provided support", "provided proof", "Proves conclusively."],
  ["partially reduced the risk", "eliminated the risk", "Eliminates all risk."],
  ["possible", "certain", "Guarantees the outcome."],
  ["difficult", "impossible", "Impossible to do."],
  ["noticeable", "dramatic", "A dramatic change."],
  [
    "influenced the decision",
    "determined the decision",
    "Determines the result.",
  ],
  ["helped the change", "caused the change", "Causes the change."],
  ["improved the system", "fixed the system", "Fixes the system."],
])
  test(`semantic strength profile: ${source}`, () => {
    const r = semanticStrength(source, rewrite, explanation);
    assert.ok(r.rewrite.length);
    assert.ok(r.teaching.length);
  });
test("grammatical surface cannot excuse instructional semantic overreach", () => {
  const text = "The evidence supported the claim.";
  const result = validateLexicalRewrite(
    text,
    {
      word: "reinforce",
      partOfSpeech: "verb",
      originalText: "supported",
      source: resolveSource(text, "supported", ""),
      suggestedSentence: text.replace("supported", "reinforced"),
      definition: "To add support to an existing claim.",
      nuance: "Proves the conclusion conclusively.",
      reason: "A useful evidence term.",
      examples: [],
      collocations: [],
      confidence: 0.9,
    },
    { canonical: "reinforce", surface: "reinforced", type: "word" },
  );
  assert.equal(result.suggestion, null);
  assert.ok(result.issues.includes("instructional-semantic-overreach"));
  assert.equal(result.stages.grammaticallyValid, true);
});
test("persuasive meaning does not license absolute mental effects", () => {
  for (const explanation of [
    "Forcefully demands agreement without requiring extra persuasion steps.",
    "Holds your attention completely and forcefully.",
  ]) {
    assert.ok(
      semanticStrength(
        "interesting",
        "compelling",
        explanation,
      ).teaching.includes("absolute-mental-effect"),
    );
  }
});
test("persuasive teaching distinguishes force from guaranteed response", () => {
  const source = "The evidence was interesting and convinced every committee member.";
  for (const teaching of ["highly convincing", "strongly persuasive", "likely to persuade", "difficult to dismiss", "attracts strong attention", "presents a powerful case"]) {
    assert.deepEqual(semanticStrength("interesting", "compelling", teaching, source).teaching, [], teaching);
  }
  for (const teaching of ["commands belief", "guarantees agreement", "forces belief", "ensures acceptance", "automatically convinces everyone", "makes the listener agree", "causes agreement"]) {
    assert.ok(semanticStrength("interesting", "compelling", teaching, source).teaching.includes("absolute-mental-effect"), teaching);
  }
  assert.deepEqual(semanticStrength("interesting", "compelling", "highly convincing", source).rewrite, []);
});
test("persuasion synonym benefit depends on source gain", () => {
  assert.equal(lexicalBenefit("convinced", "swayed", "sway", {sentence: "The evidence convinced even the critics.", definition: "to influence someone to change an opinion"}).sufficient, false);
  assert.equal(lexicalBenefit("make the panel change its mind", "sway the panel", "sway", {sentence: "The evidence could make the panel change its mind.", definition: "to influence someone to change an opinion"}).sufficient, true);
});
test("each teaching field is checked without rejecting a preserved achieved outcome", () => {
  const text = "The evidence was interesting and convinced every committee member.";
  for (const field of ["definition", "nuance", "reason"] as const) {
    const data = raw({id:"outcome", text, old:"interesting", word:"compelling", replacement:"compelling", pos:"adjective", definition:"Highly convincing and powerfully persuasive.", retain:true});
    data.suggestions[0][field] = "An argument that guarantees agreement.";
    const result = inspectAnalysisProposals(text, data);
    assert.equal(result.suggestions.length, 0, field);
  }
  const good = raw({id:"outcome", text, old:"interesting", word:"compelling", replacement:"compelling", pos:"adjective", definition:"Highly convincing and powerfully persuasive.", retain:true});
  const result = inspectAnalysisProposals(text, good);
  assert.equal(result.suggestions.length, 1, JSON.stringify(result.audit));
  assert.match(result.suggestions[0].suggestedSentence ?? "", /convinced every committee member/);
  assert.ok(semanticStrength("strong argument", "compelling", "guarantees agreement", "forced agreement").teaching.includes("absolute-mental-effect"));
});
test("protected slots are derived from source before generation and claims cannot bypass checks", async () => {
  const text = "Everyone could check the records quickly twice.";
  const slots = protectedSemanticSlots(text);
  assert.ok(slots.preservedCounts.includes("twice"));
  assert.ok(slots.preservedQualifiers.includes("quickly"));
  assert.ok(slots.preservedParticipants.includes("everyone"));
  assert.ok(slots.preservedModality.includes("could"));
  const f = {
    id: "claim",
    text,
    old: "check the records quickly twice",
    word: "inspect",
    replacement: "inspect the records",
    pos: "verb",
    retain: false,
  };
  const payload = raw(f);
  Object.assign(payload.suggestions[0], { preservation: slots });
  let calls = 0;
  const provider = new GeminiLlm("test", "test", (async (_url, init) => {
    calls++;
    const request = JSON.parse(init!.body as string);
    assert.match(
      request.systemInstruction.parts[1].text,
      /bounced back quickly/,
    );
    assert.ok(
      JSON.stringify(request.contents).includes("protectedSourceEvidence"),
    );
    return Response.json({
      candidates: [{ content: { parts: [{ text: JSON.stringify(payload) }] } }],
    });
  }) as typeof fetch);
  const result = await provider.analyzeWriting(text, []);
  assert.equal(calls, 1);
  assert.equal(result.suggestions.length, 0);
  const audit = inspectAnalysisProposals(text, payload).audit[0];
  assert.equal(audit.stages.qualifierPreserving, false);
});
test("validity and learning benefit are independent", () => {
  const f = fixtures.find((f) => f.id === "U17")!;
  const a = inspectAnalysisProposals(f.text, raw(f)).audit[0];
  assert.equal(a.stages.grammaticallyValid, true);
  assert.equal(a.stages.semanticallyFaithful, true);
  assert.equal(a.stages.learningBenefitSufficient, false);
});
for (const word of ["corroborate", "reinforce"])
  test(`strong evidence-support concept survives: ${word}`, () => {
    const text =
      "The results were consistent with our earlier findings and provided more support for them.";
    const f = {
      id: "support",
      text,
      old: "provided more support for them",
      word,
      replacement:
        word === "corroborate" ? "corroborated them" : "reinforced them",
      pos: "verb",
      retain: true,
    };
    const p = raw(f);
    p.suggestions[0].definition =
      "To provide additional support for an existing claim.";
    const r = inspectAnalysisProposals(text, p);
    assert.equal(r.suggestions.length, 1, JSON.stringify(r.audit));
    assert.equal(r.audit[0].frameConfidence, "known-safe");
  });
