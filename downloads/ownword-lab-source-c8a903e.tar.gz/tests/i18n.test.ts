import test from "node:test";
import assert from "node:assert/strict";
import { resolveLocale, translate, vi } from "../lib/i18n/messages";

test("Vietnamese is the default; only an explicit supported English preference changes it", () => {
  for (const value of [undefined, null, "", "fr", "VI", "<script>"])
    assert.equal(resolveLocale(value), "vi");
  assert.equal(resolveLocale("vi"), "vi");
  assert.equal(resolveLocale("en"), "en");
});

test("interface translations preserve every interpolation parameter", () => {
  const parameters = (text: string) =>
    [...text.matchAll(/\{(\w+)\}/g)].map((match) => match[1]).sort();
  for (const [english, vietnamese] of Object.entries(vi)) {
    assert.ok(vietnamese.trim(), `Missing translation: ${english}`);
    assert.deepEqual(parameters(vietnamese), parameters(english), english);
  }
});

test("dynamic labels preserve the learner's English word and counts in either interface language", () => {
  assert.equal(
    translate("vi", "Try “{word}”", { word: "negligible" }),
    "Thử dùng “negligible”",
  );
  assert.equal(
    translate("en", "Try “{word}”", { word: "negligible" }),
    "Try “negligible”",
  );
  assert.equal(
    translate("vi", "{visible} of {total} words", { visible: 2, total: 8 }),
    "Hiển thị 2 / 8 từ",
  );
  assert.equal(
    translate("vi", "An unchanged English practice sentence."),
    "An unchanged English practice sentence.",
  );
  assert.equal(translate("vi", "toString"), "toString");
  assert.equal(translate("en", "{count} words", { count: 1 }), "1 word");
});
