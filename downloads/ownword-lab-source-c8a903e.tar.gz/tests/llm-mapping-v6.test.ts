import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  resolveProposalAnchor,
  mapReplacement,
} from "../lib/llm/source-mapping";
import { inspectAnalysisProposals } from "../lib/llm/gemini";
import { validSource } from "../lib/domain/anchors";
const proposal = (
  text: string,
  old: string,
  word: string,
  replacement: string,
  pos = "verb",
) => ({
  suggestions: [
    {
      word,
      canonicalForm: word,
      partOfSpeech: pos,
      originalText: old,
      replacementText: replacement,
      source: { sentence: text, before: "", after: "" },
      definition: "To express the stated contextual meaning more precisely.",
      nuance: "",
      reason: "A reusable contextual concept.",
      examples: ["A natural contextual example."],
      collocations: [],
      confidence: 0.9,
    },
  ],
  opportunities: [],
  usages: [],
  summary: "",
});
const explain =
  "She explained a complicated idea in words that everyone could understand.";
const old = explain.slice(4, -1);
const good = "demystified a complicated idea so everyone could understand it";
test("unique exact quote takes precedence over incorrect context and model offsets", () => {
  const r = resolveProposalAnchor(
    "Alice carefully checked the records.",
    "checked",
    {
      before: "invented",
      after: "wrong",
      sentence: "wrong",
      start: 999,
      end: 1000,
    },
  );
  assert.equal(r.status, "exact-unique");
  assert.equal(r.source?.start, 16);
  assert.equal(r.diagnostic, "context-hint-mismatch-ignored-unique-anchor");
});
test("repeated quote stays ambiguous without reliable context", () => {
  assert.equal(
    resolveProposalAnchor("We checked it. They checked it.", "checked").status,
    "ambiguous",
  );
  assert.equal(
    resolveProposalAnchor("We checked it. They checked it.", "checked", {
      start: 3,
      end: 10,
    }).status,
    "ambiguous",
  );
});
test("repeated quote can be disambiguated by validated context", () => {
  const r = resolveProposalAnchor(
    "We checked it. They checked it.",
    "checked",
    { before: "They ", after: " it." },
  );
  assert.equal(r.status, "exact-disambiguated");
  assert.equal(r.source?.start, 20);
});
test("fabricated, folded and broken Unicode anchors are invalid", () => {
  for (const [text, quote] of [
    ["We checked it.", "Checked"],
    ["We checked it.", "invented"],
    ["😀", String.fromCharCode(0xd83d)],
  ])
    assert.equal(resolveProposalAnchor(text, quote).status, "invalid");
});
test("safe referential it and connective so retain a known strong candidate", () => {
  const r = inspectAnalysisProposals(
    explain,
    proposal(explain, old, "demystify", good),
  );
  assert.equal(r.suggestions.length, 1, JSON.stringify(r.audit));
  assert.equal(r.audit[0].mapping.repair, "source-supported-clause-glue");
  assert.equal(r.audit[0].mapping.functionWordRepairAttempted, true);
  assert.match(
    r.suggestions[0].suggestedSentence!,
    /everyone could understand it/,
  );
});
test("connective so also works without an unnecessary pronoun", () => {
  assert.equal(
    inspectAnalysisProposals(
      explain,
      proposal(explain, old, "demystify", good.replace(/ it$/, "")),
    ).suggestions.length,
    1,
  );
});
test("ambiguous noun antecedents cannot license an added it", () => {
  const text =
    "She explained a theory and an example in words that everyone could understand.";
  const r = inspectAnalysisProposals(
    text,
    proposal(
      text,
      text.slice(4, -1),
      "demystify",
      "demystified a theory and an example so everyone could understand it",
    ),
  );
  assert.equal(r.suggestions.length, 0);
});
test("new semantic clauses do not acquire grammatical-glue permission", () => {
  assert.equal(
    inspectAnalysisProposals(
      explain,
      proposal(explain, old, "demystify", good + " and profits rose"),
    ).suggestions.length,
    0,
  );
});
test("a required infinitival marker still passes the existing validated frame", () => {
  const text =
    "The evidence was strong enough to make the panel change its mind.";
  const r = inspectAnalysisProposals(
    text,
    proposal(
      text,
      "make the panel change its mind",
      "convince",
      "convince the panel to change its mind",
    ),
  );
  assert.equal(r.suggestions.length, 1, JSON.stringify(r.audit));
  assert.ok(r.audit[0].mapping.grammaticalAdditions.includes("to"));
});
test("unsupported lexical modifiers remain rejected", () => {
  const text = "The report explains the small but meaningful differences.";
  const r = inspectAnalysisProposals(
    text,
    proposal(
      text,
      "small but meaningful differences",
      "nuance",
      "dramatic nuances",
      "noun",
    ),
  );
  assert.equal(r.suggestions.length, 0);
  assert.equal(r.audit[0].mapping.semanticLexicalContentProposed, true);
});
test("supported fine-scale modifier is mapped while original significance is preserved", () => {
  const text =
    "The report explains the small but meaningful differences between two positions.";
  const r = inspectAnalysisProposals(
    text,
    proposal(
      text,
      "small but meaningful differences",
      "nuance",
      "subtle nuances",
      "noun",
    ),
  );
  assert.equal(r.suggestions.length, 1, JSON.stringify(r.audit));
  assert.equal(
    r.suggestions[0].suggestedSentence,
    text.replace("differences", "nuances"),
  );
  assert.equal(
    r.audit[0].mapping.repair,
    "supported-modifier-mapped-to-source",
  );
});
test("supporting modifier repair is independent of exact target noun", () => {
  const text = "The report explains the tiny but important differences.";
  assert.equal(
    inspectAnalysisProposals(
      text,
      proposal(
        text,
        "tiny but important differences",
        "distinction",
        "fine distinctions",
        "noun",
      ),
    ).suggestions.length,
    1,
  );
});
for (const [name, replacement] of [
  ["participants", good.replace("everyone", "they")],
  ["modality", good.replace("could ", "")],
])
  test(`glue cannot erase ${name}`, () => {
    assert.equal(
      inspectAnalysisProposals(
        explain,
        proposal(explain, old, "demystify", replacement),
      ).suggestions.length,
      0,
    );
  });
test("frequency and checking event cannot disappear after unique anchor recovery", () => {
  const text = "She checked every tiny detail twice.";
  const p = proposal(
    text,
    "checked every tiny detail twice",
    "inspect",
    "inspected every tiny detail",
  );
  p.suggestions[0].source.after = "wrong";
  const r = inspectAnalysisProposals(text, p);
  assert.equal(r.suggestions.length, 0);
  assert.ok(r.audit[0].qualityIssues?.includes("qualifier-loss"));
});
test("conditions cannot be removed by a broader declared source span", () => {
  const text =
    "She explained a complicated idea in words that everyone could understand if they listened.";
  assert.equal(
    inspectAnalysisProposals(
      text,
      proposal(text, text.slice(4, -1), "demystify", good),
    ).suggestions.length,
    0,
  );
});
test("repaired source still exactly reconstructs offsets after a Unicode prefix", () => {
  const text = "😀 She inspected the financial records.";
  const p = proposal(text, "inspected", "audit", "audited");
  p.suggestions[0].source.before = "wrong";
  const r = inspectAnalysisProposals(text, p),
    s = r.suggestions[0];
  assert.ok(s);
  assert.ok(validSource(text, "", s.source));
  assert.equal(s.source!.start, text.indexOf("inspected"));
  assert.equal(
    text.slice(0, s.source!.start) + "audited" + text.slice(s.source!.end),
    s.suggestedSentence,
  );
});
test("low-benefit same-tier synonyms remain rejected after unique anchor recovery", () => {
  const text = "The safety margin is small.";
  const p = proposal(text, "small", "narrow", "narrow", "adjective");
  p.suggestions[0].source.after = "wrong";
  const r = inspectAnalysisProposals(text, p);
  assert.equal(r.suggestions.length, 0);
  assert.ok(
    r.audit[0].qualityIssues?.includes("insufficient-learning-benefit"),
  );
});
test("unknown frame risk cannot be bypassed with good source mapping", () => {
  const text = "The change had a very big effect on how the team works.";
  assert.equal(
    inspectAnalysisProposals(
      text,
      proposal(text, "had a very big effect", "transform", "transforms"),
    ).suggestions.length,
    0,
  );
});
test("all three demonstrated v5 mapping false rejections are recovered", () => {
  const run = JSON.parse(
    readFileSync(
      "evals/results/candidate-v5-final-2026-10-30/results.json",
      "utf8",
    ),
  );
  for (const id of ["A09", "D04", "E04"]) {
    const row = run.rows.find(
      (r: { case: { id: string } }) => r.case.id === id,
    );
    const r = inspectAnalysisProposals(
      row.case.input,
      row.requests[0].rawModelOutput,
    );
    assert.equal(r.suggestions.length, 1, id + " " + JSON.stringify(r.audit));
  }
});
test("mapping token classes never grant arbitrary semantic additions", () => {
  const r = mapReplacement(old, good + " dramatically", "demystify", "verb");
  assert.ok(r.semanticAdditions.includes("dramatically"));
  assert.equal(r.repair, null);
});
