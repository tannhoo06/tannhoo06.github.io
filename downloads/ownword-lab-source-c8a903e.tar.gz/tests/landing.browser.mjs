// Public landing browser regressions; uses an existing Playwright installation.
const { chromium } = await import(
  process.env.PLAYWRIGHT_MODULE || "playwright"
);
import assert from "node:assert/strict";
import { mkdirSync } from "node:fs";
mkdirSync("outputs/landing-fixes", { recursive: true });
const browser = await chromium.launch({
  headless: true,
  channel: process.env.BROWSER_CHANNEL || "msedge",
});
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [],
  writes = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("request", (r) => {
  if (r.method() === "POST" && r.url().includes("/api/")) writes.push(r.url());
});
const ready = () =>
  page.waitForFunction(() =>
    document.documentElement.classList.contains("ow-page-scroll"),
  );
const at = async (y) => {
  await page.waitForFunction((y) => Math.abs(scrollY - y) < 3, y);
  await page.waitForTimeout(200);
};
const top = async () => {
  await page.evaluate(() => scrollTo({ top: 0, behavior: "instant" }));
  await at(0);
};
const load = async () => {
  await page.goto("http://127.0.0.1:5173/");
  await ready();
};
const snap = () =>
  page.evaluate(
    () => getComputedStyle(document.scrollingElement).scrollSnapType,
  );
const completePreviews = async () => {
  assert.equal(
    await page
      .locator(".ow-context")
      .evaluate((e) => getComputedStyle(e).visibility),
    "visible",
  );
  assert.equal(
    await page
      .locator(".ow-word-tile")
      .evaluate((e) => getComputedStyle(e).visibility),
    "visible",
  );
  assert.match(await page.locator(".ow-context").innerText(), /negligible/);
};
await load();
await page.waitForTimeout(3800);
assert.equal(await snap(), "y");
assert.equal(
  await page.evaluate(() => document.scrollingElement.tagName),
  "HTML",
);
await page.mouse.move(700, 700);
for (const delta of [60, 120, 240]) {
  await top();
  await page.mouse.wheel(0, delta);
  await page.waitForTimeout(700);
  const y = await page.evaluate(() => scrollY);
  assert.ok(
    y >= delta - 4,
    `downward departure snapped back: ${delta} -> ${y}`,
  );
}
await top();
await page.mouse.wheel(0, 720);
await at(900);
await page.mouse.wheel(0, -60);
await page.waitForTimeout(700);
assert.ok(
  await page.evaluate(() => scrollY < 850),
  "upward departure snapped back",
);
await page.mouse.wheel(0, -650);
await at(0);
// Continuous small deltas remain native and can cross the section boundary.
for (let i = 0; i < 15; i++) {
  await page.mouse.wheel(0, 60);
  await page.waitForTimeout(16);
}
// This section is no longer the document end: momentum may carry beyond it.
await page.waitForFunction(() => scrollY >= 899);
await top();
await page.keyboard.press("PageDown");
await at(900);
await page.keyboard.press("PageUp");
await at(0);
await page.keyboard.press("End");
await page.waitForFunction(
  () =>
    Math.abs(scrollY + innerHeight - document.documentElement.scrollHeight) < 3,
);
await page.keyboard.press("Home");
await at(0);
await page.getByRole("link", { name: "Cách học", exact: true }).click();
await at(900);
await page.goBack();
await at(0);
await page.screenshot({ path: "outputs/landing-fixes/introduction-vi.png" });
await page.getByRole("link", { name: "Cách học", exact: true }).click();
await at(900);
await page.screenshot({ path: "outputs/landing-fixes/how-it-works-vi.png" });
const heroTab = () =>
  page.locator(".ow-tabs [aria-selected=true]").getAttribute("id");
const beforeTab = await heroTab();
const geometry = () =>
  page.locator(".ow-steps").evaluate((e) =>
    [...e.children].map((c) => ({
      height: c.getBoundingClientRect().height,
      width: c.getBoundingClientRect().width,
    })),
  );
const beforeCards = await geometry();
const launch = page.getByRole("button", {
  name: "Thử bài luyện mẫu",
  exact: true,
});
await launch.click();
const dialog = page.getByRole("dialog");
await dialog.waitFor();
assert.equal(
  await page.evaluate(() => document.activeElement.id),
  "dialog-answer",
);
assert.ok(!(await dialog.innerText()).includes("negligible"));
assert.equal(await heroTab(), beforeTab);
await completePreviews();
assert.deepEqual(await geometry(), beforeCards);
assert.equal(await dialog.evaluate((e) => e.matches(":modal")), true);
assert.equal(
  await dialog.evaluate(
    (e) => getComputedStyle(e, "::backdrop").backgroundColor,
  ),
  "rgb(250, 248, 239)",
);
await page.screenshot({ path: "outputs/landing-fixes/practice-recall-vi.png" });
// Native modal keyboard confinement and Escape restoration.
for (let i = 0; i < 8; i++) {
  await page.keyboard.press("Tab");
  assert.equal(
    await dialog.evaluate((e) => e.contains(document.activeElement)),
    true,
  );
}
await page
  .getByRole("button", { name: "Đóng bài luyện mẫu", exact: true })
  .focus();
await page.keyboard.press("Shift+Tab");
assert.equal(
  await dialog.evaluate((e) => e.contains(document.activeElement)),
  true,
);
await page.locator("#dialog-answer").fill("small");
await page.getByRole("button", { name: "Gợi ý", exact: true }).click();
assert.ok((await dialog.innerText()).includes("negligible"));
await page.getByRole("button", { name: "Kiểm tra từ", exact: true }).click();
assert.ok(
  await page
    .getByText("Chưa đúng từ trong ví dụ. Từ mẫu là negligible.")
    .isVisible(),
);
await page.locator("#dialog-answer").fill("negligible");
await page.getByRole("button", { name: "Kiểm tra từ", exact: true }).click();
assert.ok(await page.getByText("Đúng từ mẫu. Bạn đã dùng gợi ý.").isVisible());
await page
  .getByRole("button", { name: "Tiếp tục đặt câu", exact: true })
  .click();
assert.equal(
  await page.evaluate(() => document.activeElement.id),
  "dialog-sentence",
);
await page.locator("#dialog-sentence").fill("The risk was negligible.");
await page
  .getByRole("button", { name: "Xem câu minh họa", exact: true })
  .click();
assert.ok(
  await page
    .getByText("The difference in cost was negligible.", { exact: true })
    .isVisible(),
);
await page.screenshot({
  path: "outputs/landing-fixes/practice-sentence-vi.png",
});
await page.keyboard.press("Escape");
await dialog.waitFor({ state: "hidden" });
assert.equal(await launch.evaluate((e) => e === document.activeElement), true);
assert.equal(await heroTab(), beforeTab);
await completePreviews();
assert.deepEqual(await geometry(), beforeCards);
await launch.click();
await dialog.waitFor();
assert.equal(
  await page.locator("#dialog-sentence").inputValue(),
  "The risk was negligible.",
);
await page
  .getByRole("button", { name: "Quay lại luyện nhớ", exact: true })
  .click();
assert.equal(await page.locator("#dialog-answer").inputValue(), "negligible");
await page
  .getByRole("button", { name: "Đóng bài luyện mẫu", exact: true })
  .click();
await dialog.waitFor({ state: "hidden" });
assert.equal(await launch.evaluate((e) => e === document.activeElement), true);
// Hero controls remain independent; either launch can reopen the same local exercise.
await page.getByRole("tab", { name: "3. Luyện" }).click();
await page
  .getByRole("button", { name: "Mở bài luyện mẫu", exact: true })
  .click();
await dialog.waitFor();
await page.keyboard.press("Escape");
assert.equal(await heroTab(), "sample-practice");
await completePreviews();
await page.getByRole("tab", { name: "2. Chọn từ" }).click();
await page
  .getByRole("button", { name: "Lưu từ mẫu", exact: true })
  .first()
  .click();
assert.ok(
  await page
    .getByText("Đã lưu trong ví dụ. Không lưu vào tài khoản.")
    .isVisible(),
);
// Required responsive sizes, both interface languages, normal/reduced motion.
for (const locale of ["vi", "en"]) {
  await page
    .getByRole("button", {
      name: locale === "vi" ? "Tiếng Việt" : "English",
      exact: true,
    })
    .click();
  for (const reduced of [false, true]) {
    await page.emulateMedia({
      reducedMotion: reduced ? "reduce" : "no-preference",
    });
    for (const [width, height] of [
      [1440, 900],
      [1280, 720],
      [1069, 930],
      [390, 844],
    ]) {
      await page.setViewportSize({ width, height });
      await top();
      await page.waitForTimeout(150);
      assert.ok(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
        `${locale}/${width}: overflow`,
      );
      const fits = await page.evaluate(() =>
        [...document.querySelectorAll(".ow-intro,.ow-process")].every(
          (e) => e.scrollHeight <= innerHeight + 1,
        ),
      );
      if (!fits || width < 900) assert.equal(await snap(), "none");
      if (width === 1440) assert.equal(await snap(), "y");
      assert.equal(
        await page.evaluate(
          () => getComputedStyle(document.documentElement).scrollBehavior,
        ),
        reduced ? "auto" : "smooth",
      );
      const cards = await page.locator(".ow-steps article").evaluateAll((es) =>
        es.map((e) => ({
          x: e.getBoundingClientRect().x,
          y: e.getBoundingClientRect().y,
        })),
      );
      if (width < 1200) {
        assert.ok(cards.every((c) => c.x === cards[0].x));
        assert.ok(cards.every((c, i) => !i || c.y > cards[i - 1].y));
      } else assert.ok(cards.every((c) => c.y === cards[0].y));
      const arrow = await page
        .locator(".ow-steps article")
        .first()
        .evaluate((e) => getComputedStyle(e, "::after").content);
      assert.equal(arrow, width < 1200 ? '"↓"' : '"→"');
      await page
        .getByRole("link", {
          name: locale === "vi" ? "Cách học" : "How it works",
          exact: true,
        })
        .click();
      await page.waitForFunction(
        () =>
          Math.abs(
            document.getElementById("how-it-works").getBoundingClientRect().top,
          ) < 3,
      );
      const cta = page.getByRole("button", {
        name: locale === "vi" ? "Bắt đầu ngay" : "Start now",
        exact: true,
      });
      await cta.scrollIntoViewIfNeeded();
      const rect = await cta.boundingBox();
      assert.ok(rect.y >= 0 && rect.y + rect.height <= height);
      if (!reduced) {
        await top();
        await page.screenshot({
          path: `outputs/landing-fixes/${locale}-${width}.png`,
          fullPage: true,
        });
      }
      // Practice stays usable and scrollable on short/mobile screens.
      await page
        .getByRole("button", {
          name:
            locale === "vi" ? "Thử bài luyện mẫu" : "Try the sample exercise",
          exact: true,
        })
        .click();
      await dialog.waitFor();
      assert.ok(
        await page
          .getByRole("button", {
            name: locale === "vi" ? "Kiểm tra từ" : "Check word",
            exact: true,
          })
          .isVisible(),
      );
      await page.keyboard.press("Escape");
      await dialog.waitFor({ state: "hidden" });
    }
  }
}
await page.setViewportSize({ width: 1440, height: 900 });
await page.reload();
await ready();
assert.equal(await page.locator("html").getAttribute("lang"), "en");
await page.evaluate(() => (document.documentElement.style.fontSize = "32px"));
await page.waitForFunction(
  () => !document.documentElement.classList.contains("ow-page-snap"),
);
assert.ok(
  await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth),
);
await page
  .getByRole("button", { name: "Start now", exact: true })
  .scrollIntoViewIfNeeded();
await page.evaluate(() => (document.documentElement.style.fontSize = ""));
// Both CTA destinations retain the original sign-in boundary.
for (const name of ["Start writing", "Start now"]) {
  await load();
  let destination = "";
  await page.route(/signin-with-chatgpt/, async (route) => {
    destination = route.request().url();
    await route.fulfill({
      status: 200,
      contentType: "text/html",
      body: "Verified sign-in boundary",
    });
  });
  await page.getByRole("button", { name, exact: true }).first().click();
  await page.waitForURL(/signin-with-chatgpt/);
  assert.ok(destination.includes("return_to=/start"));
  await page.unroute(/signin-with-chatgpt/);
}
// Browser-level mobile touch swipes, without JS scroll-position manipulation.
const mobile = await browser.newContext({
  viewport: { width: 375, height: 812 },
  isMobile: true,
  hasTouch: true,
});
const touch = await mobile.newPage();
await touch.goto("http://127.0.0.1:5173/");
await touch.waitForFunction(() =>
  document.documentElement.classList.contains("ow-page-scroll"),
);
const cdp = await mobile.newCDPSession(touch);
const swipe = async () => {
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [{ x: 180, y: 700 }],
  });
  for (let y = 650; y >= 150; y -= 50) {
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: [{ x: 180, y }],
    });
    await touch.waitForTimeout(20);
  }
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await touch.waitForTimeout(180);
};
for (let i = 0; i < 9; i++) await swipe();
for (let i = 0; i < 5; i++) await swipe();
const mobileFooter = await touch.locator(".ow-footer").boundingBox();
assert.ok(mobileFooter.y >= 0 && mobileFooter.y + mobileFooter.height <= 814);
assert.deepEqual(writes, []);
assert.deepEqual(errors, []);
console.log(
  "PASS: no departure snap-back; native destination settling, repeated small deltas, keyboard/anchor/history, mobile touch, 16 size/language/motion combinations; stable previews and independent hero; modal focus/Escape/reopen/hints/answer persistence; recall and ungraded sentence stage; both start actions; no learner API writes or browser errors.",
);
await browser.close();
