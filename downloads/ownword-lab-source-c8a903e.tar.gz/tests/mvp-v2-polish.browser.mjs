// Render the actual client components in development and production modes.
// This runs independently of authentication and never writes learner records.
import { build } from "esbuild";
import { createServer } from "node:http";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { createRequire } from "node:module";
import assert from "node:assert/strict";

const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const runtime = resolve(".sites-runtime/polish-ui");
mkdirSync(runtime, { recursive: true });
mkdirSync("outputs/mvp-v2-polish", { recursive: true });
const source = `
  import { createRoot } from 'react-dom/client';
  import { LanguageProvider } from './components/language-provider';
  import { Writing } from './components/writing';
  import { Settings } from './components/preferences';
  const mock = new URLSearchParams(location.search).get('mock') === '1';
  const state = {profile:{id:'demo-guard-test',name:'Test',dailyLimit:7,createdAt:'2026-10-27',onboarded:true},words:[],dueCount:0,queuedCount:0,writingCount:0,insights:[],mockMode:mock};
  const refresh = async () => state;
  createRoot(document.getElementById('root')).render(
    <LanguageProvider initialLocale="en">
      <Writing onboarding={false} mock={mock} userId={state.profile.id} refresh={refresh} notify={()=>{}} navigate={()=>{}} practice={async()=>{}} />
      <Settings state={state} refresh={refresh} notify={()=>{}} />
    </LanguageProvider>
  );
`;
for (const mode of ["development", "production"]) {
  await build({
    stdin: { contents: source, resolveDir: process.cwd(), loader: "jsx" },
    outfile: resolve(runtime, `${mode}.js`),
    bundle: true,
    platform: "browser",
    format: "esm",
    jsx: "automatic",
    alias: { "@": process.cwd() },
    define: { "process.env.NODE_ENV": JSON.stringify(mode) },
    minify: mode === "production",
  });
}
const server = createServer((request, response) => {
  const url = new URL(request.url, "http://localhost");
  if (["/development.js", "/production.js"].includes(url.pathname)) {
    response.writeHead(200, { "Content-Type": "text/javascript" });
    response.end(readFileSync(resolve(runtime, url.pathname.slice(1))));
    return;
  }
  const mode = url.pathname === "/production" ? "production" : "development";
  response.writeHead(200, { "Content-Type": "text/html" });
  response.end(
    `<!doctype html><html><head><meta charset="utf-8"></head><body><div id="root"></div><script type="module" src="/${mode}.js"></script></body></html>`,
  );
});
await new Promise((done) => server.listen(0, "127.0.0.1", done));
let browser;
const results = [];
try {
  browser = await chromium.launch({
    headless: true,
    ...(process.env.BROWSER_EXECUTABLE
      ? { executablePath: process.env.BROWSER_EXECUTABLE }
      : { channel: process.env.BROWSER_CHANNEL || "msedge" }),
  });
  const page = await browser.newPage();
  await page.addInitScript(() =>
    sessionStorage.removeItem("ownword:writing:demo-guard-test"),
  );
  await page.route("**/api/analyze", (route) =>
    route.fulfill({
      json: {
        sampleId: "empty-demo-guard-review",
        text: route.request().postDataJSON().text,
        suggestions: [],
        opportunities: [],
        usages: [],
        summary: "No new suggestions.",
      },
    }),
  );
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  for (const mode of ["development", "production"]) {
    for (const mock of [false, true]) {
      await page.goto(
        `http://127.0.0.1:${server.address().port}/${mode}?mock=${Number(mock)}`,
      );
      await page.waitForFunction(
        () => document.querySelector("#writing-text")?.disabled === false,
      );
      assert.equal(
        await page
          .getByRole("heading", { name: "Settings", exact: true })
          .count(),
        1,
      );
      const expected = mode === "development" && mock ? 1 : 0;
      const examples = await page.locator(".demo-tools").count();
      const tools = await page.locator(".settings-demo-tools").count();
      assert.equal(examples, expected, `${mode}, mock=${mock}: Demo examples`);
      assert.equal(tools, expected, `${mode}, mock=${mock}: Demo tools`);
      await page
        .locator("#writing-text")
        .fill("This is an ordinary passage for checking the empty review.");
      await page
        .getByRole("button", { name: "Review suggestions", exact: true })
        .click();
      await page.locator(".review-complete").waitFor();
      const emptyReviewExample = await page
        .getByRole("button", { name: "Try another demo example", exact: true })
        .count();
      assert.equal(
        emptyReviewExample,
        expected,
        `${mode}, mock=${mock}: empty-review demo control`,
      );
      results.push({ mode, mock, examples, tools, emptyReviewExample });
    }
  }
  assert.deepEqual(errors, []);
  writeFileSync(
    "outputs/mvp-v2-polish/demo-controls-checks.json",
    JSON.stringify({ results, errors }, null, 2),
  );
  console.log(JSON.stringify({ results, errors }, null, 2));
} finally {
  if (browser) await browser.close();
  await new Promise((done) => server.close(done));
}
