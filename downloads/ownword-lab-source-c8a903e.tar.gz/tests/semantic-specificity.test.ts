import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { semanticSpecificity } from "../lib/llm/semantic-specificity";
import { inspectAnalysisProposals } from "../lib/llm/gemini";

const cases: Array<[string,string,string,string,boolean]> = [
  ["history of the stamp", "provenance", "origin and ownership history", "origin-or-ownership-history", false],
  ["history of the stamp's origin and ownership", "provenance", "origin and ownership history", "origin-or-ownership-history", true],
  ["difference between two measurements", "discrepancy", "inconsistency or mismatch", "mismatch-or-inconsistency", true],
  ["difference in preference", "discrepancy", "inconsistency or mismatch", "mismatch-or-inconsistency", false],
  ["a change in conditions", "deterioration", "a worsening condition", "worsening", false],
  ["a change for the worse", "deterioration", "a worsening condition", "worsening", true],
  ["an effect on operations", "transformation", "a fundamental change", "fundamental-change", false],
  ["a fundamental structural change", "transformation", "a fundamental change", "fundamental-change", true],
  ["a concern about the proposal", "risk", "possibility of harm", "possible-harm", false],
  ["a concern about possible harm", "risk", "possibility of harm", "possible-harm", true],
  ["a problem with the device", "malfunction", "failure to work", "functional-failure", false],
  ["a problem: the device stopped functioning correctly", "malfunction", "failure to work", "functional-failure", true],
  ["the results provided more support for earlier findings", "corroborate", "provide supporting evidence", "mismatch-or-inconsistency", true],
  ["the problem was made less severe", "mitigate", "reduce severity", "functional-failure", true],
  ["the estimate is not final and may be revised", "provisional", "subject to revision", "fundamental-change", true],
  ["history of the stamp", "background", "the origin and previous ownership of an item", "origin-or-ownership-history", false],
  ["history with no known ownership", "provenance", "origin and ownership history", "origin-or-ownership-history", false],
  ["a change for the better", "deterioration", "a worsening condition", "worsening", false],
];
for (const [source, candidate, teaching, dimension, allowed] of cases) {
  test(`specificity ${source} → ${candidate}: ${allowed ? "allow" : "reject"}`, () => {
    assert.equal(semanticSpecificity(source, candidate, teaching).includes(dimension), !allowed);
  });
}
test("saved C02 proposal is rejected by the application", () => {
  const run = JSON.parse(readFileSync("evals/results/final-validation-3.6-2026-10-30/results.json", "utf8"));
  const row = run.rows.find((r: {case: {id:string}}) => r.case.id === "C02");
  const result = inspectAnalysisProposals(row.case.input, row.requests[0].rawModelOutput);
  assert.equal(result.suggestions.length, 0);
  assert.ok(result.audit[0].qualityIssues.includes("unsupported-semantic-specificity"));
});
