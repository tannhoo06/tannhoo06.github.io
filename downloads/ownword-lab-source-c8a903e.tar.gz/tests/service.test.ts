import test from "node:test";
import assert from "node:assert/strict";
import { VocabularyService } from "../lib/services/vocabulary";
import type { Repository } from "../lib/domain/ports";
import type { Attempt, Exercise, UserWord } from "../lib/domain/types";
import { MockLlm } from "../lib/llm/mock";
import { CATALOG } from "../lib/llm/catalog";
import { introductionQueue } from "../lib/domain/learning";
import { dueWords, practiceCandidates } from "../lib/domain/learning";

test("words waiting for definitions stay visible but cannot enter practice", () => {
  const ready = fixture().word;
  const pending = { ...ready, userWordId: "pending", word: "intransigence", definition: "" };
  assert.deepEqual(practiceCandidates([pending, ready], new Date("2026-01-02"), 5).map((w) => w.userWordId), ["uw1"]);
  assert.deepEqual(dueWords([pending, ready], new Date("2026-01-02"), 5).map((w) => w.userWordId), ["uw1"]);
  assert.deepEqual(introductionQueue([{ ...pending, introducedAt: null }], new Date("2026-01-02")), []);
});

function fixture() {
  const word: UserWord = {
    ...CATALOG[0],
    userWordId: "uw1",
    addedAt: "2026-01-01T12:00:00.000Z",
    introducedAt: "2026-01-01T12:00:00.000Z",
    source: "fixture",
    sourceText: "small difference",
    demo: false,
    stage: "new",
    nextReviewAt: "2026-01-01T12:00:00.000Z",
    attempts: [],
  };
  const exercise: Exercise = {
    id: "exercise1",
    sessionId: "session1",
    userWordId: "uw1",
    kind: "strong",
    prompt: "So small that it makes little practical difference.",
    context: "technology",
    semanticHint: word.definition,
    hint: "none",
    sentencePending: false,
    answeredAt: null,
  };
  const attempts: Attempt[] = [];
  const repository = {
    listWords: async () => [{ ...word, attempts: [...attempts] }],
    getExercise: async (_owner: string, id: string) =>
      id === exercise.id ? { ...exercise } : null,
    getSession: async (_owner: string, id: string) =>
      id === exercise.sessionId ? [{ ...exercise }] : [],
    setHint: async (_owner: string, _id: string, hint: Exercise["hint"]) => {
      exercise.hint = hint;
    },
    setSentencePending: async () => {
      if (exercise.answeredAt) return false;
      exercise.sentencePending = true;
      return true;
    },
    recordAttempt: async (
      _owner: string,
      attempt: Attempt,
      stage: UserWord["stage"],
      next: string,
    ) => {
      if (attempts.some((a) => a.exerciseId === attempt.exerciseId))
        return false;
      attempts.push(attempt);
      word.stage = stage;
      word.nextReviewAt = next;
      exercise.answeredAt = attempt.at;
      return true;
    },
  } as unknown as Repository;
  let n = 0;
  const service = new VocabularyService(
    repository,
    new MockLlm(),
    { id: "owner", name: "Test", email: "test@example.com" },
    { now: () => new Date("2026-01-02T12:00:00.000Z") },
    { next: () => `id${++n}` },
  );
  return { service, word, exercise, attempts };
}
test("wrong answers retry without revealing the word; recall then opens the sentence step", async () => {
  const f = fixture();
  const first = await f.service.answer("exercise1", "I cannot remember");
  assert.equal(first.retry, true);
  assert.equal(first.incorrect, true);
  assert.equal(first.target, null);
  assert.equal(f.exercise.hint, "none");
  assert.equal(f.attempts.length, 0);
  const again = await f.service.answer("exercise1", "small");
  assert.equal(again.retry, true);
  assert.equal(f.exercise.hint, "none");
  const recalled = await f.service.answer("exercise1", "negligible");
  assert.equal(recalled.retry, true);
  assert.equal(recalled.sentencePending, true);
  assert.equal(f.exercise.sentencePending, true);
  assert.equal(
    (await f.service.session("session1")).exercise?.sentencePending,
    true,
  );
  const final = await f.service.answer(
    "exercise1",
    "The difference in the final cost is negligible.",
  );
  assert.equal(final.retry, false);
  assert.equal(f.attempts[0].retrieved, true);
  assert.equal(f.attempts[0].precise, true);
  assert.equal(f.attempts[0].hint, "none");
});
test("a revealed answer must be used in context before completing its exercise", async () => {
  const f = fixture();
  await f.service.hint("exercise1", "revealed");
  const result = await f.service.answer("exercise1", "negligible");
  assert.equal(result.retry, true);
  assert.equal(f.attempts.length, 0);
});

test("a revealed single-word retry can be skipped without recall credit", async () => {
  const f = fixture();
  await f.service.hint("exercise1", "revealed");
  const retry = await f.service.answer("exercise1", "negligible");
  assert.equal(retry.retry, true);
  assert.equal(f.exercise.answeredAt, null);

  const skipped = await f.service.skip("exercise1");
  assert.equal(skipped.retry, false);
  assert.equal(skipped.skipped, true);
  assert.equal(f.attempts.length, 1);
  assert.equal(f.attempts[0].retrieved, false);
  assert.equal(f.attempts[0].precise, false);
  assert.equal(f.attempts[0].hint, "revealed");
  assert.ok(f.exercise.answeredAt);
  await assert.rejects(() => f.service.skip("exercise1"), /no longer open/);
});

test("skipping the sentence preserves the prior recall without inventing precise use", async () => {
  const f = fixture();
  await f.service.answer("exercise1", "negligible");
  const skipped = await f.service.skip("exercise1");
  assert.equal(skipped.retry, false);
  assert.equal(f.attempts[0].retrieved, true);
  assert.equal(f.attempts[0].precise, false);
  assert.equal(f.exercise.answeredAt !== null, true);
});

test("skipping is unavailable before the word is revealed", async () => {
  const f = fixture();
  await assert.rejects(() => f.service.skip("exercise1"), /shown the word/);
  assert.equal(f.attempts.length, 0);
});
test("synonyms leave the target hidden and allow another retrieval attempt", async () => {
  const f = fixture();
  const result = await f.service.answer("exercise1", "insignificant");
  assert.equal(result.retry, true);
  assert.equal(result.target, null);
  assert.equal(f.exercise.hint, "none");
  assert.equal(f.attempts.length, 0);
});
test("hint requests cannot lower already revealed credit", async () => {
  const f = fixture();
  await f.service.hint("exercise1", "revealed");
  const result = await f.service.hint("exercise1", "semantic");
  assert.equal(result.hint, "revealed");
});
test("completed exercise submissions cannot be counted twice", async () => {
  const f = fixture();
  await f.service.answer("exercise1", "negligible");
  await f.service.answer("exercise1", "The difference in cost is negligible.");
  await assert.rejects(
    () => f.service.answer("exercise1", "negligible"),
    /already been saved/,
  );
  assert.equal(f.attempts.length, 1);
});

test("every scheduled exercise kind retains its learning kind and requires a sentence after recall", async () => {
  for (const kind of [
    "strong",
    "completion",
    "rewrite",
    "open",
    "free",
    "contrast",
  ] as const) {
    const f = fixture();
    f.exercise.kind = kind;
    const recall = await f.service.answer("exercise1", "negligible");
    assert.equal(recall.sentencePending, true, kind);
    assert.equal(f.attempts.length, 0);
    const completed = await f.service.answer(
      "exercise1",
      "The difference in the final cost is negligible.",
    );
    assert.equal(completed.retry, false);
    assert.equal(f.attempts[0].kind, kind);
    assert.equal(f.attempts[0].context, "technology");
  }
});

test("completed session outcomes come from persisted attempts, including recall-only skips and reveals", async () => {
  const f = fixture();
  await f.service.answer("exercise1", "negligible");
  await f.service.skip("exercise1");
  const recap = await f.service.session("session1");
  assert.equal(recap.complete, true);
  assert.equal(recap.exercise, null);
  assert.equal(recap.results.length, 1);
  assert.equal(recap.results[0].outcome, "recalled-skipped");
  const revealed = fixture();
  await revealed.service.hint("exercise1", "revealed");
  await revealed.service.answer(
    "exercise1",
    "The difference in the final cost is negligible.",
  );
  assert.equal(
    (await revealed.service.session("session1")).results[0].outcome,
    "reviewed",
  );
  assert.equal(revealed.attempts[0].retrieved, false);
  assert.equal(revealed.attempts[0].hint, "revealed");
});

test("hinted recall survives a skipped sentence without losing the authoritative hint level", async () => {
  const f = fixture();
  await f.service.hint("exercise1", "letter");
  await f.service.answer("exercise1", "negligible");
  await f.service.skip("exercise1");
  assert.equal(f.attempts[0].retrieved, true);
  assert.equal(f.attempts[0].precise, false);
  assert.equal(f.attempts[0].hint, "letter");
});
test("new words queued yesterday become eligible even if no introduced words are due", () => {
  const f = fixture();
  const words: UserWord[] = Array.from({ length: 10 }, (_, i) => ({
    ...f.word,
    userWordId: `w${i}`,
    introducedAt: null,
  }));
  assert.equal(
    introductionQueue(words, new Date("2026-01-02T12:00:00Z")).length,
    3,
  );
  words[0].introducedAt = "2026-01-02T12:00:00Z";
  assert.equal(
    introductionQueue(words, new Date("2026-01-02T12:00:00Z")).length,
    2,
  );
});
