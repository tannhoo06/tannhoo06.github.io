import test from "node:test";
import assert from "node:assert/strict";
import {
  credit,
  practiceCandidates,
  practiceReviewDate,
  DEFAULT_POLICY,
  dueWords,
  evidence,
  nextReview,
  progress,
} from "../lib/domain/learning";
import type { Attempt, Exercise, UserWord } from "../lib/domain/types";
import { MockLlm } from "../lib/llm/mock";
import { GeminiLlm } from "../lib/llm/gemini";
import { CATALOG } from "../lib/llm/catalog";
import { applySpellingHint } from "../lib/domain/practice-hints";
import { readConfig } from "../lib/config";
import { findInsights } from "../lib/services/insights";
const at = (day: number) => new Date(Date.UTC(2026, 0, day, 12)).toISOString();
test("spelling hints fill the answer, including a resumed partial hint", () => {
  assert.equal(applySpellingHint("", "letter", "articulate"), "a");
  assert.equal(applySpellingHint("", "partial", "articulate"), "art");
  assert.equal(applySpellingHint("xyziculate", "partial", "articulate"), "articulate");
  assert.equal(applySpellingHint("art", "none", "articulate"), "art");
});
const attempt = (day: number, extra: Partial<Attempt> = {}): Attempt => ({
  id: `a-${day}`,
  userWordId: "uw1",
  exerciseId: `e-${day}`,
  at: at(day),
  kind: "completion",
  hint: "none",
  answer: "The difference was negligible.",
  retrieved: true,
  precise: true,
  majorMisuse: false,
  context: "technology",
  feedback: "Natural use.",
  spellingCorrection: null,
  ...extra,
});
const word: UserWord = {
  ...CATALOG[0],
  userWordId: "uw1",
  addedAt: at(1),
  introducedAt: at(1),
  source: "test",
  sourceText: "small difference",
  demo: false,
  stage: "new",
  nextReviewAt: at(1),
  attempts: [],
};
const activeHistory = () => [
  attempt(1),
  attempt(3, { context: "finance" }),
  attempt(5, { context: "environment" }),
  attempt(7),
  attempt(9, { kind: "open" }),
];
test("immediate repetitions cannot advance New to Practicing", () => {
  const repeated = Array.from({ length: 10 }, (_, i) =>
    attempt(1, {
      id: `a${i}`,
      at: new Date(Date.parse(at(1)) + i * 60000).toISOString(),
    }),
  );
  assert.equal(progress("new", repeated), "new");
  assert.equal(evidence(repeated).successes, 1);
});
test("crossing midnight without a real interval is still one occasion", () => {
  const history = [
    attempt(1, { at: "2026-01-01T23:59:00Z" }),
    attempt(2, { at: "2026-01-02T00:01:00Z" }),
  ];
  assert.equal(progress("new", history), "new");
});
test("two separate occasions need at least one contextually correct use", () => {
  assert.equal(
    progress("new", [
      attempt(1, { kind: "strong", precise: false }),
      attempt(2, { kind: "strong", precise: false }),
    ]),
    "new",
  );
  assert.equal(
    progress("new", [
      attempt(1, { kind: "strong", precise: false }),
      attempt(2),
    ]),
    "practicing",
  );
});
test("Active requires context diversity, retention, independence and recent success together", () => {
  assert.equal(progress("practicing", activeHistory()), "active");
  assert.equal(
    progress(
      "practicing",
      activeHistory().map((a) => ({ ...a, context: "technology" })),
    ),
    "practicing",
  );
  assert.equal(
    progress(
      "practicing",
      activeHistory().map((a) => ({ ...a, kind: "completion" })),
    ),
    "practicing",
  );
  assert.equal(
    progress(
      "practicing",
      activeHistory().map((a, i) => ({ ...a, at: at(i + 1) })),
    ),
    "practicing",
  );
});
test("hints lower credit and a revealed answer never earns recall credit", () => {
  assert.ok(credit(attempt(1)) > credit(attempt(1, { hint: "semantic" })));
  assert.equal(credit(attempt(1, { hint: "revealed" })), 0);
  assert.equal(evidence([attempt(1, { hint: "revealed" })]).successes, 0);
  assert.equal(evidence([attempt(1, { hint: "revealed" })]).recall, 0);
});
test("one failed Active review is grace, failures on two dates return to Practicing", () => {
  const first = [
    ...activeHistory(),
    attempt(16, { retrieved: false, precise: false }),
  ];
  assert.equal(progress("active", first), "active");
  assert.equal(
    progress("active", [
      ...first,
      attempt(16, { retrieved: false, precise: false, id: "repeat" }),
    ]),
    "active",
  );
  assert.equal(
    progress("active", [
      ...first,
      attempt(17, { retrieved: false, precise: false }),
    ]),
    "practicing",
  );
});
test("revealed maintenance reviews participate in the grace system", () => {
  assert.equal(
    progress("active", [
      ...activeHistory(),
      attempt(16, { hint: "revealed" }),
      attempt(17, { hint: "revealed" }),
    ]),
    "practicing",
  );
});
test("maintenance expands from 7 through 21, 45 and 90 days", () => {
  const base = activeHistory();
  const now = new Date(at(30));
  assert.equal(nextReview("active", base, now), at(37));
  assert.equal(nextReview("active", [...base, attempt(16)], now), at(51));
  assert.equal(
    nextReview("active", [...base, attempt(16), attempt(23)], now),
    at(75),
  );
  assert.equal(
    nextReview("active", [...base, attempt(16), attempt(23), attempt(30)], now),
    at(120),
  );
});
test("queue does not put all added words into a session", () => {
  const words = Array.from({ length: 18 }, (_, i) => ({
    ...word,
    userWordId: `w${i}`,
    introducedAt: i < 3 ? at(1) : null,
  }));
  assert.equal(dueWords(words, new Date(at(2))).length, 3);
  assert.equal(
    dueWords(
      words.map((w) => ({ ...w, introducedAt: at(1) })),
      new Date(at(2)),
    ).length,
    6,
  );
});
test("policy thresholds are configurable and validated", () => {
  assert.equal(
    progress("practicing", activeHistory(), {
      ...DEFAULT_POLICY,
      activeSuccesses: 6,
    }),
    "practicing",
  );
  assert.equal(
    readConfig({ LEARNING_POLICY_JSON: '{"activeSpanDays":14}' }).policy
      .activeSpanDays,
    14,
  );
  assert.throws(() =>
    readConfig({ LEARNING_POLICY_JSON: '{"activeSpanDays":0}' }),
  );
  assert.throws(() => readConfig({ LLM_MODE: "gemini" }));
});
test("mock suggestions respect collocation and never upgrade a big dog", async () => {
  const llm = new MockLlm();
  assert.equal(
    (await llm.suggestVocabulary("I saw a very big dog today.")).length,
    0,
  );
  assert.equal(
    (await llm.suggestVocabulary("The new route had a very big impact."))[0]
      .word,
    "substantial",
  );
});
test("valid synonyms are acknowledged without claiming retrieval of target", async () => {
  const result = await new MockLlm().evaluateRecall(
    word,
    { kind: "strong" } as Exercise,
    "insignificant",
  );
  assert.equal(result.validAlternative, true);
  assert.equal(result.retrieved, false);
  assert.ok(!/wrong/i.test(result.feedback));
});
test("minor spelling mistakes retain lexical retrieval", async () => {
  const result = await new MockLlm().evaluateRecall(
    word,
    { kind: "strong" } as Exercise,
    "negligable",
  );
  assert.equal(result.retrieved, true);
  assert.equal(result.spellingCorrection, "negligible");
  assert.equal(result.precise, false);
});
test("independent exercises do not name the target word", async () => {
  for (const kind of ["open", "free"] as const) {
    const exercise = await new MockLlm().generateExercise(
      word,
      kind,
      "finance",
    );
    assert.ok(!exercise.prompt.includes(word.word));
  }
});
test("tracked words become retrieval opportunities instead of duplicate suggestions", async () => {
  const result = await new MockLlm().analyzeWriting(
    "There is a very small difference in cost.",
    [word],
  );
  assert.equal(result.suggestions.length, 0);
  assert.equal(result.opportunities[0].userWordId, "uw1");
  assert.ok(!result.opportunities[0].prompt.includes(word.word));
});
test("insight counts come from writing and do not include substring matches", () => {
  assert.equal(
    findInsights([
      { text: "Important things are important. Unimportant is different." },
    ])[0].count,
    2,
  );
  assert.deepEqual(findInsights([]), []);
});
test("Gemini uses server-side structured requests and validates its response", async () => {
  let called = false;
  const request = (async (_url: unknown, init: RequestInit) => {
    called = true;
    const body = JSON.parse(init.body as string);
    assert.equal(
      (init.headers as Record<string, string>)["x-goog-api-key"],
      "test-only-key",
    );
    assert.equal(body.generationConfig.responseMimeType, "application/json");
    assert.ok(body.generationConfig.responseSchema);
    return Response.json({
      candidates: [
        { content: { parts: [{ text: '{"not":"the expected schema"}' }] } },
      ],
    });
  }) as typeof fetch;
  const provider = new GeminiLlm("test-only-key", "gemini-2.5-flash", request);
  await assert.rejects(
    () => provider.analyzeWriting("Some short writing.", []),
    /expected format/,
  );
  assert.equal(called, true);
});

test("practice prioritizes due words but includes future and queued words", () => {
  const future = { ...word, userWordId: "future", nextReviewAt: at(20) };
  const queued = {
    ...word,
    userWordId: "queued",
    introducedAt: null,
    nextReviewAt: at(21),
  };
  assert.deepEqual(
    practiceCandidates([future, queued, word], new Date(at(10)), 10).map(
      (w) => w.userWordId,
    ),
    ["uw1", "future", "queued"],
  );
});
test("voluntary practice preserves a future scheduled date", () => {
  const future = { ...word, nextReviewAt: at(20) };
  for (const day of [10, 11, 12])
    assert.equal(
      practiceReviewDate(future, "new", [attempt(day)], new Date(at(day))),
      at(20),
    );
  assert.notEqual(
    practiceReviewDate(word, "new", [attempt(10)], new Date(at(10))),
    word.nextReviewAt,
  );
});
test("quick review ratings cannot promote or demote mastery", () => {
  const ratings = Array.from({ length: 12 }, (_, i) =>
    attempt(i + 1, {
      context: "quick-review",
      precise: false,
      hint: "revealed",
    }),
  );
  assert.equal(evidence(ratings).successes, 0);
  assert.equal(progress("new", ratings), "new");
  assert.equal(
    progress(
      "active",
      ratings.map((a) => ({ ...a, retrieved: false })),
    ),
    "active",
  );
});
