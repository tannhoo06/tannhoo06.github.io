import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { readConfig } from "../lib/config";
import { createLlmProvider } from "../lib/llm/provider-factory";
import { OpenRouterLlm, toJsonSchema } from "../lib/llm/openrouter";
import { CATALOG } from "../lib/llm/catalog";
import type { Exercise, UserWord } from "../lib/domain/types";

const model = "google/gemini-3.6-flash";
const response = (content: unknown, name=model) => Response.json({model:name,choices:[{finish_reason:"stop",message:{content:JSON.stringify(content)}}]});
const empty = {suggestions:[],opportunities:[],usages:[],summary:""};
test("OpenRouter configuration uses one server-side key and explicit model", () => {
  assert.deepEqual(readConfig({LLM_PROVIDER:"openrouter",OPENROUTER_API_KEY:" secret "}).llm,{provider:"openrouter",key:"secret",model});
  assert.throws(()=>readConfig({LLM_PROVIDER:"openrouter"}), /OPENROUTER_API_KEY/);
  assert.throws(()=>readConfig({LLM_PROVIDER:"openrouter",OPENROUTER_API_KEY:"a\nb"}), /OPENROUTER_API_KEY/);
  assert.throws(()=>readConfig({LLM_PROVIDER:"openrouter",OPENROUTER_API_KEY:"a",OPENROUTER_MODEL:"latest"}), /provider\/model/);
});
test("Gemini nullable and object schemas convert to strict JSON Schema", () => {
  assert.deepEqual(toJsonSchema({type:"OBJECT",properties:{a:{type:"STRING",nullable:true}},required:["a"]}),{type:"object",properties:{a:{type:["string","null"]}},required:["a"],additionalProperties:false});
});
test("provider sends structured request and keeps existing safety postprocessing", async () => {
  let calls=0;
  const request: typeof fetch = async (url,init) => {
    calls++;
    assert.equal(url,"https://openrouter.ai/api/v1/chat/completions");
    assert.equal(new Headers(init?.headers).get("authorization"),"Bearer test-key");
    assert.equal(new Headers(init?.headers).get("x-openrouter-metadata"),"enabled");
    const body=JSON.parse(String(init?.body));
    assert.equal(body.model,model); assert.equal(body.max_tokens,4096); assert.equal(body.temperature,0.3);
    assert.equal(body.response_format.type,"json_schema"); assert.equal(body.provider.require_parameters,true); assert.equal(body.provider.allow_fallbacks,true); assert.equal("models" in body,false);
    assert.match(body.messages[0].content,/untrusted data/);
    return response(empty);
  };
  const provider=createLlmProvider({provider:"openrouter",key:"test-key",model},{rotationStore:{reserve:async()=>{throw Error("no rotation");}},request});
  assert.equal(provider.mode,"openrouter");
  const result=await provider.analyzeWriting("My dog is big.",[]);
  assert.deepEqual(result.suggestions,[]); assert.equal(calls,1);
});
test("manual word definition uses the model response and rejects circular entries", async () => {
  let calls = 0;
  const request: typeof fetch = async (_url, init) => {
    calls++;
    const body = JSON.parse(String(init?.body));
    assert.match(body.messages[0].content, /dictionary entry/);
    assert.deepEqual(JSON.parse(body.messages[1].content).input, { word: "intransigence" });
    return response({
      partOfSpeech: "noun",
      definition: calls === 1 ? "Refusal to change a firmly held position or compromise." : "Intransigence means not changing your position.",
      nuance: "Often suggests stubbornness in a dispute.",
      collocations: ["political intransigence"],
      examples: ["Their intransigence stalled the negotiations."],
    });
  };
  const provider = new OpenRouterLlm("test-key", model, request);
  assert.equal((await provider.defineWord("intransigence")).definition, "Refusal to change a firmly held position or compromise.");
  await assert.rejects(() => provider.defineWord("intransigence"), /definition was not suitable/);
});
test("recall uses shared evidence guards and default system instruction", async () => {
  const request: typeof fetch=async (_url,init)=>{
    const body=JSON.parse(String(init?.body)); assert.match(body.messages[0].content,/careful English vocabulary retrieval tutor/);
    return response({retrieved:true,precise:true,majorMisuse:false,validAlternative:false,spellingCorrection:null,feedback:"Correct: negligible.",nuance:""});
  };
  const provider=new OpenRouterLlm("test-key",model,request);
  const result=await provider.evaluateRecall(CATALOG.find(x=>x.word==="negligible")!,{kind:"strong",hint:"none"} as Exercise,"banana");
  assert.equal(result.retrieved,false); assert.equal(result.precise,false); assert.doesNotMatch(result.feedback,/negligible/i);
});

test("grading prompts include lexical meaning but no preset context or learner history", async () => {
  const inputs: Record<string, unknown>[] = [];
  const request: typeof fetch = async (_url, init) => {
    const body = JSON.parse(String(init?.body));
    inputs.push(JSON.parse(body.messages[1].content).input);
    return response({retrieved:false,precise:false,majorMisuse:false,validAlternative:false,spellingCorrection:null,feedback:"Try again.",nuance:""});
  };
  const word = {
    ...CATALOG.find((entry) => entry.word === "negligible")!,
    userWordId: "private-user-word-id",
    sourceText: "private source text",
    nextReviewAt: "2099-01-01",
    attempts: [{answer: "private prior answer"}],
    lexemeOverride: {definition: "duplicate private metadata"},
  };
  const exercise = {
    id: "private-exercise-id",
    sessionId: "private-session-id",
    userWordId: word.userWordId,
    kind: "strong",
    prompt: "Which word means too small to matter?",
    context: "finance",
    semanticHint: "Too small to matter",
    hint: "partial",
    sentencePending: true,
    answeredAt: null,
  } as Exercise;
  const provider = new OpenRouterLlm("test-key", model, request);
  await provider.evaluateRecall(word, exercise, "A negligible difference remained.");
  await provider.evaluateUsage(word, "The difference was negligible.", "finance");
  assert.equal(inputs.length, 2);
  for (const input of inputs) {
    const target = (input.target ?? input.word) as Record<string, unknown>;
    assert.deepEqual(Object.keys(target).sort(), ["word", "partOfSpeech", "definition"].sort());
    assert.equal(target.definition, word.definition);
    assert.doesNotMatch(JSON.stringify(input), /private-|duplicate private metadata|nextReviewAt|attempts|lexemeOverride/);
  }
  assert.deepEqual(inputs[0].exercise, {
    kind: exercise.kind,
    hint: exercise.hint,
    sentencePending: exercise.sentencePending,
  });
  assert.equal(Object.hasOwn(inputs[1], "context"), false);
  assert.doesNotMatch(JSON.stringify(inputs), /finance|Which word means/);
});

test("exercise generation does not impose a preset domain or send attempt history", async () => {
  let input: Record<string, unknown> | null = null;
  const request: typeof fetch = async (_url, init) => {
    const body = JSON.parse(String(init?.body));
    input = JSON.parse(body.messages[1].content).input;
    return response({prompt:"Describe a small effect in a finance setting without naming the target.",semanticHint:"An effect too small to matter."});
  };
  const word: UserWord = {
    ...CATALOG.find((entry) => entry.word === "negligible")!,
    userWordId: "private-user-word-id",
    addedAt: "2026-01-01",
    introducedAt: null,
    source: "Manual",
    sourceText: "private source text",
    demo: false,
    stage: "new",
    nextReviewAt: "2026-01-02",
    attempts: [{id:"private-attempt-id",userWordId:"private-user-word-id",exerciseId:"private-exercise-id",at:"2026-01-01",kind:"strong",hint:"none",answer:"private prior answer",retrieved:false,precise:false,majorMisuse:false,context:"private previous context",feedback:"",spellingCorrection:null}],
  };
  await new OpenRouterLlm("test-key", model, request).generateExercise(word, "open", "finance");
  assert.deepEqual(input, {word:"negligible",definition:word.definition,kind:"open"});
});
test("writing output still passes the existing semantic-specificity guard", async () => {
  const run=JSON.parse(readFileSync("evals/results/final-validation-3.6-2026-10-30/results.json","utf8"));
  const row=run.rows.find((r:{case:{id:string}})=>r.case.id==="C02");
  const provider=new OpenRouterLlm("test-key",model,async()=>response(row.requests[0].rawModelOutput));
  const result=await provider.analyzeWriting(row.case.input,[]);
  assert.equal(result.suggestions.length,0);
});
test("unexpected model, malformed response and rate limits fail closed", async () => {
  for (const reply of [response(empty,"different/model"), Response.json({model,choices:[{message:{content:"broken"}}]}), new Response("busy",{status:429})]) {
    const provider=new OpenRouterLlm("secret",model,async()=>reply);
    await assert.rejects(provider.analyzeWriting("My dog is big.",[]), (error:Error)=>!error.message.includes("secret"));
  }
});
