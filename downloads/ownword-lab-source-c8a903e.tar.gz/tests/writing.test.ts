import test from "node:test";
import assert from "node:assert/strict";
import { resolveSource, validSource } from "../lib/domain/anchors";
import { MockLlm } from "../lib/llm/mock";
import { VocabularyService } from "../lib/services/vocabulary";
import type { Repository } from "../lib/domain/ports";
import type { Suggestion, UserWord, WritingReview } from "../lib/domain/types";

test("anchors reject ambiguous repeats, invalid offsets, stale versions and half-surrogates", () => {
  const text = "🙂 A small difference. A small difference!";
  assert.equal(resolveSource(text, "small difference", "v1"), null);
  const start = text.lastIndexOf("small difference");
  const source = resolveSource(text, "small difference", "v1", {
    start,
    end: start + 16,
  });
  assert.ok(source);
  assert.equal(source.sentence, "A small difference!");
  assert.equal(validSource(text, "v1", source), true);
  assert.equal(validSource(text, "v2", source), false);
  assert.equal(validSource("Changed " + text, "v1", source), false);
  assert.equal(
    resolveSource(text, "small difference", "v1", {
      start: start - 1,
      end: start + 15,
    }),
    null,
  );
  assert.equal(resolveSource(text, "\ud83d", "v1"), null);
});

test("anchors preserve Unicode, apostrophes, line breaks and overlapping spans", () => {
  const text = "Café’s idea.\n🙂 A very small difference matters.";
  const broad = resolveSource(text, "very small difference", "sample");
  const narrow = resolveSource(text, "small difference", "sample");
  assert.ok(broad && narrow);
  assert.equal(text.slice(broad.start, broad.end), broad.exact);
  assert.equal(broad.end, narrow.end);
  assert.equal(resolveSource(text, "café’s idea", "sample"), null);
  assert.equal(
    resolveSource(text, "Café’s idea", "sample")?.sentence,
    "Café’s idea.",
  );
});

test("mock rewrite preserves nouns and adjusts articles; unsafe verb rewrites are unavailable", async () => {
  const llm = new MockLlm();
  const result = await llm.analyzeWriting(
    "There was a very small difference in productivity. It was an intentional choice. We bounce back.",
    [],
  );
  assert.equal(
    result.suggestions.find((s) => s.word === "negligible")?.suggestedSentence,
    "There was a negligible difference in productivity.",
  );
  assert.equal(
    result.suggestions.find((s) => s.word === "deliberate")?.suggestedSentence,
    "It was a deliberate choice.",
  );
  assert.equal(
    result.suggestions.find((s) => s.word === "resilient")?.suggestedSentence,
    null,
  );
});

test("after deciding the sample, repeating it has no new words but a fresh draft can add another", async () => {
  const llm = new MockLlm();
  const sample = "I read a very interesting story. It gave me a more detailed view. There was a very small difference, but a very big improvement.";
  const first = await llm.analyzeWriting(sample, []);
  assert.equal(first.suggestions.length, 4);
  const saved = first.suggestions.map((word, index) => ({
    ...word, userWordId: `saved-${index}`, attempts: [],
  })) as unknown as UserWord[];
  assert.equal((await llm.analyzeWriting(sample, saved)).suggestions.length, 0);
  const next = await llm.analyzeWriting(
    "I made an intentional choice. Our possible plan could change. I want to explain clearly why.",
    saved,
  );
  assert.ok(next.suggestions.some((word) => word.word === "deliberate"));
});

test("mock suggestion limit applies after filtering words already on the board", async () => {
  const llm = new MockLlm();
  const text = "A very small difference. A more detailed view. A very interesting story. An intentional choice. A possible plan. I can explain clearly.";
  const first = await llm.suggestVocabulary(text);
  const saved = first.slice(0, 5).map((word, index) => ({ ...word, userWordId: `saved-${index}`, attempts: [] })) as unknown as UserWord[];
  const next = await llm.analyzeWriting(text, saved);
  assert.ok(next.suggestions.some((word) => word.word === "articulate"));
});

function fixture(introduced = 0) {
  let serial = 0;
  const words: UserWord[] = Array.from(
    { length: introduced },
    (_, i) =>
      ({
        userWordId: `existing${i}`,
        word: `existing${i}`,
        introducedAt: "2026-01-02T12:00:00.000Z",
        attempts: [],
      }) as unknown as UserWord,
  );
  const suggestions: Suggestion[] = [];
  const reviews = new Map<string, WritingReview>();
  let practiceStarted = false;
  const repository = {
    ensureUser: async () => ({ id: "owner" }),
    setProfile: async () => {},
    listWords: async () => words,
    saveWriting: async () => "sample",
    listWriting: async () => [],
    saveInsights: async () => {},
    saveSuggestions: async (
      _owner: string,
      sampleId: string,
      items: Suggestion[],
    ) => {
      suggestions.push(
        ...items.map((s, i) => ({
          ...s,
          id: `s${i}`,
          sampleId,
          status: "pending" as const,
        })),
      );
      return suggestions;
    },
    saveReview: async (_owner: string, review: WritingReview) => {
      reviews.set(review.sampleId, review);
    },
    getReview: async (_owner: string, sampleId: string) =>
      reviews.get(sampleId) ?? null,
    recentWritingReview: async () => null,
    getSuggestion: async (_owner: string, id: string) =>
      suggestions.find((s) => s.id === id) ?? null,
    saveDecision: async (
      _owner: string,
      id: string,
      changes: Partial<Suggestion>,
    ) => Object.assign(suggestions.find((s) => s.id === id)!, changes),
    addWord: async (
      _owner: string,
      word: Suggestion,
      options: {
        source: string;
        sourceText: string;
        now: string;
        introduced: boolean;
      },
    ) => {
      const id = `uw${++serial}`;
      words.push({
        ...word,
        id: word.word,
        userWordId: id,
        source: options.source,
        sourceText: options.sourceText,
        introducedAt: options.introduced ? options.now : null,
        addedAt: options.now,
        nextReviewAt: options.now,
        stage: "new",
        demo: false,
        attempts: [],
      });
      return id;
    },
    removeUnpracticedWord: async (
      _owner: string,
      id: string,
      source: string,
    ) => {
      const index = words.findIndex(
        (w) => w.userWordId === id && w.source === source,
      );
      if (index < 0 || practiceStarted || words[index].attempts.length)
        return false;
      words.splice(index, 1);
      return true;
    },
  } as unknown as Repository;
  const service = new VocabularyService(
    repository,
    new MockLlm(),
    { id: "owner", name: "Test", email: "test@example.com" },
    { now: () => new Date("2026-01-02T12:00:00.000Z") },
    { next: () => `id${++serial}` },
  );
  return {
    service,
    suggestions,
    words,
    startPractice: () => {
      practiceStarted = true;
    },
  };
}

test("review persists immutable writing, exact anchors and reversible choices without reanalysis", async () => {
  const f = fixture();
  const text = "  There was a very small difference in productivity.  ";
  const review = await f.service.analyze(text, "");
  assert.equal(review.text, text);
  assert.equal(review.suggestions[0].source?.version, review.sampleId);
  await f.service.decide("s0", "dismissed");
  assert.equal(
    (await f.service.review("sample")).suggestions[0].status,
    "dismissed",
  );
  await f.service.decide("s0", "added");
  assert.equal(f.words.length, 1);
  assert.equal(
    f.words[0].sourceText,
    "There was a very small difference in productivity.",
  );
  await f.service.decide("s0", "pending");
  assert.equal(f.words.length, 0);
  assert.equal(
    (await f.service.review("sample")).suggestions[0].status,
    "pending",
  );
});

test("queued saves survive reload and idempotent retry, then undo removes only the new save", async () => {
  const f = fixture(3);
  await f.service.analyze(
    "There was a very small difference in productivity.",
    "",
  );
  const saved = await f.service.decide("s0", "added");
  assert.equal(saved.queued, true);
  assert.equal(
    (await f.service.decide("s0", "added")).userWordId,
    saved.userWordId,
  );
  assert.equal(f.words.length, 4);
  assert.equal((await f.service.review("sample")).suggestions[0].queued, true);
  await f.service.decide("s0", "dismissed");
  assert.equal(f.words.length, 3);
});

test("reversing a save protects words that have entered practice", async () => {
  const f = fixture();
  await f.service.analyze(
    "There was a very small difference in productivity.",
    "",
  );
  await f.service.decide("s0", "added");
  f.startPractice();
  await assert.rejects(
    () => f.service.decide("s0", "pending"),
    /learning history are preserved/,
  );
  assert.equal(f.words.length, 1);
  assert.equal(f.suggestions[0].status, "added");
});

test("reversing a suggestion never deletes a word saved elsewhere", async () => {
  const f = fixture();
  await f.service.analyze(
    "There was a very small difference in productivity.",
    "",
  );
  f.words.push({
    word: "negligible",
    userWordId: "personal",
    introducedAt: null,
    attempts: [],
  } as unknown as UserWord);
  await f.service.decide("s0", "added");
  await f.service.decide("s0", "pending");
  assert.equal(f.words[0].userWordId, "personal");
});
