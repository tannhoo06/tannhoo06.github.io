import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { test } from "node:test";
import { cognitoOwnerId } from "../lib/auth/cognito-owner";

test("only the migration pool can resolve existing Cognito owners", async (t) => {
  const singapore = "https://cognito-idp.ap-southeast-1.amazonaws.com/ap-southeast-1_example";
  const ohio = "https://cognito-idp.us-east-2.amazonaws.com/us-east-2_example";
  const original = "9c1c4e54-967b-4ba5-aded-478ee1a8f360";
  const migrated = "cbb1d880-2ef5-4e92-ceb3-ff15cb862070";
  const newAccount = "ab560942-fd18-4559-8ff4-028f55301046";
  const differentOwner = "e6dfdf5a-6dda-4ede-94a8-545dca380148";
  const googleIdentity = { providerName: "Google", providerType: "Google", userId: "123456789" };
  const providerHash = createHash("sha256").update(googleIdentity.userId).digest("hex");
  const previous = process.env.COGNITO_OWNER_MIGRATION;
  t.after(() => {
    if (previous === undefined) delete process.env.COGNITO_OWNER_MIGRATION;
    else process.env.COGNITO_OWNER_MIGRATION = previous;
  });
  process.env.COGNITO_OWNER_MIGRATION = JSON.stringify({
    issuer: singapore,
    subjects: { [migrated]: original, [differentOwner]: differentOwner },
    google: { [providerHash]: original },
  });

  assert.equal(await cognitoOwnerId(migrated, singapore, []), original);
  assert.equal(await cognitoOwnerId(newAccount, singapore, [googleIdentity]), original);
  assert.equal(await cognitoOwnerId(newAccount, ohio, [googleIdentity]), newAccount);
  assert.equal(await cognitoOwnerId(newAccount, singapore, [{ ...googleIdentity, providerType: "OIDC" }]), newAccount);
  assert.equal(await cognitoOwnerId(newAccount, singapore, []), newAccount);
  await assert.rejects(cognitoOwnerId(differentOwner, singapore, [googleIdentity]), /Conflicting/);

  delete process.env.COGNITO_OWNER_MIGRATION;
  assert.equal(await cognitoOwnerId(newAccount, singapore, [googleIdentity]), newAccount);
});
