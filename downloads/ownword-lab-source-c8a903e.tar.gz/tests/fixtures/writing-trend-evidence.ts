import { resolveSource } from "../../lib/domain/anchors";
import type { DiagnosticReport, IssueFirstReportObservation } from "../../lib/writing/contracts";
import { getDiagnosticBlueprint, getDiagnosticPrompt } from "../../lib/writing/prompt-bank";
import type { WritingProfileRecord } from "../../lib/writing/profile";

const notes = { en: "You gave a reason tied to your recommendation.", vi: "Bạn đã đưa ra lý do phù hợp với đề xuất." };
export const trendExamples = [
  "I recommend turning music off because the speaker was blue.",
  "I turn music off because when I read fiction, the lyrics distract me.",
  "I keep the music off because with a quiet background I can follow the instructions for my lab.",
  "I turn music off because my favorite color is orange.",
];

export function trendRecord(index: number, kind: "problem" | "strength", options: {
  assistance?: WritingProfileRecord["submission"]["assistance"];
  excerpt?: string;
  revision?: boolean;
  observed?: boolean;
} = {}): WritingProfileRecord {
  const { assistance = "unassisted", excerpt = trendExamples[index - 1], revision = false, observed = true } = options;
  const id = `synthetic-${index}`;
  const taskId = `task-${id}`;
  const createdAt = `2026-10-${String(index + 1).padStart(2, "0")}T10:00:00.000Z`;
  const finishedAt = createdAt.replace("10:00", "10:02");
  const prompt = getDiagnosticPrompt("music-while-studying")!;
  const blueprint = getDiagnosticBlueprint(prompt);
  const text = `${excerpt} A separate idea in this synthetic response should never be sent to the trend model.`;
  const problem = kind === "problem" ? { en: "Connect the reason to your recommendation", vi: "Liên hệ lý do với đề xuất" } : notes;
  const note = kind === "problem" ? { en: "The choice of color does not explain why music should be off.", vi: "Màu sắc chưa giải thích được vì sao nên tắt nhạc." } : notes;
  const observation: IssueFirstReportObservation = {
    kind, problem: problem.en, readerImpact: note.en, revisionCue: null,
    evidence: [resolveSource(text, excerpt, id)!], materiality: "meaningful", profileEvidenceCandidate: true,
    attribution: { primary: "ARG.SUPPORT", secondary: null, certainty: "clear" },
    issueKind: kind === "problem" ? "reason_link" : "effective_choice",
    feedback: { category: kind === "problem" ? "clarity" : "strength", replacement: null,
      vi: { problem: problem.vi, readerImpact: note.vi, revisionCue: null } },
  };
  const skills = { opportunity: "adequate", judgment: "undetermined" } as const;
  const requirements = { status: "undetermined", evidence: [] } as const;
  const report: DiagnosticReport = {
    scope: "submitted_response", provisional: true, status: observed ? "observed" : "no_actionable_findings", submissionId: id,
    promptId: prompt.id, promptVersion: blueprint.version, registryVersion: "fixture-registry", rubricVersion: "fixture-rubric", schemaVersion: "fixture-v2",
    issueFirstObservations: observed ? [observation] : [], findings: [],
    skills: { "ARG.SUPPORT": skills, "ORG.PROGRESSION": skills, "LEX.PRECISION": skills, "GRAM.ACCURACY": skills },
    taskFulfillment: { position: { ...requirements, evidence: [] }, reasons: { ...requirements, evidence: [] }, trade_off: { ...requirements, evidence: [] } },
  };
  return {
    task: { id: taskId, promptId: prompt.id, promptVersion: blueprint.version, snapshot: { prompt, blueprint, interestIds: [], locale: "en" }, createdAt },
    submission: { id, text, taskId, wordCount: 24, assistance, parentSubmissionId: null, createdAt },
    run: { id: `run-${id}`, submissionId: id, status: "succeeded", report, startedAt: createdAt, finishedAt, leaseExpiresAt: finishedAt, quotaDay: createdAt.slice(0, 10) },
    latestRevisionId: revision ? `revision-${id}` : null,
    revisionCheckedAt: revision ? createdAt.replace("10:00", "10:04") : null,
    revisionCheck: revision ? { originalId: id, revisionId: `revision-${id}`, items: [{ id: 0, status: "still_present", before: excerpt, after: excerpt, note }],
      nextStep: note, introduced: [] } : null,
  };
}
