import assert from "node:assert/strict";
import test from "node:test";
import { resolveSource } from "../lib/domain/anchors";
import type { DiagnosticSubmission, IssueFirstReportObservation } from "../lib/writing/contracts";
import { writingFocusTwoPassEnabled } from "../lib/writing/config";
import { createWritingFocusEvaluator, hasFocusTrigger, uncaughtFocusTargets, validateWritingFocusCheck } from "../lib/writing/focus-check";
import { detailWritingFocus, groupWritingFocusProblems, matchBaselineFocusKeys, selectWritingFocusSuggestions, writingFocusTargets } from "../lib/writing/focus";
import { HOSTED_WRITING_ROUTE, ISSUE_FIRST_PILOT_MODEL } from "../lib/writing/issue-first-pilot";
import { sanitizeReplacement } from "../lib/writing/replacement-safety";
import { trendRecord } from "./fixtures/writing-trend-evidence";

const agreement = "subject-verb-agreement";
const however = "however-contrast";
const past = "local:finished-past";
const submission = (text: string): DiagnosticSubmission => ({
  submissionId: "synthetic-focus", promptId: "music-while-studying", text,
});
const targets = (...keys: string[]) => writingFocusTargets(keys);

function finding(focusTopicKey: string, quote: string, replacement: string | null,
  problem = "Check the verb", issueKind: IssueFirstReportObservation["issueKind"] = "grammar_construction") {
  return {
    focusTopicKey, problem, issueKind,
    readerImpact: "The form makes this sentence difficult to follow.", revisionCue: "Check the verb form here.",
    materiality: "meaningful" as const, evidence: [{ quote, segmentId: null }],
    attribution: { primary: "GRAM.ACCURACY" as const, secondary: null, certainty: "clear" as const },
    feedback: { category: "mistake" as const, replacement, vi: {
      problem: "Kiểm tra động từ", readerImpact: "Dạng động từ chưa phù hợp.", revisionCue: "Hãy kiểm tra động từ.",
    } },
  };
}

function ordinary(input: DiagnosticSubmission, { evidence, focusTopicKey: key, ...item }: ReturnType<typeof finding>) {
  const observation: IssueFirstReportObservation = { ...item, kind: "problem", profileEvidenceCandidate: true,
    evidence: evidence.map(({ quote }) => resolveSource(input.text, quote, input.submissionId)!) };
  return { key, observation };
}

type FocusFixtureNote = [issue: IssueFirstReportObservation["issueKind"], quote: string, replacement: string | null,
  materiality?: IssueFirstReportObservation["materiality"], secondQuote?: string];

function focusRecord(index: number, text: string, notes: FocusFixtureNote[], options?: Parameters<typeof trendRecord>[2]) {
  const record = trendRecord(index, "problem", { ...options, excerpt: text });
  const input = { ...submission(record.submission.text), submissionId: record.submission.id };
  record.run!.report!.issueFirstObservations = notes.map(([issue, quote, replacement, materiality = "meaningful", secondQuote]) => {
    const { observation } = ordinary(input, finding("", quote, replacement, "Revise this wording", issue));
    if (secondQuote) observation.evidence.push(resolveSource(input.text, secondQuote, input.submissionId)!);
    return { ...observation, materiality, profileEvidenceCandidate: false,
      attribution: { primary: null, secondary: null, certainty: "uncertain" } };
  });
  return record;
}

const suggestionKeys = (records: ReturnType<typeof focusRecord>[]) =>
  selectWritingFocusSuggestions(groupWritingFocusProblems(records)).map(({ key }) => key);

test("Focus groups the screenshot-style corrections and keeps deferred essay evidence", () => {
  const first = focusRecord(1,
    "I open laptop before class. It is the one appear at the top. I listen even 5 to 6 hours. That time I think in silence. The mainboard of the dashboard is blank. I bought a matcha late. Normally i am more alert. A nice music is playing.", [
      ["grammar_construction", "open laptop", "open my laptop", "minor"],
      ["grammar_construction", "the one appear at the top", "the one that appears at the top"],
      ["grammar_construction", "even 5 to 6 hours", "even for 5 to 6 hours", "minor"],
      ["grammar_construction", "That time", "At that time", "minor"],
      ["word_meaning_or_fit", "mainboard", "main panel"],
      ["spelling", "matcha late", "matcha latte", "minor"],
      ["punctuation", "i am", "I am", "minor"],
      ["grammar_construction", "A nice music", "Nice music", "minor"],
    ]);
  const second = focusRecord(2, "The noise can overwrite the melody. My phones notification sounds are loud. I feel serent beside the river.", [
    ["word_meaning_or_fit", "overwrite", "drown out"],
    ["punctuation", "phones notification", "phone’s notification", "minor"],
    ["spelling", "serent", "serene", "minor"],
  ]);
  assert.deepEqual(suggestionKeys([first]), [agreement]);
  assert.deepEqual(suggestionKeys([first, second]), ["theme:contextual-wording", agreement]);
  assert.equal(matchBaselineFocusKeys(first).get(1), agreement);
  const groups = groupWritingFocusProblems([first, second]);
  assert.equal(groups.get("theme:spelling-mechanics")?.occurrences.length, 2);
  assert.equal(groups.get("theme:capitalization")?.occurrences.length, 1);
  assert.equal(groups.get("theme:prepositions")?.occurrences.length, 2);
  assert.deepEqual(new Set(detailWritingFocus(groups.get("theme:contextual-wording")!).evidence.map(({ submissionId, examples }) =>
    `${submissionId}:${examples[0].exact}`)), new Set([`${first.submission.id}:mainboard`, `${second.submission.id}:overwrite`]));

  const legacyKey = `note:${first.submission.id}:4`;
  const savedKeys = new Set([legacyKey]);
  const saved = groupWritingFocusProblems([first, second], false, savedKeys);
  assert.equal(saved.get(legacyKey)?.occurrences.length, 1);
  assert.equal(saved.get("theme:contextual-wording")?.occurrences.length, 2);
  assert.deepEqual(selectWritingFocusSuggestions(saved, savedKeys).map(({ key }) => key), [agreement]);
  assert.deepEqual(writingFocusTargets([...groups.keys(), legacyKey, "local:spell-receive"]).map(({ key }) => key), [agreement]);
});

test("recommendations require independent essays and distinguish minor from meaningful spelling", () => {
  const first = focusRecord(1, "We met Monday. I recieved the message.", [
    ["grammar_construction", "met Monday", "met on Monday", "minor"], ["spelling", "recieved", "received", "minor"],
  ]);
  const second = focusRecord(2, "I moved that time to a peacful village by the sea.", [
    ["grammar_construction", "that time", "at that time", "minor"], ["spelling", "peacful", "peaceful", "minor"],
  ]);
  const third = focusRecord(3, "The separated notes were filed in seperate envelopes.", [["spelling", "seperate", "separate", "minor"]]);
  const duplicate = focusRecord(4, "We met Monday. I recieved the message.", [["spelling", "recieved", "received"]]);
  const assisted = focusRecord(5, "We will meet Sunday to recieve the award.", [["spelling", "recieve", "receive"]], { assistance: "external_help" });
  const revised = focusRecord(6, "I wrote a seperate report about our earlier lunch.", [["spelling", "seperate", "separate"]]);
  revised.submission.parentSubmissionId = first.submission.id;
  const legacySpelling = "local:spell-peaceful";
  const spellingPin = groupWritingFocusProblems([second], false, new Set([legacySpelling])).get(legacySpelling);
  assert.equal(detailWritingFocus(spellingPin!).evidence[0].examples[0].exact, "peacful");
  assert.deepEqual(writingFocusTargets([legacySpelling]), []);
  assert.deepEqual(suggestionKeys([first, duplicate, assisted, revised]), []);
  assert.deepEqual(suggestionKeys([first, second, duplicate, assisted, revised]), ["theme:prepositions"]);
  assert.deepEqual(suggestionKeys([first, second, third]), ["theme:spelling-mechanics", "theme:prepositions"]);
  first.run!.report!.issueFirstObservations![1].materiality = "meaningful";
  assert.deepEqual(suggestionKeys([first, second]), ["theme:prepositions"]);
  second.run!.report!.issueFirstObservations![1].materiality = "meaningful";
  assert.deepEqual(suggestionKeys([first, second]), ["theme:spelling-mechanics", "theme:prepositions"]);
});

test("a consequential wording error or two distinct local errors can qualify after one essay", () => {
  const record = focusRecord(1, "The safety arrows prevent visitors from finding the exit. The barrier overwrites the noise.", [
    ["word_meaning_or_fit", "prevent visitors from finding the exit", "help visitors find the exit"],
    ["word_meaning_or_fit", "overwrites", "muffles"],
  ]);
  const observations = record.run!.report!.issueFirstObservations!;
  const other = observations.pop()!;
  const first = observations[0];
  observations.push({ ...first });
  assert.deepEqual(suggestionKeys([record]), [], "duplicating a source span adds no independent evidence");
  observations[1] = other;
  assert.deepEqual(suggestionKeys([record]), ["theme:contextual-wording"]);
  observations.pop();
  first.readerImpact = "Prevent reverses the apparent purpose of the arrow.";
  delete first.feedback;
  assert.deepEqual(suggestionKeys([record]), ["theme:contextual-wording"]);
});

test("anchored reasoning appears immediately and recurrence, impact and recency determine the six-card shortlist", () => {
  const first = focusRecord(1, "Choose the bus. It is blue. It saves money. I paid twice. Take the train. This is unsafe. I like music. There are two stopps.", [
    ["reason_link", "It is blue", null], ["explanation_gap", "It saves money", null],
    ["sequence_or_grouping", "I paid twice", null, "meaningful", "Take the train"],
    ["plan_or_claim_consistency", "Choose the bus", null, "meaningful", "Take the train"],
    ["reference_or_signpost", "This is unsafe", null, "meaningful", "I like music"],
    ["clause_connection", "Take the train", null], ["spelling", "stopps", "stops"],
  ]);
  assert.equal(suggestionKeys([first]).length, 6);
  assert.ok(suggestionKeys([first]).includes("theme:relevant-reasons"));
  const second = focusRecord(2, "Book a ferry for the weekend. My scarf is green. There are no tickkets left today.", [
    ["reason_link", "My scarf is green", null], ["spelling", "tickkets", "tickets"],
  ]);
  const keys = suggestionKeys([second, first]);
  assert.equal(keys.length, 6);
  assert.deepEqual(keys.slice(0, 2), ["theme:relevant-reasons", "theme:spelling-mechanics"]);
  assert.ok(!keys.includes("theme:clause-joins"));
  assert.deepEqual(suggestionKeys([first, second]), keys);
  const newer = focusRecord(3, "Visitors may book online today. We should call them well before the weekend.", [["explanation_gap", "book online today", null]]);
  assert.equal(suggestionKeys([first, newer])[0], "theme:developed-examples");
});

test("triggering handles dates and lexical variants and requires unmatched bounded occurrences", () => {
  for (const text of ["In 2023, the school builds a wall.", "Previously, our school runs a club."]) assert.ok(hasFocusTrigger(past, text));
  for (const text of ["We tried it, howver it failed.", "Howevr the room was quiet."]) assert.ok(hasFocusTrigger(however, text));
  assert.ok(hasFocusTrigger("local:word-borrow-lend", "She lent him one."));
  assert.equal(hasFocusTrigger("local:word-borrow-lend", "They went toward the library."), false);
  assert.equal(hasFocusTrigger("discuss-direct-object", "They talked it over."), false);

  const first = "It was quiet, however the song was loud.";
  const second = "I stayed, however my friend left.";
  const detection = finding(however, first, "It was quiet; however, the song was loud.");
  const single = submission(first);
  assert.deepEqual(uncaughtFocusTargets(first, targets(however), [ordinary(single, detection)]), []);
  const both = submission(`${first} ${second}`);
  assert.deepEqual(uncaughtFocusTargets(both.text, targets(however), [ordinary(both, detection)]), targets(however));
  const open = submission("The singer have talent. The speakers makes it hard to hear.");
  const caught = ordinary(open, finding(agreement, "The singer have", "The singer has"));
  assert.deepEqual(uncaughtFocusTargets(open.text, targets(agreement), [caught]), targets(agreement));
});

test("deduplication drops a reworded correction for the same long cue-only span", () => {
  const quote = "The list of recorded lectures from the first two weeks make";
  const input = { ...submission(`${quote} it easier to review.`), promptId: "recorded-lectures" };
  const base = ordinary(input, finding(agreement, quote, null, "Make the verb agree with the subject"));
  const repeated = finding(agreement, quote, quote.replace("make", "makes"), "The singular subject requires 'makes'.");
  assert.deepEqual(validateWritingFocusCheck(input, targets(agreement), [base], { observations: [repeated] })?.observations, []);
});

test("deduplication drops an alternative repair at the same comma splice even without a baseline topic key", () => {
  const quote = "Short reviews give useful context, they also spoil small surprises in the first act.";
  const input = { ...submission(quote), promptId: "reviews-before-films" };
  const key = "comma-splice";
  const base = { ...ordinary(input, finding(key, quote, quote.replace(", they", ", but they"),
    "Join the two complete thoughts", "clause_connection")), key: null };
  const repeated = finding(key, quote, quote.replace(", they", "; they"),
    "Two independent clauses are joined with only a comma.", "clause_connection");
  assert.deepEqual(validateWritingFocusCheck(input, targets(key), [base], { observations: [repeated] })?.observations, []);
});

test("deduplication preserves a different correction in an overlapping span and another occurrence of the same topic", () => {
  const sentence = "The speakers makes a strange thing very loud.";
  const input = submission(`${sentence} These classroom sounds also distracts me.`);
  const base = ordinary(input, finding(agreement, "The speakers makes", "The speakers make", "Subject and verb disagree"));
  const clarity = ordinary(input, finding(agreement, sentence, null, "Name the sound", "reference_or_signpost"));
  clarity.observation.feedback = { ...clarity.observation.feedback!, category: "clarity" };
  const repeated = finding(agreement, sentence, "The speakers make a strange thing very loud.", "Wrong verb form");
  const separate = finding(agreement, "These classroom sounds also distracts me.", "These classroom sounds also distract me.", "Plural subject needs the base verb");
  const result = validateWritingFocusCheck(input, targets(agreement), [base, clarity], { observations: [repeated, separate] });
  assert.deepEqual(result?.observations.map(({ problem }) => problem), [separate.problem]);

  const other = finding(agreement, sentence, "The speakers make a strange thing very loud.", "Subject and verb disagree");
  const overlapping = validateWritingFocusCheck(input, targets(agreement), [clarity], { observations: [other] });
  assert.equal(overlapping?.observations[0]?.feedback?.replacement, other.feedback.replacement);
  assert.equal(overlapping?.observations[0]?.profileEvidenceCandidate, false);

  const shared = submission("The speaker have talent, the lights makes a difference, and the songs fits the show.");
  const broad = ordinary(shared, finding(agreement, shared.text,
    shared.text.replace("have", "has").replace("fits", "fit")));
  const middle = finding(agreement, shared.text, shared.text.replace("lights makes", "lights make"));
  const distinct = validateWritingFocusCheck(shared, targets(agreement), [broad], { observations: [middle] });
  assert.equal(distinct?.observations[0]?.feedback?.replacement, middle.feedback.replacement);
});

test("finished-past accepts context from an earlier sentence while keeping the exact error anchored", () => {
  const setting = "In 2023, our neighborhood high school built an indoor climbing wall for afternoon classes.";
  const event = "Even students who hated running decide to join the climbing club that semester.";
  const input = { ...submission(`${setting} ${event}`), promptId: "choice-in-physical-education" };
  const item = { ...finding(past, "decide to join", "decided to join", "Use past tense for the 2023 club"),
    evidence: [{ quote: "decide to join", segmentId: 2 }] };
  const check = validateWritingFocusCheck(input, targets(past), [], { observations: [item] });
  assert.equal(check?.observations[0]?.evidence[0]?.exact, "decide to join");
  assert.equal(check?.observations[0]?.evidence[0]?.sentence, event);
  assert.equal(check?.observations[0]?.feedback?.replacement, "decided to join");

  const wrongSegment = { ...item, evidence: [{ quote: "decide to join", segmentId: 1 }] };
  assert.deepEqual(validateWritingFocusCheck(input, targets(past), [], { observations: [wrongSegment] })?.observations, []);
  assert.deepEqual(validateWritingFocusCheck({ ...input, text: `${event} ${setting}` }, targets(past), [],
    { observations: [wrongSegment] })?.observations, []);

  const lexicalInput = submission("I brought a book, however it was too short. My friend gave me another one.");
  const unrelated = finding(however, "My friend gave me another one.", "My friend gave me one more.");
  assert.deepEqual(validateWritingFocusCheck(lexicalInput, targets(however), [], { observations: [unrelated] })?.observations, []);
});

test("replacement hygiene allows conjunction and borrow/lend edits in long quotes", () => {
  const quote = "The library is very busy in the afternoon, I prefer studying at home quietly.";
  for (const conjunction of ["so", "yet"]) {
    const edit = quote.replace(", I", `, ${conjunction} I`);
    assert.equal(sanitizeReplacement(quote, edit), edit);
  }
  const loan = "When my drill broke last weekend, my neighbor borrowed me his screwdriver for two days.";
  const lent = loan.replace("borrowed", "lent");
  assert.equal(sanitizeReplacement(loan, lent), lent);
  const lends = "For weekend repairs, I often lend a set of screwdrivers from the neighbor across the street.";
  const borrow = lends.replace("lend", "borrow");
  assert.equal(sanitizeReplacement(lends, borrow), borrow);

  assert.equal(sanitizeReplacement(quote, quote.replace(", I", ", so I").replace("studying", "working")), null);
  assert.equal(sanitizeReplacement(loan, lent.replace("screwdriver", "պտուտակահան")), null);
  assert.equal(sanitizeReplacement(loan, lent.replace("screwdriver", "hammer")), null);
});

test("focused output requires an approved target, anchored evidence and actionable grounded feedback", () => {
  const quote = "In 2023, our neighborhood high school builds an indoor climbing wall for afternoon classes, and students decide to participate.";
  const input = submission(quote);
  const valid = finding(past, quote, quote.replace("builds", "built").replace("decide", "decided"));
  const invalid = [
    { ...valid, focusTopicKey: agreement },
    { ...valid, evidence: [{ quote: "I invented this sentence", segmentId: null }] },
    { ...valid, evidence: [{ quote, segmentId: 8 }] },
    { ...valid, revisionCue: "You've improved at this rule." },
    { ...valid, feedback: { ...valid.feedback, replacement: null }, revisionCue: null },
  ];
  assert.deepEqual(validateWritingFocusCheck(input, targets(past), [], { observations: invalid })?.observations, []);
  assert.deepEqual(validateWritingFocusCheck(input, targets(past), [], { observations: [] })?.observations, []);
  assert.equal(validateWritingFocusCheck(input, targets(past), [], { observations: null }), null);

  const drift = ["մասնակց.", "meet.", "partici", "partici."];
  for (const unsafe of drift) {
    const item = { ...valid, feedback: { ...valid.feedback, replacement: valid.feedback.replacement!.replace("participate.", unsafe) } };
    const [saved] = validateWritingFocusCheck(input, targets(past), [], { observations: [item] })!.observations;
    assert.equal(saved.feedback?.replacement, null);
    assert.equal(saved.revisionCue, valid.revisionCue);
    assert.deepEqual(validateWritingFocusCheck(input, targets(past), [], { observations: [{ ...item, revisionCue: null }] })?.observations, []);
  }
  assert.equal(sanitizeReplacement(quote, valid.feedback.replacement), valid.feedback.replacement);
  assert.equal(sanitizeReplacement("A good plan", "A solid plan"), "A solid plan");
});

test("baseline classifiers recognize validated local edits from the handoff", () => {
  const cases = [
    ["The speakers makes it hard to hear.", "The speakers makes", "The speakers make", "Subject–verb mismatch", "grammar_construction", agreement],
    ["However taking turns can be fair.", "However taking turns", "However, taking turns", "Add a comma after however", "punctuation", however],
    ["A path helps hikers, howevr fragile dunes collapse.", "hikers, howevr fragile dunes", "hikers; however, fragile dunes", "Punctuation before however", "clause_connection", however],
    ["Music helps me work, lyrics distract me.", "work, lyrics", "work; lyrics", "A comma alone cannot join two complete sentences", "clause_connection", "comma-splice"],
    ["Many travelers enjoy to explore hidden coves.", "enjoy to explore", "enjoy exploring", "Use the gerund after enjoy", "grammar_construction", "local:enjoy-gerund"],
    ["In 2021, my brother opens a stall, and local commuters bring him bent wheels every weekend.", "opens a stall, and local commuters bring",
      "opened a stall, and local commuters brought", "Use past tense for this finished event", "grammar_construction", past],
    ["He gladly borrowed them one from his own shelf.", "borrowed", "lent", "Use lend for giving temporarily", "word_meaning_or_fit", "local:word-borrow-lend"],
  ] as const;
  for (const [text, quote, edit, note, kind, key] of cases) {
    const record = trendRecord(1, "problem", { excerpt: text });
    const item = finding(key, quote, edit, note, kind);
    const { observation } = ordinary({ ...submission(record.submission.text), submissionId: record.submission.id }, item);
    observation.readerImpact = note;
    observation.materiality = key === however && text.startsWith("However") ? "minor" : "meaningful";
    record.run!.report!.issueFirstObservations = [observation];
    assert.equal(matchBaselineFocusKeys(record).get(0), key, text);
  }
});

test("the focused transport pins Azure Standard and fails closed on invalid provider responses", async () => {
  const input = submission("The speakers makes it hard to hear.");
  const envelope = { model: ISSUE_FIRST_PILOT_MODEL, provider: "Azure", choices: [{ finish_reason: "stop",
    message: { content: JSON.stringify({ observations: [] }) } }] };
  let response: () => Response = () => Response.json(envelope);
  const evaluate = createWritingFocusEvaluator("local-test-key", async (url, init) => {
    assert.equal(String(url), "https://openrouter.ai/api/v1/chat/completions");
    assert.equal(init?.redirect, "manual");
    const body = JSON.parse(String(init?.body));
    assert.equal(body.model, ISSUE_FIRST_PILOT_MODEL);
    assert.equal(body.max_completion_tokens, 1700);
    assert.deepEqual(body.reasoning, { effort: "low", exclude: true });
    assert.deepEqual(body.provider, { only: ["azure"], require_parameters: true, allow_fallbacks: false,
      zdr: true, data_collection: "deny", max_price: HOSTED_WRITING_ROUTE.maxPricePerMillion });
    assert.deepEqual(JSON.parse(body.messages[1].content).input.focusTargets, targets(agreement));
    return response();
  }, HOSTED_WRITING_ROUTE);
  const run = (signal = new AbortController().signal) => evaluate(input, targets(agreement), [], signal);
  assert.deepEqual(await run(), { version: 1, checkedTopicKeys: [agreement], observations: [] });
  for (const reject of [
    () => Response.json({ ...envelope, provider: "Unexpected provider" }),
    () => Response.json({ ...envelope, model: "different-model" }),
    () => Response.json(envelope, { headers: { "X-OpenRouter-Cache-Status": "HIT" } }),
    () => Response.json({ ...envelope, choices: [{ ...envelope.choices[0], finish_reason: "length" }] }),
    () => Response.json({ ...envelope, choices: [{ finish_reason: "stop", message: { content: "{}" } }] }),
    () => new Response(null, { status: 302, headers: { location: "https://example.invalid" } }),
    () => new Response(null, { status: 503 }),
  ]) {
    response = reject;
    assert.equal(await run(), null);
  }
  assert.equal(await run(AbortSignal.abort()), null);
  assert.equal(writingFocusTwoPassEnabled({}), true);
  assert.equal(writingFocusTwoPassEnabled({ WRITING_FOCUS_TWO_PASS_ENABLED: "false" }), false);
});
