import assert from "node:assert/strict";
import test from "node:test";
import { learningDay, streakAwardHeader } from "../lib/domain/learning-streak";
import { LearningStreakService } from "../lib/services/learning-streak";
import { withLearningCredit } from "../lib/server/streak-response";

test("the same activity day only earns one award and the next day preserves the streak", async () => {
  const rows = new Map<string, { day: string }[]>();
  const days = {
    async insertActivityDay(owner: string, day: string) {
      const saved = rows.get(owner) ?? [];
      if (saved.some((item) => item.day === day)) return false;
      rows.set(owner, [...saved, { day }]);
      return true;
    },
    async listActivityDays(owner: string) { return rows.get(owner) ?? []; },
  };
  let now = new Date("2026-11-20T16:59:00Z");
  const clock = { now: () => now };
  const learner = new LearningStreakService(days, "learner", clock);
  const anotherLearner = new LearningStreakService(days, "another", clock);

  assert.equal((await learner.current()).count, 0);
  const first = await withLearningCredit(new Response(), learner);
  assert.equal(JSON.parse(first.headers.get(streakAwardHeader)!).count, 1);
  const duplicate = await withLearningCredit(new Response(), learner);
  assert.equal(duplicate.headers.get(streakAwardHeader), null);

  now = new Date("2026-11-20T17:00:00Z");
  assert.equal(learningDay(now), "2026-11-21");
  assert.equal((await learner.current()).count, 1);
  assert.equal((await learner.complete())?.count, 2);
  assert.equal((await anotherLearner.current()).count, 0);
});
