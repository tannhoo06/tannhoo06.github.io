import test from "node:test";
import assert from "node:assert/strict";
import { resolveSource, validSource } from "../lib/domain/anchors";
import type { Lexeme, WritingAnalysis } from "../lib/domain/types";
import { canonicalLexicalItem } from "../lib/llm/lexical-units";
import { inspectSuggestion } from "../lib/llm/suggestion-guards";
import { validateLexicalRewrite } from "../lib/llm/rewrite-quality";
import { GeminiLlm, inspectAnalysisProposals } from "../lib/llm/gemini";
import { guardEvaluation, hasWordEvidence } from "../lib/llm/evaluation-guards";

type Suggestion = WritingAnalysis["suggestions"][number];
function assess(
  text: string,
  old: string,
  word: string,
  replacement: string,
  pos = "verb",
  meta: Partial<Parameters<typeof canonicalLexicalItem>[0]> = {},
) {
  const normalized = canonicalLexicalItem({
    word,
    partOfSpeech: pos,
    replacementText: replacement,
    ...meta,
  });
  assert.equal(normalized.valid, true, normalized.reason);
  const s: Suggestion = {
    word: normalized.canonical,
    partOfSpeech: normalized.type === "phrasalVerb" ? "phrasal verb" : pos,
    definition: "A precise contextual lexical meaning.",
    nuance: "",
    examples: ["A natural English example."],
    collocations: [],
    originalText: old,
    source: resolveSource(text, old, ""),
    suggestedSentence: null,
    reason: "Names the stated concept.",
    confidence: 0.9,
  };
  const local = inspectSuggestion(text, s, replacement);
  assert.ok(local.suggestion, local.reason);
  return validateLexicalRewrite(text, local.suggestion, normalized);
}
test("v3 heed to is rejected even after canonical lemma normalization", () => {
  const r = assess(
    "She paid close attention to the instructions.",
    "paid close attention",
    "heeded",
    "heeded",
  );
  assert.equal(r.suggestion, null);
  assert.ok(r.issues.includes("invalid-valency"));
  assert.ok(r.issues.includes("formality-only"));
});
test("heed advice accepts a direct object when source explicitly includes following guidance", () => {
  const text = "She paid attention to the advice and followed it.";
  const r = assess(text, "paid attention to", "heed", "heeded");
  assert.ok(r.suggestion);
  assert.equal(
    r.suggestion.suggestedSentence,
    "She heeded the advice and followed it.",
  );
});
test("hinges on colon recovers only the unchanged antecedent object", () => {
  const text =
    "Our launch depends on one thing: getting approval before Friday.";
  const r = assess(text, "depends on one thing", "hinge", "hinges on");
  assert.ok(r.suggestion);
  assert.equal(
    r.suggestion.suggestedSentence,
    "Our launch hinges on one thing: getting approval before Friday.",
  );
  assert.ok(r.repaired);
  assert.ok(validSource(text, "", r.suggestion.source));
});
test("dangling hinges on colon without a safely recoverable object is rejected", () => {
  const r = assess(
    "The launch depends on approval: it is still pending.",
    "depends on approval",
    "hinge",
    "hinges on",
  );
  assert.equal(r.suggestion, null);
  assert.ok(r.issues.includes("invalid-grammatical-frame"));
});
test("a valid hinges on whether clause retains its conditionality", () => {
  const text = "The launch depends on whether approval arrives before Friday.";
  assert.ok(
    assess(text, "depends on whether", "hinge", "hinges on whether").suggestion,
  );
});
test("everyone and modality survive a faithful explanatory replacement", () => {
  const text =
    "She explained a complicated idea in words that everyone could understand.";
  const r = assess(text, "explained", "demystify", "demystified");
  assert.ok(r.suggestion);
  assert.match(r.suggestion.suggestedSentence!, /everyone could understand/);
});
test("dropping everyone and could is rejected despite grammatical structure", () => {
  const text =
    "She explained a complicated idea in words that everyone could understand.";
  const r = assess(
    text,
    "explained a complicated idea in words that everyone could understand",
    "demystify",
    "demystified a complicated idea",
  );
  assert.equal(r.suggestion, null);
  assert.ok(r.issues.includes("participant-loss"));
  assert.ok(r.issues.includes("qualifier-loss"));
});
test("a contextual adverb can preserve the checked-twice event using an exact insertion anchor", () => {
  const text =
    "She explain the idea clearly, with every tiny detail checked twice.";
  const r = assess(
    text,
    "with every tiny detail checked twice",
    "meticulously",
    "with every tiny detail meticulously checked twice",
    "adverb",
  );
  assert.ok(r.suggestion);
  assert.match(r.suggestion.suggestedSentence!, /meticulously checked twice/);
  assert.ok(validSource(text, "", r.suggestion.source));
});
test("v3 trailing adverb, checked-event loss and lost frequency are rejected", () => {
  const text =
    "She explain the idea clearly, with every tiny detail checked twice.";
  const r = assess(
    text,
    "with every tiny detail checked twice",
    "meticulously",
    "meticulously",
    "adverb",
  );
  assert.equal(r.suggestion, null);
  assert.ok(r.issues.includes("qualifier-loss"));
  assert.ok(r.issues.includes("event-structure-loss"));
  assert.ok(r.issues.includes("awkward-local-attachment"));
});
test("bounce back is a complete canonical phrasal unit, not an isolated bounced entry", () => {
  const text =
    "After setbacks, the team recovered quickly and adapted its plans.";
  const r = assess(
    text,
    "recovered quickly",
    "bounced",
    "bounced back quickly",
    "verb",
    {
      canonicalForm: "bounce back",
      surfaceForm: "bounced back",
      lexicalType: "phrasalVerb",
    },
  );
  assert.ok(r.suggestion);
  assert.equal(r.suggestion.word, "bounce back");
  assert.equal(r.suggestion.partOfSpeech, "phrasal verb");
});
test("an explicitly incomplete phrasal head and arbitrary multiword fragments fail closed", () => {
  assert.equal(
    canonicalLexicalItem({
      word: "bounce",
      canonicalForm: "bounce",
      surfaceForm: "bounced",
      lexicalType: "word",
      partOfSpeech: "verb",
      replacementText: "bounced back",
    }).reason,
    "missing-required-particle",
  );
  assert.equal(
    canonicalLexicalItem({
      word: "the team worked",
      lexicalType: "multiword",
      partOfSpeech: "phrase",
    }).valid,
    false,
  );
  assert.equal(hasWordEvidence("bounce back", "bounce"), false);
  assert.equal(hasWordEvidence("bounce back", "back"), false);
  const incomplete = assess(
    "The team recovered quickly after a setback.",
    "recovered",
    "bounce",
    "bounced",
  );
  assert.equal(incomplete.suggestion, null);
  assert.ok(incomplete.issues.includes("missing-required-particle"));
});
test("canonical verb lemma and surface tense are separate while adverb stays unchanged", () => {
  const n = canonicalLexicalItem({
    word: "streamlined",
    canonicalForm: "streamline",
    surfaceForm: "streamlined",
    lexicalType: "word",
    partOfSpeech: "verb",
  });
  assert.equal(n.valid, true);
  assert.equal(n.canonical, "streamline");
  assert.equal(
    canonicalLexicalItem({ word: "meticulously", partOfSpeech: "adverb" })
      .canonical,
    "meticulously",
  );
  assert.equal(
    canonicalLexicalItem({
      word: "explained",
      canonicalForm: "explained",
      partOfSpeech: "verb",
    }).valid,
    false,
  );
});
test("valid transitive objects are retained and verb-preposition mismatches are blocked", () => {
  assert.ok(
    assess(
      "The policy made the problem less severe.",
      "made the problem less severe",
      "mitigate",
      "mitigated the problem",
    ).suggestion,
  );
  const bad = assess(
    "We talked about the budget.",
    "talked",
    "discuss",
    "discussed",
  );
  assert.equal(bad.suggestion, null);
  assert.ok(bad.issues.includes("invalid-valency"));
});
test("partial reduction cannot become complete resolution", () => {
  const r = assess(
    "The policy helped reduce the problem but did not solve it.",
    "helped reduce the problem",
    "solve",
    "solved the problem",
  );
  assert.equal(r.suggestion, null);
  assert.ok(r.issues.includes("semantic-expansion"));
});
test("mitigate preserves the partial-effect limitation rather than deleting it", () => {
  const text =
    "The policy made the problem less severe, although it did not solve it completely.";
  assert.ok(
    assess(
      text,
      "made the problem less severe",
      "mitigate",
      "mitigated the problem",
    ).suggestion,
  );
  const bad = assess(
    text,
    "made the problem less severe, although it did not solve it completely",
    "mitigate",
    "mitigated the problem",
  );
  assert.equal(bad.suggestion, null);
  assert.ok(bad.issues.includes("qualifier-loss"));
});
test("existing generic-synonym restraint and strong v3 concepts coexist", () => {
  assert.equal(
    assess("The safety margin is small.", "small", "slim", "slim", "adjective")
      .reason,
    "formality-only",
  );
  const text =
    "The system made the repeated paperwork steps fewer and simpler.";
  assert.ok(
    assess(
      text,
      "made the repeated paperwork steps fewer and simpler",
      "streamline",
      "streamlined the repeated paperwork steps",
    ).suggestion,
  );
  assert.ok(
    assess(
      "She was careful about checking every decimal.",
      "careful about",
      "meticulous",
      "meticulous in",
      "adjective",
    ).suggestion,
  );
});
test("temporal lexical encoding can preserve a not-final estimate without a false negation rejection", () => {
  const text = "The initial estimate is not final; we may revise it later.";
  assert.ok(
    assess(text, "not final", "tentative", "tentative", "adjective").suggestion,
  );
});
test("quantity, named participants and protected causal/conditional information cannot disappear", () => {
  for (const [text, old, replacement] of [
    [
      "Alice checked three figures twice.",
      "checked three figures twice",
      "verified the figures",
    ],
    [
      "Alice checked the figures before Friday.",
      "Alice checked the figures before Friday",
      "verified the figures",
    ],
    [
      "We checked the figures only if approval arrived.",
      "checked the figures only if approval arrived",
      "verified the figures",
    ],
  ]) {
    const r = assess(text, old, "verify", replacement);
    assert.equal(r.suggestion, null);
    assert.ok(
      r.issues.some((x) => x === "qualifier-loss" || x === "participant-loss"),
    );
  }
});
test("bounded phrasal evidence requires the full unit, supports head inflection and controlled separation", () => {
  for (const [unit, text] of [
    ["bounce back", "The team bounced back quickly."],
    ["phase out", "They phased the old product out."],
    ["rule out", "We ruled it out."],
    ["account for", "This accounts for the discrepancy."],
  ])
    assert.equal(hasWordEvidence(unit, text), true, text);
  for (const text of [
    "bounce away",
    "bounce. Back",
    "back bounce",
    "bounce never back",
  ])
    assert.equal(hasWordEvidence("bounce back", text), false, text);
  assert.equal(
    hasWordEvidence("rule out", "rule the option because it is out"),
    false,
  );
});
test("bare multiword definition recall never earns sentence precision or a disabled hint", () => {
  const word: Lexeme = {
    id: "compound",
    word: "bounce back",
    partOfSpeech: "phrasal verb",
    definition: "To recover after a setback.",
    nuance: "",
    examples: [],
    collocations: [],
  };
  const raw = {
    retrieved: true,
    precise: true,
    majorMisuse: false,
    validAlternative: false,
    spellingCorrection: null,
    feedback: "Well done: bounce back, starting with b.",
    nuance: "b-o-u-n-c-e back",
  };
  const bare = guardEvaluation(word, "bounced back", raw, {
    definitionRecall: true,
    hideUnrecalledTarget: true,
    hint: "none",
  });
  assert.equal(bare.retrieved, true);
  assert.equal(bare.precise, false);
  const missing = guardEvaluation(word, "bounce", raw, {
    definitionRecall: true,
    hideUnrecalledTarget: true,
    hint: "none",
  });
  assert.equal(missing.retrieved, false);
  assert.equal(missing.precise, false);
  assert.doesNotMatch(
    missing.feedback + missing.nuance,
    /bounce|starting with|b-o-u/i,
  );
});
test("the real adapter stores canonical compounds and exposes no internal frame metadata in one call", async () => {
  const text = "The team recovered quickly after setbacks.";
  const s = {
    word: "bounce back",
    canonicalForm: "bounce back",
    surfaceForm: "bounced back",
    lexicalType: "phrasalVerb",
    concept: "recovery after setbacks",
    replacementText: "bounced back quickly",
    partOfSpeech: "verb",
    definition: "To recover after difficulty or a setback.",
    nuance: "",
    examples: ["The team bounced back quickly."],
    collocations: ["bounce back from a setback"],
    originalText: "recovered quickly",
    source: { sentence: text, before: "The team ", after: " after setbacks." },
    reason: "A reusable recovery expression.",
    confidence: 0.9,
  };
  let calls = 0;
  const provider = new GeminiLlm("test", "test", (async () => {
    calls++;
    return Response.json({
      candidates: [
        {
          content: {
            parts: [
              {
                text: JSON.stringify({
                  suggestions: [s],
                  opportunities: [],
                  usages: [],
                  summary: "",
                }),
              },
            ],
          },
        },
      ],
    });
  }) as typeof fetch);
  const result = await provider.analyzeWriting(text, []);
  assert.equal(calls, 1);
  assert.equal(result.suggestions[0].word, "bounce back");
  assert.ok(!("canonicalForm" in result.suggestions[0]));
  const audit = inspectAnalysisProposals(text, {
    suggestions: [s],
    opportunities: [],
    usages: [],
    summary: "",
  });
  assert.equal(audit.audit[0].stages.lexicalItemValid, true);
});
