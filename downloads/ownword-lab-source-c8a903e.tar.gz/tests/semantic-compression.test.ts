import test from "node:test";
import assert from "node:assert/strict";
import { inspectAnalysisProposals } from "../lib/llm/gemini";

function inspect(input: string, old = "ownership history", replacement = "provenance", definition = "the origin and ownership history of an object") {
  return inspectAnalysisProposals(input, {suggestions: [{concept:definition, originalText:old, word:"provenance", canonicalForm:"provenance", surfaceForm:"provenance", lexicalType:"word", replacementText:replacement, preservation:{preservedQualifiers:[],preservedParticipants:[],preservedConditions:[],preservedCounts:[],preservedModality:[]}, partOfSpeech:"noun", definition, nuance:definition, collocations:[], examples:["The museum checked the provenance."], source:{sentence:input,before:"",after:""}, reason:"Names the source concept precisely.", confidence:0.9}],opportunities:[],usages:[],summary:""});
}
test("explicit ownership history survives only through audited compression", () => {
  const r=inspect("The records describe the ownership history of the stamp.");
  assert.equal(r.suggestions.length,1,JSON.stringify(r.audit));
  assert.equal(r.audit[0].reason,"source-supported-semantic-compression");
  assert.ok("frameEvidence" in r.audit[0]);
  assert.match(JSON.stringify("frameEvidence" in r.audit[0] && r.audit[0].frameEvidence),/origin-or-ownership-history/);
  assert.equal(r.suggestions[0].suggestedSentence,"The records describe the provenance of the stamp.");
});
for(const [label,input,old,replacement] of [
  ["generic history","The records describe the history of the stamp.","history","provenance"],
  ["negation","The records describe the ownership history of the stamp without known ownership.","ownership history","provenance"],
  ["possible","The records describe the possible ownership history of the stamp.","ownership history","provenance"],
  ["incomplete","The records describe the incomplete ownership history of the stamp.","ownership history","provenance"],
  ["complement changed","The records describe the ownership history of the stamp.","ownership history","provenance of the painting"],
  ["plural complement","The records describe the ownership history of the stamps.","ownership history","provenance"],
  ["different determiner","The records describe an ownership history of the stamp.","ownership history","provenance"],
  ["different complement","The records describe the ownership history in the ledger.","ownership history","provenance"],
]) test(`compression fails closed: ${label}`,()=>assert.equal(inspect(input,old,replacement).suggestions.length,0));
test("unproven instructional claims cannot use compression proof",()=>assert.equal(inspect("The records describe the ownership history of the stamp.","ownership history","provenance","a guaranteed complete record of every prior owner").suggestions.length,0));
