// Run against the local preview. Isolated API fixtures never write learner data.
import { createRequire } from "node:module";
import { mkdirSync } from "node:fs";
import assert from "node:assert/strict";
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const browser = await chromium.launch({
  headless: true,
  ...(process.env.BROWSER_EXECUTABLE
    ? { executablePath: process.env.BROWSER_EXECUTABLE }
    : { channel: process.env.BROWSER_CHANNEL || "msedge" }),
});
const base = process.env.TEST_BASE_URL || "http://127.0.0.1:5173";
const out = "outputs/quick-review-focused";
mkdirSync(out, { recursive: true });
const words = [
  ["nuanced", "Sensitive to small but meaningful differences."],
  ["negligible", "So small that it makes little practical difference."],
  ["compelling", "Convincing enough to hold your attention or persuade you."],
].map(([word, definition], i) => ({
  id: word,
  userWordId: word,
  word,
  definition,
  partOfSpeech: "adjective",
  examples: [`Her ${word} response helped us understand the issue.`],
  collocations: [],
  nuance: "",
  stage: "new",
  source: "Writing",
  sourceText: "",
  addedAt: "2026-10-20T00:00:00Z",
  introducedAt: "2026-10-21T00:00:00Z",
  nextReviewAt: i === 0 ? "2026-10-22T00:00:00Z" : "2027-10-30T00:00:00Z",
  attempts: [],
  demo: false,
}));
const state = {
  profile: {
    id: "navigation-fixture",
    name: "Test",
    dailyLimit: 7,
    onboarded: true,
  },
  words,
  dueCount: 1,
  queuedCount: 0,
  writingCount: 3,
  insights: [],
  mockMode: true,
};
const errors = [];
try {
  for (const mobile of [false, true]) {
    const context = await browser.newContext({
      viewport: mobile
        ? { width: 375, height: 812 }
        : { width: 1366, height: 900 },
      hasTouch: mobile,
      isMobile: mobile,
      reducedMotion: "reduce",
    });
    const origin = new URL(base);
    await context.addCookies([
      { name: "__sites_local_auth", value: "1", url: origin.origin },
      {
        name: "ownword-language",
        value: mobile ? "vi" : "en",
        url: origin.origin,
      },
    ]);
    const page = await context.newPage();
    page.on("pageerror", (e) => errors.push(e.message));
    const ratings = new Map();
    const writes = [];
    await page.route("**/api/**", async (route) => {
      const path = new URL(route.request().url()).pathname;
      const body =
        route.request().method() === "POST"
          ? route.request().postDataJSON()
          : null;
      if (body) writes.push({ path, body });
      if (path === "/api/state") return route.fulfill({ json: state });
      if (path === "/api/practice/start") {
        ratings.clear();
        return route.fulfill({ json: { sessionId: "navigation-session" } });
      }
      if (path === "/api/practice/quick-rate") {
        assert.ok(!ratings.has(body.exerciseId), "No duplicate rating");
        ratings.set(body.exerciseId, body.rating);
        return route.fulfill({ json: { saved: true } });
      }
      if (path === "/api/practice") {
        const index = words.findIndex((_, i) => !ratings.has("ex-" + i));
        return route.fulfill({
          json: {
            complete: index < 0,
            total: words.length,
            results: [],
            words: words.map((w, i) => ({
              userWordId: w.userWordId,
              word: w.word,
              exerciseId: "ex-" + i,
            })),
            exercise:
              index < 0
                ? null
                : {
                    id: "ex-" + index,
                    kind: "strong",
                    position: index + 1,
                    total: words.length,
                    hint: "none",
                    sentencePending: false,
                    prompt: words[index].definition,
                    definition: words[index].definition,
                  },
          },
        });
      }
      throw new Error("Unexpected request: " + path);
    });
    const button = (name) => page.getByRole("button", { name, exact: true });
    const flip = () => button(mobile ? "Lật thẻ" : "Flip card");
    const next = () => button(mobile ? "Thẻ tiếp theo" : "Next card");
    const prev = () => button(mobile ? "Thẻ trước" : "Previous card");
    const front = () => page.locator(".quick-card.is-front").waitFor();
    const back = () => page.locator(".quick-card.is-revealed").waitFor();
    const snapshot = async (name) => {
      await page.evaluate(() => document.fonts.ready);
      assert.ok(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
      );
      await page.screenshot({
        path: `${out}/${mobile ? "mobile" : "desktop"}-${name}.png`,
        fullPage: true,
      });
    };
    await page.goto(base + "/practice");
    await page.locator(".practice-mode-quick").click();
    await button(mobile ? "Bắt đầu ôn nhanh" : "Start quick review").click();
    await front();
    assert.ok(await prev().isDisabled());
    await snapshot("front");
    await button(mobile ? "Phím tắt" : "Shortcuts").click();
    await page
      .getByRole("dialog", { name: mobile ? "Phím tắt" : "Shortcuts" })
      .waitFor();
    await page.keyboard.press("ArrowRight");
    assert.equal(
      await page.locator(".quick-progress-row > span").textContent(),
      mobile ? "Từ 1 / 3" : "Card 1 of 3",
    );
    await page.keyboard.press("Escape");
    assert.equal(await page.getByRole("dialog").count(), 0);
    if (mobile) {
      await flip().tap({ position: { x: 70, y: 40 } });
    } else {
      await page.locator(".quick-session-heading h1").click();
      const scrollY = await page.evaluate(() => window.scrollY);
      await page.keyboard.press("Space");
      assert.equal(
        await page.evaluate(() => window.scrollY),
        scrollY,
        "Space must not scroll",
      );
    }
    await back();
    assert.equal(
      await page.locator(".quick-flip-hint, .quick-rating-prompt").count(),
      0,
    );
    assert.equal(
      await page.locator(".quick-card-navigation > span").count(),
      0,
    );
    assert.equal(
      await page
        .locator(".quick-response .quick-note:not(.quick-saved-rating)")
        .count(),
      0,
    );
    const deckBounds = await page.locator(".quick-deck").boundingBox();
    const navBounds = await page.locator(".quick-card-navigation").boundingBox();
    const ratingBounds = await page.locator(".quick-rating-actions").boundingBox();
    assert.ok(deckBounds.y + deckBounds.height <= navBounds.y, "Navigation follows the deck");
    assert.ok(navBounds.y + navBounds.height <= ratingBounds.y, "Rating actions follow navigation");
    const center = (bounds) => bounds.x + bounds.width / 2;
    assert.ok(Math.abs(center(deckBounds) - center(navBounds)) < 2, "Navigation is centered under the deck");
    assert.ok(Math.abs(center(deckBounds) - center(ratingBounds)) < 2, "Rating actions are centered under the deck");
    await snapshot("back");
    if (mobile) await flip().tap({ position: { x: 70, y: 40 } });
    else await page.keyboard.press("Space");
    await front();
    // The translation disclosure must operate independently of the flip target.
    await page.locator(".suggestion-translation summary").click();
    assert.equal(await page.locator(".quick-card.is-front").count(), 1);
    assert.ok(
      await page.locator(".suggestion-translation").evaluate((el) => el.open),
    );
    if (!mobile) {
      await page.keyboard.press("Space"); // native summary toggle
      assert.equal(await page.locator(".quick-card.is-front").count(), 1);
      await page.locator(".quick-session-heading h1").click();
      await page.keyboard.press("ArrowRight");
    } else await next().tap();
    await page
      .getByText(mobile ? "Từ 2 / 3" : "Card 2 of 3", { exact: true })
      .waitFor();
    if (!mobile) await page.keyboard.press("ArrowLeft");
    else await prev().tap();
    await page
      .getByText(mobile ? "Từ 1 / 3" : "Card 1 of 3", { exact: true })
      .waitFor();
    assert.equal(
      writes.filter((r) => r.path.endsWith("quick-rate")).length,
      0,
      "Browsing never records ratings",
    );
    await next().click();
    await next().click();
    assert.ok(await next().isDisabled());
    await flip().click();
    await button(mobile ? "Chưa nhớ" : "Forgot").click();
    await page
      .getByText(mobile ? "Từ 1 / 3" : "Card 1 of 3", { exact: true })
      .waitFor();
    assert.deepEqual(
      [...ratings],
      [["ex-2", "forgot"]],
      "Rate a future card using its own exercise",
    );
    await next().click();
    await next().click();
    await page.locator(".quick-saved-rating").waitFor();
    assert.equal(
      await button(mobile ? "Chưa nhớ" : "Forgot").count(),
      0,
      "Rated cards cannot be rated twice",
    );
    await prev().click();
    await prev().click();
    await flip().click();
    await button(mobile ? "Đã nhớ" : "Got it").click();
    await page
      .getByText(mobile ? "Từ 2 / 3" : "Card 2 of 3", { exact: true })
      .waitFor();
    await button(mobile ? "Bỏ qua" : "Skip").click();
    await page.locator(".quick-complete").waitFor();
    assert.equal(await page.locator(".quick-results li").count(), 3);
    await button(
      mobile ? "Tiếp tục luyện tập đầy đủ" : "Continue to Full Practice",
    ).waitFor();
    await snapshot("recap");
    assert.deepEqual([...ratings.values()], ["forgot", "got", "skip"]);
    await context.close();
  }
  assert.deepEqual(errors, []);
  console.log(
    "PASS desktop Space/arrow keys, mobile tap flip, independent translation, navigation boundaries, no browsing writes, out-of-order ratings, no duplicates, recap and handoff CTA.",
  );
} finally {
  await browser.close();
}
