import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {instructionalResponseOverclaims} from "../lib/llm/semantic-policy";
import {inspectAnalysisProposals} from "../lib/llm/gemini";

const cases: Array<[string,string,string,boolean]> = [
 ["compelling","adjective","naturally leads others toward agreement",false],
 ["compelling","adjective","drives strong conviction",false],
 ["persuasive","adjective","makes listeners agree",false],
 ["cogent","adjective","ensures acceptance",false],
 ["forceful","adjective","changes the audience's mind",false],
 ["convincing","adjective","guarantees belief",false],
 ["compelling","adjective","commands belief",false],
 ["compelling","adjective","typically makes readers accept the argument",false],
 ["compelling","adjective","tends to produce conviction",false],
 ["compelling","adjective","inevitably changes minds",false],
 ["compelling","adjective","highly persuasive and attention-holding",true],
 ["compelling","adjective","makes an argument seem especially convincing",true],
 ["persuasive","adjective","having strong power to influence opinion",true],
 ["cogent","adjective","clear, logical, and convincing",true],
 ["compelling","adjective","strongly attracts attention or belief",true],
 ["sway","verb","influencing someone to change an opinion",true],
 ["convince","verb","causing someone to believe or accept something",true],
 ["compelling","adjective","can make an argument more persuasive",true],
];
for(const [word,pos,teaching,allowed] of cases) test(`response teaching ${word}: ${teaching}`,()=>{
 const r=instructionalResponseOverclaims(word,pos,{nuance:teaching});assert.equal(r.length===0,allowed,JSON.stringify(r));
 if(!allowed){assert.equal(r[0].field,"nuance");assert.equal(r[0].candidate,word);assert.equal(r[0].lexicallyEntailed,false);}
});
test("ordinary achieved-event examples remain separate from generic claims",()=>{
 assert.equal(instructionalResponseOverclaims("compelling","adjective",{"example-0":"Her compelling argument convinced the jury."}).length,0);
 assert.ok(instructionalResponseOverclaims("compelling","adjective",{"example-0":"Compelling arguments always make listeners agree."}).length);
});
test("saved OpenRouter E06 is rejected with an auditable field and phrase",()=>{
 const r=JSON.parse(readFileSync("evals/results/openrouter-reliability-2026-10-30/results.json","utf8"));
 const row=r.rows.find((x:{case:{id:string}})=>x.case.id==="E06");
 const result=inspectAnalysisProposals(row.case.input,row.requests[0].rawModelOutput);
 assert.equal(result.suggestions.length,0);assert.equal(result.audit[0].reason,"instructional-response-entailment-overclaim");
 assert.match(JSON.stringify(result.audit[0]),/naturally|driving|conviction|agreement/i);
});
test("saved useful sway remains retained",()=>{
 const r=JSON.parse(readFileSync("evals/results/final-validation-3.6-2026-10-30/results.json","utf8"));
 const row=r.rows.find((x:{case:{id:string}})=>x.case.id==="D02");
 assert.equal(inspectAnalysisProposals(row.case.input,row.requests[0].rawModelOutput).suggestions[0]?.word,"sway");
});
test("convince may teach an entailed response through the full application",()=>{
 const text="The evidence was strong enough to make the panel change its mind.";
 const raw={suggestions:[{word:"convince",canonicalForm:"convince",partOfSpeech:"verb",originalText:"make the panel change its mind",replacementText:"convince the panel to change its mind",source:{sentence:text,before:"",after:""},definition:"To cause someone to believe or accept something.",nuance:"Focuses on a resulting change in belief.",reason:"Names an achieved change of mind.",examples:["The evidence convinced the panel."],collocations:[],confidence:0.9}],opportunities:[],usages:[],summary:""};
 const result=inspectAnalysisProposals(text,raw);assert.equal(result.suggestions.length,1,JSON.stringify(result.audit));
});

const successCases: Array<[string,string,string,boolean]> = [
 ["compelling","adjective","persuades the audience",false],
 ["compelling","adjective","naturally persuades listeners",false],
 ["persuasive","adjective","convinces people",false],
 ["cogent","adjective","wins the audience over",false],
 ["forceful","adjective","secures agreement",false],
 ["convincing","adjective","gets people to accept the claim",false],
 ["compelling","adjective","naturally holds interest and persuades",false],
 ["compelling","adjective","highly persuasive",true],
 ["compelling","adjective","can help persuade an audience",true],
 ["persuasive","adjective","having strong power to influence opinion",true],
 ["cogent","adjective","clear, logical, and convincing",true],
 ["sway","verb","influence someone to change an opinion",true],
 ["convince","verb","cause someone to believe or accept something",true],
 ["compelling","adjective","is designed to persuade people",true],
 ["compelling","adjective","may influence opinion",true],
 ["compelling","adjective","wins over the audience",false],
 ["compelling","adjective","results in agreement",false],
];
for(const [word,pos,teaching,allowed] of successCases) test(`success predicate ${word}: ${teaching}`,()=>{
 const findings=instructionalResponseOverclaims(word,pos,{nuance:teaching});
 assert.equal(findings.length===0,allowed,JSON.stringify(findings));
 if(!allowed){assert.equal(findings[0].dimension,"persuasion-success");assert.equal(findings[0].lexicallyEntailed,false);}
});
test("live E06 direct success predicate is rejected with audit",()=>{
 const r=JSON.parse(readFileSync("evals/results/openrouter-example-mini-2026-10-30/results.json","utf8"));
 const row=r.rows.find((x:{case:{id:string}})=>x.case.id==="E06");
 const result=inspectAnalysisProposals(row.case.input,row.requests[0].rawModelOutput);
 const item=result.audit.find(x=>x.word==="compelling");
 assert.ok(!result.suggestions.some(x=>x.word==="compelling"));
 assert.equal(item?.reason,"instructional-response-entailment-overclaim");
 assert.ok(item && "instructionalResponseFindings" in item && item.instructionalResponseFindings?.some(x=>x.field==="nuance"&&x.phrase==="persuades"&&!x.lexicallyEntailed));
});
