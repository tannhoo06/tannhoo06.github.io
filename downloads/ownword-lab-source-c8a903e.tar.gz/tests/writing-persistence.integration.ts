import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mkdtemp, mkdir, readFile, writeFile, copyFile, rm, rmdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { drizzle as d1Drizzle } from "drizzle-orm/d1";
import { migrate as d1Migrate } from "drizzle-orm/d1/migrator";
import { drizzle as pgDrizzle } from "drizzle-orm/node-postgres";
import { migrate as pgMigrate } from "drizzle-orm/node-postgres/migrator";
import { Miniflare } from "miniflare";
import { Pool } from "pg";
import * as d1Schema from "../db/schema";
import * as pgSchema from "../db/schema.pg";
import { D1WritingRepository } from "../lib/adapters/d1-writing-repository";
import { PgWritingRepository } from "../lib/adapters/pg-writing-repository";
import { D1Repository } from "../lib/adapters/d1-repository";
import { PgRepository } from "../lib/adapters/pg-repository";
import { streakAwardHeader } from "../lib/domain/learning-streak";
import { LearningStreakService } from "../lib/services/learning-streak";
import { resolveSource } from "../lib/domain/anchors";
import { createWritingApi } from "../lib/server/writing-api";
import { AppError } from "../lib/services/app-error";
import { WRITING_LEASE_MS, WritingService } from "../lib/services/writing";
import { readHostedWritingRuntime, readWritingConfig } from "../lib/writing/config";
import type { DiagnosticReport } from "../lib/writing/contracts";
import { validateIssueFirstOutput } from "../lib/writing/experimental/issue-first";
import { validateWritingFocusCheck } from "../lib/writing/focus-check";
import { toIssueFirstPilotReport } from "../lib/writing/issue-first-pilot";
import { WRITING_FOCUS_PIN_LIMIT, writingFocusHistoryKey, writingFocusTargets } from "../lib/writing/focus";
import { createMockWritingEvaluator } from "../lib/writing/mock-evaluator";
import type { WritingEvaluator, WritingFocusEvaluator, WritingRepository } from "../lib/writing/persistence";
import { getWritingProfileSessions } from "../lib/writing/profile";
import { prepareWritingRevision } from "../lib/writing/revision-check";
import { prepareWritingTrendAnalysis, validateWritingTrendAnalysis, writingTrendSourceKey, type WritingTrendAnalyst } from "../lib/writing/profile-trends";
import { validateWritingSkillVerification, type WritingSkillVerifier } from "../lib/writing/skill-verification";

type Database = {
  repository: WritingRepository;
  activityDays: Pick<PgRepository, "insertActivityDay" | "listActivityDays">;
  migrate: (folder: string) => Promise<void>;
  query: (text: string, ...params: string[]) => Promise<Record<string, unknown>[]>;
  withFreshConnection?: (verify: (repository: WritingRepository) => Promise<void>) => Promise<void>;
  close: () => Promise<void>;
};

async function openD1(): Promise<Database> {
  const miniflare = new Miniflare({
    modules: true,
    script: 'export default {fetch(){return new Response("test")}}',
    d1Databases: ["DB"],
    compatibilityDate: "2026-05-15",
  });
  const binding = await miniflare.getD1Database("DB");
  const db = d1Drizzle(binding as unknown as D1Database, { schema: d1Schema });
  return {
    repository: new D1WritingRepository(db),
    activityDays: new D1Repository(db, randomUUID),
    migrate: (migrationsFolder) => d1Migrate(db, { migrationsFolder }),
    query: async (text, ...params) => (await binding.prepare(text.replace(/\$\d+/g, "?")).bind(...params).all()).results,
    close: () => miniflare.dispose(),
  };
}

async function openPg(connection: string): Promise<Database> {
  const url = new URL(connection);
  if (!["127.0.0.1", "localhost", "[::1]"].includes(url.hostname) ||
    url.pathname !== "/ownword_writing_test" || url.search || url.hash) {
    throw new Error("Use a dedicated loopback PostgreSQL URL for the ownword_writing_test database.");
  }
  const parent = new Pool({ connectionString: url.href });
  const name = `ownword_writing_test_${randomUUID().replaceAll("-", "")}`;
  try {
    await parent.query(`create database "${name}" template template0`);
  } catch (error) {
    await parent.end();
    throw error;
  }
  url.pathname = `/${name}`;
  const pool = new Pool({ connectionString: url.href, max: 8 });
  const db = pgDrizzle(pool, { schema: pgSchema });
  return {
    repository: new PgWritingRepository(db),
    activityDays: new PgRepository(db, randomUUID),
    migrate: (migrationsFolder) => pgMigrate(db, { migrationsFolder }),
    query: async (text, ...params) => (await pool.query(text, params)).rows,
    withFreshConnection: async (verify) => {
      const reconnected = new Pool({ connectionString: url.href, max: 1 });
      try {
        await verify(new PgWritingRepository(pgDrizzle(reconnected, { schema: pgSchema })));
      } finally {
        await reconnected.end();
      }
    },
    close: async () => {
      await pool.end();
      try { await parent.query(`drop database "${name}"`); } finally { await parent.end(); }
    },
  };
}

async function applyMigrations(database: Database, folder: string, upgrade: boolean) {
  if (!upgrade) {
    await database.migrate(folder);
    return;
  }
  const journal = JSON.parse(await readFile(join(folder, "meta", "_journal.json"), "utf8")) as {
    version: string;
    entries: { tag: string }[];
  };
  const focus = journal.entries.pop();
  const streak = journal.entries.pop();
  const profile = journal.entries.pop();
  const revisionCheck = journal.entries.pop();
  const lifecycle = journal.entries.pop();
  assert.ok(focus?.tag.endsWith("_writing_focus"));
  assert.ok(streak?.tag.endsWith("_learning_streak"));
  assert.ok(profile && profile.tag.endsWith("_writing_profile_analysis"));
  assert.ok(revisionCheck && revisionCheck.tag.endsWith("_writing_revision_check"));
  assert.ok(lifecycle && lifecycle.tag.endsWith("_writing_lifecycle"));
  const baseline = await mkdtemp(join(tmpdir(), "ownword-writing-baseline-"));
  await mkdir(join(baseline, "meta"));
  try {
    await writeFile(join(baseline, "meta", "_journal.json"), JSON.stringify(journal));
    for (const { tag } of journal.entries) await copyFile(join(folder, `${tag}.sql`), join(baseline, `${tag}.sql`));
    await database.migrate(baseline);
    await database.query("insert into app_user (id, name, created_at) values ('legacy', 'Legacy', '2026-11-01')");
    await database.query("insert into writing_sample (id, user_id, text, prompt, created_at) values ('old', 'legacy', 'Original text', 'Old prompt', '2026-11-01')");
    await database.query("insert into request_limit (id, count) values ('legacy-practice-counter', 7)");

    journal.entries.push(lifecycle);
    await copyFile(join(folder, `${lifecycle.tag}.sql`), join(baseline, `${lifecycle.tag}.sql`));
    await writeFile(join(baseline, "meta", "_journal.json"), JSON.stringify(journal));
    await database.migrate(baseline);
    assert.deepEqual(await database.query("select id from writing_task"), []);

    const f = fixture(database, evaluateProfileSamples);
    const task = await f.task();
    const original = (await f.primary.submit({ ...f.body(task.id), text: profileSamples[0][2] })).record.submission;
    const revision = (await f.primary.submit({
      ...f.body(task.id), text: "Saved before checks were available.", parentSubmissionId: original.id,
    })).record.submission;
    f.advance(1000);
    const earlierRevision = (await f.primary.submit({
      ...f.body(task.id), text: "Saved before profile chronology was available.", parentSubmissionId: original.id,
    })).record.submission;
    journal.entries.push(revisionCheck);
    await copyFile(join(folder, `${revisionCheck.tag}.sql`), join(baseline, `${revisionCheck.tag}.sql`));
    await writeFile(join(baseline, "meta", "_journal.json"), JSON.stringify(journal));
    await database.migrate(baseline);
    const historicalCheck = { originalId: original.id, revisionId: earlierRevision.id, items: [], introduced: [],
      nextStep: { en: "Keep revising.", vi: "Tiếp tục chỉnh sửa." } };
    await database.query("insert into writing_revision_check (revision_id, result) values ($1, $2)",
      earlierRevision.id, JSON.stringify(historicalCheck));

    await database.migrate(folder);
    assert.equal((await database.query("select text from writing_sample where id = 'old'"))[0].text, "Original text");
    assert.equal((await database.query("select count from request_limit where id = 'legacy-practice-counter'"))[0].count, 7);
    assert.deepEqual(await f.primary.getRevisionCheck(revision.id), { check: null, pending: false });
    assert.deepEqual(await f.primary.getRevisionCheck(earlierRevision.id), { check: historicalCheck, pending: false });
    const [originalEvidence] = await database.repository.listProfileRecords(f.id);
    assert.deepEqual(originalEvidence.revisionCheck, historicalCheck);
    assert.equal(originalEvidence.revisionCheckedAt, null);
    assert.deepEqual((await f.primary.getSubmission(revision.id)).submission, revision);
    const writingProfile = await f.primary.profileOverview();
    assert.equal(writingProfile.history[0].id, original.id);
    assert.equal(writingProfile.history[0].latestRevisionId, earlierRevision.id);
    assert.equal(writingProfile.trends.state, "emerging");
    const restoredFocus = await f.primary.focusBoard();
    assert.equal(restoredFocus.suggestions[0].key, "subject-verb-agreement");
    assert.equal((await f.primary.focusDetail(restoredFocus.suggestions[0].key)).evidence[0].submissionId, original.id);
  } finally {
    for (const { tag } of journal.entries) await rm(join(baseline, `${tag}.sql`), { force: true });
    await rm(join(baseline, "meta", "_journal.json"), { force: true });
    await rmdir(join(baseline, "meta"));
    await rmdir(baseline);
  }
}

const text = "I would turn music off for difficult reading. Music distracts me when I switch between reading and taking notes.";
const mock = createMockWritingEvaluator([{
  promptId: "music-while-studying",
  text,
  output: {
    opportunities: { "ARG.SUPPORT": "limited", "ORG.PROGRESSION": "limited", "LEX.PRECISION": "adequate", "GRAM.ACCURACY": "limited" },
    taskFulfillment: {
      position: { status: "undetermined", evidence: [] },
      reasons: { status: "undetermined", evidence: [] },
      trade_off: { status: "undetermined", evidence: [] },
    },
    findings: [{
      skillId: "LEX.PRECISION", judgment: "positive", evidence: [{ quote: "switch between reading and taking notes", segmentId: 2 }],
      readerImpact: "The wording makes the two activities clear.", revisionCue: null,
    }],
  },
}]);

function deferred() {
  let release!: () => void;
  const promise = new Promise<void>((resolve) => { release = resolve; });
  return { promise, release };
}

function fixture(
  database: Database,
  evaluator: WritingEvaluator = mock,
  limits = { successes: 1, attempts: 5 },
  revisionCheck?: ConstructorParameters<typeof WritingService>[7],
  trendAnalyst?: WritingTrendAnalyst,
  skillVerifier?: WritingSkillVerifier,
  focusEvaluator?: WritingFocusEvaluator,
) {
  let timestamp = Date.parse("2026-11-16T12:00:00Z");
  const id = randomUUID();
  function service(owner = id, repository = database.repository, trendPolicy?: ConstructorParameters<typeof WritingService>[9]) {
    return new WritingService(repository, owner, () =>
      database.query("insert into app_user (id, name, created_at) values ($1, 'Fixture', '2026-11-16') on conflict do nothing", owner),
    { now: () => new Date(timestamp) }, { next: randomUUID }, limits, evaluator, revisionCheck, trendAnalyst, trendPolicy, skillVerifier,
    new LearningStreakService(database.activityDays, owner, { now: () => new Date(timestamp) }), focusEvaluator);
  }
  const primary = service();
  const task = (owner = primary, requestId = randomUUID()) =>
    owner.createTask({ promptId: "music-while-studying", interestIds: [], locale: "en", requestId });
  const body = (taskId: string, requestId = randomUUID()) => ({ taskId, requestId, text });
  return { id, primary, service, task, body, setTime: (at: string) => { timestamp = Date.parse(at); }, advance: (ms: number) => { timestamp += ms; } };
}

function httpError(status: number) {
  return (error: unknown) => error instanceof AppError && error.status === status;
}

async function checkOwnership(database: Database) {
  const f = fixture(database);
  const outsiderId = randomUUID();
  const outsider = f.service(outsiderId);
  const taskKey = randomUUID();
  const task = await f.task(f.primary, taskKey);
  assert.equal((await f.task(f.primary, taskKey)).id, task.id);
  assert.notEqual((await f.task(outsider, taskKey)).id, task.id);
  await assert.rejects(f.primary.createTask({ promptId: "fair-group-plans", interestIds: [], locale: "en", requestId: taskKey }), httpError(409));
  await assert.rejects(f.primary.createTask({ promptId: "quiet-or-music", interestIds: [], locale: "en", requestId: randomUUID() }), httpError(400));
  const request = f.body(task.id);
  const { record } = await f.primary.submit(request);
  assert.equal(record.task.snapshot.prompt.id, "music-while-studying");
  assert.equal(record.task.promptVersion, "v2");
  assert.equal(record.run?.report?.findings[0].evidence[0].exact, "switch between reading and taking notes");
  assert.equal(record.submission.text, text);
  const submissionId = record.submission.id;
  assert.equal((await f.primary.profile()).latestSubmissionId, submissionId);
  assert.equal((await outsider.profile()).latestSubmissionId, null);
  assert.equal((await f.primary.history()).find(({ id }) => id === submissionId)?.title, "Music while studying");
  assert.deepEqual(await outsider.history(), []);
  await assert.rejects(outsider.submit(request), httpError(404));
  await assert.rejects(outsider.getSubmission(submissionId), httpError(404));
  await assert.rejects(outsider.retry(submissionId, { requestId: randomUUID() }), httpError(404));
  await assert.rejects(outsider.deleteSubmission(submissionId), httpError(404));
  await outsider.deleteAll();
  assert.equal((await f.primary.getSubmission(submissionId)).submission.text, text);
  await assert.rejects(database.query(
    "insert into writing_submission (id, user_id, task_id, client_request_id, text, word_count, assistance, created_at) values ('invalid-owner', $1, $2, 'direct', 'Sample', 1, 'unknown', '2026-11-16')",
    outsiderId, task.id,
  ));
}

async function checkConcurrency(database: Database) {
  const started = deferred();
  const finish = deferred();
  let calls = 0;
  const f = fixture(database, async (input) => {
    calls++;
    started.release();
    await finish.promise;
    return mock(input);
  });
  const request = f.body((await f.task()).id);
  const first = f.primary.submit(request);
  try {
    await Promise.race([started.promise, first]);
    const otherTasks = await Promise.all(Array.from({ length: 4 }, () => f.task()));
    const peers = await Promise.all([
      ...Array.from({ length: 8 }, () => f.service().submit(request)),
      ...otherTasks.map(({ id }) => f.service().submit(f.body(id))),
    ]);
    assert.equal(calls, 1);
    assert.ok(peers.slice(0, 8).every(({ record, quotaReached }) => record.run?.status === "pending" && !quotaReached));
    assert.equal(new Set(peers.slice(0, 8).map(({ record }) => record.submission.id)).size, 1);
    assert.ok(peers.slice(8).every(({ record, quotaReached }) => !record.run && quotaReached));
    assert.deepEqual(await f.primary.quotas(), {
      limits: { successes: 1, attempts: 5 }, pending: 1, remaining: 0, resetAt: "2026-11-17T00:00:00.000Z",
    });
  } finally {
    finish.release();
    await first;
  }
  const completed = await first;
  const replay = await f.primary.submit(request);
  assert.equal(completed.record.run?.status, "succeeded");
  assert.equal(replay.record.run?.id, completed.record.run?.id);
  assert.equal(replay.record.submission.id, completed.record.submission.id);
  assert.equal((await database.query("select id from writing_run where user_id = $1", f.id)).length, 1);
  await assert.rejects(f.primary.submit({ ...request, text: "Different text" }), httpError(409));
  await assert.rejects(f.primary.submit(f.body(request.taskId)), httpError(409));
}

async function checkRetries(database: Database) {
  let calls = 0;
  const f = fixture(database, (input) => {
    calls++;
    if (calls === 1) throw new Error("Do not persist evaluator error content");
    return mock(input);
  });
  const request = f.body((await f.task()).id);
  const first = await f.primary.submit(request);
  assert.equal(first.record.run?.status, "failed");
  assert.equal(first.record.run?.report, null);
  assert.equal((await f.primary.quotas()).remaining, 1);
  assert.equal((await f.primary.submit(request)).record.run?.id, first.record.run?.id);
  assert.equal(calls, 1);
  const retry = { requestId: randomUUID() };
  const concurrentRetry = { requestId: randomUUID() };
  const id = first.record.submission.id;
  const outcomes = await Promise.all([f.primary.retry(id, retry), f.service().retry(id, retry), f.service().retry(id, concurrentRetry)]);
  assert.equal(calls, 2);
  assert.ok(outcomes.every(({ record }) => record.run?.status === "pending" || record.run?.status === "succeeded"));
  assert.equal((await f.primary.getSubmission(id)).run?.status, "succeeded");
  const other = await f.primary.submit(f.body((await f.task()).id));
  const [winningRun] = await database.query("select idempotency_key from writing_run where user_id = $1 and status = 'succeeded'", f.id);
  const winningRetry = [retry, concurrentRetry].find(({ requestId }) => `retry:${requestId}` === winningRun.idempotency_key);
  assert.ok(winningRetry);
  await assert.rejects(f.primary.retry(other.record.submission.id, winningRetry), httpError(409));
  assert.equal((await database.query("select id from writing_run where user_id = $1", f.id)).length, 2);

  const failing = fixture(database, () => ({ status: "invalid_output", reason: "unusable_evidence" }), { successes: 1, attempts: 2 });
  const failed = await failing.primary.submit(failing.body((await failing.task()).id));
  await failing.primary.retry(failed.record.submission.id, { requestId: randomUUID() });
  assert.equal((await failing.primary.quotas()).remaining, 0);
  const denied = await failing.primary.retry(failed.record.submission.id, { requestId: randomUUID() });
  assert.equal(denied.quotaReached, true);
  assert.deepEqual(await database.repository.getQuota(failing.id, "2026-11-16T12:00:00Z"), { attempts: 2, pending: 0, successes: 0 });
}

async function checkExpiryAndRollover(database: Database) {
  const started = deferred();
  const finish = deferred();
  let calls = 0;
  const f = fixture(database, async (input) => {
    if (++calls === 1) {
      started.release();
      await finish.promise;
    }
    return mock(input);
  });
  const task = await f.task();
  const request = f.body(task.id);
  const first = f.primary.submit(request);
  try {
    await Promise.race([started.promise, first]);
    const pending = await f.primary.submit(request);
    f.advance(WRITING_LEASE_MS);
    assert.equal((await f.primary.getSubmission(pending.record.submission.id)).run?.status, "expired");
    assert.equal((await f.primary.quotas()).remaining, 1);
    assert.equal((await f.primary.submit(request)).record.run?.status, "expired");
    const recovered = await f.primary.retry(pending.record.submission.id, { requestId: randomUUID() });
    assert.equal(recovered.record.run?.status, "succeeded");
    assert.notEqual(recovered.record.run?.id, pending.record.run?.id);
  } finally {
    finish.release();
    await first;
  }
  assert.equal(calls, 2);
  assert.deepEqual(await database.repository.getQuota(f.id, "2026-11-16T12:05:00Z"), { attempts: 2, pending: 0, successes: 1 });

  const atMidnight = deferred();
  const settleMidnight = deferred();
  let midnightCalls = 0;
  const midnight = fixture(database, async (input) => {
    if (++midnightCalls === 1) {
      atMidnight.release();
      await settleMidnight.promise;
    }
    return mock(input);
  });
  midnight.setTime("2026-11-16T23:59:59Z");
  const before = midnight.primary.submit(midnight.body((await midnight.task()).id));
  try {
    await Promise.race([atMidnight.promise, before]);
    midnight.advance(1_001);
    const after = await midnight.primary.submit(midnight.body((await midnight.task()).id));
    assert.equal(after.record.run?.quotaDay, "2026-11-17");
    assert.equal(after.record.run?.status, "succeeded");
  } finally {
    settleMidnight.release();
    await before;
  }
  assert.equal((await before).record.run?.quotaDay, "2026-11-16");
  for (const day of ["2026-11-16", "2026-11-17"]) {
    assert.deepEqual(await database.repository.getQuota(midnight.id, `${day}T23:59:59Z`), { attempts: 1, pending: 0, successes: 1 });
  }
}

async function checkDeletion(database: Database) {
  const f = fixture(database);
  const request = f.body((await f.task()).id);
  const { record } = await f.primary.submit(request);
  const submissionId = record.submission.id;
  const revisionBody = { ...f.body(request.taskId), text: "My own revision.", parentSubmissionId: submissionId };
  const revision = await f.primary.submit(revisionBody);
  assert.equal((await f.primary.submissionDetail(submissionId)).latestRevisionId, revision.record.submission.id);
  assert.equal(revision.record.run, null);
  assert.equal(revision.record.submission.assistance, "ownword_hint");
  await f.primary.deleteSubmission(revision.record.submission.id);
  assert.equal((await f.primary.submissionDetail(submissionId)).latestRevisionId, null);
  await assert.rejects(f.primary.submit(revisionBody), httpError(409));
  const keptRevision = await f.primary.submit({ ...revisionBody, requestId: randomUUID() });
  await f.primary.deleteSubmission(submissionId);
  for (const id of [submissionId, keptRevision.record.submission.id]) {
    await assert.rejects(f.primary.getSubmission(id), httpError(404));
  }
  await assert.rejects(f.primary.submit(request), httpError(404));
  assert.deepEqual(await database.query("select report from writing_run where user_id = $1", f.id), []);
  assert.equal((await f.primary.quotas()).remaining, 0);
  const savedWithoutQuota = await f.primary.submit(f.body((await f.task()).id));
  assert.equal(savedWithoutQuota.quotaReached, true);
  await f.primary.deleteAll();
  assert.equal((await f.primary.quotas()).remaining, 0);

  const started = deferred();
  const settle = deferred();
  const active = fixture(database, async (input) => {
    started.release();
    await settle.promise;
    return mock(input);
  });
  const inFlight = active.body((await active.task()).id);
  const pending = active.primary.submit(inFlight);
  try {
    await Promise.race([started.promise, pending]);
    const replay = await active.primary.submit(inFlight);
    await active.primary.deleteSubmission(replay.record.submission.id);
  } finally {
    settle.release();
    await assert.rejects(pending, httpError(404));
  }
  assert.deepEqual(await database.query("select id from writing_run where user_id = $1", active.id), []);
  assert.deepEqual(await database.query("select id from writing_submission where user_id = $1", active.id), []);
  assert.deepEqual(await database.repository.getQuota(active.id, "2026-11-16T12:05:00Z"), { attempts: 1, pending: 0, successes: 0 });
}

async function checkRevisionFeedback(database: Database) {
  let calls = 0;
  const evaluating = deferred();
  const finish = deferred();
  const f = fixture(database, (input) => {
    const result = mock(input);
    return result.status === "validated"
      ? { ...result, report: { ...result.report, issueFirstObservations: [] } }
      : result;
  }, { successes: 1, attempts: 2 }, async ({ revisionId, report }) => {
    if (++calls === 1) {
      evaluating.release();
      await finish.promise;
    } else {
      throw new Error("Simulate a provider failure");
    }
    return {
      originalId: report.submissionId, revisionId, items: [], introduced: [],
      nextStep: { en: "Read the new sentence aloud.", vi: "Đọc thành tiếng câu vừa sửa." },
    };
  });
  const task = await f.task();
  const { record: original } = await f.primary.submit(f.body(task.id));
  const parentSubmissionId = original.submission.id;
  const saveRevision = (text: string) => f.primary.submit({ ...f.body(task.id), text, parentSubmissionId });
  const { record: same } = await saveRevision(text);
  f.advance(50);
  const { record: first } = await saveRevision("My own revision.");
  f.advance(50);
  const { record: newest } = await saveRevision("My own revision with a new sentence.");
  const list = await f.primary.revisions(parentSubmissionId);
  assert.deepEqual(list.map(({ id }) => id), [newest.submission.id, first.submission.id, same.submission.id]);
  assert.deepEqual(Object.keys(list[0]).sort(), ["createdAt", "id", "wordCount"]);
  const outsider = f.service(randomUUID());
  await assert.rejects(outsider.revisions(parentSubmissionId), httpError(404));
  await assert.rejects(outsider.checkRevision(newest.submission.id), httpError(404));
  await assert.rejects(outsider.getRevisionCheck(first.submission.id), httpError(404));
  await assert.rejects(f.primary.getRevisionCheck(parentSubmissionId), httpError(404));
  await assert.rejects(f.primary.checkRevision(parentSubmissionId), httpError(404));
  await assert.rejects(f.primary.checkRevision(same.submission.id), httpError(409));
  assert.equal(calls, 0);

  const api = createWritingApi(async () => f.service());
  const endpoint = `https://ownword.test/api/writing/submissions/${first.submission.id}/revision-check`;
  const request = new Request(endpoint);
  const context = { params: Promise.resolve({ id: first.submission.id }) };
  const initial = await api.revisionCheck(request, context);
  assert.equal(initial.status, 200);
  assert.equal(initial.headers.get("cache-control"), "no-store");
  assert.deepEqual(await initial.json(), { check: null, pending: false });

  const requests = [
    f.primary.checkRevision(first.submission.id),
    f.service().checkRevision(first.submission.id),
  ];
  const checks = Promise.allSettled(requests);
  try {
    await Promise.race([evaluating.promise, checks.then(() => assert.fail("Expected a check to reach the evaluator"))]);
    await assert.rejects(Promise.race(requests), httpError(409));
    assert.deepEqual(await (await api.revisionCheck(request, context)).json(), { check: null, pending: true });
  } finally {
    finish.release();
  }
  const outcomes = await checks;
  const completed = outcomes.find(({ status }) => status === "fulfilled");
  const competing = outcomes.find(({ status }) => status === "rejected");
  assert.ok(completed?.status === "fulfilled");
  assert.ok(competing?.status === "rejected" && httpError(409)(competing.reason));
  const check = completed.value;
  assert.equal(check.revisionId, first.submission.id);
  assert.equal(calls, 1);
  assert.deepEqual(await (await api.revisionCheck(request, context)).json(), { check, pending: false });

  await assert.rejects(f.primary.checkRevision(newest.submission.id), httpError(503));
  assert.deepEqual(await f.primary.getRevisionCheck(newest.submission.id), { check: null, pending: false });
  await assert.rejects(f.primary.checkRevision(newest.submission.id), httpError(429));
  assert.deepEqual(await f.service().checkRevision(first.submission.id), check);
  assert.equal(calls, 2);
  assert.equal((await f.primary.getSubmission(newest.submission.id)).run, null);
  assert.deepEqual((await f.primary.getSubmission(parentSubmissionId)).run, original.run);
  await f.primary.deleteSubmission(first.submission.id);
  await assert.rejects(f.primary.getRevisionCheck(first.submission.id), httpError(404));
  assert.deepEqual(await database.query("select result from writing_revision_check where revision_id = $1", first.submission.id), []);

  f.setTime("2026-11-17T12:00:00Z");
  const revisionId = newest.submission.id;
  const firstLease = randomUUID();
  const secondLease = randomUUID();
  const leaseDay = Date.parse("2026-11-17T12:00:00Z");
  const reserve = (leaseToken: string, age: number) => database.repository.reserveRevisionCheck(f.id, {
    revisionId, leaseToken, attemptLimit: 2,
    now: new Date(leaseDay + age).toISOString(),
    leaseExpiresAt: new Date(leaseDay + age + WRITING_LEASE_MS).toISOString(),
  });
  assert.equal((await reserve(firstLease, 0)).status, "claimed");
  f.advance(WRITING_LEASE_MS);
  assert.deepEqual(await f.primary.getRevisionCheck(revisionId), { check: null, pending: false });
  assert.equal((await reserve(secondLease, WRITING_LEASE_MS)).status, "claimed");
  const retryResult = { ...check, revisionId };
  assert.equal(await database.repository.finishRevisionCheck(f.id, revisionId, firstLease, retryResult), false);
  assert.equal(await database.repository.finishRevisionCheck(f.id, revisionId, secondLease, retryResult), true);
  assert.deepEqual(await f.primary.getRevisionCheck(revisionId), { check: retryResult, pending: false });
  await f.primary.deleteSubmission(parentSubmissionId);
  assert.deepEqual(await database.query("select result from writing_revision_check where revision_id = $1", revisionId), []);
}

async function checkApi(database: Database) {
  assert.equal(readWritingConfig({}), null);
  assert.equal(readWritingConfig({ WRITING_MODULE_ENABLED: "false" }), null);
  assert.deepEqual(readWritingConfig({ WRITING_MODULE_ENABLED: "true" }), { successes: 8, attempts: 12 });
  const f = fixture(database);
  const origin = new URL(process.env.APP_ORIGIN || "https://ownword.test").origin;
  const endpoint = `${origin}/api/writing/submissions`;
  const post = (body: string, source = origin) => new Request(endpoint, {
    method: "POST",
    headers: { origin: source, "content-type": "application/json" },
    body,
  });
  const disabled = createWritingApi(async () => { throw new AppError("Disabled", 404); });
  assert.equal((await disabled.prompts(new Request(endpoint))).status, 404);
  const anonymous = createWritingApi(async () => { throw new AppError("Sign in", 401); });
  assert.equal((await anonymous.prompts(new Request(endpoint))).status, 401);
  const api = createWritingApi(async () => f.primary);
  assert.equal((await api.submit(post("{}", "https://other.test"))).status, 403);
  assert.equal((await api.submit(post(JSON.stringify({ text: "🙂".repeat(8_001) })))).status, 413);
  const request = f.body((await f.task()).id);
  for (const text of ["\0bad text", "\ud800bad text"]) {
    assert.equal((await api.submit(post(JSON.stringify({ ...request, text })))).status, 400);
  }
  assert.equal((await api.submit(post(JSON.stringify({ ...request, userId: randomUUID() })))).status, 400);
  const owned = await api.submit(post(JSON.stringify({ ...request, text: "  🙂 Exact text.\r\n " })));
  assert.equal(owned.status, 200);
  assert.equal(owned.headers.get("cache-control"), "no-store");
  const { submission: { id, text: storedText } } = await owned.json() as { submission: { id: string; text: string } };
  assert.equal(storedText, "  🙂 Exact text.\r\n ");
  const outsider = createWritingApi(async () => f.service(randomUUID()));
  const context = { params: Promise.resolve({ id }) };
  assert.equal((await outsider.submission(new Request(endpoint), context)).status, 404);
  assert.equal((await outsider.deleteSubmission(post("{}"), context)).status, 404);
  assert.equal((await api.deleteSubmission(post("{}"), context)).status, 200);
  assert.equal((await api.submission(new Request(endpoint), context)).status, 404);

  const limited = fixture(database);
  const limitedApi = createWritingApi(async () => limited.primary);
  const first = await limitedApi.submit(post(JSON.stringify(limited.body((await limited.task()).id))));
  assert.equal(first.status, 200);
  const assessed = await first.json() as { run: { report: DiagnosticReport } };
  assert.ok(assessed.run.report);
  const denied = await limitedApi.submit(post(JSON.stringify(limited.body((await limited.task()).id))));
  assert.equal(denied.status, 429);
  const saved = await denied.json() as {
    code: string; quota: Awaited<ReturnType<WritingService["quotas"]>>; submission: { id: string; text: string }; run: null;
  };
  assert.equal(saved.code, "daily_limit");
  assert.equal(saved.quota.remaining, 0);
  assert.equal(saved.quota.resetAt, "2026-11-17T00:00:00.000Z");
  assert.equal(saved.submission.text, text);
  assert.equal(saved.run, null);
  const retry = await limitedApi.retry(post(JSON.stringify({ requestId: randomUUID() })), {
    params: Promise.resolve({ id: saved.submission.id }),
  });
  assert.equal(retry.status, 429);
  const retried = await retry.json() as typeof saved;
  assert.equal(retried.submission.id, saved.submission.id);
}

const profileSamples = [
  ["A steady rhythm help", "A steady rhythm helps", "A steady rhythm help me settle in when I review familiar notes. Without the music, I spend too long looking out the window. For difficult reading, I prefer silence so that I can follow the argument."],
  ["My headphones makes", "My headphones make", "My headphones makes the library seem less crowded. Quiet conversations can break my concentration, so I sometimes put on instrumental tracks. I remove the headphones before starting a chapter that needs my full attention."],
  ["Each tune need", "Each tune needs", "Each tune need a steady tempo for me to use it while studying. A slow track fits a routine exercise. I keep my phone away from the desk because choosing songs would otherwise take up most of my time."],
  ["One short break help", "One short break helps", "One short break help when I stop understanding what I read. I make tea and then return to my notes without turning on the stereo. For the final few minutes, I try to say the main idea aloud."],
] as const;

const evaluateProfileSamples: WritingEvaluator = (submission) => {
  const example = profileSamples.find(([, , text]) => text === submission.text);
  if (!example) return mock(submission);
  const [before, after] = example;
  const result = validateIssueFirstOutput(submission, {
    opportunities: { "ARG.SUPPORT": "adequate", "ORG.PROGRESSION": "limited", "LEX.PRECISION": "adequate", "GRAM.ACCURACY": "adequate" },
    taskFulfillment: { position: { status: "undetermined", evidence: [] }, reasons: { status: "undetermined", evidence: [] },
      trade_off: { status: "undetermined", evidence: [] } },
    observations: [{ kind: "problem", problem: "Correct the subject–verb agreement", issueKind: "grammar_construction", materiality: "meaningful",
      readerImpact: "The verb form does not agree with its subject.", revisionCue: "Match the verb to its subject.",
      evidence: [{ quote: before, segmentId: null }], attribution: { primary: "GRAM.ACCURACY", secondary: null, certainty: "clear" },
      profileEvidenceCandidate: true, feedback: { category: "mistake", replacement: after, vi: { problem: "Dùng động từ phù hợp với chủ ngữ",
        readerImpact: "Chủ ngữ và động từ chưa khớp nhau.", revisionCue: "Kiểm tra lại dạng động từ." } } }],
  }, "learner");
  const report = toIssueFirstPilotReport(submission, result);
  assert.ok(report);
  return { status: "validated", report, rejectedFindings: [], rejectedRequirements: [] };
};

async function checkFocus(database: Database) {
  const checked: string[][] = [];
  const f = fixture(database, async (submission, context) => {
    assert.equal(context, undefined);
    const result = await evaluateProfileSamples(submission);
    if (result.status === "validated" && submission.text === profileSamples[1][2]) {
      result.report.issueFirstObservations![0].problem = "Subject–verb mismatch";
    }
    return result;
  }, { successes: 8, attempts: 8 }, undefined, undefined, undefined, async (_submission, targets) => {
    const checkedTopicKeys = targets.map(({ key }) => key);
    checked.push(checkedTopicKeys);
    return { version: 1, checkedTopicKeys, observations: [] };
  });
  const outsider = f.service(randomUUID());
  const origin = new URL(process.env.APP_ORIGIN || "https://ownword.test").origin;
  const url = `${origin}/api/writing/focus`;
  const api = createWritingApi(async () => f.primary);
  const readOnly = createWritingApi(async () => outsider);
  const post = (key: string, action: string, source = origin) => new Request(url, {
    method: "POST", headers: { origin: source, "content-type": "application/json" }, body: JSON.stringify({ key, action }),
  });
  const request = async (owner: WritingService, index: number) => {
    const task = await f.task(owner);
    return { ...f.body(task.id), text: profileSamples[index][2] };
  };

  const emptyBoard = { active: [], suggestions: [], dismissed: [], pinCount: 0, pinLimit: WRITING_FOCUS_PIN_LIMIT,
    coachedCount: 0, coachingAvailable: true };
  assert.deepEqual(await f.primary.focusBoard(), emptyBoard);
  const first = await request(f.primary, 0);
  const original = (await f.primary.submit(first)).record.submission;
  await f.primary.submit(first);
  await f.primary.submit({ ...f.body(first.taskId), parentSubmissionId: original.id, text: "I edited my first essay." });
  const [only] = (await f.primary.focusBoard()).suggestions;
  assert.equal(only.sessionCount, 1);
  assert.equal(only.example.exact, profileSamples[0][0]);
  const { key } = only;
  const detailRequest = () => new Request(`${url}?problem=${encodeURIComponent(key)}`);
  assert.equal((await readOnly.focus(detailRequest())).status, 404);
  assert.equal((await readOnly.updateFocus(post(key, "add"))).status, 404);
  assert.equal((await api.updateFocus(post(key, "add", "https://other.test"))).status, 403);

  const [added, duplicate] = await Promise.all([api.updateFocus(post(key, "add")), api.updateFocus(post(key, "add"))]);
  assert.deepEqual([added.status, duplicate.status].sort(), [200, 409]);
  const pinnedBoard = { ...emptyBoard, active: [{ ...only, coached: true }], pinCount: 1, coachedCount: 1 };
  assert.deepEqual(await f.service().focusBoard(), pinnedBoard);
  await database.withFreshConnection?.(async (repository) =>
    assert.deepEqual(await f.service(f.id, repository).focusBoard(), pinnedBoard));

  f.advance(1000);
  const secondRequest = await request(f.primary, 1);
  const secondRecord = (await f.primary.submit(secondRequest)).record;
  const second = secondRecord.submission;
  assert.equal(secondRecord.run?.report?.focusContext, undefined);
  assert.deepEqual(secondRecord.run?.report?.focusCheck, { version: 1, checkedTopicKeys: [key], observations: [] });
  const focusedProfile = await f.primary.profileOverview();
  assert.equal(focusedProfile.radar.current?.submissionId, second.id);
  assert.equal(focusedProfile.radar.previous?.submissionId, original.id);
  assert.deepEqual(checked, [[key]], "one baseline subject–verb error does not exhaust the essay");

  const response = await api.focus(detailRequest());
  assert.equal(response.headers.get("cache-control"), "no-store");
  const detail = await response.json() as Awaited<ReturnType<WritingService["focusDetail"]>>;
  assert.deepEqual(new Set(detail.evidence.map(({ submissionId }) => submissionId)), new Set([original.id, second.id]));
  assert.ok(detail.evidence.every(({ explanation, examples }) => explanation.en && examples[0].exact));
  assert.equal((await f.primary.focusBoard()).active[0].sessionCount, 2);
  assert.equal((await api.updateFocus(post(key, "remove"))).status, 200);
  assert.equal((await f.service().focusBoard()).suggestions[0].sessionCount, 2);
  assert.equal((await api.updateFocus(post(key, "dismiss"))).status, 200);
  f.advance(1000);
  const third = await request(f.primary, 2);
  const beforeThird = await database.repository.listFocusRecords(f.id);
  const thirdId = (await f.primary.submit(third)).record.submission.id;
  assert.equal(checked.length, 1);
  const ordinaryProfile = await f.primary.profileOverview();
  assert.equal(ordinaryProfile.radar.current?.submissionId, thirdId);
  assert.equal(ordinaryProfile.radar.previous?.submissionId, second.id);
  assert.deepEqual(await f.service().focusBoard(), { ...emptyBoard, dismissed: [{ key, title: only.title }] });
  assert.equal((await api.focus(detailRequest())).status, 404);
  assert.equal((await api.updateFocus(post(key, "add"))).status, 409);
  await outsider.submit(await request(outsider, 3));
  assert.equal((await outsider.focusBoard()).suggestions[0].key, key);
  assert.equal(checked.length, 1);
  assert.equal((await readOnly.updateFocus(post(key, "restore"))).status, 409, "other account has no dismissal to restore");
  assert.equal((await api.updateFocus(post(key, "restore"))).status, 200);
  assert.equal((await f.primary.focusBoard()).suggestions[0].sessionCount, 3);
  assert.equal((await api.updateFocus(post(key, "add"))).status, 200);
  assert.equal(await database.repository.deleteSubmission(f.id, original.id, {
    historyKey: writingFocusHistoryKey(beforeThird), retainKeys: [],
  }), false, "a newly completed report invalidates an older deletion plan");
  await f.primary.deleteSubmission(original.id);
  assert.equal(await database.repository.updateFocusState(f.id, key, "remove", [original.id, second.id]), true,
    "a surviving source supports an in-flight transition");
  assert.equal((await api.updateFocus(post(key, "add"))).status, 200);
  await f.primary.deleteSubmission(second.id);
  assert.equal((await f.primary.focusBoard()).active[0].sessionCount, 1);
  await f.primary.deleteSubmission(thirdId);
  assert.deepEqual(await database.repository.listFocusStates(f.id), []);
  const returned = (await f.primary.submit(await request(f.primary, 3))).record.submission;
  assert.equal((await f.primary.focusBoard()).suggestions[0].sessionCount, 1);
  assert.equal((await api.updateFocus(post(key, "dismiss"))).status, 200);
  await f.primary.deleteSubmission(returned.id);
  assert.deepEqual(await database.repository.listFocusStates(f.id), []);
  await f.primary.submit(await request(f.primary, 3));
  assert.equal((await f.primary.focusBoard()).suggestions[0].key, key);
  await f.primary.deleteAll();
  assert.deepEqual(await database.repository.listFocusStates(f.id), []);
  assert.equal((await outsider.focusBoard()).suggestions[0].key, key);
  await database.query("insert into writing_focus_state (user_id, problem_key, status) values ($1, $2, 'dismissed')", f.id, key);
  await f.primary.submit(await request(f.primary, 0));
  assert.equal((await f.primary.focusBoard()).suggestions[0].key, key, "a previously orphaned dismissal must not hide new feedback");
  assert.deepEqual(await database.repository.listFocusStates(f.id), []);
}

async function checkFocusEvidence(database: Database) {
  const samples = [
    {
      text: "We discuss about the budget at every meeting. I saw a umbrella near the entrance. The article need another example. The room was crowded, so I went home and wrote my notes there.",
      notes: [
        ["discuss about the budget", "discuss the budget", "Wrong preposition", "grammar_construction"],
        ["a umbrella", "an umbrella", "Article correction", "grammar_construction"],
        ["article need", "article needs", "Article correction", "grammar_construction"],
      ],
    },
    {
      text: "The volunteers discussed about the plan outside. We saw a elephant close to the road. Although it rained, but we walked. I definetely wanted to stay longer and take a photo of the hillside.",
      notes: [
        ["discussed about the plan", "discussed the plan", "Extra about after discussed", "grammar_construction"],
        ["a elephant", "an elephant", "Change the determiner", "grammar_construction"],
        ["Although it rained, but we walked", "Although it rained, we walked", "Fix although", "clause_connection"],
        ["definetely", "definitely", "Spelling", "spelling"],
      ],
    },
    {
      text: "Although I like coffee. I drink tea most mornings. Our new classmate tried to book acommodation for the trip. The online form did not open until midday, so I sent her a new link to try.",
      notes: [
        ["Although I like coffee. I drink tea", "Although I like coffee, I drink tea", "Fix although", "clause_connection"],
        ["acommodation", "accommodation", "Spelling", "spelling"],
      ],
    },
  ];
  const contexts: string[][] = [];
  const f = fixture(database, (submission, context) => {
    assert.equal(context, undefined);
    const notes = samples.find((sample) => submission.text.includes(sample.notes[0][0]))?.notes ?? [];
    const validation = validateIssueFirstOutput(submission, {
      opportunities: { "ARG.SUPPORT": "adequate", "ORG.PROGRESSION": "adequate", "LEX.PRECISION": "adequate", "GRAM.ACCURACY": "adequate" },
      taskFulfillment: { position: { status: "undetermined", evidence: [] }, reasons: { status: "undetermined", evidence: [] },
        trade_off: { status: "undetermined", evidence: [] } },
      observations: notes.map(([quote, replacement, problem, issueKind]) => ({
        kind: "problem", problem, issueKind, materiality: "meaningful", readerImpact: "This construction needs the suggested correction.",
        revisionCue: null, evidence: [{ quote, segmentId: null }], attribution: { primary: null, secondary: null, certainty: "uncertain" },
        profileEvidenceCandidate: false, feedback: { category: "mistake", replacement, vi: { problem,
          readerImpact: "Hãy xem gợi ý sửa cho cụm này.", revisionCue: null } },
      })),
    }, "learner");
    const report = toIssueFirstPilotReport(submission, validation);
    assert.ok(report, JSON.stringify(validation));
    return { status: "validated", report, rejectedFindings: [], rejectedRequirements: [] };
  }, { successes: 12, attempts: 12 }, undefined, undefined, undefined, async (_submission, targets) => {
    const checkedTopicKeys = targets.map(({ key }) => key);
    contexts.push(checkedTopicKeys);
    return { version: 1, checkedTopicKeys, observations: [] };
  });
  const submit = async (text: string, assistance = "unassisted") => {
    f.advance(1000);
    const result = await f.primary.submit({ ...f.body((await f.task()).id), text, assistance });
    assert.equal(result.record.run?.status, "succeeded");
    return result.record.submission;
  };
  const first = await submit(samples[0].text);
  await submit(samples[0].text);
  await submit(samples[0].text.replace("crowded", "noisy"));
  await submit(samples[1].text, "external_help");
  assert.equal((await f.primary.focusBoard()).suggestions.find(({ key }) => key === "discuss-direct-object")?.sessionCount, 1);
  const ordinary = await submit(samples[2].text);
  const third = await submit(samples[1].text.replace(
    "The volunteers discussed about the plan outside.", "Before the tour, our volunteers discussed about the plan beside the gate."
  ).replace("I definetely wanted to stay longer and take a photo of the hillside.",
    "I definetely wanted to leave before the bus pulled away, so I asked the guide for directions."));
  const board = await f.primary.focusBoard();
  const discuss = board.suggestions.find(({ key }) => key === "discuss-direct-object")!;
  assert.equal(discuss.sessionCount, 2);
  const detail = await f.primary.focusDetail(discuss.key);
  assert.deepEqual(new Set(detail.evidence.map(({ submissionId }) => submissionId)), new Set([first.id, third.id]));
  assert.deepEqual(detail.evidence.map(({ replacement, cue }) => [replacement, cue]),
    [["discussed the plan", null], ["discuss the budget", null]]);
  assert.equal(board.suggestions.find(({ key }) => key === "local:article-sound")?.sessionCount, 2);
  assert.ok(board.suggestions.every(({ key }) => !key.startsWith("note:")));
  assert.equal(board.suggestions.find(({ key }) => key === "theme:clause-joins")?.sessionCount, 2);
  const unsupported = board.suggestions.find(({ key }) => key === "theme:spelling-mechanics")!;
  assert.equal(unsupported.sessionCount, 2);
  assert.equal((await f.primary.updateFocus({ key: unsupported.key, action: "add" })).coachedCount, 0);
  await submit("The library opens at nine. I will bring a book for the train and return it next week.", "ownword_hint");
  assert.equal(contexts.at(-1), undefined);
  const mixedBoard = await f.primary.updateFocus({ key: discuss.key, action: "add" });
  assert.equal(mixedBoard.coachedCount, 1);
  assert.equal(mixedBoard.active.find(({ key }) => key === discuss.key)?.coached, true);
  assert.equal(mixedBoard.active.find(({ key }) => key === unsupported.key)?.coached, false);
  await submit("The library is closed on Wednesday. We plan to check the notice before visiting on Saturday.");
  assert.equal(contexts.length, 0, "the supported pin has no trigger in the essay");
  await submit("The library is closed on Wednesday. We will discuss the notice before visiting on Saturday.");
  assert.deepEqual(contexts.at(-1), ["discuss-direct-object"]);
  assert.deepEqual(writingFocusTargets([unsupported.key, "local:article-sound"]).map(({ key }) => key), ["local:article-sound"]);
  const many = ["local:spell-receive", "local:article-sound", "local:finished-past", "local:word-borrow-lend",
    "discuss-direct-object", "subject-verb-agreement", "however-contrast", "comma-splice", unsupported.key];
  const bounded = writingFocusTargets(many);
  assert.equal(bounded.length, 6);
  assert.deepEqual(writingFocusTargets([...many].reverse()), bounded);
  assert.ok(!bounded.some(({ key }) => key === unsupported.key || key.startsWith("local:spell-")));
  assert.ok((await f.primary.focusDetail(unsupported.key)).evidence.some(({ submissionId }) =>
    submissionId === ordinary.id || submissionId === third.id));

  // A previously essay-local note keeps its saved state when its classifier learns the pattern.
  const previousKey = `note:${first.id}:0`;
  await database.query("insert into writing_focus_state (user_id, problem_key, status) values ($1, $2, 'dismissed')", f.id, previousKey);
  assert.ok((await f.primary.focusBoard()).dismissed.some(({ key }) => key === previousKey));
  assert.equal((await f.primary.focusDetail(discuss.key)).evidence.length, 2);
  await f.primary.updateFocus({ key: previousKey, action: "restore" });
  assert.equal((await f.primary.focusDetail(discuss.key)).evidence.length, 2);

  const ready = await f.primary.focusBoard();
  assert.equal(ready.pinCount, ready.pinLimit - 1);
  const candidates = ready.suggestions.slice(0, 2);
  assert.equal(candidates.length, 2);
  const lastSlot = await Promise.allSettled(candidates.map(({ key }) => f.service().updateFocus({ key, action: "add" })));
  assert.equal(lastSlot.filter(({ status }) => status === "fulfilled").length, 1);
  const denied = lastSlot.find((result): result is PromiseRejectedResult => result.status === "rejected");
  assert.ok(denied && httpError(409)(denied.reason));
  assert.match(denied.reason.message, /Writing Focus is full/);

  const full = await f.primary.focusBoard();
  assert.equal(full.pinCount, full.pinLimit);
  const waiting = candidates.find(({ key }) => full.suggestions.some((item) => item.key === key));
  assert.ok(waiting);
  assert.equal((await f.primary.updateFocus({ key: discuss.key, action: "remove" })).pinCount, full.pinLimit - 1);
  assert.equal((await f.primary.updateFocus({ key: waiting.key, action: "add" })).pinCount, full.pinLimit);

  const legacySpelling = `note:${ordinary.id}:1`;
  await database.query("insert into writing_focus_state (user_id, problem_key, status) values ($1, $2, 'dismissed')", f.id, legacySpelling);
  assert.ok((await f.primary.focusBoard()).dismissed.some(({ key }) => key === legacySpelling));
  const restored = await f.primary.updateFocus({ key: legacySpelling, action: "restore" });
  assert.ok(restored.suggestions.some(({ key }) => key === legacySpelling));
  assert.equal((await f.service().focusDetail(legacySpelling)).evidence[0].submissionId, ordinary.id);
  await f.primary.deleteSubmission(ordinary.id);
  assert.ok(!(await database.repository.listFocusStates(f.id)).some(({ key }) => key === legacySpelling));
  assert.deepEqual((await f.primary.focusDetail(unsupported.key)).evidence.map(({ submissionId }) => submissionId), [third.id]);

  const legacyPinned = `note:${third.id}:3`;
  await database.query("insert into writing_focus_state (user_id, problem_key, status) values ($1, $2, 'active')", f.id, legacyPinned);
  assert.equal((await f.primary.focusBoard()).active.find(({ key }) => key === legacyPinned)?.coached, false);
  const unpinned = await f.primary.updateFocus({ key: legacyPinned, action: "remove" });
  assert.ok(unpinned.suggestions.some(({ key }) => key === legacyPinned));
  assert.equal((await f.primary.focusDetail(legacyPinned)).evidence[0].submissionId, third.id);
  await f.primary.deleteSubmission(third.id);
  assert.ok(!(await database.repository.listFocusStates(f.id)).some(({ key }) => key === legacyPinned || key === unsupported.key));
}

async function checkFocusPassSeparation(database: Database) {
  const pin = "subject-verb-agreement";
  const found = "The new speakers makes";
  const secondText = `${profileSamples[1][2]} ${found} each song sound clearer.`;
  let mode = "recover";
  let calls = 0;
  const ordinaryReports = new Map<string, DiagnosticReport>();
  const f = fixture(database, async (submission, context) => {
    assert.equal(context, undefined);
    const result = await evaluateProfileSamples(submission.text === secondText
      ? { ...submission, text: profileSamples[1][2] } : submission);
    if (result.status === "validated") {
      if (mode === "legacy") result.report.focusContext = { version: 1, topicKeys: [pin] };
      ordinaryReports.set(submission.submissionId, result.report);
    }
    if (mode === "timeout") f.advance(WRITING_LEASE_MS - 4_000);
    return result;
  }, { successes: 8, attempts: 8 }, undefined, undefined, undefined, async (submission, targets, baseline, signal) => {
    calls++;
    if (mode === "failure") throw new Error("Focused transport unavailable");
    if (mode === "timeout") return new Promise((resolve) => {
      signal.addEventListener("abort", () => resolve(null), { once: true });
    });
    assert.equal(submission.text, secondText);
    assert.ok(baseline.some(({ key }) => key === pin));
    return validateWritingFocusCheck(submission, targets, baseline, { observations: [{
      focusTopicKey: pin, problem: "Correct the subject–verb agreement", issueKind: "grammar_construction", materiality: "meaningful",
      readerImpact: "The form does not agree with a plural subject.", revisionCue: "Use the base form after the plural subject.",
      evidence: [{ quote: found, segmentId: null }], attribution: { primary: "GRAM.ACCURACY", secondary: null, certainty: "clear" },
      feedback: { category: "mistake", replacement: "The new speakers make", vi: {
        problem: "Dùng động từ phù hợp với chủ ngữ", readerImpact: "Chủ ngữ và động từ chưa khớp nhau.", revisionCue: "Kiểm tra lại dạng động từ.",
      } },
    }] });
  });
  const submit = async (text: string) => {
    f.advance(1000);
    const { record } = await f.primary.submit({ ...f.body((await f.task()).id), text, assistance: "unassisted" });
    assert.equal(record.run?.status, "succeeded");
    assert.ok(record.run?.report);
    return { id: record.submission.id, report: record.run.report };
  };
  const first = await submit(profileSamples[0][2]);
  await f.primary.updateFocus({ key: pin, action: "add" });
  const second = await submit(secondText);
  assert.equal(calls, 1);
  assert.equal(second.report.focusCheck?.observations[0]?.evidence[0]?.exact, found);
  assert.deepEqual({ ...second.report, focusCheck: undefined }, { ...ordinaryReports.get(second.id), focusCheck: undefined });
  assert.deepEqual((await f.primary.getSubmission(second.id)).run?.report, second.report);
  const sessions = getWritingProfileSessions(await database.repository.listProfileRecords(f.id));
  assert.deepEqual(sessions.find(({ submission }) => submission.id === second.id)?.evidence.flatMap(({ anchors }) =>
    anchors.map(({ exact }) => exact)), [profileSamples[1][0]]);
  assert.ok((await f.primary.focusDetail(pin)).evidence.some(({ examples }) => examples.some(({ exact }) => exact === found)));
  const revisionInput = { report: second.report, original: secondText, revised: secondText.replace(found, "The new speakers make"),
    revisionId: randomUUID(), prompt: "Music while studying" };
  assert.deepEqual(prepareWritingRevision(revisionInput),
    prepareWritingRevision({ ...revisionInput, report: ordinaryReports.get(second.id)! }));

  mode = "failure";
  const failed = await submit(profileSamples[2][2]);
  assert.equal(calls, 2);
  assert.deepEqual(failed.report, ordinaryReports.get(failed.id));
  mode = "timeout";
  const timedOut = await submit(profileSamples[3][2]);
  assert.equal(calls, 3);
  assert.deepEqual(timedOut.report, ordinaryReports.get(timedOut.id));
  mode = "legacy";
  const legacy = await submit("Music makes a long bus ride feel shorter. I still need a quiet space for hard work, so I leave my headphones off when I write. After a break I switch to an instrumental track while I check my notes.");
  assert.equal(calls, 3);
  assert.deepEqual((await f.primary.getSubmission(legacy.id)).run?.report?.focusContext, { version: 1, topicKeys: [pin] });
  const profile = await f.primary.profileOverview();
  assert.equal(profile.radar.current?.submissionId, legacy.id);
  assert.equal(profile.radar.previous, null, "a legacy coached report remains readable and cannot be compared");
  await f.primary.deleteSubmission(second.id);
  assert.ok(!(await f.primary.focusDetail(pin)).evidence.some(({ submissionId }) => submissionId === second.id));
  assert.equal((await f.primary.focusBoard()).active[0]?.key, pin);
  assert.ok(first.report.focusCheck === undefined);
}

async function checkProfile(database: Database) {
  const start = deferred();
  const release = deferred();
  let analystCalls = 0;
  const analyst: WritingTrendAnalyst = async (input) => {
    analystCalls++;
    if (analystCalls === 1) {
      start.release();
      await release.promise;
      return null;
    }
    const recurring = input.candidates.find(({ kind }) => kind === "recurring_issue");
    assert.ok(recurring);
    assert.ok(input.candidates.some(({ kind }) => kind === "persistent_issue"));
    return validateWritingTrendAnalysis(input, { selections: [{ candidate: recurring.id, theme: null, evidence: recurring.others.slice(0, 2) }] });
  };
  const f = fixture(database, evaluateProfileSamples, { successes: 8, attempts: 8 }, async ({ report, revisionId }) => {
    const before = report.issueFirstObservations![0].evidence[0].exact;
    const note = { en: "Check the verb in this revision.", vi: "Kiểm tra động từ trong bản sửa này." };
    return { revisionId, originalId: report.submissionId, introduced: [], nextStep: note,
      items: [{ id: 0, status: "still_present", before, after: before, note }] };
  }, analyst);
  const add = async (index: number) => {
    f.advance(1000);
    const task = await f.task();
    const { record } = await f.primary.submit({ ...f.body(task.id), text: profileSamples[index][2], assistance: "unassisted" });
    assert.equal(record.run?.status, "succeeded");
    return record;
  };
  assert.equal((await f.primary.profileOverview()).trends.state, "emerging");
  const first = await add(0);
  f.advance(1000);
  const revision = (await f.primary.submit({ ...f.body(first.task.id), parentSubmissionId: first.submission.id,
    text: `${first.submission.text} At weekends I also study outside.` })).record;
  await f.primary.checkRevision(revision.submission.id);
  f.advance(1000);
  const unchecked = (await f.primary.submit({ ...f.body(first.task.id), parentSubmissionId: first.submission.id,
    text: `${first.submission.text} I study outside at weekends.` })).record;
  const second = await add(1);
  assert.equal((await f.primary.refreshProfileTrends()).trends.state, "emerging");
  assert.equal(analystCalls, 0);
  const third = await add(2);

  const records = await database.repository.listProfileRecords(f.id);
  assert.deepEqual(records.map(({ submission }) => submission.id), [third.submission.id, second.submission.id, first.submission.id]);
  assert.equal(records[2].latestRevisionId, unchecked.submission.id);
  assert.equal(records[2].revisionCheck?.revisionId, revision.submission.id);
  assert.equal(records[2].revisionCheckedAt, "2026-11-16T12:00:02.000Z");
  const outsider = f.service(randomUUID());
  const outsiderOverview = await outsider.profileOverview();
  assert.deepEqual(outsiderOverview.history, []);
  assert.equal(outsiderOverview.trends.state, "emerging");

  const overview = await f.primary.profileOverview();
  assert.equal(overview.trends.state, "available");
  assert.equal(overview.history.length, 3);
  assert.equal(overview.recentSessionIds[0], third.submission.id);
  assert.equal(overview.nextStep?.href, `/writing/submissions/${third.submission.id}/practice/0`);
  assert.equal(overview.radar.current?.skills["LEX.PRECISION"].judgment, "undetermined");
  assert.equal(analystCalls, 0);
  const api = createWritingApi(async () => f.primary);
  const apiOverview = await api.profileOverview();
  assert.equal(apiOverview.headers.get("cache-control"), "no-store");
  const payload = await apiOverview.json() as { latestSubmissionId: string | null };
  assert.equal(payload.latestSubmissionId, third.submission.id);

  const firstRefresh = f.primary.refreshProfileTrends();
  try {
    await Promise.race([start.promise, firstRefresh]);
    assert.equal((await f.service().profileOverview()).trends.state, "pending");
    assert.equal((await f.service().refreshProfileTrends()).trends.state, "pending");
    assert.equal(analystCalls, 1);
  } finally {
    release.release();
  }
  const failed = await firstRefresh;
  assert.equal(failed.trends.state, "retry");
  assert.ok(failed.trends.retryAt);
  assert.deepEqual(failed.recentInsights.map(({ submissionId }) => submissionId), [third.submission.id]);
  assert.equal((await f.primary.refreshProfileTrends()).trends.state, "retry");
  f.advance(30_001);

  const refreshed = await f.primary.refreshProfileTrends();
  assert.equal(refreshed.trends.state, "ready");
  assert.equal(refreshed.trends.items[0].kind, "recurring_issue");
  assert.match(refreshed.nextStep?.reason.en ?? "", /2 separate responses/);
  assert.deepEqual(refreshed.trends.items[0].evidence.map(({ submissionId }) => submissionId), [second.submission.id, third.submission.id]);
  assert.deepEqual(await f.service().profileOverview(), refreshed);
  await database.withFreshConnection?.(async (repository) => {
    assert.deepEqual(await f.service(f.id, repository).profileOverview(), refreshed);
  });
  assert.equal((await f.service().refreshProfileTrends()).trends.state, "ready");
  assert.equal(analystCalls, 2);
  const stored = await database.repository.getProfileAnalysis(f.id);
  assert.ok(stored?.result);
  assert.equal(await database.repository.getProfileAnalysis(randomUUID()), null);
  assert.doesNotMatch(JSON.stringify(stored), /A steady rhythm|My headphones|Each tune/);

  const fourth = await add(3);
  assert.equal((await f.primary.profileOverview()).trends.state, "available");
  await assert.rejects(f.primary.refreshProfileTrends(), httpError(429));
  assert.equal(analystCalls, 2);
  f.setTime("2026-11-17T12:00:00Z");
  assert.equal((await f.primary.refreshProfileTrends()).trends.state, "ready");
  assert.equal(analystCalls, 3);
  const latest = await database.repository.getProfileAnalysis(f.id);
  assert.ok(latest?.resultJson);
  assert.notEqual(latest.evidenceKey, stored.evidenceKey);

  const origin = new URL(process.env.APP_ORIGIN || "https://ownword.test").origin;
  const request = (body = "{}") => new Request(`${origin}/api/writing/profile/trends`, {
    method: "POST", headers: { origin, "content-type": "application/json" }, body,
  });
  const disabled = createWritingApi(async () => f.service(f.id, database.repository, "disabled"));
  const disabledResponse = await disabled.profileOverview();
  const disabledProfile = await disabledResponse.json() as typeof refreshed;
  assert.equal(disabledResponse.status, 200);
  assert.equal(disabledProfile.trends.state, "disabled");
  assert.deepEqual(disabledProfile.trends.items, []);
  assert.ok(disabledProfile.recentInsights.length > 0);
  assert.equal((await disabled.refreshProfileTrends(request())).status, 503);
  assert.equal((await api.refreshProfileTrends(request('{"policy":"improvement-pilot"}'))).status, 400);

  const pilot = prepareWritingTrendAnalysis(getWritingProfileSessions(await database.repository.listProfileRecords(f.id)),
    "improvement-pilot");
  const pilotKey = await writingTrendSourceKey(pilot);
  const pilotService = f.service(f.id, database.repository, "improvement-pilot");
  const stalePilotResult = { ...JSON.parse(latest.resultJson), policy: pilot.policy };
  await database.query("update writing_profile_analysis set result = $1, evidence_key = $2 where user_id = $3", JSON.stringify(stalePilotResult), pilotKey, f.id);
  assert.deepEqual((await pilotService.profileOverview()).trends.items, []);
  const pilotResult = JSON.stringify({ ...stalePilotResult, version: pilot.version });
  await database.query("update writing_profile_analysis set result = $1, evidence_key = $2 where user_id = $3", pilotResult, pilotKey, f.id);
  assert.equal((await pilotService.profileOverview()).trends.state, "ready");
  assert.deepEqual((await f.primary.profileOverview()).trends.items, []);
  for (const result of [JSON.stringify({ ...JSON.parse(latest.resultJson), version: "writing-trends-v2" }), "{invalid"]) {
    await database.query("update writing_profile_analysis set result = $1, evidence_key = $2 where user_id = $3", result, latest.evidenceKey, f.id);
    const response = await api.profileOverview();
    const profile = await response.json() as typeof refreshed;
    assert.equal(response.status, 200);
    assert.deepEqual(profile.trends.items, []);
    assert.ok(profile.recentInsights.length > 0);
  }
  assert.equal(analystCalls, 3);
  const recovered = await api.refreshProfileTrends(request());
  assert.equal(recovered.status, 200);
  assert.equal(((await recovered.json()) as typeof refreshed).trends.state, "ready");
  assert.equal(analystCalls, 4);

  const repeat = await add(0);
  f.advance(1000);
  const anotherPrompt = await f.primary.createTask({ promptId: "fair-group-plans", interestIds: [], locale: "en", requestId: randomUUID() });
  const nearCopy = (await f.primary.submit({ ...f.body(anotherPrompt.id),
    text: first.submission.text.replace("music", "quiet music"), assistance: "unassisted" })).record.submission;
  const deduplicated = await f.primary.profileOverview();
  assert.equal(deduplicated.independentSessionCount, 4);
  assert.equal(deduplicated.history.length, 6);
  assert.ok(deduplicated.history.some(({ id }) => id === repeat.submission.id));
  assert.ok(deduplicated.history.some(({ id }) => id === nearCopy.id));
  assert.equal(deduplicated.trends.state, "ready");
  assert.equal((await database.repository.getProfileAnalysis(f.id))?.evidenceKey, latest.evidenceKey);
  assert.equal(analystCalls, 4);

  await f.primary.deleteSubmission(fourth.submission.id);
  assert.equal(await database.repository.getProfileAnalysis(f.id), null);
  assert.equal((await f.primary.profileOverview()).trends.state, "available");
  await f.primary.deleteAll();
  assert.deepEqual((await f.primary.profileOverview()).history, []);
}

async function checkTargetedVerification(database: Database) {
  const later = "My brother writes his notes before he reads the next chapter. I leave my phone in a drawer. I prefer to study in silence when the chapter is new.";
  const baseline = profileSamples[0][2];
  const evaluator: WritingEvaluator = async (submission) => {
    const result = await evaluateProfileSamples({ ...submission, text: baseline });
    assert.equal(result.status, "validated");
    const report = result.report;
    if (submission.text === baseline) {
      const observation = report.issueFirstObservations![0];
      return { ...result, report: { ...report, issueFirstObservations: [{ ...observation,
        readerImpact: "The singular subject needs a present-tense verb ending." }] } };
    }
    return { ...result, report: { ...report, status: "no_actionable_findings", issueFirstObservations: [] } };
  };
  let calls = 0;
  let baselineId = "";
  const f = fixture(database, evaluator, { successes: 15, attempts: 15 }, undefined, undefined, async (input, targets) => {
    calls++;
    assert.deepEqual(targets, [{ id: "subject-verb-agreement", evidenceId: `observation:${baselineId}:0` }]);
    if (input.text !== later) throw new Error("Fixture provider failure");
    return validateWritingSkillVerification(input, targets, { results: [{ targetId: targets[0].id, status: "correct",
      examples: [{ kind: "correct", quote: "My brother writes", segmentId: 1 }] }] });
  });
  const pilot = f.service(f.id, database.repository, "improvement-pilot");
  const add = async (text: string, assistance = "unassisted", service = pilot) => {
    f.advance(1000);
    const task = await f.task(service);
    const request = { ...f.body(task.id), text, assistance };
    return { ...(await service.submit(request)), request };
  };
  const first = await add(baseline);
  baselineId = first.record.submission.id;
  assert.equal(calls, 0);
  const second = await add(later);
  assert.equal(calls, 1);
  const verified = second.record.run?.report?.skillVerification;
  assert.equal(verified?.results[0].examples[0].anchor.exact, "My brother writes");
  assert.deepEqual(second.record.run?.report?.issueFirstObservations, []);
  assert.deepEqual((await pilot.submit(second.request)).record.run?.report?.skillVerification, verified);
  const api = createWritingApi(async () => f.service(f.id, database.repository, "improvement-pilot"));
  for (let i = 0; i < 2; i++) assert.equal((await api.profileOverview()).status, 200);
  assert.equal((await pilot.profileOverview()).radar.current?.skills["GRAM.ACCURACY"].judgment, "undetermined");
  assert.equal(calls, 1);

  const repeat = await add(later);
  assert.equal(repeat.record.run?.report?.skillVerification, undefined);
  for (const assistance of ["unknown", "ownword_hint", "external_help"]) {
    assert.equal((await add(`I changed my study routine this week. Label ${assistance}.`, assistance)).record.run?.report?.skillVerification, undefined);
  }
  const revision = await pilot.submit({ ...f.body(first.record.task.id), parentSubmissionId: baselineId, text: `${baseline} I tried again.` });
  assert.equal(revision.record.run, null);
  const stranger = f.service(randomUUID(), database.repository, "improvement-pilot");
  await assert.rejects(stranger.getSubmission(second.record.submission.id), httpError(404));
  await add("My sister takes study breaks. She likes to practise after dinner.", "unassisted", stranger);
  const release = await add("My classmates prefer the library. I usually study in the park.", "unassisted", f.primary);
  assert.equal(release.record.run?.report?.skillVerification, undefined);
  assert.equal(calls, 1);
  const failure = await add("The reading room can be useful when our apartment is loud. I keep my notes on paper.");
  assert.equal(calls, 2);
  assert.equal(failure.record.run?.status, "succeeded");
  assert.equal(failure.record.run?.report?.skillVerification, undefined);
}

async function checkDeterministicImprovements(database: Database) {
  const support = [
    ["My sister checks", "My sister checks the bus timetable before leaving home. The road by the school is busy. I usually wait at the library instead."],
    ["The owner carries", "The owner carries a spare light for anyone whose bicycle is missing one. I bring my own when I remember. It gets dark early in winter."],
  ] as const;
  const relapse = ["My brother carry", "My brother carries", "My brother carry a spare map when we walk by the river. Once I took the wrong bridge and had to call him."] as const;
  const first = profileSamples[0];
  const second = profileSamples[2];
  const evaluator: WritingEvaluator = async (submission) => {
    const diagnosis = [first, second, relapse].find((row) => row[2] === submission.text);
    const template = await evaluateProfileSamples({ ...submission, text: first[2] });
    assert.equal(template.status, "validated");
    const existing = template.report.issueFirstObservations![0];
    let report = { ...template.report, issueFirstObservations: [] as typeof template.report.issueFirstObservations };
    if (diagnosis) {
      const [quote, replacement] = diagnosis;
      const anchor = resolveSource(submission.text, quote, submission.submissionId);
      assert.ok(anchor);
      report.issueFirstObservations = [{ ...existing, evidence: [anchor],
        problem: "Correct the subject–verb agreement in the present tense",
        readerImpact: "The singular subject needs a present-tense verb ending.", feedback: { ...existing.feedback!, replacement } }];
    } else if (submission.text === support[0][1]) {
      const anchor = resolveSource(submission.text, "I usually wait at the library instead.", submission.submissionId);
      assert.ok(anchor);
      report.issueFirstObservations = [{ ...existing, kind: "strength", issueKind: "effective_choice", evidence: [anchor],
        problem: "Gives a concrete alternative", readerImpact: "The example makes the other waiting option clear.", revisionCue: null,
        feedback: { ...existing.feedback!, category: "strength", replacement: null },
        attribution: { primary: "ARG.SUPPORT", secondary: null, certainty: "clear" } }];
    } else {
      report = { ...report, status: "no_actionable_findings" };
    }
    return { ...template, report };
  };
  let analystCalls = 0;
  let verificationCalls = 0;
  const f = fixture(database, evaluator, { successes: 12, attempts: 12 }, undefined, async (input) => {
    analystCalls++;
    assert.ok(input.candidates.every(({ kind }) => String(kind) !== "improvement"));
    if (analystCalls === 1) return null;
    const issue = input.candidates.find(({ kind }) => kind === "recurring_issue");
    assert.ok(issue);
    return validateWritingTrendAnalysis(input, { selections: [{ candidate: issue.id, theme: null, evidence: issue.others.slice(0, 2) }] });
  }, async (submission, targets) => {
    verificationCalls++;
    const example = support.find((row) => row[1] === submission.text);
    return validateWritingSkillVerification(submission, targets, { results: targets.map(({ id }) => ({ targetId: id,
      status: example ? "correct" : "no_opportunity", examples: example ? [{ kind: "correct", quote: example[0], segmentId: 1 }] : [] })) });
  });
  const pilot = (repository = database.repository) => f.service(f.id, repository, "improvement-pilot");
  const add = async (body: string) => {
    f.advance(1000);
    const service = pilot();
    const task = await f.task(service);
    const { record } = await service.submit({ ...f.body(task.id), text: body, assistance: "unassisted" });
    assert.equal(record.run?.status, "succeeded");
    return record;
  };
  const earlier = [await add(first[2]), await add(second[2])];
  const later = [await add(support[0][1]), await add(support[1][1])];
  const gains = async (service: WritingService) => {
    const response = await createWritingApi(async () => service).profileOverview();
    assert.equal(response.status, 200);
    const profile = await response.json() as Awaited<ReturnType<WritingService["profileOverview"]>>;
    return profile.trends.items.filter(({ kind }) => kind === "improvement");
  };
  const expected = await gains(pilot());
  assert.equal(expected[0]?.id, "improvement:subject-verb-agreement");
  assert.deepEqual(expected[0]?.evidence.map(({ submissionId }) => submissionId),
    [...earlier, ...later].map(({ submission }) => submission.id));
  assert.equal(analystCalls, 0);
  assert.equal(verificationCalls, 3);
  assert.deepEqual(await gains(f.primary), []);
  assert.deepEqual(await gains(f.service(randomUUID(), database.repository, "improvement-pilot")), []);
  await pilot().refreshProfileTrends();
  assert.deepEqual(await gains(pilot()), expected, "Ordinary analyst failure cannot hide a grounded gain");
  f.advance(31_000);
  await pilot().refreshProfileTrends();
  assert.equal(analystCalls, 2);
  assert.deepEqual(await gains(pilot()), expected, "Different ordinary analysis cannot change a grounded gain");
  await database.withFreshConnection?.(async (repository) => assert.deepEqual(await gains(pilot(repository)), expected));
  assert.equal(verificationCalls, 3);
  await add(relapse[2]);
  assert.deepEqual(await gains(pilot()), [], "The ordinary grounded contradiction withdraws the gain before refresh");
  assert.equal(analystCalls, 2);
}

const postgres = process.env.OWNWORD_TEST_PG_URL;
test("the hosted trend switch requires Terra and ignores the improvement pilot", () => {
  const environment = { WRITING_MODULE_ENABLED: "true", WRITING_TERRA_ENABLED: "true",
    WRITING_TRENDS_ENABLED: "true", WRITING_TREND_IMPROVEMENT_PILOT: "true", WRITING_SKILL_VERIFICATION_PILOT: "true" };
  assert.deepEqual(readHostedWritingRuntime({}), { key: "", terra: false, trends: false });
  assert.equal(readHostedWritingRuntime(environment).trends, false);
  const configured = { ...environment, WRITING_TERRA_OPENROUTER_API_KEY: " fixture-key " };
  assert.deepEqual(readHostedWritingRuntime(configured), { key: "fixture-key", terra: true, trends: true });
  assert.deepEqual(readHostedWritingRuntime({ ...configured, WRITING_TRENDS_ENABLED: "false" }),
    { key: "fixture-key", terra: true, trends: false });
});

for (const upgrade of [false, true]) {
  const baseline = upgrade ? "an existing baseline" : "a clean database";
  test(`D1 Writing lifecycle and migrations on ${baseline}`, async () => {
    await validateDatabase(await openD1(), "drizzle", upgrade);
  });
  test(`PostgreSQL Writing lifecycle and migrations on ${baseline}`, {
    skip: !postgres && "Set OWNWORD_TEST_PG_URL to a disposable localhost instance to run PostgreSQL integration.",
  }, async () => {
    await validateDatabase(await openPg(postgres!), "drizzle-pg", upgrade);
  });
}

async function validateDatabase(database: Database, folder: string, upgrade: boolean) {
  try {
    await applyMigrations(database, folder, upgrade);
    await checkDailyStreak(database);
    await checkOwnership(database);
    await checkConcurrency(database);
    await checkRetries(database);
    await checkExpiryAndRollover(database);
    await checkDeletion(database);
    await checkRevisionFeedback(database);
    await checkApi(database);
    await checkFocus(database);
    await checkFocusEvidence(database);
    await checkFocusPassSeparation(database);
    await checkProfile(database);
    await checkTargetedVerification(database);
    await checkDeterministicImprovements(database);
  } finally {
    await database.close();
  }
}

async function checkDailyStreak(database: Database) {
  const f = fixture(database);
  const streak = f.primary.streak!;
  const task = await f.task();
  assert.equal((await streak.current()).count, 0, "starting a task is not a completion");
  const origin = new URL(process.env.APP_ORIGIN || "https://ownword.test").origin;
  const api = createWritingApi(async () => f.primary);
  const body = f.body(task.id);
  const submit = () => api.submit(new Request(`${origin}/api/writing/submissions`, {
    method: "POST", headers: { origin, "content-type": "application/json" }, body: JSON.stringify(body),
  }));

  f.setTime("2026-11-16T16:59:59.000Z");
  const first = await submit();
  assert.deepEqual(JSON.parse(first.headers.get(streakAwardHeader) ?? "null"), {
    day: "2026-11-16", todayIndex: 0, count: 1, week: [true, false, false, false, false, false, false],
  });
  assert.equal((await streak.current()).count, 1);

  f.setTime("2026-11-16T17:00:00.000Z");
  assert.equal((await streak.current()).count, 1, "yesterday's streak remains active throughout today");
  assert.equal((await submit()).headers.get(streakAwardHeader), null, "reopening a finished assessment does not grant credit");
  const concurrent = await Promise.all(Array.from({ length: 8 }, () => f.service().streak!.complete()));
  const awards = concurrent.filter((award) => award !== null);
  assert.deepEqual(awards, [{ day: "2026-11-17", todayIndex: 1, count: 2, week: [true, true, false, false, false, false, false] }]);
  assert.equal(await streak.complete(), null);
  assert.equal((await f.service(randomUUID()).streak!.current()).count, 0, "daily history is scoped to the account");

  f.setTime("2026-11-18T17:00:00.000Z");
  assert.equal((await streak.current()).count, 0, "a missed day ends the current streak");
  assert.equal((await streak.complete())?.count, 1);
  assert.equal((await database.activityDays.listActivityDays(f.id)).length, 3, "history remains after a missed day");
}
