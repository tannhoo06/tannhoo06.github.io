// UI regressions use isolated API fixtures; no learner database is modified.
import { createRequire } from "node:module";
import { mkdirSync, writeFileSync } from "node:fs";
import assert from "node:assert/strict";
const require = createRequire(import.meta.url);
process.env.PW_TEST_SCREENSHOT_NO_FONTS_READY = "1";
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const { build } = await import("esbuild");
mkdirSync(".sites-runtime/mvp-v2", { recursive: true });
mkdirSync("outputs/mvp-v2", { recursive: true });
await build({
  stdin: {
    contents: `export { CATALOG } from './lib/llm/catalog'; export { MockLlm } from './lib/llm/mock'; export { resolveSource } from './lib/domain/anchors';`,
    resolveDir: process.cwd(),
    loader: "ts",
  },
  bundle: true,
  format: "esm",
  platform: "node",
  outfile: ".sites-runtime/mvp-v2/fixtures.mjs",
});
const { CATALOG, MockLlm, resolveSource } = await import(
  "../.sites-runtime/mvp-v2/fixtures.mjs"
);
const initialWords = [
  "nuanced",
  "negligible",
  "compelling",
  "substantial",
  "arbitrary",
  "meticulous",
];
const now = Date.now();
const makeWord = (name, i) => ({
  ...(CATALOG.find((w) => w.word === name) ?? {
    partOfSpeech: "adjective",
    definition:
      name === "arbitrary"
        ? "Based on personal choice rather than reason or a system."
        : "Showing great attention to detail; very careful and precise.",
    collocations: [],
    examples: [],
    nuance: "",
  }),
  word: name,
  userWordId: "uw-" + name,
  addedAt: new Date(now - i * 1000).toISOString(),
  introducedAt: new Date(now - 86400000).toISOString(),
  source: "Writing",
  sourceText: "It gave me a more detailed view of how people focus.",
  demo: false,
  stage: "new",
  nextReviewAt: new Date(
    now + (i < 2 ? -86400000 : (i - 1) * 86400000),
  ).toISOString(),
  attempts: [],
});
const makeState = () => ({
  profile: { id: "v2-browser", name: "Jane", dailyLimit: 7, onboarded: true },
  words: initialWords.map(makeWord),
  dueCount: 2,
  queuedCount: 0,
  writingCount: 6,
  insights: [],
  mockMode: true,
});
let state = makeState();
const sources = (phrase) =>
  Array.from({ length: 5 }, (_, i) => {
    const text = `This is a ${phrase} improvement for our team. Example ${i + 1}.`;
    return {
      sampleId: "sample-" + i,
      sentence: text,
      text,
      start: text.indexOf(phrase),
      end: text.indexOf(phrase) + phrase.length,
    };
  });
const insights = [
  [
    "very big",
    "substantial",
    "Large in amount or importance: a substantial investment.",
  ],
  [
    "very small",
    "negligible",
    "Too small to make a practical difference, not simply small in size.",
  ],
  [
    "interesting",
    "compelling",
    "Persuasive or strong enough to hold attention.",
  ],
].map(([phrase, word, meaning]) => ({
  phrase,
  count: 6,
  alternatives: [{ word, meaning }],
  sources: sources(phrase),
}));
let settingsWrites = [],
  startRequests = [];
let settingsFailure = false;
let review = null,
  analyzeCount = 0;
let focusedWord = null;
const browser = await chromium.launch({
  headless: true,
  ...(process.env.BROWSER_EXECUTABLE
    ? { executablePath: process.env.BROWSER_EXECUTABLE }
    : { channel: process.env.BROWSER_CHANNEL || "msedge" }),
});
const errors = [],
  checks = [];
const page = await browser.newPage({ viewport: { width: 1440, height: 1050 } });
page.on("pageerror", (e) => errors.push(e.message));
page.setDefaultTimeout(12000);
const screenshot = async (name) => {
  await page.screenshot({
    path: `outputs/mvp-v2/${name}.png`,
    fullPage: !(await page.getByRole("dialog").count()),
    animations: "disabled",
    timeout: 15000,
  });
};
await page.context().addCookies([
  { name: "__sites_local_auth", value: "1", domain: "127.0.0.1", path: "/" },
  { name: "ownword-language", value: "en", domain: "127.0.0.1", path: "/" },
]);
let exerciseIndex = 0,
  hintLevel = "none",
  sentencePending = false,
  completed = false;
let results = [];
const sessionWords = () =>
  focusedWord
    ? state.words.filter((w) => w.userWordId === focusedWord)
    : state.words.slice(0, 2);
const exercise = () => ({
  id: "ex-" + exerciseIndex,
  kind: "strong",
  prompt: sessionWords()[exerciseIndex].definition,
  definition: sessionWords()[exerciseIndex].definition,
  hint: hintLevel,
  hintText:
    sentencePending || hintLevel === "revealed"
      ? sessionWords()[exerciseIndex].word
      : hintLevel === "letter"
        ? "It starts with “n”."
        : hintLevel === "semantic"
          ? "Think about subtle differences."
          : undefined,
  sentencePending,
  position: exerciseIndex + 1,
  total: sessionWords().length,
});
const session = () => ({
  complete: completed,
  total: sessionWords().length,
  exercise: completed ? null : exercise(),
  words: sessionWords().map((w) => ({
    word: w.word,
    userWordId: w.userWordId,
  })),
  results,
});
const evaluation = (retrieved, precise = false) => ({
  retrieved,
  precise,
  majorMisuse: false,
  validAlternative: false,
  spellingCorrection: null,
  feedback: "Try a natural context.",
  nuance: "",
});
await page.route("**/api/**", async (route) => {
  const url = new URL(route.request().url()),
    path = url.pathname.replace("/api/", ""),
    body =
      route.request().method() === "POST" ? route.request().postDataJSON() : {};
  if (path === "analyze") {
    analyzeCount++;
    const sampleId = "browser-sample-" + analyzeCount;
    const analysis = await new MockLlm().analyzeWriting(body.text, state.words);
    review = {
      ...analysis,
      sampleId,
      text: body.text,
      usages: [],
      suggestions: analysis.suggestions.map((s, i) => ({
        ...s,
        id: sampleId + "-" + i,
        sampleId,
        status: "pending",
        source: resolveSource(body.text, s.originalText, sampleId),
      })),
    };
    return route.fulfill({ json: review });
  }
  if (path === "writing/review") return route.fulfill({ json: review });
  if (path === "suggestions/decide") {
    const s = review.suggestions.find((s) => s.id === body.id);
    s.status = body.decision;
    if (
      body.decision === "added" &&
      !state.words.some((w) => w.word === s.word)
    )
      state.words.push(makeWord(s.word, state.words.length));
    const owned = state.words.find((w) => w.word === s.word);
    s.savedWordId = owned?.userWordId;
    s.queued = false;
    return route.fulfill({
      json: { status: s.status, userWordId: owned?.userWordId, queued: false },
    });
  }
  if (path === "settings") {
    if (settingsFailure) {
      settingsFailure = false;
      return route.fulfill({
        status: 503,
        json: { error: "Temporary settings failure" },
      });
    }
    settingsWrites.push(body);
    Object.assign(state.profile, body);
    return route.fulfill({ json: { saved: true } });
  }
  if (path === "insights/add") {
    if (!state.words.some((w) => w.word === body.word))
      state.words.push(makeWord(body.word, state.words.length));
    return route.fulfill({ json: { queued: false } });
  }
  if (path === "words/remove") {
    state.words = state.words.filter((w) => w.userWordId !== body.id);
    return route.fulfill({ json: { removed: true } });
  }
  if (path === "state") return route.fulfill({ json: state });
  if (path === "practice/start") {
    startRequests.push(body);
    focusedWord = body.wordId ?? null;
    exerciseIndex = 0;
    hintLevel = "none";
    sentencePending = false;
    completed = false;
    results = [];
    return route.fulfill({ json: { sessionId: "fixture-session" } });
  }
  if (path === "practice") return route.fulfill({ json: session() });
  if (path === "practice/hint") {
    hintLevel = body.level;
    return route.fulfill({
      json: {
        hint: hintLevel,
        hintText:
          hintLevel === "revealed"
            ? sessionWords()[exerciseIndex].word
            : "Think about subtle differences.",
      },
    });
  }
  if (path === "practice/answer") {
    if (!sentencePending && hintLevel !== "revealed") {
      if (body.answer === sessionWords()[exerciseIndex].word) {
        sentencePending = true;
        return route.fulfill({
          json: {
            retry: true,
            sentencePending: true,
            target: body.answer,
            evaluation: evaluation(true),
          },
        });
      }
      return route.fulfill({
        json: {
          retry: true,
          incorrect: true,
          target: null,
          evaluation: evaluation(false),
        },
      });
    }
    results.push({
      word: sessionWords()[exerciseIndex].word,
      userWordId: sessionWords()[exerciseIndex].userWordId,
      outcome:
        hintLevel === "revealed"
          ? "reviewed"
          : hintLevel === "none"
            ? "recalled-used"
            : "hinted-used",
    });
    exerciseIndex++;
    sentencePending = false;
    hintLevel = "none";
    completed = exerciseIndex >= sessionWords().length;
    return route.fulfill({
      json: {
        retry: false,
        target: "word",
        evaluation: evaluation(true, true),
      },
    });
  }
  if (path === "practice/skip") {
    results.push({
      word: sessionWords()[exerciseIndex].word,
      userWordId: sessionWords()[exerciseIndex].userWordId,
      outcome: hintLevel === "revealed" ? "reviewed" : "recalled-skipped",
    });
    exerciseIndex++;
    sentencePending = false;
    hintLevel = "none";
    completed = exerciseIndex >= sessionWords().length;
    return route.fulfill({
      json: { retry: false, skipped: true, evaluation: evaluation(false) },
    });
  }
  return route.fulfill({
    status: 404,
    json: { error: "Unexpected fixture request: " + path },
  });
});
const group = process.argv[2] || "practice";
try {
  if (group === "practice") {
    await page.goto("http://127.0.0.1:5173/practice", {
      waitUntil: "domcontentloaded",
    });
    await page
      .getByRole("heading", { name: "2 words ready to practice" })
      .waitFor();
    assert.equal(await page.locator("#practice-answer").count(), 0);
    await screenshot("practice-intro");
    checks.push("Session intro precedes questions");
    await page
      .getByRole("button", { name: "Start practice", exact: true })
      .click();
    await page.locator("#practice-answer").waitFor();
    await screenshot("practice-recall");
    await page.locator("#practice-answer").fill("detail");
    await page.getByRole("button", { name: "Check", exact: true }).click();
    await page.getByRole("heading", { name: "Not quite." }).waitFor();
    assert.match(
      await page.locator(".recall-recovery").innerText(),
      /Try again, get a hint, or reveal the word\./,
    );
    assert.ok(
      (await page.locator(".recall-recovery").boundingBox()).height < 85,
    );
    await screenshot("practice-wrong");
    for (const label of ["Try again", "Hint", "Reveal word"])
      assert.equal(
        await page.getByRole("button", { name: label, exact: true }).count(),
        1,
      );
    checks.push("Wrong recall has all three recovery paths");
    await page.getByRole("button", { name: "Hint", exact: true }).click();
    await page.locator(".hint-box").waitFor();
    assert.ok((await page.locator(".hint-box").boundingBox()).height < 90);
    await screenshot("practice-hint");
    await page.getByRole("button", { name: "Try again", exact: true }).click();
    await page.locator("#practice-answer").fill("nuanced");
    await page.getByRole("button", { name: "Check", exact: true }).click();
    await page
      .getByRole("heading", { name: "Use it in a sentence", exact: true })
      .waitFor();
    await screenshot("practice-sentence");
    assert.equal(await page.locator(".previous-attempt").count(), 0);
    assert.equal(
      await page
        .getByRole("button", { name: "Reveal word", exact: true })
        .count(),
      0,
    );
    checks.push("Correct recall directly opens sentence input");
    await page
      .locator("#practice-answer")
      .fill("It gave me a nuanced understanding of the situation.");
    await page.waitForFunction(() =>
      JSON.parse(
        sessionStorage.getItem("ownword:practice:v2-browser:fixture-session") ||
          "null",
      )?.answer?.includes("nuanced understanding"),
    );
    await page.reload({ waitUntil: "domcontentloaded" });
    await page
      .getByRole("button", { name: "Start practice", exact: true })
      .click();
    await page
      .getByRole("heading", { name: "Use it in a sentence", exact: true })
      .waitFor();
    assert.equal(
      await page.locator("#practice-answer").inputValue(),
      "It gave me a nuanced understanding of the situation.",
    );
    checks.push(
      "Resuming after reload preserves sentence phase, answer, and authoritative hint",
    );
    await page
      .getByRole("button", { name: "Check sentence", exact: true })
      .click();
    await page.getByText("Word 2 of 2", { exact: true }).waitFor();
    checks.push("Successful sentence automatically advances");
    await page.locator("#practice-answer").fill("nothing");
    await page.getByRole("button", { name: "Check", exact: true }).click();
    await page
      .getByRole("button", { name: "Reveal word", exact: true })
      .click();
    await page.getByRole("heading", { name: "Answer: negligible" }).waitFor();
    assert.equal(await page.locator(".previous-attempt").count(), 0);
    await screenshot("practice-revealed");
    await page
      .getByRole("button", { name: "Skip this step", exact: true })
      .click();
    await page
      .getByRole("heading", { name: "Practice complete", exact: true })
      .waitFor();
    await screenshot("practice-complete");
    assert.equal(await page.locator(".recap-row").count(), 2);
    assert.match(
      await page.locator(".recap-rows").innerText(),
      /Recalled with a hint; used in a sentence/,
    );
    assert.match(
      await page.locator(".recap-rows").innerText(),
      /Reviewed; needs more practice/,
    );
    assert.equal(
      await page
        .getByRole("button", { name: "Go to WordBoard", exact: true })
        .count(),
      1,
    );
    assert.equal(
      await page
        .getByRole("button", { name: /Next word|Finish this session|Saving/ })
        .count(),
      0,
    );
    checks.push(
      "Reveal opens sentence; skip advances directly to durable per-word recap",
    );
    await page.reload({ waitUntil: "domcontentloaded" });
    await page
      .getByRole("heading", { name: "Practice complete", exact: true })
      .waitFor();
    assert.equal(await page.locator(".recap-row").count(), 2);
    checks.push("Completion recap survives a hard reload");
  }
  if (group === "board") {
    state.words.push(
      { ...makeWord("deliberate", 6), stage: "practicing" },
      {
        ...makeWord("pivotal", 7),
        stage: "active",
        nextReviewAt: new Date(now - 1000).toISOString(),
      },
    );
    await page.goto("http://127.0.0.1:5173/board", {
      waitUntil: "domcontentloaded",
    });
    await page.locator(".word-card-v2").first().waitFor();
    assert.equal(await page.locator(".stage-switcher button").count(), 4);
    assert.equal(await page.locator(".word-card-v2").count(), 6);
    await screenshot("board-populated");
    await page
      .locator(".stage-switcher button")
      .filter({ hasText: "Practicing" })
      .click();
    assert.equal(await page.locator(".word-card-v2").count(), 1);
    assert.match(await page.locator(".word-card-v2").innerText(), /deliberate/);
    await page
      .locator(".stage-switcher button")
      .filter({ hasText: "Active" })
      .click();
    assert.equal(await page.locator(".word-card-v2").count(), 1);
    assert.equal(await page.locator(".word-card-v2 .is-due").count(), 1);
    await page
      .locator(".stage-switcher button")
      .filter({ hasText: "All" })
      .click();
    assert.equal(await page.locator(".word-card-v2").count(), 8);
    await page
      .getByRole("textbox", { name: "Search words", exact: true })
      .fill("nuanced");
    assert.equal(await page.locator(".word-card-v2").count(), 1);
    await page
      .getByRole("textbox", { name: "Search words", exact: true })
      .fill("");
    await page
      .getByRole("combobox", { name: "Sort words", exact: true })
      .selectOption("alphabetical");
    assert.match(
      await page.locator(".word-card-v2").first().innerText(),
      /^arbitrary/,
    );
    checks.push("Four stage counts; tabs, All, search, sort work");
    await page.locator(".word-card-v2").filter({ hasText: "nuanced" }).click();
    await page.getByRole("dialog").waitFor();
    await screenshot("board-drawer");
    await page.keyboard.press("Escape");
    assert.equal(
      await page
        .locator(".word-card-v2")
        .filter({ hasText: "nuanced" })
        .evaluate((e) => e === document.activeElement),
      true,
    );
    checks.push("Card opens side drawer; Escape restores focus");
    await page.locator(".word-card-v2").filter({ hasText: "nuanced" }).click();
    for (const label of [
      "From your writing",
      "Common collocations",
      "Example sentence",
      "What to work on next",
    ])
      assert.equal(
        await page.getByRole("heading", { name: label, exact: true }).count(),
        1,
      );
    await page
      .getByRole("button", { name: "Practice this word", exact: true })
      .click();
    await page.waitForURL("**/practice");
    assert.equal(startRequests.at(-1).wordId, "uw-nuanced");
    await page
      .getByRole("heading", { name: "1 word ready to practice", exact: true })
      .waitFor();
    await page.getByRole("link", { name: "WordBoard", exact: true }).click();
    await page.locator(".word-card-v2").filter({ hasText: "nuanced" }).click();
    page.once("dialog", (dialog) => dialog.accept());
    await page
      .getByRole("button", { name: "Remove from WordBoard", exact: true })
      .click();
    await page.getByRole("dialog").waitFor({ state: "hidden" });
    assert.equal(
      state.words.some((w) => w.word === "nuanced"),
      false,
    );
    checks.push(
      "Drawer source/usage/guidance visible; targeted practice and confirmed removal work",
    );
    state = { ...state, words: [], dueCount: 0 };
    await page.goto("http://127.0.0.1:5173/board", {
      waitUntil: "domcontentloaded",
    });
    await page
      .getByRole("heading", { name: "No words yet", exact: true })
      .waitFor();
    assert.equal(
      await page.locator(".stage-switcher, .board-controls-v2").count(),
      0,
    );
    assert.equal(await page.locator(".board-empty-v2 button").count(), 1);
    await screenshot("board-empty");
    checks.push("Empty board has one CTA and no stage/search/sort controls");
  }
  if (group === "insights") {
    state = { ...state, words: [], insights };
    await page.goto("http://127.0.0.1:5173/insights", {
      waitUntil: "domcontentloaded",
    });
    await page
      .getByRole("heading", { name: "Your patterns", exact: true })
      .waitFor();
    assert.equal(await page.locator(".pattern-card").count(), 3);
    assert.equal(await page.locator(".pattern-evidence").count(), 0);
    assert.equal(
      await page
        .getByRole("heading", {
          name: "Repeating a word is not automatically bad.",
          exact: true,
        })
        .count(),
      1,
    );
    await screenshot("patterns-compact");
    await page
      .getByRole("button", {
        name: "See examples from my writing",
        exact: true,
      })
      .first()
      .click();
    assert.equal(await page.locator(".pattern-evidence").count(), 1);
    assert.equal(await page.locator(".pattern-evidence li").count(), 3);
    assert.equal(await page.locator(".pattern-evidence mark").count(), 3);
    await screenshot("patterns-expanded");
    await page
      .getByRole("button", { name: "Add to WordBoard", exact: true })
      .first()
      .click();
    await page.getByRole("link", { name: "View on WordBoard" }).waitFor();
    assert.equal(state.words.length, 1);
    checks.push(
      "Compact patterns; single selected evidence card; three highlighted excerpts; explicit add becomes View",
    );
    await page
      .getByRole("button", {
        name: "Expand examples for very small",
        exact: true,
      })
      .click();
    assert.equal(await page.locator(".pattern-evidence").count(), 1);
    assert.match(
      await page.locator(".is-expanded .pattern-phrase").innerText(),
      /very small/,
    );
    checks.push("Expanding another card closes the previous examples");
  }
  if (group === "settings") {
    await page.goto("http://127.0.0.1:5173/settings", {
      waitUntil: "domcontentloaded",
    });
    await page
      .getByRole("heading", { name: "Settings", exact: true })
      .waitFor();
    assert.equal(await page.locator(".settings-group").count(), 4);
    assert.equal(await page.locator("#practice-length option").count(), 3);
    assert.equal(await page.locator("#practice-length").inputValue(), "7");
    assert.equal(
      await page.getByText("Demo tools", { exact: true }).count(),
      1,
    );
    assert.equal(
      await page
        .getByRole("button", { name: "Save changes", exact: true })
        .count(),
      0,
    );
    await screenshot("settings-main");
    await page
      .getByRole("combobox", { name: "Practice length", exact: true })
      .selectOption("10");
    await page.getByText("Changes saved", { exact: true }).waitFor();
    assert.equal(state.profile.dailyLimit, 10);
    await screenshot("settings-saved");
    assert.ok(
      (await page.locator(".settings-saved").boundingBox()).width < 320,
    );
    assert.equal(
      await page
        .locator(".settings-saved")
        .evaluate((e) => getComputedStyle(e).position),
      "fixed",
    );
    await page
      .locator(".settings-saved")
      .waitFor({ state: "hidden", timeout: 5000 });
    checks.push(
      "Compact saved toast auto-dismisses without changing the four Settings groups",
    );
    await page
      .getByRole("textbox", { name: "Display name", exact: true })
      .fill("Kelvin LTK");
    await page
      .getByRole("textbox", { name: "Display name", exact: true })
      .press("Enter");
    await page.waitForFunction(() => document.querySelector(".settings-saved"));
    await page.waitForTimeout(150);
    assert.equal(state.profile.name, "Kelvin LTK");
    assert.ok(settingsWrites.some((w) => w.name === "Kelvin LTK"));
    checks.push(
      "Four groups; 5/7/10 dropdown; autosave; name saves on Enter; saved feedback",
    );
    settingsFailure = true;
    await page
      .getByRole("combobox", { name: "Practice length", exact: true })
      .selectOption("5");
    await page
      .getByRole("alert")
      .getByText("Temporary settings failure", { exact: true })
      .waitFor();
    assert.equal(await page.locator("#practice-length").inputValue(), "5");
    await page.getByRole("button", { name: "Try again", exact: true }).click();
    await page.getByText("Changes saved", { exact: true }).waitFor();
    assert.equal(state.profile.dailyLimit, 5);
    await page.reload({ waitUntil: "domcontentloaded" });
    await page.locator("#practice-length").waitFor();
    assert.equal(await page.locator("#practice-length").inputValue(), "5");
    checks.push(
      "Autosave failure retains choice; retry succeeds; preference survives reload",
    );
    await page.getByRole("button", { name: /How practice works/ }).click();
    await page
      .getByRole("heading", { name: "How practice works", exact: true })
      .waitFor();
    assert.equal(await page.locator(".settings-help-v2 li").count(), 3);
    await screenshot("settings-help");
    await page
      .getByRole("button", { name: "Back to Settings", exact: true })
      .click();
    assert.equal(
      await page.getByRole("link", { name: /Log out/ }).getAttribute("href"),
      "/signout-with-chatgpt?return_to=/",
    );
    await page.getByRole("button", { name: "More", exact: true }).click();
    assert.equal(await page.locator(".more-destinations a").count(), 2);
    await screenshot("settings-menu");
    checks.push(
      "Concise help; isolated logout; canonical two-item overflow menu",
    );
  }
  if (group === "writing") {
    state = { ...state, words: [] };
    await page.goto("http://127.0.0.1:5173/write", {
      waitUntil: "domcontentloaded",
    });
    await page
      .getByRole("heading", {
        name: "Write something you want to say",
        exact: true,
      })
      .waitFor();
    await screenshot("write-initial");
    assert.equal(
      await page.getByText("Demo examples", { exact: true }).count(),
      1,
    );
    await page
      .locator("#writing-text")
      .fill(
        "I read a very interesting story about remote work recently. It gave me a more detailed view of how people focus. There was a very small difference in productivity, but a very big improvement in how people felt.",
      );
    await page.reload({ waitUntil: "domcontentloaded" });
    await page.waitForFunction(() =>
      document
        .querySelector("#writing-text")
        ?.value.includes("very interesting story"),
    );
    await page
      .getByRole("button", { name: "Review suggestions", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Add to practice", exact: true })
      .waitFor();
    assert.equal(await page.locator(".suggestion-decisions button").count(), 2);
    assert.equal(
      await page
        .getByRole("button", { name: /I already|Keep original|Save word/ })
        .count(),
      0,
    );
    assert.ok((await page.locator(".source-mark").count()) > 0);
    await screenshot("write-review");
    await page
      .getByRole("button", { name: "Add to practice", exact: true })
      .click();
    await page.getByText("Suggestion 2 of 4", { exact: true }).waitFor();
    assert.equal(state.words.length, 1);
    await page.getByRole("button", { name: "Skip", exact: true }).click();
    await page.getByText("Suggestion 3 of 4", { exact: true }).waitFor();
    await page.reload({ waitUntil: "domcontentloaded" });
    await page.getByText("Suggestion 3 of 4", { exact: true }).waitFor();
    assert.equal(analyzeCount, 1);
    await page.getByRole("button", { name: "Skip", exact: true }).click();
    await page.getByText("Suggestion 4 of 4", { exact: true }).waitFor();
    await page
      .getByRole("button", { name: "Add to practice", exact: true })
      .click();
    await page
      .getByRole("heading", { name: "Review complete", exact: true })
      .waitFor();
    assert.equal(state.words.length, 2);
    checks.push(
      "Draft reload; anchored mock suggestions; two decisions; add and skip auto-advance; reload restores cursor without analysis",
    );
    await page
      .getByRole("button", { name: "Continue writing", exact: true })
      .click();
    await page
      .locator("#writing-text")
      .fill(
        "I made an intentional choice to change my routine. Our possible plan is still flexible.",
      );
    await page
      .getByRole("button", { name: "Review suggestions", exact: true })
      .click();
    await page
      .getByRole("heading", { name: "deliberate", exact: true })
      .waitFor();
    assert.equal(analyzeCount, 2);
    assert.match(
      await page.locator(".review-writing").innerText(),
      /intentional choice/,
    );
    assert.doesNotMatch(
      await page.locator(".review-writing").innerText(),
      /remote work/,
    );
    checks.push(
      "New draft and new review do not inherit the previous source or decisions",
    );
  }
  if (group === "responsive") {
    state = { ...makeState(), insights };
    const overflow = [];
    for (const locale of ["en", "vi"]) {
      await page.context().addCookies([
        {
          name: "ownword-language",
          value: locale,
          domain: "127.0.0.1",
          path: "/",
        },
      ]);
      for (const width of [1024, 768, 390, 375, 320]) {
        await page.setViewportSize({ width, height: 900 });
        for (const view of [
          "write",
          "board",
          "insights",
          "settings",
          "practice",
        ]) {
          await page.goto("http://127.0.0.1:5173/" + view, {
            waitUntil: "domcontentloaded",
          });
          await page.locator("#main-content h1").waitFor();
          const dimensions = await page.evaluate(() => ({
            viewport: innerWidth,
            scroll: document.documentElement.scrollWidth,
          }));
          if (dimensions.scroll > dimensions.viewport + 1)
            overflow.push({ locale, width, view, ...dimensions });
          if (width === 390) await screenshot(`${view}-${locale}-390`);
          if (view === "board") {
            await page.locator(".word-card-v2").first().click();
            await page.getByRole("dialog").waitFor();
            assert.ok(
              await page
                .getByRole("dialog")
                .evaluate((e) => e.getBoundingClientRect().width <= innerWidth),
            );
            if (width === 390) await screenshot(`drawer-${locale}-390`);
            await page.keyboard.press("Escape");
          }
        }
      }
    }
    console.log(JSON.stringify({ overflow }, null, 2));
    assert.deepEqual(overflow, []);
    checks.push(
      "No horizontal page overflow on five screen widths in EN and VN; narrow drawer fits",
    );
  }
  if (group === "mobile-flow") {
    const overflows = [];
    const check = async (label) => {
      const d = await page.evaluate(() => ({
        w: innerWidth,
        scroll: document.documentElement.scrollWidth,
      }));
      if (d.scroll > d.w + 1) overflows.push({ label, ...d });
    };
    await page.addInitScript(() => {
      sessionStorage.removeItem("ownword:writing:v2-browser");
      sessionStorage.removeItem("ownword:session:v2-browser");
    });
    for (const locale of ["en", "vi"])
      for (const width of [390, 320]) {
        await page.context().addCookies([
          {
            name: "ownword-language",
            value: locale,
            domain: "127.0.0.1",
            path: "/",
          },
        ]);
        await page.setViewportSize({ width, height: 900 });
        state = { ...makeState(), words: [], insights };
        await page.goto("http://127.0.0.1:5173/write", {
          waitUntil: "domcontentloaded",
        });
        await page.locator("#writing-text").waitFor();
        await page
          .locator("#writing-text")
          .fill(
            "I read a very interesting story about remote work. It gave me a more detailed view of how people focus.",
          );
        await page
          .locator(".writing-editor-footer button[type=submit]")
          .click();
        await page.locator(".suggestion-decisions").waitFor();
        await check(`${locale}-${width}-review`);
        if (width === 390) await screenshot(`review-${locale}-390`);
        state = makeState();
        exerciseIndex = 0;
        hintLevel = "none";
        sentencePending = false;
        completed = false;
        focusedWord = null;
        results = [];
        await page.goto("http://127.0.0.1:5173/practice", {
          waitUntil: "domcontentloaded",
        });
        await page.locator(".intro-v2 > .button-primary").click();
        await page.locator("#practice-answer").waitFor();
        await check(`${locale}-${width}-recall`);
        if (width === 390) await screenshot(`recall-${locale}-390`);
        await page.locator("#practice-answer").fill("nuanced");
        await page.locator(".practice-v2 form button[type=submit]").click();
        await page.locator(".was-recalled").waitFor();
        await check(`${locale}-${width}-sentence`);
        if (width === 390) await screenshot(`sentence-${locale}-390`);
        await page.locator(".practice-actions > .button-secondary").click();
        await page.waitForFunction(() =>
          /^(Word|Từ) 2/.test(
            document.querySelector(".practice-progress-row > span")
              ?.textContent || "",
          ),
        );
        await page.locator("#practice-answer").fill("none");
        await page.locator(".practice-v2 form button[type=submit]").click();
        await page.locator(".recall-recovery").waitFor();
        await page
          .locator(".practice-actions > .button-secondary")
          .nth(2)
          .click();
        await page.locator(".was-revealed").waitFor();
        await check(`${locale}-${width}-reveal`);
        if (width === 390) await screenshot(`reveal-${locale}-390`);
        await page.locator(".practice-actions > .button-secondary").click();
        await page.locator(".finish-v2 h1").waitFor();
        await check(`${locale}-${width}-completion`);
        if (width === 390) await screenshot(`completion-${locale}-390`);
        state = { ...makeState(), insights };
        await page.goto("http://127.0.0.1:5173/insights", {
          waitUntil: "domcontentloaded",
        });
        await page.locator(".pattern-expand").first().click();
        await page.locator(".pattern-evidence").waitFor();
        await check(`${locale}-${width}-patterns`);
        if (width === 390) await screenshot(`patterns-expanded-${locale}-390`);
        await page.goto("http://127.0.0.1:5173/settings", {
          waitUntil: "domcontentloaded",
        });
        await page.locator("button.settings-link-row").click();
        await page.locator(".settings-help-v2").waitFor();
        await check(`${locale}-${width}-help`);
      }
    assert.deepEqual(overflows, []);
    checks.push(
      "Review, recall, sentence, reveal, completion, expanded patterns, and help fit at 320/390px in EN/VN",
    );
  }
  if (group === "auth") {
    await page.unroute("**/api/**");
    const anonymous = await browser.newContext();
    let response = await anonymous.request.get(
      "http://127.0.0.1:5173/api/state",
    );
    assert.equal(response.status(), 401);
    response = await anonymous.request.get("http://127.0.0.1:5173/api/state", {
      headers: {
        "oai-authenticated-user-id": "forged",
        "oai-authenticated-user-email": "forged@example.test",
      },
    });
    assert.equal(response.status(), 401);
    await anonymous.close();
    await page.goto(
      "http://127.0.0.1:5173/signin-with-chatgpt?return_to=/write",
      { waitUntil: "domcontentloaded" },
    );
    await page
      .getByRole("heading", {
        name: "Write something you want to say",
        exact: true,
      })
      .waitFor();
    assert.equal(
      (await page.request.get("http://127.0.0.1:5173/api/state")).status(),
      200,
    );
    const origin = "http://127.0.0.1:5173";
    response = await page.request.post(origin + "/api/settings", {
      headers: { Origin: "https://example.invalid" },
      data: { dailyLimit: 7 },
    });
    assert.equal(response.status(), 403);
    response = await page.request.post(origin + "/api/settings", {
      headers: { Origin: origin },
      data: { dailyLimit: 100 },
    });
    assert.equal(response.status(), 400);
    await page.goto(origin + "/signout-with-chatgpt?return_to=/", {
      waitUntil: "domcontentloaded",
    });
    assert.equal((await page.request.get(origin + "/api/state")).status(), 401);
    checks.push(
      "Real local sign-in/sign-out, unauthorized and forged identity rejection, origin guard, preference validation",
    );
  }
  assert.deepEqual(errors, []);
  console.log(JSON.stringify({ group, checks, pageErrors: errors }, null, 2));
  writeFileSync(
    `outputs/mvp-v2/${group}-checks.json`,
    JSON.stringify({ checks, errors }, null, 2),
  );
} finally {
  await browser.close();
}
