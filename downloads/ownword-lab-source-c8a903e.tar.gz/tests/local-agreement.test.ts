import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {repairLocalAgreement} from '../lib/llm/local-agreement';
import {inspectAnalysisProposals} from '../lib/llm/gemini';

const cases: Array<[string,string,string]> = [
 ['The change have a profound effect.','profound','The change has a profound effect.'],
 ['The result show a clear pattern.','clear','The result shows a clear pattern.'],
 ['This policy make the process easier.','easier','This policy makes the process easier.'],
 ['The results shows a clear pattern.','clear','The results show a clear pattern.'],
 ['It are effective.','effective','It is effective.'],
 ['They is effective.','effective','They are effective.'],
 ['The changes have a profound effect.','profound','The changes have a profound effect.'],
 ['The result shows a clear pattern.','clear','The result shows a clear pattern.'],
 ['They are effective.','effective','They are effective.'],
 ['I have enough evidence.','enough','I have enough evidence.'],
 ['You have enough evidence.','enough','You have enough evidence.'],
 ['The team organise its work efficiently.','efficiently','The team organise its work efficiently.'],
 ['The data shows a trend.','trend','The data shows a trend.'],
 ['The committee have reached a decision.','decision','The committee have reached a decision.'],
 ['The result show the change, but the outcome is clear.','clear','The result shows the change, but the outcome is clear.'],
 ['I is effective.','effective','I am effective.'],
 ['She explain the idea clearly, with every tiny detail meticulously checked twice.','meticulously','She explains the idea clearly, with every tiny detail meticulously checked twice.'],
 ['He have enough evidence to support the claim.','claim','He has enough evidence to support the claim.'],
 ['These policies makes the process easier.','easier','These policies make the process easier.'],
 ['The staff are reviewing the proposal.','proposal','The staff are reviewing the proposal.'],
 ['The researchers explain the result clearly.','clearly','The researchers explain the result clearly.'],
 ['She explains the idea clearly.','clearly','She explains the idea clearly.'],
 ['She and he explain the idea clearly.','clearly','She and he explain the idea clearly.'],
 ['She can explain the idea clearly.','clearly','She can explain the idea clearly.'],
];
for(const [sentence,focus,expected] of cases)test(`local agreement: ${sentence}`,()=>{
 const r=repairLocalAgreement(sentence,sentence.indexOf(focus));
 assert.equal(r?.repairedSentence??sentence,expected);
 if(r)assert.equal(r.diagnostic,'learner-facing-local-agreement-repair');
});
test('exact final-suite E04 repairs only the final sentence and retains lexical evidence',()=>{
 const run=JSON.parse(readFileSync('evals/results/openrouter-final-confirmation-full-2026-10-30/results.json','utf8'));
 const row=run.rows.find((x:{case:{id:string}})=>x.case.id==='E04');
 const result=inspectAnalysisProposals(row.case.input,row.requests[0].rawModelOutput);
 const s=result.suggestions.find(x=>x.word==='meticulously');
 assert.equal(s?.suggestedSentence,'She explains the idea clearly, with every tiny detail meticulously checked twice.');
 assert.equal(s?.source?.sentence,row.case.input);
 assert.equal(s?.definition,row.actual.suggestions[0].definition);
 assert.equal(s?.nuance,row.actual.suggestions[0].nuance);
 const audit=result.audit.find(x=>x.word==='meticulously');
 assert.ok(audit && 'localAgreementRepair' in audit && audit.localAgreementRepair?.originalVerb==='explain' && audit.localAgreementRepair.repairedVerb==='explains');
});
test('saved live E01 is repaired without changing its source or lexical teaching',()=>{
 const run=JSON.parse(readFileSync('evals/results/openrouter-success-mini-2026-10-30/results.json','utf8'));
 const row=run.rows.find((x:{case:{id:string}})=>x.case.id==='E01');
 const r=inspectAnalysisProposals(row.case.input,row.requests[0].rawModelOutput);
 const s=r.suggestions.find(x=>x.word==='profound');
 assert.equal(s?.suggestedSentence,'The change has a profound effect on how our team organise its work.');
 assert.equal(s?.source?.sentence,row.case.input);
 assert.equal(s?.definition,row.actual.suggestions[0].definition);
 const audit=r.audit.find(x=>x.word==='profound');
 assert.ok(audit && 'localAgreementRepair' in audit && audit.localAgreementRepair?.originalVerb==='have' && audit.localAgreementRepair.repairedVerb==='has');
});
