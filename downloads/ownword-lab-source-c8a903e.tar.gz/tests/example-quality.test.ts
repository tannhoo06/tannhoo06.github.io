import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {danglingExampleModifiers} from "../lib/llm/example-quality";
import {inspectAnalysisProposals} from "../lib/llm/gemini";

const cases: Array<[string,boolean]> = [
 ["New data was brought forward, hoping to sway the committee.",false],
 ["The report was revised, trying to make the explanation clearer.",false],
 ["The evidence was submitted, intending to prove the claim.",false],
 ["The proposal was changed, hoping to gain approval.",false],
 ["The statistics were highlighted, seeking to reassure investors.",false],
 ["Hoping to persuade the committee, the evidence was submitted.",false],
 ["The researchers brought forward new data, hoping to sway the committee.",true],
 ["She revised the report, trying to make the explanation clearer.",true],
 ["The team submitted the evidence, intending to support the claim.",true],
 ["The proposal was revised to improve clarity.",true],
 ["New data was presented in an attempt to persuade the committee.",true],
 ["The storm intensified, causing widespread damage.",true],
 ["The report revealed inconsistencies, raising concerns about accuracy.",true],
 ["The argument was compelling, drawing attention to the central issue.",true],
];
for(const [example,allowed] of cases)test(`example agent check: ${example}`,()=>{
 const findings=danglingExampleModifiers([example]);assert.equal(findings.length===0,allowed,JSON.stringify(findings));
 if(!allowed){assert.equal(findings[0].disposition,"reject-suggestion");assert.ok(findings[0].inferredController);assert.ok(findings[0].modifierPredicate);}
});
test("saved bad sway example is blocked without changing its lexical or rewrite checks",()=>{
 const run=JSON.parse(readFileSync("evals/results/openrouter-temporal-mini-2026-10-30/results.json","utf8"));
 const row=run.rows.find((x:{case:{id:string}})=>x.case.id==="D02");
 const result=inspectAnalysisProposals(row.case.input,row.requests[0].rawModelOutput);
 assert.equal(result.suggestions.length,0);assert.equal(result.audit[0].reason,"instructional-example-dangling-modifier");
 assert.match(JSON.stringify(result.audit[0]),/hoping to sway/);
 const clean=structuredClone(row.requests[0].rawModelOutput);
 clean.suggestions[0].examples=["The researchers presented new data, hoping to sway the committee."];
 const valid=inspectAnalysisProposals(row.case.input,clean);
 assert.equal(valid.suggestions[0]?.word,"sway",JSON.stringify(valid.audit));
 assert.equal(valid.suggestions[0]?.suggestedSentence,"The evidence was strong enough to sway the sceptical panel.");
});
