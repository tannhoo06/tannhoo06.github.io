const { chromium } = await import(
  process.env.PLAYWRIGHT_MODULE || "playwright"
);
import assert from "node:assert/strict";
import { mkdirSync } from "node:fs";
mkdirSync("outputs/landing-public", { recursive: true });
const browser = await chromium.launch({ headless: true, channel: "msedge" });
const page = await browser.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const ready = () =>
  page.waitForFunction(() =>
    document.documentElement.classList.contains("ow-page-scroll"),
  );
await page.goto("http://127.0.0.1:5173/");
await ready();
assert.equal(await page.locator("html").getAttribute("lang"), "vi");
for (const locale of ["vi", "en"]) {
  await page
    .getByRole("button", {
      name: locale === "vi" ? "Tiếng Việt" : "English",
      exact: true,
    })
    .click();
  for (const [width, height] of [
    [1440, 900],
    [1280, 720],
    [1069, 930],
    [390, 844],
  ]) {
    await page.setViewportSize({ width, height });
    await page.evaluate(() => scrollTo({ top: 0, behavior: "instant" }));
    await page.waitForTimeout(300);
    await page.locator("#faq-audience-trigger").evaluate((e) => {
      if (e.getAttribute("aria-expanded") === "false") e.click();
    });
    assert.ok(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    );
    await page.screenshot({
      path: `outputs/landing-public/${locale}-${width}-full.png`,
      fullPage: true,
    });
    await page.locator('.ow-nav a[href="#faq"]').click();
    await page.waitForTimeout(1000);
    assert.ok((await page.locator("#faq").boundingBox()).y >= -2);
    assert.equal(
      await page.evaluate(
        () => getComputedStyle(document.documentElement).scrollSnapType,
      ),
      "none",
    );
    for (const id of [
      "audience",
      "account",
      "pricing",
      "suggestions",
      "writing",
    ]) {
      const button = page.locator(`#faq-${id}-trigger`);
      await button.focus();
      if ((await button.getAttribute("aria-expanded")) === "true")
        await page.keyboard.press("Enter");
      await page.keyboard.press("Space");
      assert.equal(await button.getAttribute("aria-expanded"), "true");
      assert.ok(await page.locator(`#faq-${id}-answer`).isVisible());
      assert.equal(
        await button.evaluate((e) => getComputedStyle(e).outlineStyle),
        "solid",
      );
      await page.keyboard.press("Enter");
      assert.equal(await button.getAttribute("aria-expanded"), "false");
    }
    await page.locator("#faq-audience-trigger").click();
    await page.locator(".ow-audience").scrollIntoViewIfNeeded();
    await page.screenshot({
      path: `outputs/landing-public/${locale}-${width}-support.png`,
    });
    await page.locator("body").click({ position: { x: 4, y: 4 } });
    await page.keyboard.press("End");
    await page.waitForTimeout(750);
    const footer = await page.locator(".ow-footer").boundingBox();
    assert.ok(footer.y + footer.height <= height + 2, "footer reachable");
    await page.screenshot({
      path: `outputs/landing-public/${locale}-${width}-footer.png`,
    });
    await page.emulateMedia({ reducedMotion: "reduce" });
    assert.equal(
      await page.evaluate(
        () => getComputedStyle(document.documentElement).scrollBehavior,
      ),
      "auto",
    );
    await page.emulateMedia({ reducedMotion: "no-preference" });
  }
  for (const path of ["/privacy", "/terms"]) {
    await page.locator(`.ow-footer a[href="${path}"]`).click();
    await page
      .getByText(
        locale === "vi"
          ? "Trang nháp — chưa hoàn thiện"
          : "Draft page — not yet complete",
        { exact: true },
      )
      .waitFor();
    assert.equal(await page.locator("html").getAttribute("lang"), locale);
    await page.locator("header a").click();
    await ready();
  }
  assert.equal(
    await page.locator(".ow-feedback-link").getAttribute("href"),
    "mailto:ownword_support@gmail.com",
  );
  assert.equal(
    await page.locator('.ow-footer a[href^="mailto:"]').getAttribute("href"),
    "mailto:ownword_support@gmail.com",
  );
  await page.reload();
  await ready();
  assert.equal(await page.locator("html").getAttribute("lang"), locale);
}
await page.route(/signin-with-chatgpt/, (route) =>
  route.fulfill({
    status: 200,
    contentType: "text/html",
    body: "Sign-in boundary checked",
  }),
);
for (const selector of [
  ".ow-actions .button-primary",
  ".ow-bottom-action .button-primary",
  ".ow-invitation .button-primary",
]) {
  await page.goto("http://127.0.0.1:5173/");
  await ready();
  await page.locator(selector).click();
  await page.waitForURL(/signin-with-chatgpt/);
  assert.ok(page.url().includes("return_to=/start"));
}
assert.deepEqual(errors, []);
await browser.close();
console.log(
  "PASS: 8 viewport/language layouts; five keyboard accordions and focus; FAQ anchor; ordinary lower scrolling; footer End access; reduced motion; persistent language; both legal draft routes; mailto destinations; all three sign-in actions; no browser errors.",
);
