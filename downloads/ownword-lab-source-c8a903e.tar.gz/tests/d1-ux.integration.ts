import { Miniflare } from "miniflare";
import { drizzle } from "drizzle-orm/d1";
import { readFile } from "node:fs/promises";
import assert from "node:assert/strict";
import { D1Repository } from "../lib/adapters/d1-repository";
import { D1KeyRotationStore } from "../lib/adapters/d1-key-rotation";
import { D1DailyLlmBudget } from "../lib/adapters/d1-llm-budget";
import { RoundRobinKeys } from "../lib/llm/key-pool";
import { VocabularyService } from "../lib/services/vocabulary";
import { MockLlm } from "../lib/llm/mock";
import type { LlmProvider } from "../lib/domain/ports";
import { CATALOG } from "../lib/llm/catalog";
import * as schema from "../db/schema";

// A separate ephemeral D1 database. Never connects to the preview learner's DB.
const mf = new Miniflare({
  modules: true,
  script: 'export default {fetch(){return new Response("test")}}',
  d1Databases: ["DB"],
  compatibilityDate: "2026-05-15",
});
try {
  const binding = await mf.getD1Database("DB");
  for (const path of [
    "drizzle/0000_square_leper_queen.sql",
    "drizzle/0001_sloppy_goblin_queen.sql",
    "drizzle/0002_removed_word.sql",
    "drizzle/0003_watery_tana_nile.sql",
    "drizzle/0004_sudden_mysterio.sql",
    "drizzle/0005_kind_hobgoblin.sql",
    "drizzle/0006_overjoyed_stepford_cuckoos.sql",
  ]) {
    for (const statement of (await readFile(path, "utf8")).split(
      "--> statement-breakpoint",
    ))
      if (statement.trim()) await binding.prepare(statement.trim()).run();
  }
  let serial = 0;
  const ids = { next: () => `integration-${++serial}` };
  const db = drizzle(binding as unknown as D1Database, { schema });
  const keyStore = new D1KeyRotationStore(db);
  const fakeKeys = Array.from({ length: 6 }, (_, i) => `test-key-${i + 1}`);
  // Every call uses a fresh selector/store, as independent Worker instances do.
  for (let i = 0; i < 14; i++) {
    const selected = await new RoundRobinKeys(
      fakeKeys,
      new D1KeyRotationStore(db),
    ).nextKey();
    assert.equal(selected, fakeKeys[i % 6]);
  }
  const concurrent = await Promise.all(
    Array.from({ length: 120 }, () =>
      new RoundRobinKeys(fakeKeys, new D1KeyRotationStore(db)).nextKey(),
    ),
  );
  for (const key of fakeKeys)
    assert.equal(concurrent.filter((value) => value === key).length, 20);
  const isolatedPool = await keyStore.reserve("different-test-pool", 3);
  assert.equal(isolatedPool, 0);
  const rows = await binding.prepare("select * from llm_key_rotation").all();
  assert.ok(!JSON.stringify(rows.results).includes("test-key-"));
  console.log(
    "PASS persistent six-key rotation, 120 concurrent reservations, pool isolation and no stored secrets",
  );
  const budgetDate = () => new Date("2026-10-29T12:00:00Z");
  const admissions = await Promise.all(
    Array.from({ length: 20 }, () =>
      new D1DailyLlmBudget(db, 3, budgetDate).take(),
    ),
  );
  assert.equal(admissions.filter(Boolean).length, 3);
  assert.equal(
    await new D1DailyLlmBudget(
      db,
      3,
      () => new Date("2026-10-30T00:00:00Z"),
    ).take(),
    true,
  );
  console.log("PASS atomic global LLM budget and UTC-day reset");
  const repo = new D1Repository(db, ids.next);
  const quotaDay = "2026-10-26";
  assert.equal(await repo.discoveryCount("quota-owner", quotaDay, "concept"), 0);
  const conceptUses = await Promise.all(Array.from({ length: 24 }, () => repo.consumeDiscovery("quota-owner", quotaDay, "concept", 20)));
  assert.equal(conceptUses.filter(Boolean).length, 20);
  assert.equal(await repo.discoveryCount("quota-owner", quotaDay, "concept"), 20);
  assert.equal(await repo.consumeDiscovery("quota-owner", quotaDay, "concept", 20), false);
  assert.equal(await repo.discoveryCount("quota-owner", quotaDay, "concept"), 20);
  const writingUses = await Promise.all(Array.from({ length: 14 }, () => repo.consumeDiscovery("quota-owner", quotaDay, "writing", 10)));
  assert.equal(writingUses.filter(Boolean).length, 10);
  assert.equal(await repo.discoveryCount("quota-owner", quotaDay, "writing"), 10);
  assert.equal(await repo.discoveryCount("other-owner", quotaDay, "concept"), 0);
  assert.equal(await repo.discoveryCount("quota-owner", "2026-10-27", "concept"), 0);
  console.log("PASS atomic 20/10 discovery quotas, category/owner/day isolation and denied-use stability");
  const make = (id: string) =>
    new VocabularyService(
      repo,
      new MockLlm(),
      { id, name: "Fixture", email: "fixture@example.test" },
      { now: () => new Date("2026-10-26T08:00:00Z") },
      ids,
    );
  const service = make("isolated-owner");
  const manualService = make("manual-owner");
  const firstManual = await manualService.addManual("  Intransigence  ");
  assert.equal(firstManual.status, "added");
  if (firstManual.status !== "added") throw new Error("Expected valid manual word");
  assert.equal((await manualService.state()).profile.onboarded, true);
  const duplicateManual = await manualService.addManual("INTRANSIGENCE");
  assert.equal(duplicateManual.status, "already");
  if (duplicateManual.status !== "already") throw new Error("Expected existing manual word");
  assert.equal(duplicateManual.userWordId, firstManual.userWordId);
  const longestManual = await manualService.addManual("pneumonoultramicroscopicsilicovolcanoconiosis");
  assert.equal(longestManual.status, "added");
  if (longestManual.status !== "added") throw new Error("Expected longest accepted word");
  const invalidManual = await manualService.addManual("hihi");
  assert.equal(invalidManual.status, "review");
  if (invalidManual.status === "review") assert.equal(invalidManual.check.status, "invalid");
  assert.equal((await manualService.addManual("hihi", true)).status, "review");
  await assert.rejects(() => manualService.addManual("a".repeat(46)));
  assert.equal((await manualService.state()).words.length, 2);
  let uncertainChecks = 0;
  const uncertainProvider: LlmProvider = new MockLlm();
  uncertainProvider.checkWord = async () => { uncertainChecks++; return { status: "uncertain", suggestion: null }; };
  const uncertainService = new VocabularyService(repo, uncertainProvider, { id: "uncertain-owner", name: "Fixture", email: "fixture@example.test" }, { now: () => new Date("2026-10-26T08:00:00Z") }, ids);
  assert.equal((await uncertainService.addManual("possibleword")).status, "review");
  assert.equal((await uncertainService.addManual("possibleword", true)).status, "added");
  assert.equal(uncertainChecks, 1);
  assert.equal((await uncertainService.addManual("negligible")).status, "added");
  assert.ok((await uncertainService.state()).words.find((word) => word.word === "negligible")?.definition);
  assert.equal(uncertainChecks, 1);
  await manualService.removeWord(firstManual.userWordId);
  await manualService.removeWord(longestManual.userWordId);
  assert.equal((await manualService.state()).words.length, 0);
  assert.equal(await repo.discoveryCount("manual-owner", quotaDay, "concept"), 0);
  assert.equal(await repo.discoveryCount("manual-owner", quotaDay, "writing"), 0);
  console.log("PASS manual normalization, duplicate handling, undo removal and zero discovery quota use");
  const ideaService = make("idea-owner");
  const candidate = { id: "idea-negligible", word: "negligible", partOfSpeech: "adjective", definition: "Too small to matter", nuance: "A slight effect", collocations: ["negligible impact"], examples: ["The impact was negligible."], vietnameseMeaning: "không đáng kể" };
  const savedIdea = await ideaService.saveConceptDiscovery("a very small difference", [candidate]);
  assert.equal((await ideaService.latestConceptDiscovery())?.id, savedIdea.id);
  assert.equal((await ideaService.latestConceptDiscovery())?.candidates[0].vietnameseMeaning, "không đáng kể");
  assert.equal(await make("other-owner").latestConceptDiscovery(), null);
  const addedIdea = await ideaService.addConceptCandidate(savedIdea.id, candidate.id);
  assert.equal(addedIdea.status, "added");
  const [ideaWord] = (await ideaService.state()).words;
  assert.equal(ideaWord.definition, candidate.definition);
  assert.deepEqual(ideaWord.collocations, candidate.collocations);
  assert.equal(ideaWord.sourceText, savedIdea.concept);
  assert.equal((await ideaService.addConceptCandidate(savedIdea.id, candidate.id)).status, "already");
  assert.equal((await ideaService.translateConceptCandidate(savedIdea.id, candidate.id)).meaning, "không đáng kể");
  assert.equal((await ideaService.recentConceptDiscovery("a   very small difference"))?.id, savedIdea.id);
  let translations = 0;
  const translatingProvider = new MockLlm();
  translatingProvider.translateLexeme = async () => { translations++; return "nghĩa đã lưu"; };
  const translatingService = new VocabularyService(repo, translatingProvider, { id: "idea-owner", name: "Fixture", email: "fixture@example.test" }, { now: () => new Date("2026-10-26T08:00:00Z") }, ids);
  const legacyIdea = await ideaService.saveConceptDiscovery("an older idea", [{ ...candidate, id: "legacy-candidate", vietnameseMeaning: undefined }]);
  assert.equal((await translatingService.translateConceptCandidate(legacyIdea.id, "legacy-candidate")).meaning, "nghĩa đã lưu");
  assert.equal((await translatingService.translateConceptCandidate(legacyIdea.id, "legacy-candidate")).meaning, "nghĩa đã lưu");
  assert.equal(translations, 1);
  await assert.rejects(() => make("other-owner").addConceptCandidate(savedIdea.id, candidate.id));
  await assert.rejects(() => make("other-owner").translateConceptCandidate(savedIdea.id, candidate.id));
  console.log("PASS idea persistence, candidate metadata, ownership and duplicate handling");
  assert.equal((await service.state()).profile.dailyLimit, 7);
  await binding
    .prepare(
      "insert into app_user (id, name, created_at, daily_limit, onboarded) values (?, ?, ?, ?, ?)",
    )
    .bind("legacy-owner", "Existing learner", "2026-01-01", 6, 1)
    .run();
  assert.equal((await make("legacy-owner").state()).profile.dailyLimit, 6);
  const review = await service.analyze(
    "There was a very small difference in productivity. I read a very interesting story. It offered a more detailed view. There was a very big improvement.",
    "",
  );
  assert.equal((await service.recentWritingReview(review.text, ""))?.sampleId, review.sampleId);
  assert.equal((await service.analyze(review.text, "")).sampleId, review.sampleId);
  assert.equal(review.suggestions.length, 4);
  const id = review.suggestions[0].id;
  await service.decide(id, "dismissed");
  assert.equal(
    (await make("isolated-owner").review(review.sampleId)).suggestions[0]
      .status,
    "dismissed",
  );
  await assert.rejects(
    () => make("other-owner").review(review.sampleId),
    /could not be found/,
  );
  await service.decide(id, "added");
  await service.decide(id, "pending");
  assert.equal((await service.state()).words.length, 0);
  for (const s of review.suggestions) await service.decide(s.id, "added");
  const resumed = await service.review(review.sampleId);
  assert.equal(resumed.suggestions.filter((s) => s.queued).length, 1);
  const queued = resumed.suggestions.find((s) => s.queued)!;
  await service.decide(queued.id, "pending");
  assert.equal((await service.state()).words.length, 3);
  const session = await service.startPractice();
  assert.ok(session.sessionId);
  assert.equal(session.total, 3);
  assert.equal(
    (await repo.getSession("isolated-owner", session.sessionId)).length,
    3,
  );
  const many = make("many-ready");
  await many.state();
  await many.settings({ dailyLimit: 10 });
  for (const word of CATALOG.slice(0, 12))
    await repo.addWord("many-ready", word, {
      source: "Test writing",
      sourceText: word.examples[0],
      now: "2026-10-25T08:00:00Z",
      introduced: true,
    });
  assert.equal((await many.state()).dueCount, 10);
  const manySession = await many.startPractice();
  assert.equal(manySession.total, 10);
  assert.ok((await repo.getSession("many-ready", manySession.sessionId)).every((exercise) => exercise.prompt.includes("Bring to mind") || exercise.prompt.includes("Describe a realistic situation")));
  const firstExercise = (
    await repo.getSession("many-ready", manySession.sessionId)
  )[0];
  const firstWord = (await many.state()).words.find(
    (word) => word.userWordId === firstExercise.userWordId,
  )!;
  assert.equal(
    (await many.answer(firstExercise.id, "I do not remember")).incorrect,
    true,
  );
  assert.equal(
    (await many.answer(firstExercise.id, firstWord.word)).sentencePending,
    true,
  );
  assert.equal(
    (await repo.getExercise("many-ready", firstExercise.id))?.sentencePending,
    true,
  );
  assert.equal((await many.answer(firstExercise.id, firstWord.word)).retry, true);
  assert.equal(
    (await many.session(manySession.sessionId)).exercise?.sentencePending,
    true,
  );
  await assert.rejects(() => service.skip(firstExercise.id), /no longer open/);
  assert.equal((await many.skip(firstExercise.id)).skipped, true);
  assert.equal(
    (await many.session(manySession.sessionId)).exercise?.position,
    2,
  );
  assert.equal(
    (await make("many-ready").session(manySession.sessionId)).results[0]
      .outcome,
    "recalled-skipped",
  );
  await assert.rejects(
    () => service.decide(id, "pending"),
    /learning history are preserved/,
  );
  assert.equal((await service.state()).words.length, 3);
  const repeat = await service.analyze(review.text, "");
  assert.equal(repeat.suggestions.length, 1);
  assert.ok(repeat.opportunities.length >= 3);
  const shared = make("other-owner");
  const sharedReview = await shared.analyze(
    "There was a very small difference in cost.",
    "",
  );
  await shared.decide(sharedReview.suggestions[0].id, "added");
  const wordToRemove = (await service.state()).words.find(
    (word) => word.word === "negligible",
  )!;
  const activeSession = await service.startPractice(wordToRemove.userWordId);
  const attemptsBefore = await binding
    .prepare(
      "select count(*) as count from practice_attempt where user_word_id = ?",
    )
    .bind(wordToRemove.userWordId)
    .first<{ count: number }>();
  assert.equal(
    await service.removeWord(wordToRemove.userWordId).then((r) => r.removed),
    true,
  );
  assert.equal(
    (await service.state()).words.some(
      (word) => word.userWordId === wordToRemove.userWordId,
    ),
    false,
  );
  assert.equal(
    (await shared.state()).words.some((word) => word.word === "negligible"),
    true,
  );
  assert.equal(
    (await service.review(review.sampleId)).suggestions.find(
      (s) => s.word === "negligible",
    )?.status,
    "pending",
  );
  assert.equal(
    (await service.review(repeat.sampleId)).opportunities.some(
      (item) => item.userWordId === wordToRemove.userWordId,
    ),
    false,
  );
  assert.equal(
    await repo
      .getSession("isolated-owner", activeSession.sessionId)
      .then((items) => items.length),
    0,
  );
  const attemptsAfter = await binding
    .prepare(
      "select count(*) as count from practice_attempt where user_word_id = ?",
    )
    .bind(wordToRemove.userWordId)
    .first<{ count: number }>();
  assert.equal(attemptsAfter?.count, attemptsBefore?.count);
  await assert.rejects(
    () => service.removeWord(wordToRemove.userWordId),
    /not found on your board/,
  );
  await assert.rejects(
    () => shared.removeWord(wordToRemove.userWordId),
    /not found on your board/,
  );
  const patterns = make("patterns-owner");
  const source = "There was a very big improvement in productivity.";
  await patterns.analyze(source, "");
  const patternSave = await patterns.addInsight("substantial");
  const savedPatternWord = (await patterns.state()).words[0];
  assert.equal(savedPatternWord.sourceText, source);
  assert.equal(
    (await patterns.addInsight("substantial")).userWordId,
    patternSave.userWordId,
  );
  assert.equal((await patterns.state()).words.length, 1);
  for (const size of [5, 7, 10]) {
    await many.settings({ dailyLimit: size });
    assert.equal((await many.startPractice()).total, size);
  }
  const boardBeforeSelection = (await many.state()).words;
  const chosenIds = boardBeforeSelection.slice(-2).map((word) => word.userWordId);
  const chosenSession = await many.startPractice(undefined, false, undefined, chosenIds);
  const chosenWords = (await many.session(chosenSession.sessionId)).words;
  assert.deepEqual(new Set(chosenWords.map((word) => word.userWordId)), new Set(chosenIds));
  assert.equal((await many.state()).words.length, boardBeforeSelection.length);
  await assert.rejects(
    () => many.startPractice(undefined, false, undefined, [chosenIds[0], chosenIds[0]]),
    /valid set of words/,
  );
  await assert.rejects(
    () => many.startPractice(undefined, false, undefined, [chosenIds[0], savedPatternWord.userWordId]),
    /no longer available/,
  );
  await patterns.seed();
  assert.ok((await patterns.state()).words.some((word) => word.demo));
  await patterns.clearDemo();
  assert.equal((await patterns.state()).words.length, 1);
  assert.equal(
    (await patterns.state()).words[0].userWordId,
    patternSave.userWordId,
  );
  assert.equal((await patterns.state()).writingCount, 1);
  console.log(
    "PASS isolated D1 migrations, review reload, decisions, 5/7/10 sessions, session word selection, legacy preferences, recap, pattern source/duplicates, demo cleanup, ownership isolation and retained history",
  );

  const flexible = make("flexible-practice");
  await flexible.state();
  const fr = await flexible.analyze("There was a very small difference.", "");
  await flexible.decide(fr.suggestions[0].id, "added");
  const fw = (await flexible.state()).words[0];
  await binding
    .prepare("update user_word set next_review_at = ? where id = ?")
    .bind("2026-11-15T08:00:00.000Z", fw.userWordId)
    .run();
  const before = (await flexible.state()).words[0];
  const quick = await flexible.startPractice(undefined, true);
  await assert.rejects(() =>
    make("other-owner").quickRate(quick.exercise.id, "got"),
  );
  await flexible.quickRate(quick.exercise.id, "got");
  await assert.rejects(() => flexible.quickRate(quick.exercise.id, "got"));
  const after = (await flexible.state()).words[0];
  assert.equal(after.nextReviewAt, before.nextReviewAt);
  assert.equal(after.stage, before.stage);
  assert.equal(after.attempts.at(-1)?.context, "quick-review");
  assert.equal(after.attempts.at(-1)?.answer, "got");
  assert.ok((await flexible.startPractice()).sessionId);
  const manual = await flexible.startPractice(fw.userWordId);
  await flexible.answer(manual.exercise.id, "negligible");
  await flexible.answer(
    manual.exercise.id,
    "The difference in cost was negligible.",
  );
  assert.equal(
    (await flexible.state()).words[0].nextReviewAt,
    before.nextReviewAt,
  );
  assert.ok((await flexible.startPractice()).sessionId);

  await assert.rejects(() =>
    flexible.startPractice(undefined, false, quick.sessionId),
  );
  const handoff = make("handoff-owner");
  await handoff.state();
  await handoff.seed();
  const sourceSession = await handoff.startPractice(undefined, true);
  const sourceCards = await repo.getSession(
    "handoff-owner",
    sourceSession.sessionId,
  );
  // Browsing exposes each owned Quick Review exercise without recording a rating.
  const browsable = await handoff.session(sourceSession.sessionId);
  assert.deepEqual(
    browsable.words.map((w) => w.exerciseId),
    sourceCards.map((e) => e.id),
  );
  assert.ok(sourceCards.every((e) => !e.answeredAt));
  await assert.rejects(() =>
    make("other-owner").session(sourceSession.sessionId),
  );
  const fullSession = await handoff.startPractice();
  assert.ok(
    (await handoff.session(fullSession.sessionId)).words.every(
      (w) => !w.exerciseId,
    ),
  );
  const forgottenIds: string[] = [];
  await assert.rejects(() =>
    handoff.startPractice(undefined, false, sourceSession.sessionId),
  );
  for (let i = 0; i < sourceCards.length; i++) {
    const rating = i % 2 === 0 ? "forgot" : i === 1 ? "got" : "skip";
    await handoff.quickRate(sourceCards[i].id, rating);
    if (rating === "forgot") forgottenIds.push(sourceCards[i].userWordId);
  }
  await assert.rejects(() =>
    make("other-owner").startPractice(
      undefined,
      false,
      sourceSession.sessionId,
    ),
  );
  const bridge = await handoff.startPractice(
    undefined,
    false,
    sourceSession.sessionId,
  );
  assert.deepEqual(
    (await handoff.session(bridge.sessionId)).words.map((w) => w.userWordId),
    forgottenIds,
  );
  await binding
    .prepare("update app_user set daily_limit = 2 where id = ?")
    .bind("handoff-owner")
    .run();
  const capped = await handoff.startPractice(
    undefined,
    false,
    sourceSession.sessionId,
  );
  assert.deepEqual(
    (await handoff.session(capped.sessionId)).words.map((w) => w.userWordId),
    forgottenIds.slice(0, 2),
  );
  console.log(
    "PASS explicit forgotten set, ownership, completed source, zero-forgotten rejection and deterministic cap",
  );
  await make("lexical-owner").state();
  const compoundId = await repo.addWord(
    "lexical-owner",
    {
      id: "lexical-bounce-back",
      word: "bounce back",
      partOfSpeech: "phrasal verb",
      definition: "To recover after difficulty or a setback.",
      nuance: "",
      collocations: ["bounce back from a setback"],
      examples: ["The team bounced back quickly."],
    },
    {
      source: "quality regression",
      sourceText: "The team recovered quickly.",
      now: "2026-10-29T10:00:00.000Z",
      introduced: false,
    },
  );
  const compound = (await repo.listWords("lexical-owner")).find(
    (w) => w.userWordId === compoundId,
  )!;
  assert.equal(compound.word, "bounce back");
  assert.equal(compound.partOfSpeech, "phrasal verb");
  assert.equal(
    (await repo.listWords("other-owner")).some(
      (w) => w.userWordId === compoundId,
    ),
    false,
  );
  console.log(
    "PASS canonical multi-word lexical unit round-trip with owner isolation",
  );
} finally {
  await mf.dispose();
}
