import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {instructionalTemporalOverclaims} from "../lib/llm/semantic-policy";
import {inspectAnalysisProposals} from "../lib/llm/gemini";

const cases: Array<[string,string,boolean]> = [
 ["profound","deep and lasting",false],
 ["profound","emphasizes the lasting nature of an effect",false],
 ["significant","important and enduring",false],
 ["dramatic","striking and persistent",false],
 ["transformative","produces permanent change",false],
 ["substantial","large and long-lasting",false],
 ["powerful","continues indefinitely",false],
 ["severe","the effect does not fade",false],
 ["profound","deep, significant, or far-reaching",true],
 ["significant","important or meaningful",true],
 ["dramatic","striking or very noticeable",true],
 ["transformative","causing a fundamental change",true],
 ["enduring","lasting over time",true],
 ["persistent","continuing despite difficulty",true],
 ["temporary","having limited duration",true],
 ["profound","may be long-lasting in this context",true],
 ["profound","not necessarily lasting",true],
 ["prolonged","sustained or continuing for a long time",true],
];
for(const [word,teaching,allowed] of cases) test(`temporal teaching ${word}: ${teaching}`,()=>{
 const r=instructionalTemporalOverclaims(word,"adjective",{nuance:teaching});assert.equal(r.length===0,allowed,JSON.stringify(r));
 if(!allowed){assert.equal(r[0].field,"nuance");assert.equal(r[0].candidate,word);assert.equal(r[0].lexicallyEntailed,false);}
});
test("individual examples can have duration without defining the word as temporal",()=>{
 assert.equal(instructionalTemporalOverclaims("profound","adjective",{"example-0":"The profound effect lasted for decades."}).length,0);
 assert.ok(instructionalTemporalOverclaims("profound","adjective",{"example-0":"A profound effect is always lasting."}).length);
});
test("saved E01 is rejected by the full application with temporal audit",()=>{
 const run=JSON.parse(readFileSync("evals/results/complete-confirmation-3.6-2026-10-30/results.json","utf8"));
 const row=run.rows.find((r:{case:{id:string}})=>r.case.id==="E01");
 const result=inspectAnalysisProposals(row.case.input,row.requests[0].rawModelOutput);
 const entry=result.audit.find(x=>x.word==="profound")!;
 assert.equal(result.suggestions.some(x=>x.word==="profound"),false);
 assert.equal(entry.reason,"instructional-temporal-entailment-overclaim");
 assert.match(JSON.stringify(entry),/lasting/);
});
test("source-specific duration is preserved when generic teaching is neutral",()=>{
 const run=JSON.parse(readFileSync("evals/results/complete-confirmation-3.6-2026-10-30/results.json","utf8"));
 const row=run.rows.find((r:{case:{id:string}})=>r.case.id==="E01");
 const raw=structuredClone(row.requests[0].rawModelOutput);
 const text="The change have a very big effect on how our team organise its work that lasted for decades.";
 raw.suggestions=raw.suggestions.slice(0,1);raw.suggestions[0].source.sentence=text;
 raw.suggestions[0].nuance="Emphasizes a deep and significant effect.";
 const result=inspectAnalysisProposals(text,raw);
 assert.equal(result.suggestions.length,1,JSON.stringify(result.audit));
 assert.match(result.suggestions[0].suggestedSentence??"",/lasted for decades/);
});
