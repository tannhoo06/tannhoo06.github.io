import test from "node:test";
import assert from "node:assert/strict";
import { findInsights } from "../lib/services/insights";
import { wordCloud } from "../lib/domain/word-cloud";
import type { UserWord } from "../lib/domain/types";

test("insights retain the correct occurrence, sample, and complete source sentence", () => {
  const text =
    "😀 An important idea. Another important choice!\nThis is interesting.";
  const insights = findInsights([{ id: "writing-1", text }]);
  const important = insights.find((item) => item.phrase === "important")!;
  assert.equal(important.count, 2);
  assert.equal(important.sources?.length, 2);
  assert.deepEqual(
    important.sources?.map((source) => source.sentence),
    ["😀 An important idea.", "Another important choice!"],
  );
  for (const source of important.sources ?? []) {
    assert.equal(source.sampleId, "writing-1");
    assert.equal(source.text.slice(source.start, source.end), "important");
  }
});

test("insights aggregate across samples without losing source identity or changing counts when examples are capped", () => {
  const insights = findInsights(
    Array.from({ length: 8 }, (_, index) => ({
      id: `sample-${index}`,
      text: "This is very big.",
    })),
  );
  assert.equal(insights[0].count, 8);
  assert.equal(insights[0].sources?.length, 5);
  assert.equal(insights[0].sources?.[4].sampleId, "sample-4");
  assert.deepEqual(findInsights([{ text: "No matching patterns." }]), []);
});

test("word cloud counts recorded contextual uses across time ranges, not recall-only answers", () => {
  const now = Date.parse("2026-11-02T12:00:00Z");
  const word = {
    word: "negligible",
    stage: "practicing",
    demo: false,
    attempts: [
      { kind: "spontaneous", answer: "A negligible cost and negligible delay.", at: "2026-10-01T12:00:00Z" },
      { kind: "completion", answer: "negligible", at: "2026-11-01T12:00:00Z" },
      { kind: "free", answer: "The difference is negligible.", at: "2026-11-01T12:00:00Z" },
      { kind: "free", answer: "Its impact was negligible.", at: "2026-10-15T12:00:00Z" },
    ],
  } as UserWord;
  assert.deepEqual(wordCloud([word], now)[0].counts, [4, 2, 1]);
  assert.deepEqual(wordCloud([word], now, [
    { text: "The impact was negligible.", createdAt: "2026-09-01T12:00:00Z" },
    { text: "A negligible change and negligible cost.", createdAt: "2026-10-20T12:00:00Z" },
    { text: "Negligible in practice.", createdAt: "2026-11-01T12:00:00Z" },
  ])[0].counts, [8, 5, 2]);
  assert.deepEqual(wordCloud([{ ...word, demo: true }], now), []);
});
