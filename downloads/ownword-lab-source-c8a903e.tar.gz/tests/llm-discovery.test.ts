import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { GeminiLlm, inspectAnalysisProposals } from "../lib/llm/gemini";
import { inspectSuggestion } from "../lib/llm/suggestion-guards";
import { learnerFriendlyDefinition } from "../lib/llm/definition-quality";
import { resolveSource, validSource } from "../lib/domain/anchors";
import type { WritingAnalysis } from "../lib/domain/types";

type Suggestion = WritingAnalysis["suggestions"][number];
const proposal = (
  text: string,
  originalText: string,
  word: string,
  rewrite: string | null,
  partOfSpeech = "verb",
): Suggestion => ({
  word,
  originalText,
  partOfSpeech,
  suggestedSentence: rewrite,
  source: resolveSource(text, originalText, ""),
  definition: "To express the stated concept more directly.",
  nuance: "",
  reason: "A reusable name for this concept.",
  confidence: 0.9,
  examples: ["A natural English example."],
  collocations: [],
});
const model = (suggestions: unknown[], summary = "") => ({
  suggestions,
  opportunities: [],
  usages: [],
  summary,
});
const response = (value: unknown) =>
  (async () =>
    Response.json({
      candidates: [{ content: { parts: [{ text: JSON.stringify(value) }] } }],
    })) as typeof fetch;

test("stored D02 convince proposal survives its exactly mapped internal deletion", () => {
  const run = JSON.parse(
    readFileSync("evals/results/candidate-v2b-2026-10-29/results.json", "utf8"),
  );
  const row = run.rows.find(
    (r: { case: { id: string } }) => r.case.id === "D02",
  );
  const result = inspectAnalysisProposals(
    row.case.input,
    row.requests[0].rawModelOutput,
  );
  assert.equal(result.suggestions.length, 1);
  assert.equal(result.suggestions[0].word, "convince");
  assert.equal(
    result.suggestions[0].suggestedSentence,
    "The evidence was strong enough to convince the sceptical panel.",
  );
  assert.ok(validSource(row.case.input, "", result.suggestions[0].source));
});
test("explicit minimal phrase preserves the original outside the span despite surrounding agreement edits", () => {
  const text = "The change have a very big effect on our work.";
  const result = inspectSuggestion(
    text,
    proposal(
      text,
      "very big",
      "profound",
      "The change has a profound effect on our work.",
      "adjective",
    ),
    "profound",
  );
  assert.ok(result.suggestion);
  assert.equal(
    result.suggestion.suggestedSentence,
    "The change have a profound effect on our work.",
  );
  assert.equal(result.suggestion.originalText, "very big");
});
test("multi-token local replacement retains its original participants and exact source offsets", () => {
  const text =
    "The evidence was strong enough to make the sceptical panel change its mind.";
  const old = "make the sceptical panel change its mind";
  const result = inspectSuggestion(
    text,
    proposal(text, old, "convince", null),
    "convince the sceptical panel",
  );
  assert.ok(result.suggestion);
  assert.equal(
    result.suggestion.suggestedSentence,
    text.replace(old, "convince the sceptical panel"),
  );
  assert.equal(result.suggestion.source!.start, text.indexOf(old));
});
test("oversized A03 quote is narrowed even with explicit replacement metadata", () => {
  const text =
    "The proposal was interesting because its evidence was strong enough to persuade everyone.";
  const old = "interesting because its evidence was strong enough";
  const result = inspectSuggestion(
    text,
    proposal(text, old, "compelling", null, "adjective"),
    "compelling because its evidence was strong enough",
  );
  assert.equal(result.suggestion?.originalText, "interesting");
  assert.equal(
    result.suggestion?.suggestedSentence,
    text.replace("interesting", "compelling"),
  );
});
test("unrelated semantic multi-hunk edits outside the lexical quote are still rejected", () => {
  const text = "The team made the steps simpler, but costs stayed high.";
  const s = proposal(
    text,
    "made the steps simpler",
    "streamline",
    "The team streamlined the steps, but costs collapsed.",
  );
  const result = inspectSuggestion(text, s, "streamlined the steps");
  assert.equal(result.suggestion, null);
  assert.equal(result.reason, "unrelated-semantic-edit");
});
test("unrelated content, missing nouns and unisolatable broad rewrites cannot pass repair", () => {
  const text = "It had a very big impact.";
  assert.equal(
    inspectSuggestion(
      text,
      proposal(text, "very big impact", "profound", null, "adjective"),
      "profound disaster",
    ).suggestion,
    null,
  );
  assert.equal(
    inspectSuggestion(
      text,
      proposal(text, "very big impact", "profound", null, "adjective"),
      "profound",
    ).reason,
    "missing-modified-noun",
  );
  const sentence =
    "She explained a complicated idea in words that everyone could understand.";
  assert.equal(
    inspectSuggestion(
      sentence,
      proposal(
        sentence,
        "explained a complicated idea in words that everyone could understand",
        "demystify",
        "She managed to demystify the complicated idea.",
      ),
    ).reason,
    "unrelated-content-in-replacement",
  );
});
test("ambiguous anchors remain rejected rather than choosing an occurrence", () => {
  const text = "It was very big. It was very big.";
  assert.equal(
    inspectSuggestion(
      text,
      proposal(text, "very big", "substantial", null, "adjective"),
      "substantial",
    ).suggestion,
    null,
  );
});
test("grammar/spelling-only and formal noun swaps stay suppressed on the new path", () => {
  for (const [text, old, word, replacement] of [
    ["She explain the idea.", "explain", "explained", "explained"],
    ["It was intresting.", "intresting", "interesting", "interesting"],
    ["We discuss about the budget.", "discuss about", "discuss", "discuss"],
  ])
    assert.equal(
      inspectSuggestion(text, proposal(text, old, word, null), replacement)
        .reason,
      "grammar-or-spelling-only",
    );
  const text = "There was a small increase in the dose.";
  assert.equal(
    inspectSuggestion(
      text,
      proposal(text, "small increase", "increment", null, "noun"),
      "slight increment",
    ).reason,
    "formal-noun-swap",
  );
});
test("definitions are bounded, noncircular and reject the recorded unclear pronoun wording", () => {
  assert.equal(
    learnerFriendlyDefinition(
      "demystify",
      "To make a difficult or mysterious subject easier to understand.",
    ),
    true,
  );
  assert.equal(
    learnerFriendlyDefinition(
      "demystify",
      "To clarify something that makes it seem mysterious or complex.",
    ),
    false,
  );
  assert.equal(
    learnerFriendlyDefinition(
      "demystify",
      "To demystify a complicated subject.",
    ),
    false,
  );
  assert.equal(
    learnerFriendlyDefinition("demystify", Array(40).fill("meaning").join(" ")),
    false,
  );
});
test("one paid-call shape separates concept, minimal replacement and instructional metadata", async () => {
  let requests = 0;
  const text = "The tool made repeated paperwork steps simpler.";
  const s = proposal(
    text,
    "made repeated paperwork steps simpler",
    "streamline",
    null,
  );
  const value = model([
    {
      ...s,
      concept: "simplifying repeated work",
      replacementText: "streamlined repeated paperwork steps",
      definition: "To make a process simpler and more efficient.",
      source: { sentence: text, before: "The tool ", after: "." },
    },
  ]);
  const provider = new GeminiLlm("test", "test", (async (url, init) => {
    requests++;
    const body = JSON.parse(init!.body as string);
    const required =
      body.generationConfig.responseSchema.properties.suggestions.items
        .required;
    assert.ok(required.includes("concept"));
    assert.ok(required.includes("replacementText"));
    assert.ok(!required.includes("suggestedSentence"));
    assert.match(
      body.systemInstruction.parts[0].text,
      /optional vocabulary discovery/i,
    );
    return response(value)(url, init);
  }) as typeof fetch);
  const result = await provider.analyzeWriting(text, []);
  assert.equal(requests, 1);
  assert.equal(result.suggestions.length, 1);
  assert.equal(
    result.suggestions[0].suggestedSentence,
    "The tool streamlined repeated paperwork steps.",
  );
  assert.ok(!("concept" in result.suggestions[0]));
  assert.ok(!("replacementText" in result.suggestions[0]));
});
test("already precise writing can still return no suggestion and no grammar judgments", async () => {
  const result = await new GeminiLlm(
    "test",
    "test",
    response(model([], "Grammatically correct.")),
  ).analyzeWriting("The meeting starts at nine tomorrow morning.", []);
  assert.equal(result.suggestions.length, 0);
  assert.doesNotMatch(result.summary, /grammatical/i);
});
test("non-English definition rejection remains authoritative on the new one-call path", async () => {
  const text = "It had a very big effect.";
  const s = {
    concept: "a major effect",
    word: "profound",
    partOfSpeech: "adjective",
    definition:
      "suficientemente importante o notable como para tener en cuenta",
    nuance: "",
    examples: ["It had a profound effect."],
    collocations: [],
    originalText: "very big",
    source: { sentence: text, before: "It had a ", after: " effect." },
    replacementText: "profound",
    reason: "Names the concept.",
    confidence: 0.9,
  };
  await assert.rejects(
    () =>
      new GeminiLlm("test", "test", response(model([s]))).analyzeWriting(
        text,
        [],
      ),
    /English instructional text/,
  );
});
