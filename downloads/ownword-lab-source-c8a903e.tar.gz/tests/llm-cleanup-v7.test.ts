import test from "node:test";
import assert from "node:assert/strict";
import { inspectAnalysisProposals } from "../lib/llm/gemini";
import { semanticStrength, lexicalBenefit } from "../lib/llm/semantic-policy";
import { resolveSource } from "../lib/domain/anchors";
import { validateLexicalRewrite } from "../lib/llm/rewrite-quality";
function assess(
  text: string,
  old: string,
  word: string,
  replacement: string,
  pos = "verb",
  definition = "To express the supported contextual meaning more precisely.",
) {
  return inspectAnalysisProposals(text, {
    suggestions: [
      {
        word,
        canonicalForm: word,
        partOfSpeech: pos,
        originalText: old,
        replacementText: replacement,
        definition,
        nuance: "",
        reason: "A reusable lexical concept in this source.",
        source: { sentence: text, before: "", after: "" },
        examples: ["A natural contextual example."],
        collocations: [],
        confidence: 0.9,
      },
    ],
    opportunities: [],
    usages: [],
    summary: "",
  });
}
test("explicit more support licenses further corroborated", () => {
  const r = assess(
    "The results provided more support for them.",
    "provided more support for",
    "corroborate",
    "further corroborated",
    "verb",
    "To provide additional evidence supporting an existing claim.",
  );
  assert.equal(r.suggestions.length, 1, JSON.stringify(r.audit));
  assert.ok(
    r.audit[0].mapping.diagnostics.includes("supported-evidence-modifier"),
  );
});
test("unsupported further is rejected", () => {
  const r = assess(
    "The results supported them.",
    "supported",
    "corroborate",
    "further corroborated",
  );
  assert.equal(r.suggestions.length, 0);
  assert.ok(
    r.audit[0].mapping.diagnostics.includes("unsupported-added-modifier"),
  );
});
test("explicit quickly supports rapid modifier while preserving protected speed wording", () => {
  const r = assess(
    "The team recovered quickly after setbacks.",
    "recovered quickly",
    "bounce back",
    "rapidly bounced back",
    "phrasal verb",
    "To recover after difficulty or a setback.",
  );
  assert.equal(r.suggestions.length, 1, JSON.stringify(r.audit));
  assert.match(r.suggestions[0].suggestedSentence!, /bounced back quickly/);
});
test("speed cannot be invented", () =>
  assert.equal(
    assess(
      "The team recovered after setbacks.",
      "recovered",
      "bounce back",
      "rapidly bounced back",
      "phrasal verb",
    ).suggestions.length,
    0,
  ));
test("safe affect/effect nominalization proves same subject and object", () => {
  const text = "The difference is too small to affect our decision.";
  const r = assess(
    text,
    "too small to affect",
    "negligible",
    "negligible in its effect on",
    "adjective",
    "So small or unimportant as to be not worth considering.",
  );
  assert.equal(r.suggestions.length, 1, JSON.stringify(r.audit));
  assert.ok(
    r.audit[0].mapping.diagnostics.includes("event-nominalization-supported"),
  );
  assert.equal(r.audit[0].frameConfidence, "known-safe");
});
test("nominalization cannot strengthen a large effect into transformation", () => {
  const r = assess(
    "The change had a big effect on the team.",
    "had a big effect on the team",
    "transformation",
    "the transformation of the team",
    "noun",
    "A complete fundamental change in form or nature.",
  );
  assert.equal(r.suggestions.length, 0);
});
test("unambiguous singular it is allowed", () =>
  assert.equal(
    assess(
      "She explained a concept in words that everyone could understand.",
      "explained a concept in words that everyone could understand",
      "demystify",
      "demystified a concept so everyone could understand it",
    ).suggestions.length,
    1,
  ));
test("ambiguous antecedents do not license it", () =>
  assert.equal(
    assess(
      "She explained a concept and a method in words that everyone could understand.",
      "explained a concept and a method in words that everyone could understand",
      "demystify",
      "demystified a concept and a method so everyone could understand it",
    ).suggestions.length,
    0,
  ));
test("plural referent them is supported", () =>
  assert.equal(
    assess(
      "She explained the complex ideas in words that everyone could understand.",
      "explained the complex ideas in words that everyone could understand",
      "demystify",
      "demystified the complex ideas so everyone could understand them",
    ).suggestions.length,
    1,
  ));
test("pronoun number mismatch is rejected", () =>
  assert.equal(
    assess(
      "She explained the complex ideas in words that everyone could understand.",
      "explained the complex ideas in words that everyone could understand",
      "demystify",
      "demystified the complex ideas so everyone could understand it",
    ).suggestions.length,
    0,
  ));
test("without necessarily eliminating is not affirmative elimination", () =>
  assert.equal(
    semanticStrength(
      "made the problem less severe",
      "mitigated the problem",
      "Reduces severity without necessarily eliminating the cause.",
    ).teaching.length,
    0,
  ));
test("affirmative elimination remains an unsupported strong claim", () =>
  assert.ok(
    semanticStrength(
      "reduced the risk",
      "eliminated the risk",
      "Eliminates the problem.",
    ).teaching.length,
  ));
test("helps prove is a contribution, not conclusive proof", () =>
  assert.equal(
    semanticStrength(
      "provided more support",
      "corroborated",
      "Provides evidence that supports or helps prove a statement.",
    ).teaching.length,
    0,
  ));
test("affirmative proves is still rejected for mere support", () =>
  assert.ok(
    semanticStrength(
      "provided support",
      "proves",
      "Proves the claim conclusively.",
    ).teaching.length,
  ));
test("noun head repair retains all source modifiers", () => {
  const r = assess(
    "The report explains small but meaningful differences.",
    "small but meaningful differences",
    "subtlety",
    "subtleties",
    "noun",
    "A small meaningful difference or detail.",
  );
  assert.equal(r.suggestions.length, 1, JSON.stringify(r.audit));
  assert.match(
    r.suggestions[0].suggestedSentence!,
    /small but meaningful subtleties/,
  );
});
test("unrepaired noun-head qualifier dropping is rejected by unchanged final preservation", () => {
  const text = "The report explains only two important differences.";
  const r = validateLexicalRewrite(
    text,
    {
      word: "nuance",
      partOfSpeech: "noun",
      originalText: "only two important differences",
      source: resolveSource(text, "only two important differences", ""),
      suggestedSentence: "The report explains nuances.",
      definition: "A small meaningful difference.",
      nuance: "",
      reason: "A useful concept.",
      examples: [],
      collocations: [],
      confidence: 0.9,
    },
    { canonical: "nuance", surface: "nuances", type: "word" },
  );
  assert.equal(r.suggestion, null);
  assert.ok(r.issues.includes("qualifier-loss"));
});
test("same-level property substitution fails regardless of candidate spelling", () => {
  for (const word of ["slender", "narrow", "slim"]) {
    const r = assess(
      "The safety margin is small.",
      "small",
      word,
      word,
      "adjective",
      "Narrow or small in amount, extent or degree.",
    );
    assert.equal(r.suggestions.length, 0);
  }
});
test("streamline retains source-supported concept benefit", () =>
  assert.equal(
    assess(
      "The tool made the steps fewer and simpler.",
      "made the steps fewer and simpler",
      "streamline",
      "streamlined the steps",
      "verb",
      "To make a process simpler and more efficient.",
    ).suggestions.length,
    1,
  ));
test("mitigate survives a negated elimination disclaimer", () => {
  const text =
    "The policy made the problem less severe, although it did not solve it.";
  const p = assess(
    text,
    "made the problem less severe",
    "mitigate",
    "mitigated the problem",
    "verb",
    "To reduce severity without necessarily eliminating the cause.",
  );
  assert.equal(p.suggestions.length, 1, JSON.stringify(p.audit));
});
test("corroborate retains qualified teaching and benefit", () =>
  assert.equal(
    assess(
      "The results provided more support for them.",
      "provided more support for",
      "corroborate",
      "corroborated",
      "verb",
      "To provide evidence that supports or helps prove a statement.",
    ).suggestions.length,
    1,
  ));
test("provisional is useful without dropping initial status", () =>
  assert.equal(
    assess(
      "The initial estimate is not final.",
      "not final",
      "provisional",
      "provisional",
      "adjective",
      "For the present and subject to change later.",
    ).suggestions.length,
    1,
  ));
test("bounce back remains a full lexical unit", () =>
  assert.equal(
    assess(
      "The team recovered quickly after setbacks.",
      "recovered",
      "bounce back",
      "bounced back",
      "phrasal verb",
      "To recover after a setback.",
    ).suggestions.length,
    1,
  ));
test("negation cannot leak across conjunctions or not-only/double-negation", () => {
  for (const s of [
    "Does not merely support but proves conclusively.",
    "Not only eliminates the risk.",
    "Does not not prove the claim.",
  ])
    assert.ok(
      semanticStrength("provided support and reduced risk", "supported", s)
        .teaching.length,
      s,
    );
});
test("qualified teaching is distinct from a new qualified outcome in the rewrite", () => {
  assert.equal(
    semanticStrength(
      "supported the claim",
      "supported",
      "May help prove a theory.",
    ).teaching.length,
    0,
  );
  assert.ok(
    semanticStrength(
      "reduced the problem",
      "may eliminate the problem",
      "",
    ).rewrite.includes("qualified-complete-resolution"),
  );
});
test("ordinary formality and same-tier words have no source-evidence benefit", () => {
  assert.equal(
    lexicalBenefit("use", "utilize", "utilize", {
      sentence: "We use the tool.",
      definition: "To make use of something.",
      partOfSpeech: "verb",
    }).sufficient,
    false,
  );
  assert.equal(
    lexicalBenefit("big", "large", "large", {
      sentence: "The box is big.",
      definition: "Of great size.",
      partOfSpeech: "adjective",
    }).sufficient,
    false,
  );
});
