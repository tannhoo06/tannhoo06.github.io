# Ownword MVP V2 — Implementation Specification

_Last consolidated: 2026-10-27_

## 0. Purpose

This document is the build-agent specification for Ownword MVP V2.

It is intentionally different from the living UX report:
- The living report preserves discussion history and approved reasoning.
- This implementation specification contains only the current canonical decisions the build agent should follow.
- If this implementation specification conflicts with an older discussion note, follow this specification.

The implementation goal is to **refine the existing MVP**, not rebuild Ownword from scratch.

---

# 1. Product goal

Ownword helps advanced English learners turn vocabulary they already recognize into vocabulary they can retrieve and use naturally.

Core loop:

**Write → Discover → Choose → Practice → Retrieve → Activate**

Ownword is not:
- a generic AI writing assistant;
- a thesaurus that automatically makes language more advanced;
- a Duolingo-style gamification product;
- a vocabulary bookmark list;
- a system that treats repeated simple words as inherently bad.

Ownword should prefer:
- precision;
- naturalness;
- contextual fit;
- learner choice;
- productive vocabulary activation.

The system may remain sophisticated internally, but learners should not feel the learning-engine machinery.

---

# 2. Global implementation constraints

## 2.1 Preserve

Unless a change below explicitly requires otherwise, preserve:
- existing authentication;
- existing stored user data;
- existing WordBoard/user-word records;
- existing practice history and scheduling data;
- existing stage/progression logic;
- existing mock/demo data flow while real LLM integration is not yet implemented;
- existing responsive behavior;
- existing routing structure where practical;
- the current calm visual identity.

Do not reset or invalidate existing user state as part of this UX refactor.

## 2.2 Do not implement yet

The following are out of scope for this V2 implementation pass:
- real Gemini semantic-suggestion quality work;
- AWS architecture migration;
- a full landing-page redesign;
- new gamification systems;
- new scoring systems visible to learners;
- changes to learning thresholds unless a UX requirement below makes a small compatibility change necessary.

## 2.3 Visual system

Preserve:
- cream / off-white background;
- restrained green accents;
- editorial typography;
- generous whitespace;
- simple bordered cards;
- limited use of badges;
- the botanical hill / plant motif on WordBoard where already approved.

Avoid:
- glassmorphism;
- heavy gradients;
- AI-glow visuals;
- dense dashboards;
- unnecessary metric panels;
- control-panel-style screens.

---

# 2.4 Visual reference images — mandatory implementation guidance

The user will provide the approved UI sketches alongside this specification.

Treat those sketches as **implementation references**, not loose inspiration.

When a written requirement and a reference image describe the same screen:
- use this specification for product behavior, state transitions, terminology, data behavior, and acceptance criteria;
- use the reference image for layout, spacing, hierarchy, component placement, visual density, proportions, and overall presentation.

The build should match the approved sketches **as closely as practical within the existing application**, while preserving the current working architecture and responsive behavior.

Do not replace the approved visual direction with generic SaaS, dashboard, AI-gradient, or default component-library layouts.

Because the uploaded image filenames may be meaningless or corrupted, identify each reference by its **visible content** as described below.

## Reference A — Practice flow states

Identify the image that contains six numbered panels with headings similar to:
1. **Practice start (new)**
2. **Recall word (empty)**
3. **Correct recall → sentence step**
4. **Wrong answer (simpler)**
5. **Hint or reveal**
6. **After reveal → sentence step**

This is the primary visual reference for:
- Practice session entry;
- recall state;
- correct-recall transition;
- sentence-use state;
- wrong-answer state;
- hint / reveal state;
- action hierarchy inside practice.

Use together with Sections 7–12 of this specification.

## Reference B — Write / Suggestion Review V2

Identify the image headed:

**Ownword — Suggestion Review V2**

It contains:
- **Before typing / first-use state** on the left;
- **With recommendations** on the right.

This is the primary visual reference for:
- Write screen;
- two-panel suggestion review;
- highlighted original writing;
- suggestion-card hierarchy;
- **Add to practice** and **Skip** actions;
- suggestion progress/navigation.

Use together with Sections 5–6.

## Reference C — Settings V2

Identify the image containing numbered sections such as:
1. `... menu (updated)`
2. **Settings page (main)**
3. **Practice length dropdown (using dropdown)**
4. **Autosave feedback**
5. **How practice works (expanded)**

This is the primary visual reference for:
- overflow menu;
- Settings information architecture;
- practice-length dropdown;
- autosave feedback;
- How practice works content.

Use together with Sections 17–18.

Important:
- The practice-length control must be a **dropdown**.
- Do not substitute radio cards / clickable boxes.

## Reference D — Your patterns / Insights V2

Identify the two-panel image with headings:
1. **Compact insight cards**
2. **Expanded examples**

Both panels use the title:

**Your patterns**

This is the primary visual reference for:
- compact pattern cards;
- phrase/frequency vs alternative layout;
- Add to WordBoard action;
- See examples from my writing action;
- selected-card expansion;
- contextual fit guidance.

Use together with Section 16.

## Reference E — WordBoard V2 triptych

Identify the three-panel image with headings:
1. **Empty WordBoard**
2. **Populated WordBoard**
3. **Word detail drawer**

This image is the primary reference for:
- **Empty WordBoard**
- **Word detail drawer**
- general WordBoard visual language;
- botanical landscape / plant motif.

However, its populated middle panel is **not the final authority** for the populated WordBoard layout. See Reference F.

## Reference F — Refined populated WordBoard

Identify the standalone portrait-oriented WordBoard image showing:
- **WordBoard** heading;
- stage switcher:
  - New
  - Practicing
  - Active
  - All
- search;
- **Newest first** sort dropdown;
- compact 2-column word-card grid;
- botanical landscape at the bottom.

This is the **final visual source of truth for the populated WordBoard screen**.

If Reference E and Reference F differ for the populated WordBoard:
- follow **Reference F**.

Use together with Section 14.

## Reference G — Older three-column WordBoard concept — deprecated

Identify the older three-panel image where the populated WordBoard is split into permanent vertical columns:
- New;
- Practicing;
- Active.

This image may also contain a word-detail drawer.

This reference is **deprecated for the main WordBoard layout**.

Do not implement the permanent three-column Kanban layout.

It may be used only as historical context for:
- stage meaning;
- older visual ideas;
- drawer details that are consistent with the current specification.

If it conflicts with Reference E, Reference F, or Section 14:
- ignore the deprecated layout;
- follow the current specification and newer references.

## Reference H — Practice completion

Identify the standalone completion screen with the Vietnamese heading:

**Hoàn thành buổi luyện tập**

It contains:
- practice summary card;
- per-word outcome rows;
- primary **Về WordBoard** action;
- secondary **Tiếp tục viết** action.

This is the primary visual reference for the Practice Completion screen.

Use together with Section 13.

## Visual-reference precedence

If any visual references conflict, use this precedence:

1. This implementation specification for **behavior and product logic**.
2. The explicitly designated final reference for that screen.
3. Newer approved references over older/deprecated references.
4. Existing Ownword visual system for details not specified elsewhere.

For WordBoard specifically:
- Empty state → Reference E
- Populated state → Reference F
- Word detail drawer → Reference E
- Older permanent-column board → do not implement

## Final visual QA requirement

After implementing each redesigned surface:
1. Open the implemented screen beside its corresponding reference image.
2. Compare:
   - page width;
   - major section placement;
   - spacing;
   - typography hierarchy;
   - card dimensions;
   - controls;
   - CTA hierarchy;
   - visual density;
   - empty-state composition;
   - drawer/panel proportions.
3. Correct obvious deviations where they are not required by technical or responsive constraints.

A screen should not be considered complete merely because it contains the same information. It should also **visually resemble the approved reference as closely as practical**.


---

# 3. Canonical terminology

Use these names consistently.

## App
**Ownword**

## Feature
**WordBoard**

Do not call the app “WordBoard.”

## Word stages
- **New**
- **Practicing**
- **Active**

## Insights page
Canonical user-facing name:

**Your patterns**

Do not use “Analysis” as the main learner-facing page title.

## Suggestion action
Canonical action:

**Add to practice**

This action must add the suggested word to the learner’s WordBoard and make it eligible for the practice system.

## Insight action
Canonical action:

**Add to WordBoard**

This performs the same underlying user-word creation behavior as **Add to practice**.

The two labels differ because of context:
- Suggestion Review asks whether the learner wants to practice the word.
- Your patterns explicitly feeds a discovered alternative into WordBoard.

## Practice settings
Practice length values:
- **Short (~5 words)**
- **Standard (~7 words)**
- **Longer (~10 words)**

Default:
- **Standard (~7 words)**

---

# 4. Cross-screen state flow

The build must preserve this product lifecycle.

## 4.1 Discovery flow

1. User writes a short English passage.
2. User reviews vocabulary suggestions.
3. User chooses:
   - **Add to practice**
   - **Skip**
4. **Add to practice** creates/adds the word to WordBoard.
5. New WordBoard words enter the **New** stage.
6. Practice scheduling determines when the word is ready for review.

## 4.2 Practice flow

1. User opens Practice.
2. User sees a short session-intro state.
3. User starts the session.
4. For each word:
   - recall the word from meaning;
   - then use the word in a sentence;
   - hints/reveal reduce independent-recall evidence internally;
   - skip sentence if needed.
5. State saves silently.
6. User automatically moves to the next word.
7. Completion screen summarizes what happened.
8. Practice evidence continues feeding existing New → Practicing → Active progression.

## 4.3 Insights flow

1. Your patterns identifies recurring expressions.
2. Frequency is presented as a pattern, not a mistake.
3. A context-sensitive alternative may be suggested.
4. User may:
   - **Add to WordBoard**
   - inspect examples from their writing
5. If already on WordBoard:
   - replace the add action with **View on WordBoard**.

## 4.4 WordBoard flow

1. Word appears in WordBoard.
2. Stage remains visible.
3. Clicking the card opens the word-detail drawer.
4. Drawer explains:
   - meaning;
   - source writing;
   - usage;
   - what to work on next;
   - next review.
5. **Practice this word** launches practice for that word if supported by the current system.

---

# 5. Write screen

## Goal

Reach value quickly.

The user should feel:

**I write something → Ownword notices useful vocabulary opportunities.**

## Default state

Show:
- page heading;
- one short instruction;
- large writing field;
- a few optional starter-prompt chips if already supported;
- one primary CTA:
  - **Review suggestions**

Avoid:
- onboarding surveys;
- proficiency assessments;
- long setup flows;
- extra controls before writing.

## Acceptance criteria

- A new user can understand what to do without opening help.
- There is only one obvious primary CTA after entering enough text.
- No learning-engine state is exposed here.
- Existing draft persistence may remain.

---

# 6. Suggestion Review V2

## Goal

The screen should feel like:

**See suggestion → understand it → decide whether to practice it → move on.**

It must not feel like managing suggestion states.

## Layout

Preserve the two-panel layout.

### Left
**Your writing**
- original submitted writing remains visible;
- relevant phrase is highlighted;
- user keeps context for why the suggestion exists.

### Right
Current suggestion.

## Suggestion content

Default visible content:
- original phrase;
- suggested word;
- short meaning;
- one natural example sentence;
- optional disclosure:
  - **Why this word?**
  - or **More examples**

Do not show all nuance/collocation/detail by default.

## Actions

Exactly two core decisions:
- **Add to practice** — primary;
- **Skip** — secondary.

Remove from the main path:
- “I already know this”;
- “I already use this”;
- similar learner-classification actions.

Rationale:
Knowing a word but failing to retrieve it is the product problem Ownword is solving.

## Progress

Use a simple progress indicator.

Canonical pattern:

**Suggestion 1 of 4**

Previous/next navigation may remain if needed.

Do not use mixed state chips such as:
- Saved;
- Not selected;
- Recall;
- other backend statuses.

## Behavior

### Add to practice
- save word to WordBoard;
- mark the suggestion decision;
- allow the learner to continue to the next suggestion.

### Skip
- do not add the word;
- continue cleanly.

Avoid intermediate state-management screens.

## Acceptance criteria

- User can process a suggestion with at most one primary decision click.
- Only two core decision actions are visible by default.
- Original writing remains visible.
- Suggestion progress is understandable without knowing internal states.
- “I already know/use this word” does not appear in the main review flow.
- Add to practice creates or links to the appropriate WordBoard record.

---

# 7. Practice V2 — session entry

## Goal

Do not drop the learner immediately into a question.

## Session intro

Show a lightweight state:

**2 words ready to practice**

Supporting copy:

**You’ll recall each word, then use it in a sentence.**

May show:
- words in session;
- approximate session length.

Primary CTA:
- **Start practice**

Do not turn this into a setup wizard.

## Acceptance criteria

- Practice does not begin immediately on navigation.
- User understands the two-part practice structure before starting.
- Starting practice requires one obvious action.

---

# 8. Practice V2 — recall step

## Goal

One task only.

Canonical prompt pattern:

**Which word fits this meaning?**

Then display the meaning.

Example:

> Sensitive to small but meaningful differences.

Show:
- one answer field;
- **Hint**;
- **Check**.

Remove duplicated wording such as:
- “Recall the word”
- plus “Bring to mind a word meaning…”

## Acceptance criteria

- Only one instruction describes the recall task.
- Answer input is the visual focus.
- Hint is available but secondary.
- Internal scoring is not shown.

---

# 9. Practice V2 — correct recall → sentence use

## Goal

Recall and sentence use should feel like one continuous exercise.

After correct recall, transition the same exercise area to:

✓ **nuanced**

**Use it in a sentence**

Supporting copy:

**Write one complete sentence using nuanced.**

Show:
- sentence input;
- **Check sentence**;
- optional hint;
- **Skip this step**.

Remove stale recall controls from this state.

## Skip behavior

When **Skip this step** is clicked:
- save silently;
- move immediately to the next word.

Do not show:
- saving screen;
- skip confirmation;
- separate “Next word” requirement.

## Acceptance criteria

- Correct recall transitions directly into sentence use.
- User does not need to interpret the previous recall UI.
- Skip is always available.
- Skip advances immediately.

---

# 10. Practice V2 — wrong recall

## Goal

Failure should feel normal and recoverable.

Show concise feedback:

**Not quite.**

**Try again, get a hint, or reveal the word.**

Actions:
- **Try again**
- **Hint**
- **Reveal word**

Avoid:
- large red error panels;
- verbose failure explanations;
- visually punitive states.

## Acceptance criteria

- Wrong-answer state remains approximately as visually lightweight as normal recall.
- All three recovery paths are obvious.
- No progress penalty language is shown.

---

# 11. Practice V2 — hint and reveal

Progressive hint logic may remain internally.

Possible progression:
1. semantic clue;
2. first letter;
3. partial spelling;
4. reveal.

Do not expose hint scoring.

After reveal:

**Answer: nuanced**

Then proceed directly to:

**Use it in a sentence**

Do not add another confirmation screen.

## Acceptance criteria

- Reveal leads directly into sentence use.
- Hint/reveal usage can still be recorded internally.
- No raw score adjustment is shown to the learner.

---

# 12. Practice V2 — moving between words

After either:
- successful sentence completion;
- or sentence skip;

the system must:
1. save state silently;
2. move directly to the next word.

Do not expose:
- “Saving…” as a normal interaction state;
- a confirmation card;
- a separate Next Word button unless required because there is no automatic transition support.

Preferred behavior is automatic transition.

---

# 13. Practice completion screen

## Goal

Answer:

**What changed because I practiced?**

## Structure

Headline:

**Practice complete**

Short summary:

**You practiced 2 words today.**

Compact recap rows, for example:

- **nuanced** — Recalled and used in a sentence.
- **compelling** — Reviewed; needs more practice.

Supporting note:

**These words will return later if they still need reinforcement.**

## Actions

Primary:
- **Go to WordBoard**

Secondary:
- **Continue writing**

## Tone

Avoid:
- confetti;
- XP;
- exaggerated celebration;
- fake achievement language.

## Acceptance criteria

- Completion is not an empty page.
- Each practiced word has a plain-language outcome.
- WordBoard is the primary next step.
- Continue writing is available as secondary action.

---

# 14. WordBoard V2

## Goal

WordBoard should feel like a personal vocabulary workspace, not a saved-word database.

Visible progression remains:

**New → Practicing → Active**

Do not implement permanent full-height Kanban columns.

## 14.1 Populated layout

Page heading:
- **WordBoard**

Description:
- one sentence explaining that selected words appear here and progress from New → Practicing → Active.

Then:

### Stage switcher
- **New**
- **Practicing**
- **Active**
- **All**

Each shows a count.

Use subtle stage dots/colors.

The stage switcher should feel like progression, not database filtering.

### Controls
- search;
- simple sort, e.g. newest first.

### Word list
Use a compact **2-column card grid**.

## 14.2 Word cards

Show:
- word;
- part of speech;
- short definition;
- next-review timing where relevant;
- stage badge;
- small overflow menu only if needed.

Do not show raw progress metrics.

Clicking the card opens the word-detail drawer.

## 14.3 Empty WordBoard

Remove:
- New / Practicing / Active summary boxes;
- search;
- sort;
- filters;
- 0 / 0 counters;
- sample-collection controls;
- duplicate CTAs.

Canonical empty state:

- keep the document/file icon;
- headline:
  - **No words yet**
- short explanation:
  - words chosen while writing appear here and progress through New → Practicing → Active;
- one CTA:
  - **Write something**

Keep the botanical landscape at the bottom.

## Acceptance criteria

### Populated
- stage switcher is visible;
- grid scales without three-column vertical overflow;
- cards remain compact;
- search/sort appear only when useful.

### Empty
- no stage boxes;
- no search/sort;
- one central empty-state block;
- file icon remains;
- one Write something CTA.

---

# 15. Word detail drawer

Keep the side drawer.

Do not navigate to a separate page for basic word inspection.

## Show prominently

- stage;
- word;
- part of speech;
- short definition;
- **From your writing** source sentence;
- common collocations;
- one natural example sentence;
- **What to work on next**;
- next review;
- **Practice this word**;
- **Remove from WordBoard**.

## What to work on next

Do not foreground:
- retrieval score;
- precision score;
- flexibility score;
- retention score;
- raw context count;
- other diagnostic metrics.

Translate evidence into learner guidance.

Examples:
- **Use this word in more contexts.**
- **Try writing it in a different situation or topic.**
- **You recall this reliably; now focus on using it naturally.**

Detailed attempt history may remain behind an optional disclosure.

## Acceptance criteria

The drawer should answer:
1. What does this word mean?
2. Where did I get it from?
3. How is it naturally used?
4. What should I work on next?
5. When will I review it again?

---

# 16. Your patterns — Insights V2

## Goal

A concise reflection on writing habits.

It must not feel like:
- an audit;
- an error report;
- a mandatory vocabulary-replacement system.

## Page title

**Your patterns**

Description:

**Notice phrases you use often and explore more precise options when they fit.**

## Global message

Show once near the top:

**Repeating a word is not automatically bad.**

Explain briefly that common wording is normal and that the page only surfaces patterns plus more precise options where appropriate.

Do not repeat this disclaimer inside every card.

## Insight cards

Default card:

### Left
- **You often use**
- phrase, e.g. **“very big”**
- **used 6 times**

### Right
- **A more specific option**
- e.g. **substantial**
- short usage explanation
- **Add to WordBoard**
- **See examples from my writing**

## Contextual fit

Do not frame alternatives as universal replacements.

Use word-specific fit guidance.

Examples:
- substantial → amount, scale, importance;
- compelling → strongly holds attention or persuades;
- negligible → so small that it has little practical effect.

## Expanded examples

When user clicks **See examples from my writing**:
- expand only that card;
- show a few source excerpts;
- highlight the recurring phrase;
- show a subset first, e.g. 3 of 6;
- keep alternative and WordBoard action visible;
- optionally show one short “when this fits” note.

Other cards remain compact.

## Existing WordBoard word

If alternative is already on WordBoard:
- replace **Add to WordBoard** with **View on WordBoard**.

Never add automatically.

## Acceptance criteria

- repetition warning appears once, not per card;
- default view is compact and scannable;
- evidence is progressively disclosed;
- alternatives are contextual, not “better-word” replacements;
- every actionable alternative can flow into WordBoard.

---

# 17. Overflow menu

Keep the existing `...` menu.

Canonical items:
- **Your patterns**
- **Settings**

No major redesign required.

---

# 18. Settings V2

## Goal

Supporting infrastructure should be simple, predictable, and low-friction.

## Layout

Single clean main column.

Group into four sections:

### Profile
- display name

### Practice
- practice/session length

### About & Support
- **How practice works**
- optional **Feedback / Report a problem**

### Account
- **Log out**

Demo Mode:
- visually isolate during testing;
- remove/hide from production UX.

## Practice length

Use a **dropdown**.

Do not use:
- clickable option cards;
- radio-card boxes;
- adjacent numeric choices like 5 / 6 / 7 / 8.

Dropdown options:
- **Short (~5 words)**
- **Standard (~7 words)**
- **Longer (~10 words)**

Default:
- **Standard (~7 words)**

## Save behavior

Use autosave.

Do not require a persistent Save Changes button for simple preferences.

Lightweight confirmation:

**Changes saved**

**Your settings have been updated.**

Display name may save on blur / Enter if reliable.

## How practice works

Keep concise:

1. **Write in context**
2. **Get feedback**
3. **Progress over time**

Explain New → Practicing → Active without exposing thresholds or formulas.

## Acceptance criteria

- practice length uses dropdown;
- page has four clearly separated groups;
- simple changes autosave;
- Demo Mode does not compete with normal settings;
- logout is isolated under Account.

---

# 19. Responsive behavior

All redesigned surfaces must remain usable on smaller screens.

Minimum expectations:
- two-column desktop grids collapse cleanly to one column;
- side drawer becomes an appropriate full-width sheet/panel on narrow screens;
- stage switcher remains horizontally usable without destroying layout;
- suggestion review stacks logically on mobile while preserving writing context and suggestion decision;
- buttons remain thumb/touch friendly;
- no horizontal page overflow.

Do not create a second mobile-only product flow unless necessary.

---

# 20. Implementation order

Use this order to reduce regressions:

1. Global terminology and shared UI primitives
2. Write / Suggestion Review — compare against Reference B
3. Practice entry + recall + sentence-use flow — compare against Reference A
4. Practice completion — compare against Reference H
5. WordBoard empty + populated states — compare against References E and F
6. Word-detail drawer — compare against Reference E
7. Your patterns — compare against Reference D
8. Overflow menu + Settings — compare against Reference C
9. Responsive pass
10. Visual-reference comparison pass
11. Regression pass

Do not start with a full visual rewrite of the app shell.

At the end of each screen group, compare the implementation against its mapped reference before moving on.

---

# 21. Data / state behavior that must remain coherent

## Suggestion → WordBoard
**Add to practice** must produce the same effective UserWord state as adding an eligible suggestion to WordBoard.

## Insights → WordBoard
**Add to WordBoard** must not create duplicates.

If the word already exists:
- show **View on WordBoard**.

## Practice → progression
Practice results must continue feeding the existing learning/progression engine.

Do not manually force stages from UI interactions.

## Skip
Skipping a sentence step should not erase prior recall evidence.

## Hint / reveal
Hint/reveal state should remain available to the existing learning logic even though the scoring consequence is hidden from the learner.

## Delete
Removing a word from WordBoard should use the existing destructive behavior and should not silently remove unrelated writing history.

---

# 22. Regression checklist

Before considering V2 complete, verify:

### Authentication / persistence
- sign in still works;
- refresh does not lose saved words;
- existing users retain WordBoard data;
- practice history remains available.

### Writing
- draft can still be entered;
- suggestions still render in mock mode;
- previous review state does not corrupt new reviews.

### Suggestion Review
- Add to practice works;
- Skip works;
- progress advances correctly;
- no removed legacy decision buttons remain.

### Practice
- session intro appears;
- recall works;
- correct recall moves into sentence use;
- wrong recall offers Try again / Hint / Reveal;
- reveal transitions into sentence use;
- skip sentence advances immediately;
- no unnecessary saving confirmation is exposed;
- completion summary is correct.

### WordBoard
- stage counts are accurate;
- tabs filter correctly;
- All shows all words;
- search works;
- sort works;
- empty state is clean;
- card opens detail drawer;
- no duplicate UserWords are created.

### Word detail
- source writing displays;
- collocations/example display;
- next review displays;
- practice action works;
- remove action works.

### Your patterns
- compact cards render;
- examples expand only for selected card;
- Add to WordBoard works;
- View on WordBoard replaces add when appropriate.

### Settings
- practice length dropdown works;
- autosave works;
- saved feedback appears;
- display name saves correctly;
- logout works;
- Demo Mode is isolated or hidden appropriately.

### Responsive
- no horizontal overflow;
- mobile layouts remain usable;
- drawer/sheet behavior is correct.

---

# 23. Deferred after V2 UX implementation

Do not block this V2 build on these.

## Real LLM integration
After flows are stable:
- integrate Gemini or chosen provider;
- evaluate semantic preservation;
- reject “fancier synonym” behavior;
- ensure suggestions preserve intended meaning;
- allow uncertainty where replacement depends on context.

## Landing page
Only revisit after signed-in product cleanup is complete.

## AWS capstone architecture
Treat separately from this UX implementation spec.

---

# 24. Definition of done

MVP V2 is complete when:

1. The signed-in product follows the simplified Write → Choose → Practice → WordBoard loop.
2. Suggestion review no longer feels like a control panel.
3. Practice feels continuous rather than a chain of status screens.
4. WordBoard scales beyond a handful of words.
5. Word-detail guidance is learner-facing, not diagnostic.
6. Your patterns is compact, contextual, and optional.
7. Settings exposes only meaningful preferences.
8. Existing user state and learning logic continue to work.
9. Mock mode still supports testing before real LLM integration.
10. The regression checklist passes.
11. Each redesigned screen has been visually compared against its mapped approved sketch.
12. No deprecated sketch has overridden a newer approved design.
13. The final populated WordBoard follows Reference F rather than the old permanent-column concept.

The build agent should prefer **simplification over feature addition** throughout this implementation.
