# Ownword UI handoff — 2 November 2026

## Which checkout is the live preview

The local preview at `http://127.0.0.1:5173` is served from this `ownword-site` checkout (`C:\Users\gdkie\Documents\ChatGPT\English learning\ownword-site`). The conversation initially opened in `C:\Users\gdkie\Documents\English_learner`, which contains separate `ownword` and `ownword-latest` copies. The user's flashcard screenshot matches **this** checkout, where the stacked deck already exists. Apply follow-up flashcard work here unless the user identifies a different checkout. The preview was already running when checked and returned HTTP 200.

## Earlier reference review and existing implementation

- The user pointed to [Cult UI Direction Aware Tabs](https://www.cult-ui.com/docs/components/direction-aware-tabs) for the landing hero's stage switcher and [Kokonut UI Throw Deck](https://kokonutui.com/docs/cards/card-stack) for the flashcard. Both live examples were inspected. The Cult UI example slides content according to tab direction and resizes its panel. No Cult UI Direction Aware Tabs integration was made in this work.
- Before the control-layout change below, this checkout already had the new flashcard visual: `components/kokonutui/study-card-stack.tsx` renders two resting cards under an animated top card; `components/FlipCard.tsx` supplies the two-sided card; `components/quick-review.tsx` supplies the vocabulary content and session controls. The deck is an Ownword adaptation of the reference, with the existing review session deciding navigation and ratings. It does not implement the reference's drag-to-throw interaction.
- Quick Review still uses the existing practice API and state. Left/right arrows browse cards; flipping reveals the word; Forgot/Got it/Skip record ratings. Keyboard shortcuts and reduced-motion behavior remain in place.

## Changes made for the user's annotated screenshot

The user wanted the circled controls moved close to the deck and properly centered, like the reference's arrow–count–arrow row. The final order under either card face is:

1. Previous arrow — `01 / 05` counter — next arrow, centered directly below the deck.
2. Two rating/reveal actions, constrained to the deck's width and centered.
3. “Pause review” / “Về Luyện tập” below the actions.
4. Optional Vietnamese translation disclosure after those controls on the revealed face, so it cannot push the controls away from the card.

Files changed:

| File | Change |
| --- | --- |
| `components/quick-review.tsx` | Moved the navigation before the action row, put the visible count between the arrows, moved Pause review below the actions, and moved optional translation below the controls. Rating and navigation handlers were not changed. |
| `components/kokonutui/study-card-stack.tsx` | Removed the count from the deck component and its unused `index`/`total` props. The deck now only renders the layered cards and transition. |
| `app/mvp-v2.css` | Centers the navigation and action row at a maximum width of 380px, uses equal 44px arrow targets and a flexible center count, and tightens spacing below the deck. |
| `tests/quick-review.browser.mjs` | Replaced the old “ratings before navigation” assertion with order and horizontal-center checks for deck, arrows/count, and rating actions. |

## Verification and limits

- `npm run typecheck` passed after the final changes.
- `node --check tests/quick-review.browser.mjs` passed.
- The running preview was inspected visually at desktop and 390px phone width, on both front and revealed card faces. The deck, navigation row, and buttons are centered; the controls remain directly under the card when translation is available.
- `node tests/quick-review.browser.mjs` could not run in this checkout because the `playwright` module is absent. Its layout assertions were updated but have not executed. It uses isolated API fixtures when Playwright is available.

No database, learning rules, rating behavior, or hosted deployment was changed. Refresh `http://127.0.0.1:5173/practice` and open Quick Review to inspect the result.

## Writing UI changes — Lucian #224, #281, and #235

The later writing request was implemented in the same live preview checkout. The source is the exact MIT-licensed Lucian UX/UI Prompt snippets for [#224](https://lucianlabs.dev/en/uxui-prompt/#224), [#281](https://lucianlabs.dev/en/uxui-prompt/#281), and [#235](https://lucianlabs.dev/en/uxui-prompt/#235), adapted to the Ownword theme and React. The Lucian interaction structure, easing, and timing were retained; the components include source/license comments. These are locally stored code, not a runtime dependency.

| File | Current responsibility |
| --- | --- |
| `components/lucian-224-suggestion.tsx` | Phrase → suggested word panel, numbered citation badge with hover/focus preview, and a direct Oxford Learner’s Dictionaries lookup link for the suggested word. The Oxford card is a dictionary reference, not a claim that Oxford verified Ownword's recommendation. |
| `components/lucian-281-highlighted-writing.tsx` | Validates suggestion anchors and renders the user's original passage with Lucian's timed sweeping marker effect on matched phrases. Buttons still select suggestions. |
| `components/lucian-235-writing-scan.tsx` | Replaces the old plain writing textarea/action layout with Lucian's sparkle action, text scan, glowing line, highlighted sentences, and fold. The action reads “Xem gợi ý” in Vietnamese. |
| `components/writing.tsx` | Wires the three components into the existing analysis flow. Starts the #235 scan while `analyze` runs, folds the editor, then renders the existing two-column suggestion board with #235's unfold timing. Keeps draft/session persistence, prompt chips, suggestion decisions, and review navigation. |
| `app/lucian-suggestions.css` | Maps Lucian tokens to Ownword colors and ports #224/#281/#235 styles, motion values, responsive sizing, and reduced-motion rules. |
| `app/layout.tsx` | Loads the Lucian stylesheet after the existing site styles. |
| `app/mvp-v2.css` | Removes the superseded custom inline/highlight effects and scopes the writing panel header rule to its direct header so nested Lucian source-card headers are unaffected. |

The #235 original ends in a three-line summary card. Here it ends in Ownword's existing suggestion board, as requested. The prior standalone bottom “Review suggestions” button is replaced by the sparkle “Xem gợi ý” action inside the editor card. The #281 sweep marks only returned, valid suggestion anchors. The #224 panel shows the selected phrase, proposed word, explanation, and Oxford lookup.

### Writing verification and limits

- `npx tsc --noEmit --incremental false` passed. Plain `npm run typecheck` attempted to write `tsconfig.tsbuildinfo` outside this task's writable roots and got EPERM; this is a sandbox write limit, not a TypeScript failure.
- Targeted ESLint passed for `writing.tsx` and all three Lucian components.
- The running local mock preview was exercised at desktop and 375px width. A sample passage beginning “Our highest priority…” returned `highest priority → paramount`; the scan, fold, board reveal, phrase highlight, citation keyboard preview, and direct `/definition/english/paramount` link were inspected. At 375px the editor/button and suggestion board fit without horizontal overflow. No live OpenRouter request was needed or tested.
- Reduced motion is handled in the components and stylesheet (no scan delay/animated sweep or unfold when the user prefers reduced motion). It has been reviewed in code but not emulated in the browser.

Refresh `http://127.0.0.1:5173/write` to inspect the writing flow. To reproduce the populated local mock case, enter: `Our highest priority is to help new learners. We had to explain clearly why the plan mattered. The team was able to recover quickly after the setback.`

## Writing editor follow-up — border, samples, and Animate UI

The user annotated the editor screen and asked for a clearer card border, a matching sample block hidden under a centered “Dùng bài mẫu?” control, removal of the old saved-review strip, quieter draft text, and hover/press motion on important controls.

- `components/writing.tsx`: Removed the “Các gợi ý trước đó đã được lưu.” / “Tiếp tục xem gợi ý” row. Wrapped the existing sample prompt block in a native `<details>` disclosure, collapsed by default, and changed its four choice buttons to Animate UI's Button primitive for spring press feedback. The sample text and analyze behavior are unchanged.
- `components/lucian-235-writing-scan.tsx`: Uses Animate UI's Button press primitive for “Xem gợi ý” and the prebuilt Shine effect on hover; the sparkle icon stays. The duplicate visible helper sentence below the card is now screen-reader-only, while the draft status remains visible.
- `app/lucian-suggestions.css`: Changed the editor edge from a faint shadow outline to a solid, uniform border. The sample panel now shares the editor's paper background, border, radius, and shadow. A centered disclosure toggle uses Animate UI's 350ms disclosure curve, and the button/toggle/choice hover states use short color and shadow transitions. Motion reduces for users who request reduced motion.
- `lib/i18n/mvp-v2.ts`: Added the “Use a sample?” → “Dùng bài mẫu?” label.

Verification: TypeScript and targeted ESLint passed before and after this follow-up. In the local preview, the editor and samples were checked at desktop and 375px; borders match and there is no horizontal overflow. The disclosure opens and closes with mouse and keyboard Enter. The Animate UI Shine layer and press primitive are mounted on the main action. A live OpenRouter request and reduced-motion emulation were not run.

## Compact samples and shared Lucian confirmations

The next request asked to shrink the spacious sample buttons/card, remove the “Bài viết dùng thử” dropdown, and replace browser warnings with a Lucian confirmation box. The exact source snippets for [#009 Rolling label button](https://lucianlabs.dev/en/uxui-prompt/#009) and [#269 Type-the-name delete confirmation](https://lucianlabs.dev/en/uxui-prompt/#269) were fetched with the Lucian CLI, then adapted to Ownword.

- `components/lucian-009-sample-button.tsx` keeps #009's rolling letters, rising selected fill, arrow orb motion, and press scale. It receives each sample's label/icon and derives selected state from whether the editor exactly matches that sample. Its footprint is reduced to a 52px pill so four choices fit inside a narrower card.
- `app/lucian-suggestions.css` limits the expanded sample card to 680px and centers it below the main editor. The #009 pills use two columns on desktop and one column on a 375px phone. The same file styles #269's dim layer, warning card, title icon, input verification, action buttons, and entrance/exit motion with Ownword colors.
- `components/writing.tsx` uses the #009 choices, removes the local “Bài viết dùng thử” dropdown, and sends both draft-replacement decisions to the shared confirmation dialog.
- `components/lucian-269-confirmation.tsx` is an app-level promise-based confirmation provider using the Lucian dialog shape and motion with Radix AlertDialog focus handling. For WordBoard removal it keeps the Lucian type-the-word safeguard, matching-letter feedback, and wrong-letter shake. The cancel and action buttons use Animate UI press feedback.
- `app/layout.tsx` mounts the confirmation provider under the language and motion providers. `components/wordboard.tsx` routes word removal through it. `components/preferences.tsx` routes the existing sample-collection removal warning through it. `lib/i18n/mvp-v2.ts` adds the small set of Vietnamese dialog labels.

Every explicit native `window.confirm`/`alert`/`prompt` call in the app was removed; a code search found none remaining. The `beforeunload` guard in `components/preferences.tsx` remains because browsers do not allow a custom asynchronous dialog when a tab is closed or hard-refreshed, and removing it could lose unsaved settings. In-app confirmations now share #269.

Verification: `npx tsc --noEmit --incremental false` and targeted ESLint passed. Desktop and 375px layouts were visually checked with no horizontal overflow. In the local preview, the draft dialog canceled without changing text; confirming a sample replaced the draft and selected its pill. WordBoard removal kept its action disabled until the word was typed and cancel left the word in place. Sample-collection removal opened the same dialog and cancel closed it without clearing data. Live OpenRouter and OS-level reduced-motion emulation remain untested. During repeated local mock analyses the demo account reached its daily writing-discovery limit, so no further analysis call was used for this last UI pass.

## Latest writing sample control revision

The user then requested a design swap: use the Lucian #009 rolling pill for the centered “Dùng bài mẫu?” disclosure and return the four topic choices to compact, simpler text controls. This section supersedes the earlier description of #009 on each topic choice.

- `components/lucian-009-sample-button.tsx`: `RollingSampleToggle` now renders the disclosure's native `<summary>` with #009's rolling label, fill, arrow orb, and press motion. The orb points down while closed and rotates up while open.
- `components/writing.tsx`: Places `RollingSampleToggle` as the `<details>` summary. The four sample choices use Animate UI's Button for press feedback, and restore their original plane, paw, book, and target icons before the labels. Choosing a sample and its draft-replacement confirmation retain the existing behavior.
- `app/lucian-suggestions.css`: Narrows the expanded sample card to 600px, aligns the two topic columns at common left edges, and gives each topic a content-width pill. The layout stacks at phone width. It also styles the disclosure's selected/open #009 state and respects reduced motion.

Verification: `npx tsc --noEmit --incremental false` and targeted ESLint passed after the revision. The local `/write` preview was inspected at 1265px and 375px. At desktop width, first and third topic choices share the same left edge, as do second and fourth; at phone width the choices stack and the page has no horizontal overflow. The disclosure was opened and closed in the browser; its arrow points up when open and down when closed. No new analysis request was sent because the local mock account had already reached its daily limit.

The disclosure arrow was refined once more at the user's request: it now stays at a 45-degree angle, pointing down-right when closed and up-right when open. The rolling label and orb animation are unchanged.

The arrow transition now rotates the SVG arrow 90 degrees between those directions; the circular orb remains stationary, rather than flipping vertically.

## Lucian #267 language switch and text change

The old language setting inside the workspace profile menu was replaced with a globe button immediately to the profile button's left. The landing header's segmented Vietnamese/English control was also replaced with the same switch, including in its mobile menu.

- `components/lucian-267-language-switch.tsx` ports Lucian #267's globe dropdown and staggered text transition. It uses the existing `useI18n` locale state, so the choice persists. The menu supports outside click, arrow keys, Home/End, Escape, Tab, and focus restoration. The text change uses 260 ms exit and 380 ms entry phases with 45 ms stagger, and respects reduced motion.
- `components/studio.tsx` mounts the switch before the profile control, removes the profile menu's old language setting, and applies the text change to workspace navigation labels.
- `components/landing.tsx` applies the switch and text change to landing navigation, hero copy, and calls to action.
- `app/lucian-suggestions.css` adapts #267's colors, dropdown, and text motion to Ownword; the mobile menu places the dropdown inside the viewport.

Browser checks covered the desktop workspace menu and locale persistence, keyboard selection/Escape focus restoration, the landing hero's English text transition, and the 375 px landing menu without horizontal overflow. OS-level reduced-motion emulation was not run.

## Lucian #399 Insights word cloud

Insights now uses the Lucian #399 word cloud in place of the previous insights view. The cloud represents the learner's saved WordBoard words and excludes demo words. Hovering or focusing a word shows its recorded use count and highlights other words in the same learning stage. The All, 30-day, and 7-day controls reshuffle the cloud to the selected period. Words with no uses in the selected period leave that period's cloud.

- `components/lucian-399-word-cloud.tsx` ports #399's spiral word placement, period switching, word motion, stage grouping, and keyboard focus behavior. Placement recalculates when its card resizes and reserves space above the footer.
- `app/lucian-399-word-cloud.css` adapts the card and cloud colors to Ownword. The phone card has a 400 px layout so words and the footer remain separate.
- `lib/domain/word-cloud.ts` aggregates whole-word English matches from saved writing samples and contextual practice answers for All/30-day/7-day periods. Recall-only answers do not count. `lib/services/vocabulary.ts` supplies these aggregate counts in `AppState.cloudWords`, avoiding a transfer of full writing text to the browser. `lib/domain/types.ts` defines the aggregate type.
- `components/studio.tsx` routes Insights to the new cloud. `app/cloud-preview/page.tsx` is a local dummy-data preview for visual testing; the real `/insights` route uses account data and correctly shows an empty state when the local account has no non-demo saved words.
- `tests/insights.test.ts` covers period counts from both writing and practice, including older writing and the demo-word exclusion.

Verification: `npx tsc --noEmit --incremental false` and targeted ESLint passed. The focused Insights test suite passed (3 tests). `/cloud-preview` was checked at desktop and 375 px: period controls, hover/focus counts, stage highlighting, reshuffle, and footer clearance worked without horizontal overflow. `/insights` was checked with the local demo account and displayed the expected empty state. A populated real account and OS-level reduced-motion setting were not available for browser testing.

## Discover word-entry rework

The user approved the proposed compact word-entry layout. The direct add action is now the focal card on `/discover`, with the two existing discovery routes as smaller equal cards beneath it.

- `components/lucian-025-word-field.tsx` and `app/lucian-025-word-field.css` port the notched floating label field from Lucian #025. The input is explicitly marked English, accepts one word or short phrase, uses a visible label, and shows an inline validation hint. Browser spellcheck is enabled; automatic replacement is disabled so a device cannot silently change a learner's intended word.
- `components/kokonutui/particle-button.tsx` is Kokonut UI's BT-01 Particle Button from its published component registry. It provides loading, success, error, press and reduced-motion feedback for the existing add request. `components/discover.tsx` preserves Enter-to-submit, duplicate handling, the existing Kokonut undo action, concept discovery, writing navigation and quota display.
- `app/discover.css` shortens the page's vertical gaps, focuses the 760 px entry card, and makes the two discovery choices compact and responsive.
- Direct manual input is capped at 45 characters consistently in the field, `app/api/[...path]/route.ts`, and `lib/services/vocabulary.ts`. This uses the conventional 45-letter longest dictionary word as the benchmark; the limit also applies to short phrases in this direct-entry field. `tests/d1-ux.integration.ts` covers the 45-letter boundary and a 46-character rejection.

No LLM spelling gate was added. A model can incorrectly reject rare terms and phrases, and a required request would add latency and cost to every manual save. Browser spellcheck offers optional suggestions where the browser supports them; the server still checks format and length, not dictionary membership. The user remains in control of the exact saved text.

Verification: TypeScript and targeted ESLint passed. The D1 integration test passed, including the new 45/46-character assertions. In the running preview, the page was inspected at desktop and 375 px without horizontal overflow; invalid input displayed the localized inline error, Enter submitted a disposable test word, and the test word was removed from WordBoard afterward. Browser-specific spelling suggestions and OS-level reduced motion were not emulated.

## Idea discovery, manual word check, and card follow-up (2026-11-02)

This section supersedes the previous statement that direct word entry has no model check. The user showed that `hihi` had been accepted, then approved a dedicated idea discovery experience and asked for the Undo placement, card details, and prompt fixes.

- `/discover` keeps the Lucian #025 direct-entry field and Kokonut Particle Button. `components/discover.tsx` now handles a model-backed spelling/wordhood check before a new manual word is saved. An obvious typo gets an inline correction choice; obvious gibberish such as `hihi` is blocked with an inline explanation; uncertain rare or technical words can be saved as written with an explicit choice. Existing duplicates are reported without another model call. The local mock has a narrow deterministic rule for `hihi`, repeated letters, and `neglibile`; the live Gemini/OpenRouter provider uses a structured model call. This check can be fallible, especially on rare terms.
- `app/discover.css` aligns the Undo button and subsequent status messages to the right of the entry card. `app/lucian-025-word-field.css` removes the second focus outline while preserving the field's own focus border.
- `components/studio.tsx`, `components/shared.tsx`, and `app/[view]/page.tsx` add `/idea`. The first discovery choice opens this full view. `components/lucian-233-idea-prompt.tsx` and its CSS port Lucian [#233 Prompt box](https://lucianlabs.dev/en/uxui-prompt/#233): three rotating typed examples, sample chips that type into the textarea, conic focus edge, send spinner, and the generating skeleton. The example animation continues even when a previous result is loaded. Its decorative caret hides on focus so only the real text cursor remains; the global textarea outline is suppressed inside this control.
- `components/idea-discovery.tsx` shows the latest persisted idea result, up to three candidate cards, and a new-idea action. A StageShow restraint review removed a duplicated completed-status panel, repeated language helper, and redundant eyebrow, then tightened vertical spacing so the actual suggestion card appears sooner. Busy state still uses Lucian #233's skeleton. The card includes definition, nuance, example, collocations, and a dictionary lookup.
- The dictionary lookup uses a compact adaptation of Lucian [#009 Rolling label button](https://lucianlabs.dev/en/uxui-prompt/#009) in `components/lucian-009-dictionary-link.tsx`, retaining staggered rolling letters and the two-arrow orb. The example word uses the sweep timing and mark treatment from Lucian [#281 Sweeping highlighter](https://lucianlabs.dev/en/uxui-prompt/#281). The quiet “Hiện nghĩa tiếng Việt” disclosure appears only under the Vietnamese interface and requests a concise meaning for that exact candidate only when opened. The local mock has demo meanings for its curated words; the live provider requests a context-aware Vietnamese gloss. Translation calls use the same global model-call budget and API rate limit.
- `app/api/[...path]/route.ts`, `lib/services/vocabulary.ts`, the domain ports/types, and `lib/adapters/d1-repository.ts` persist each result and save a candidate by its server-stored ID. Suggestions retain their metadata, even if the global catalog already contains that word, through `user_word.lexeme_override`. Results and translations are owner checked. Saving a candidate offers Kokonut's Undo Button. WordBoard labels the source as “Từ ý tưởng”.
- `db/schema.ts` and `drizzle/0005_kind_hobgoblin.sql` add the result table and per-user lexeme override. The local preview D1 database was backed up before this migration and migrated once. `README.md` includes the command for fresh local databases. Existing `hihi` entries were not removed; the check applies to new manual saves.

Verification: TypeScript, targeted ESLint, and the focused D1 integration test passed. The integration test covers the 45-character boundary, invalid `hihi` (including an attempted override), persisted results, candidate metadata, duplicate handling, owner isolation, and on-demand translation. The running local mock preview was checked: `hihi` shows inline review and does not save; an example idea returned `negligible` and survived reload; the Vietnamese meaning opened; the dictionary link and highlighted example rendered; the prompt rotated past its first letter; and its focused textarea had no extra outline. The result card was checked at 375px without horizontal overflow. A disposable `quizzical` word used for visual Undo checking was removed from WordBoard after the check. A live model response and system reduced-motion setting were not exercised.
