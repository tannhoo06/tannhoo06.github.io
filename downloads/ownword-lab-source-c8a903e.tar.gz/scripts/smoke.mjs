import assert from "node:assert/strict";
const base = process.env.TEST_BASE_URL || "http://127.0.0.1:5173";
if (!["127.0.0.1", "localhost"].includes(new URL(base).hostname))
  throw new Error("This test is for the loopback development server only.");
const check = (label, actual, expected) => {
  assert.equal(actual, expected, label);
  console.log(`PASS ${label}`);
};
check(
  "anonymous API access is rejected",
  (await fetch(`${base}/api/state`)).status,
  401,
);
check(
  "forged identity headers are stripped by the local auth adapter",
  (
    await fetch(`${base}/api/state`, {
      headers: {
        "oai-authenticated-user-id": "forged",
        "oai-authenticated-user-email": "forged@example.com",
      },
    })
  ).status,
  401,
);
const login = await fetch(`${base}/signin-with-chatgpt?return_to=/board`, {
  redirect: "manual",
});
const cookie = login.headers.get("set-cookie")?.split(";")[0];
assert.ok(cookie, "local sign-in provides a test cookie");
const headers = {
  Cookie: cookie,
  Origin: base,
  "Content-Type": "application/json",
};
const stateResponse = await fetch(`${base}/api/state`, { headers });
check("signed-in persistent state loads", stateResponse.status, 200);
const state = await stateResponse.json();
assert.ok(Array.isArray(state.words));
assert.equal(stateResponse.headers.get("cache-control"), "no-store");
check(
  "cross-origin writes are rejected",
  (
    await fetch(`${base}/api/settings`, {
      method: "POST",
      headers: { ...headers, Origin: "https://unrelated.invalid" },
      body: JSON.stringify({ name: "should never save" }),
    })
  ).status,
  403,
);
check(
  "invalid writing is rejected",
  (
    await fetch(`${base}/api/analyze`, {
      method: "POST",
      headers,
      body: JSON.stringify({ text: "x" }),
    })
  ).status,
  400,
);
check(
  "unknown or unowned suggestions cannot be added",
  (
    await fetch(`${base}/api/suggestions/decide`, {
      method: "POST",
      headers,
      body: JSON.stringify({ id: "unowned-fixture", decision: "added" }),
    })
  ).status,
  404,
);
check(
  "unknown or unowned exercises cannot be graded",
  (
    await fetch(`${base}/api/practice/answer`, {
      method: "POST",
      headers,
      body: JSON.stringify({ exerciseId: "unowned-fixture", answer: "test" }),
    })
  ).status,
  404,
);
const recorded = state.words
  .flatMap((w) => w.attempts)
  .find((a) => !a.exerciseId.startsWith("seed:") && a.kind !== "spontaneous");
if (recorded) {
  check(
    "replaying a completed exercise cannot earn duplicate credit",
    (
      await fetch(`${base}/api/practice/answer`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          exerciseId: recorded.exerciseId,
          answer: recorded.answer,
        }),
      })
    ).status,
    409,
  );
  const fresh = await (await fetch(`${base}/api/state`, { headers })).json();
  check(
    "replayed attempt leaves the evidence ledger unchanged",
    fresh.words.flatMap((w) => w.attempts).length,
    state.words.flatMap((w) => w.attempts).length,
  );
}
console.log(
  `Persistent state verified: ${state.words.length} board entries. No user content or credentials logged.`,
);
