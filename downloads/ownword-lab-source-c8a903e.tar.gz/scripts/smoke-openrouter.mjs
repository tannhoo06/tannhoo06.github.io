import { build } from 'esbuild';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// One paid synthetic request; never print credentials or response content.
process.loadEnvFile('.dev.vars');
if (!process.env.OPENROUTER_API_KEY?.trim()) throw Error('OPENROUTER_API_KEY is missing');
mkdirSync('.sites-runtime/evals',{recursive:true});
const bundle=resolve('.sites-runtime/evals/openrouter-smoke.mjs');
await build({stdin:{contents:'export {OpenRouterLlm} from "./lib/llm/openrouter";',resolveDir:process.cwd(),loader:'ts'},bundle:true,packages:'external',platform:'node',format:'esm',outfile:bundle});
const {OpenRouterLlm}=await import(pathToFileURL(bundle).href);
let status=null, returnedModel=null, usage=null;
const request=async(url,init)=>{const res=await fetch(url,init); status=res.status; const body=await res.clone().json().catch(()=>({})); returnedModel=body.model??null;usage=body.usage??null; if (!res.ok) console.log(JSON.stringify({status,errorCode:body.error?.code??null,errorMessage:String(body.error?.message??'').replaceAll(process.env.OPENROUTER_API_KEY,'[redacted]').slice(0,300)})); return res;};
try {
 const result=await new OpenRouterLlm(process.env.OPENROUTER_API_KEY.trim(),'google/gemini-3.6-flash',request).analyzeWriting('The meeting starts at nine tomorrow morning.',[]);
 console.log(JSON.stringify({status,returnedModel,suggestions:result.suggestions.length,usage,passed:true}));
} catch(error) { console.log(JSON.stringify({status,returnedModel,passed:false,error:String(error.message).replaceAll(process.env.OPENROUTER_API_KEY,'[redacted]')})); process.exitCode=1; }
