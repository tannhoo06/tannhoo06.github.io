import { readFileSync, writeFileSync } from "node:fs";

const path = "docs/ownword-architecture.drawio";
let source = readFileSync(path, "utf8");
if (source.includes('diagram id="operations"')) {
  console.log("Operations page already exists");
  process.exit(0);
}

const escape = (value) => String(value).replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
const label = (id, value, x, y, width, height, style) =>
  `<mxCell id="${id}" value="${escape(value)}" style="${style}" vertex="1" parent="1"><mxGeometry x="${x}" y="${y}" width="${width}" height="${height}" as="geometry" /></mxCell>`;
const edge = (id, value, from, to, dashed = false) =>
  `<mxCell id="${id}" value="${escape(value)}" style="edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;fontSize=12;strokeColor=#475569;strokeWidth=1.5;endArrow=classic;${dashed ? "dashed=1;" : ""}" edge="1" parent="1" source="${from}" target="${to}"><mxGeometry relative="1" as="geometry" /></mxCell>`;
const base = "rounded=1;whiteSpace=wrap;html=1;fontSize=14;strokeWidth=1.5;";
const vm = base + "fillColor=#dae8fc;strokeColor=#6c8ebf;";
const aws = base + "fillColor=#d5e8d4;strokeColor=#82b366;";
const external = base + "fillColor=#ffe6cc;strokeColor=#d79b00;";
const pending = base + "fillColor=#f5f5f5;strokeColor=#999999;dashed=1;";
const note = base + "fillColor=#fff2cc;strokeColor=#d6b656;";
const cells = [
  label("ops-title", "Ownword pilot — off-instance backup and monitoring (live)", 35, 15, 1000, 35, "text;html=1;fontSize=20;fontStyle=1;strokeColor=none;fillColor=none;align=left;"),
  label("ops-cron", "Lightsail cron<br>23:00 UTC pg_dump", 70, 130, 190, 70, vm),
  label("ops-dump", "Local verified dump<br>14-day retention", 70, 250, 190, 70, vm),
  label("ops-health", "Hourly backup-health.sh<br>freshness + S3 HEAD", 70, 370, 190, 70, vm),
  label("ops-iam", "Scoped VM IAM user<br>private key; S3 + metric", 70, 490, 190, 70, vm),
  label("ops-s3", "S3 private backup bucket<br>30-day lifecycle · SSE-S3", 420, 130, 230, 80, aws),
  label("ops-logs", "S3 private access logs<br>30-day lifecycle", 750, 130, 220, 80, aws),
  label("ops-cw", "CloudWatch BackupFresh<br>missing/zero ⇒ ALARM", 420, 370, 230, 80, aws),
  label("ops-sns", "SNS operator alerts<br>encrypted topic", 750, 370, 220, 80, aws),
  label("ops-kms", "KMS customer key<br>alarm topic only · $1/mo", 750, 500, 220, 75, aws),
  label("ops-email", "Operator email<br>confirmed + test received", 1090, 370, 220, 80, external),
  label("ops-reminders", "SNS learner reminder topic<br>created; sending not enabled", 1090, 520, 220, 75, pending),
  label("ops-note", "Singapore ap-southeast-1. S3 dump was downloaded and restored into a disposable database. Reminders have no subscribers or job.", 40, 650, 1280, 65, note),
  edge("ops-e1", "pg_dump", "ops-cron", "ops-dump"),
  edge("ops-e2", "HTTPS PutObject + HEAD", "ops-dump", "ops-s3"),
  edge("ops-e3", "server access logs", "ops-s3", "ops-logs"),
  edge("ops-e4", "check object", "ops-health", "ops-s3"),
  edge("ops-e5", "PutMetricData hourly", "ops-health", "ops-cw"),
  edge("ops-e6", "alarm action", "ops-cw", "ops-sns"),
  edge("ops-e7", "encrypt", "ops-kms", "ops-sns"),
  edge("ops-e8", "email", "ops-sns", "ops-email"),
];

const page = `<diagram id="operations" name="Backups and alerts"><mxGraphModel adaptiveColors="auto" dx="1200" dy="760" grid="1" gridSize="10" page="1" pageScale="1" pageWidth="1400" pageHeight="780"><root><mxCell id="0" /><mxCell id="1" parent="0" />${cells.join("")}</root></mxGraphModel></diagram>`;
source = source.replace("Global daily budget&lt;br&gt;20 calls default", "Global + per-user budget&lt;br&gt;20 + 8 calls/day default");
source = source.replace("Solid = live data flow; * snapshot schedule reported, not verified", "Solid = live data flow; snapshots enabled; see Backups and alerts page");
source = source.replace("</mxfile>", `${page}</mxfile>`);
writeFileSync(path, source);
console.log("Added Backups and alerts page to editable draw.io XML");
