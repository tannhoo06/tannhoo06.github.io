import { writeFileSync } from "node:fs";

// Editable diagrams.net source for the deployed Ownword pilot. Run from repo root.
const escape = (s) => String(s).replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
const box = (id, value, x, y, w, h, style) =>
  `<mxCell id="${id}" value="${escape(value)}" style="${style}" vertex="1" parent="1"><mxGeometry x="${x}" y="${y}" width="${w}" height="${h}" as="geometry" /></mxCell>`;
const icon = (id, name, detail, x, y, shape, color) => [
  box(id, "", x, y, 74, 74, `sketch=0;outlineConnect=0;fillColor=${color};strokeColor=${shape === "bucket" ? "none" : "#ffffff"};html=1;aspect=fixed;shape=${shape === "bucket" ? "mxgraph.aws4.bucket" : "mxgraph.aws4.resourceIcon;resIcon=mxgraph.aws4." + shape};`),
  box(`${id}-label`, `<b>${name}</b><br><small>${detail}</small>`, x - 51, y + 77, 176, 52,
    "text;whiteSpace=wrap;html=1;fillColor=none;strokeColor=none;align=center;verticalAlign=top;fontSize=14;fontColor=#172334;"),
].join("");
const serviceCard = (id, name, detail, x, y, w, shape, color) => [
  box(id, "", x, y, w, 104, "rounded=1;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#B7C4D3;strokeWidth=1.5;"),
  box(`${id}-icon`, "", x + 14, y + 20, 64, 64,
    `sketch=0;outlineConnect=0;fillColor=${color};strokeColor=${shape === "bucket" ? "none" : "#ffffff"};html=1;aspect=fixed;shape=${shape === "bucket" ? "mxgraph.aws4.bucket" : "mxgraph.aws4.resourceIcon;resIcon=mxgraph.aws4." + shape};`),
  box(`${id}-text`, `<b>${name}</b><br><small>${detail}</small>`, x + 87, y + 15, w - 96, 74,
    "text;whiteSpace=wrap;html=1;fillColor=none;strokeColor=none;align=left;verticalAlign=middle;fontSize=14;fontColor=#172334;"),
].join("");
const arrow = (id, value, from, to, extra = "") =>
  `<mxCell id="${id}" value="${escape(value)}" style="edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;strokeColor=#475569;strokeWidth=1.6;endArrow=classic;fontSize=12;fontColor=#334155;labelBackgroundColor=#FFFFFF;${extra}" edge="1" parent="1" source="${from}" target="${to}"><mxGeometry relative="1" as="geometry" /></mxCell>`;
const graph = (w, h, cells, links) =>
  `<mxGraphModel adaptiveColors="auto" dx="${w}" dy="${h}" grid="1" gridSize="10" page="1" pageScale="1" pageWidth="${w}" pageHeight="${h}"><root><mxCell id="0" /><mxCell id="1" parent="0" />${cells.join("")}${links.join("")}</root></mxGraphModel>`;
const panel = "rounded=1;whiteSpace=wrap;html=1;fillColor=#F8FAFC;strokeColor=#94A3B8;strokeWidth=1.5;align=left;verticalAlign=top;spacingLeft=15;spacingTop=12;fontSize=17;fontStyle=1;fontColor=#26364A;";
const vm = "rounded=1;whiteSpace=wrap;html=1;fillColor=#FFF8EE;strokeColor=#ED7100;strokeWidth=1.6;align=left;verticalAlign=top;spacingLeft=13;spacingTop=11;fontSize=16;fontStyle=1;fontColor=#26364A;";
const service = "rounded=1;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#C9D3DF;strokeWidth=1.4;align=center;verticalAlign=middle;fontSize=15;fontColor=#172334;";
const external = "rounded=1;whiteSpace=wrap;html=1;fillColor=#FFF1DC;strokeColor=#E3A44E;strokeWidth=1.5;align=center;verticalAlign=middle;fontSize=15;fontColor=#172334;";
const note = "text;whiteSpace=wrap;html=1;fillColor=none;strokeColor=none;align=left;fontSize=14;fontColor=#64748B;";
const externalPanel = "rounded=1;whiteSpace=wrap;html=1;fillColor=#FFFBF5;strokeColor=#E3A44E;strokeWidth=1.4;align=left;verticalAlign=top;spacingLeft=12;spacingTop=9;fontSize=16;fontStyle=1;fontColor=#805625;";

const overviewNodes = [
  box("all-title", "Ownword · every AWS service used", 35, 20, 1050, 40,
    "text;html=1;fillColor=none;strokeColor=none;align=left;fontSize=24;fontStyle=1;fontColor=#172334;"),
  box("all-subtitle", "Seven deployed services across Singapore, Ohio and global IAM. CloudShell was used for setup only.", 37, 64, 1300, 38, note),
  box("all-internet", "Public Internet", 20, 160, 245, 165, externalPanel),
  box("all-ohio", "AWS Ohio · us-east-2", 20, 395, 245, 160, panel),
  box("all-global", "AWS Global", 20, 610, 245, 160, panel),
  box("all-singapore", "AWS Singapore · ap-southeast-1", 280, 160, 850, 610, panel),
  box("all-provider", "External provider", 1145, 160, 210, 165, externalPanel),
  box("all-recipient", "Operator", 1145, 395, 210, 160, externalPanel),
  box("all-admin", "AWS admin · Singapore", 1145, 610, 210, 160, panel),
  box("all-browser", "Learner browser", 35, 210, 175, 104, external),
  serviceCard("all-lightsail", "Amazon Lightsail", "VM; snapshots enabled", 300, 210, 220, "lightsail", "#ED7100"),
  box("all-router", "OpenRouter<br><small>model API</small>", 1160, 210, 180, 104, external),
  serviceCard("all-cognito", "Amazon Cognito", "Ohio · PKCE sign-in", 35, 425, 220, "cognito", "#DD344C"),
  serviceCard("all-s3", "Amazon S3", "backup + access-log buckets", 300, 425, 220, "bucket", "#7AA116"),
  serviceCard("all-cw", "Amazon CloudWatch", "BackupFresh alarm", 580, 425, 220, "cloudwatch_2", "#E7157B"),
  serviceCard("all-sns", "Amazon SNS", "operator alert topic", 885, 425, 220, "sns", "#E7157B"),
  box("all-operator", "Operator email<br><small>alarm recipient</small>", 1160, 425, 180, 104, external),
  serviceCard("all-iam", "AWS IAM", "VM backup + metric access", 35, 640, 220, "identity_and_access_management", "#DD344C"),
  serviceCard("all-kms", "AWS KMS", "operator SNS encryption", 885, 640, 220, "key_management_service", "#DD344C"),
  serviceCard("all-cloudshell", "AWS CloudShell", "Singapore · setup only", 1160, 640, 180, "cloudshell", "#C925D1"),
  box("all-footer", "On the Lightsail VM: Caddy, Next.js, PostgreSQL and backup jobs. External: sslip.io DNS and OpenRouter. RDS, EC2 and Route 53 are not deployed.", 37, 779, 1300, 34, note),
];
const overviewEdges = [
  arrow("all-e1", "HTTPS", "all-browser", "all-lightsail"),
  arrow("all-e2", "model HTTPS", "all-lightsail", "all-router"),
  arrow("all-e3", "PKCE sign-in", "all-browser", "all-cognito"),
  arrow("all-e4", "daily dump", "all-lightsail", "all-s3"),
  arrow("all-e5", "metric", "all-lightsail", "all-cw", "exitX=1;exitY=0.75;entryX=0;entryY=0.25;"),
  arrow("all-e6", "alarm", "all-cw", "all-sns"),
  arrow("all-e7", "email", "all-sns", "all-operator"),
  arrow("all-e9", "encrypts", "all-kms", "all-sns"),
];

const appNodes = [
  box("app-title", "Ownword · live application and sign-in", 35, 20, 1030, 39,
    "text;html=1;fillColor=none;strokeColor=none;align=left;fontSize=24;fontStyle=1;fontColor=#172334;"),
  box("app-subtitle", "Public pilot · Singapore app · Ohio authentication", 37, 61, 1030, 27, note),
  box("app-sg", "AWS Singapore · ap-southeast-1", 385, 110, 620, 525, panel),
  box("app-vm", "Amazon Lightsail · ownword-pilot · Ubuntu / 2 GB", 420, 175, 545, 410, vm),
  box("app-browser", "Learner browser", 37, 319, 133, 65, external),
  box("app-dns", "sslip.io DNS<br><small>resolves static IP</small>", 211, 205, 139, 65, external),
  box("app-lightsail-icon", "", 450, 211, 69, 69,
    "sketch=0;outlineConnect=0;fillColor=#ED7100;strokeColor=#ffffff;html=1;aspect=fixed;shape=mxgraph.aws4.resourceIcon;resIcon=mxgraph.aws4.lightsail;"),
  box("app-caddy", "Caddy 2<br><small>HTTPS proxy</small>", 452, 319, 140, 66, service),
  box("app-next", "Next.js 16<br><small>UI + API / callback</small>", 665, 319, 150, 66, service),
  box("app-pg", "PostgreSQL 16<br><small>private volume</small>", 665, 465, 150, 66, service),
  box("app-router", "OpenRouter<br><small>configured Gemini · HTTPS</small>", 1090, 319, 205, 70, external),
  box("app-ohio", "AWS Ohio · us-east-2", 35, 510, 300, 230, panel),
  icon("app-cognito", "Amazon Cognito", "public sign-in · PKCE", 151, 560, "cognito", "#DD344C"),
  box("app-footer", "Cognito redirects to /auth/callback; Next.js exchanges the code and validates the ID token over HTTPS. PostgreSQL runs on Lightsail; no RDS or load balancer.", 37, 756, 1280, 34, note),
];
const appEdges = [
  arrow("a1", "DNS lookup", "app-browser", "app-dns"),
  arrow("a2", "HTTPS 443", "app-browser", "app-caddy"),
  arrow("a3", "HTTP 3000", "app-caddy", "app-next"),
  arrow("a4", "TCP 5432", "app-next", "app-pg"),
  arrow("a5", "HTTPS LLM", "app-next", "app-router"),
  arrow("a6", "OAuth / PKCE", "app-browser", "app-cognito"),
];

const opsNodes = [
  box("ops-title", "Ownword · backup and alerting", 35, 20, 1030, 39,
    "text;html=1;fillColor=none;strokeColor=none;align=left;fontSize=24;fontStyle=1;fontColor=#172334;"),
  box("ops-subtitle", "All backup and monitoring resources are in AWS Singapore", 37, 61, 1100, 27, note),
  box("ops-sg", "AWS Singapore · ap-southeast-1", 38, 108, 1190, 652, panel),
  box("ops-vm", "Amazon Lightsail VM", 75, 175, 285, 455, vm),
  box("ops-lightsail-icon", "", 101, 208, 65, 65,
    "sketch=0;outlineConnect=0;fillColor=#ED7100;strokeColor=#ffffff;html=1;aspect=fixed;shape=mxgraph.aws4.resourceIcon;resIcon=mxgraph.aws4.lightsail;"),
  box("ops-backup", "Daily backup<br><small>pg_dump · 23:00 UTC</small>", 109, 307, 214, 68, service),
  box("ops-health", "Hourly health check<br><small>S3 object + age</small>", 109, 447, 214, 68, service),
  box("ops-snapshot", "Lightsail snapshots<br><small>enabled · first unverified</small>", 109, 652, 214, 65, service),
  icon("ops-s3", "Amazon S3", "private dumps · 30 days", 513, 301, "bucket", "#7AA116"),
  icon("ops-logs", "Amazon S3", "private access logs", 792, 301, "bucket", "#7AA116"),
  icon("ops-cw", "Amazon CloudWatch", "BackupFresh + alarm", 513, 479, "cloudwatch_2", "#E7157B"),
  icon("ops-sns", "Amazon SNS", "operator alert topic", 792, 479, "sns", "#E7157B"),
  icon("ops-kms", "AWS KMS", "customer key encrypts SNS alerts", 1051, 600, "key_management_service", "#DD344C"),
  icon("ops-iam", "AWS IAM (global)", "VM user: S3 upload + metrics", 1326, 271, "identity_and_access_management", "#DD344C"),
  box("ops-email", "Operator email<br><small>confirmed alert recipient</small>", 1274, 482, 218, 72, external),
  box("ops-footer", "S3 backups were downloaded and restored in a disposable database. Learner reminder emails remain disabled.", 38, 783, 1400, 31, note),
];
const opsEdges = [
  arrow("o0", "", "ops-vm", "ops-snapshot"),
  arrow("o1", "daily upload", "ops-backup", "ops-s3"),
  arrow("o2", "access logs", "ops-s3", "ops-logs"),
  arrow("o3", "BackupFresh", "ops-health", "ops-cw"),
  arrow("o4", "alarm", "ops-cw", "ops-sns"),
  arrow("o5", "email", "ops-sns", "ops-email"),
];

const pages = [
  `<diagram id="aws-all" name="All AWS services">${graph(1370, 835, overviewNodes, overviewEdges)}</diagram>`,
  `<diagram id="aws-app" name="App and sign-in">${graph(1330, 800, appNodes, appEdges)}</diagram>`,
  `<diagram id="aws-ops" name="Backups and alerts">${graph(1520, 830, opsNodes, opsEdges)}</diagram>`,
];
writeFileSync("docs/ownword-aws-architecture.drawio",
  `<?xml version="1.0" encoding="UTF-8"?>\n<mxfile host="app.diagrams.net" agent="Codex" version="24.7.17" type="device">${pages.join("")}</mxfile>\n`);
console.log("Wrote three-page editable AWS diagram");
