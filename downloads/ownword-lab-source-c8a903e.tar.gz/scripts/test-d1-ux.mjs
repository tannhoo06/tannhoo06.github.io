import { build } from 'esbuild';
import { spawnSync } from 'node:child_process';
await build({entryPoints:['tests/d1-ux.integration.ts'],outfile:'.sites-runtime/tests/d1-ux.mjs',bundle:true,platform:'node',format:'esm',packages:'external'});
const result=spawnSync(process.execPath,['.sites-runtime/tests/d1-ux.mjs'],{stdio:'inherit'});process.exit(result.status??1);
