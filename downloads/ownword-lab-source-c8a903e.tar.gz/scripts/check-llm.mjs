// Explicit local diagnostic. Keys stay in process memory and never enter build output.
import { build } from "esbuild";
import { mkdirSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";

if (process.argv.slice(2).some((arg) => arg !== "--live")) {
  console.error("Usage: node scripts/check-llm.mjs [--live]");
  process.exit(1);
}
process.loadEnvFile(".dev.vars");
mkdirSync(".sites-runtime/llm-check", { recursive: true });
const modulePath = resolve(".sites-runtime/llm-check/provider.mjs");
await build({
  stdin: {
    contents:
      'export {readConfig} from "./lib/config"; export {createLlmProvider} from "./lib/llm/provider-factory";',
    resolveDir: process.cwd(),
    loader: "ts",
  },
  outfile: modulePath,
  bundle: true,
  platform: "node",
  format: "esm",
  target: "node22",
});
const { readConfig, createLlmProvider } = await import(
  pathToFileURL(modulePath).href
);
let config;
try {
  config = readConfig(process.env).llm;
  console.log(
    JSON.stringify({
      provider: config.provider,
      ...(config.provider === "gemini"
        ? {
            model: config.model,
            keyCount: config.keys.length,
            strategy: config.keyStrategy,
          }
        : config.provider === "openrouter" ? {model: config.model, keyCount: 1} : {}),
    }),
  );
  if (process.argv.includes("--live")) {
    if (config.provider === "mock")
      throw new Error("Select a live provider before running a live check.");
    // Smoke checks use an isolated selector; production uses the D1 implementation.
    const positions = new Map();
    const rotationStore = {
      async reserve(id, size) {
        const index = ((positions.get(id) ?? -1) + 1) % size;
        positions.set(id, index);
        return index;
      },
    };
    const slots = [];
    const request = async (url, init) => {
      const selected = new Headers(init.headers).get("x-goog-api-key");
      slots.push(config.provider === "gemini" ? config.keys.indexOf(selected) + 1 : 1);
      const response = await fetch(url, init);
      if (!response.ok) {
        let details = await response
          .clone()
          .json()
          .catch(() => ({}));
        let message = String(
          details.error?.message ?? "Provider rejected the request.",
        );
        for (const key of config.provider === "gemini" ? config.keys : [config.key])
          message = message.split(key).join("[redacted]");
        console.error(
          JSON.stringify({
            keySlot: slots.at(-1),
            httpStatus: response.status,
            message: message.slice(0, 500),
          }),
        );
      }
      return response;
    };
    const count = config.provider === "gemini" && config.keyStrategy !== "single" ? config.keys.length : 1;
    for (let i = 0; i < count; i++) {
      const provider = createLlmProvider(config, { rotationStore, request });
      const start = performance.now();
      const analysis = await provider.analyzeWriting(
        "There was a very small difference in the cost of the two plans.",
        [],
      );
      console.log(
        JSON.stringify({
          request: i + 1,
          keySlot: slots.at(-1),
          status: "passed",
          suggestions: analysis.suggestions.length,
          durationMs: Math.round(performance.now() - start),
        }),
      );
    }
    if (slots.some((slot, index) => index > 0 && slot === slots[index - 1]))
      throw new Error("Consecutive key slots repeated.");
    console.log(
      "PASS live provider responses and expected key sequence. No learner records were written.",
    );
  }
} catch (error) {
  let message = error instanceof Error ? error.message : "LLM check failed.";
  if (config?.provider === "gemini")
    for (const key of config.keys)
      message = message.split(key).join("[redacted]");
  if (config?.provider === "openrouter") message = message.split(config.key).join("[redacted]");
  console.error(message);
  process.exitCode = 1;
}
