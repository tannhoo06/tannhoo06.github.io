import { closePgDb } from "../db/pg";
import { enrichPendingManualWords } from "../lib/server/manual-word-enrichment";

try {
  const result = await enrichPendingManualWords();
  if (result.attempted) console.log(`Manual word enrichment: ${result.enriched}/${result.attempted} completed`);
} catch (error) {
  console.error("Manual word enrichment worker failed:", error);
  process.exitCode = 1;
} finally {
  await closePgDb();
}
