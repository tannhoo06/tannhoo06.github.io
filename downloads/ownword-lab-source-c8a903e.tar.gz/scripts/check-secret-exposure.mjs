import { existsSync, readFileSync, readdirSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join } from "node:path";

if (existsSync(".dev.vars")) process.loadEnvFile(".dev.vars");
const keys = Object.entries(process.env)
  .filter(
    ([name, value]) =>
      /^GEMINI_API_KEY(?:_[1-9]\d*)?$/.test(name) && value?.trim(),
  )
  .map(([, value]) => Buffer.from(value.trim()));
if (!keys.length) {
  console.log("No configured Gemini keys available for a literal secret scan.");
  process.exit(0);
}
const tracked = execFileSync("git", ["ls-files", "--cached", "--others", "--exclude-standard", "-z"], {
  encoding: "utf8",
  windowsHide: true,
})
  .split("\0")
  .filter(Boolean);
function filesUnder(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const file = join(directory, entry.name);
    return entry.isDirectory()
      ? filesUnder(file)
      : entry.isFile()
        ? [file]
        : [];
  });
}
const files = [...tracked, ...(existsSync("dist") ? filesUnder("dist") : [])];
let leaks = 0;
for (const file of files) {
  if (!existsSync(file)) continue;
  const bytes = readFileSync(file);
  if (keys.some((key) => bytes.includes(key))) leaks++;
}
if (leaks) {
  console.error(
    `Secret scan failed: configured key material was found in ${leaks} source/build files. Values withheld.`,
  );
  process.exitCode = 1;
} else
  console.log(
    `PASS configured keys absent from ${files.length} tracked-source/build files. Values withheld.`,
  );
