import { build } from "esbuild";
import { mkdirSync } from "node:fs";
import { spawnSync } from "node:child_process";
mkdirSync(".sites-runtime/tests", { recursive: true });
await build({
  entryPoints: [
    "tests/cognito-owner.test.ts",
    "tests/learning.test.ts",
    "tests/service.test.ts",
    "tests/writing.test.ts",
    "tests/writing-focus-check.test.ts",
    "tests/insights.test.ts",
    "tests/i18n.test.ts",
    "tests/llm-provider.test.ts",
    "tests/llm-output-policy.test.ts",
    "tests/llm-discovery.test.ts",
    "tests/llm-rewrite-quality.test.ts",
    "tests/llm-v5.test.ts",
    "tests/llm-mapping-v6.test.ts",
    "tests/llm-cleanup-v7.test.ts",
    "tests/semantic-specificity.test.ts",
    "tests/semantic-compression.test.ts",
    "tests/openrouter.test.ts",
    "tests/instructional-response.test.ts",
    "tests/instructional-temporal.test.ts",
    "tests/example-quality.test.ts",
    "tests/local-agreement.test.ts",
  ],
  outdir: ".sites-runtime/tests",
  outExtension: { ".js": ".mjs" },
  bundle: true,
  platform: "node",
  format: "esm",
  target: "node22",
});
const result = spawnSync(
  process.execPath,
  [
    "--test",
    ".sites-runtime/tests/cognito-owner.test.mjs",
    ".sites-runtime/tests/learning.test.mjs",
    ".sites-runtime/tests/service.test.mjs",
    ".sites-runtime/tests/writing.test.mjs",
    ".sites-runtime/tests/writing-focus-check.test.mjs",
    ".sites-runtime/tests/insights.test.mjs",
    ".sites-runtime/tests/i18n.test.mjs",
    ".sites-runtime/tests/llm-provider.test.mjs",
    ".sites-runtime/tests/llm-output-policy.test.mjs",
    ".sites-runtime/tests/llm-discovery.test.mjs",
    ".sites-runtime/tests/llm-rewrite-quality.test.mjs",
    ".sites-runtime/tests/llm-v5.test.mjs",
    ".sites-runtime/tests/llm-mapping-v6.test.mjs",
    ".sites-runtime/tests/llm-cleanup-v7.test.mjs",
    ".sites-runtime/tests/semantic-specificity.test.mjs",
    ".sites-runtime/tests/semantic-compression.test.mjs",
    ".sites-runtime/tests/openrouter.test.mjs",
    ".sites-runtime/tests/instructional-response.test.mjs",
    ".sites-runtime/tests/instructional-temporal.test.mjs",
    ".sites-runtime/tests/example-quality.test.mjs",
    ".sites-runtime/tests/local-agreement.test.mjs",
  ],
  { stdio: "inherit" },
);
if (result.status !== 0) process.exit(result.status ?? 1);
await build({
  entryPoints: ["tests/d1-ux.integration.ts", "tests/writing-persistence.integration.ts"],
  outdir: ".sites-runtime/tests",
  outExtension: { ".js": ".mjs" },
  bundle: true,
  packages: "external",
  platform: "node",
  format: "esm",
  target: "node22",
});
const integration = spawnSync(
  process.execPath,
  [".sites-runtime/tests/d1-ux.integration.mjs"],
  { stdio: "inherit" },
);
if (integration.status !== 0) process.exit(integration.status ?? 1);
const writing = spawnSync(process.execPath, ["--test", ".sites-runtime/tests/writing-persistence.integration.mjs"], {
  stdio: "inherit",
});
process.exit(writing.status ?? 1);
