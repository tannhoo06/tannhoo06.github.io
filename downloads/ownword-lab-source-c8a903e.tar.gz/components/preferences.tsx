"use client";
import { useI18n } from "./language-provider";
import { LucianLanguageText } from "./lucian-267-language-switch";
import { useConfirmAction } from "./lucian-269-confirmation";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Check,
  ChevronDown,
  ChevronRight,
  FileText,
  Info,
  Lightbulb,
  LoaderCircle,
  LogOut,
  Plus,
  Settings2,
  ShieldCheck,
  UserRound,
  X,
} from "lucide-react";
import type { AppState, Insight } from "@/lib/domain/types";
import {
  api,
  Button,
  ErrorMessage,
  type Navigate,
  type Notify,
} from "./shared";

const fitGuidance: Record<string, string> = {
  substantial: "Use “substantial” for amount, scale, or importance.",
  compelling:
    "Use “compelling” for something that strongly holds attention or persuades.",
  negligible:
    "Use “negligible” when something is so small that it has little practical effect.",
  crucial:
    "Use “crucial” when something is necessary for a particular outcome.",
  pivotal: "Use “pivotal” for something that changes what happens next.",
  significant:
    "Use “significant” for an amount or effect large enough to matter.",
  paramount:
    "Use “paramount” when something matters more than everything else in the situation.",
};
function Excerpt({
  source,
}: {
  source: NonNullable<Insight["sources"]>[number];
}) {
  const exact = source.text.slice(source.start, source.end);
  if (!exact) return <>{source.sentence}</>;
  const escaped = exact.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return (
    <>
      {source.sentence
        .split(new RegExp(`(${escaped})`, "gi"))
        .map((part, i) =>
          part.toLowerCase() === exact.toLowerCase() ? (
            <mark key={i}>{part}</mark>
          ) : (
            part
          ),
        )}
    </>
  );
}
export function Insights({
  state,
  navigate,
  refresh,
  notify,
}: {
  state: AppState;
  navigate: Navigate;
  refresh: () => Promise<AppState>;
  notify: Notify;
}) {
  const { t, locale } = useI18n();
  const [busy, setBusy] = useState<string | null>(null),
    [error, setError] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null),
    [exampleLimit, setExampleLimit] = useState(3);
  const [notice, setNotice] = useState(true);
  const repeated = state.insights.filter((item) => item.count >= 2);
  const showWordField = repeated.length >= 3 && repeated.reduce((sum, item) => sum + item.count, 0) >= 8;
  async function add(word: string) {
    setBusy(word);
    setError("");
    try {
      const result = await api<{ queued: boolean }>("insights/add", { word });
      await refresh();
      notify(
        result.queued
          ? t("“{word}” is saved for later practice.", { word })
          : t("“{word}” is ready to practice.", { word }),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(null);
    }
  }
  function option(alt: Insight["alternatives"][number]) {
    const owned = state.words.find((w) => w.word === alt.word);
    return (
      <div className="pattern-option" key={alt.word}>
        <h3 lang="en">{alt.word}</h3>
        <p lang="en">{alt.meaning}</p>
        {owned ? (
          <a
            className="button-primary"
            href={`/board?stage=all&word=${encodeURIComponent(owned.userWordId)}`}
          >
            {t("View on WordBoard")}
            <ArrowRight size={16} />
          </a>
        ) : (
          <Button disabled={!!busy} onClick={() => add(alt.word)}>
            {busy === alt.word ? (
              <LoaderCircle size={16} className="spin" />
            ) : (
              <Plus size={17} />
            )}{" "}
            {t("Add to WordBoard")}
          </Button>
        )}
      </div>
    );
  }
  return (
    <div className="patterns-v2">
      <div className="page-heading">
        <div>
          <h1><LucianLanguageText value={t("Your patterns")} order={2} /></h1>
          <p>
            <LucianLanguageText block value={t(
              "Notice phrases you use often and explore more precise options when they fit.",
            )} order={3} />
          </p>
        </div>
        <span className="pattern-count">
          {t("{count} insights", { count: state.insights.length })}
        </span>
      </div>
      {notice && (
        <aside className="patterns-notice">
          <Lightbulb size={30} strokeWidth={1.5} aria-hidden="true" />
          <div>
            <h2>{t("Repeating a word is not automatically bad.")}</h2>
            <p>
              {t(
                "Common words are a natural part of writing. These insights simply highlight patterns and suggest more precise options you can use when they fit.",
              )}
            </p>
          </div>
          <button
            className="icon-button"
            aria-label={t("Dismiss pattern guidance")}
            onClick={() => setNotice(false)}
          >
            <X size={18} />
          </button>
        </aside>
      )}
      {error && <ErrorMessage message={error} />}
      {!state.insights.length ? (
        <div className="insights-empty">
          <BookOpen size={34} strokeWidth={1.3} />
          <h2>{t("No writing to explore yet.")}</h2>
          <p>
            {t("Write a few sentences to see recurring choices in context.")}
          </p>
          <Button secondary onClick={() => navigate("write")}>
            {t("Write something")}
            <ArrowRight size={17} />
          </Button>
        </div>
      ) : (
        <>
        {showWordField && <section className="pattern-word-field" aria-label={locale === "vi" ? "Những cụm từ bạn thường dùng" : "Phrases you use often"}>
          <h2>{locale === "vi" ? "Những từ bạn thường dùng" : "Words you often reach for"}</h2>
          <div>{repeated.map((item) => <button key={item.phrase} type="button" style={{ fontSize: `${Math.min(25, 16 + item.count * 1.5)}px` }} onClick={() => { setExpanded(item.phrase); document.getElementById(`pattern-${state.insights.indexOf(item)}`)?.scrollIntoView({ behavior: "auto", block: "center" }); }} aria-label={`${item.phrase}: ${item.count} ${locale === "vi" ? "lần" : "uses"}`}>
            <span lang="en">{item.phrase}</span>
            <small>{locale === "vi" ? `${item.count} lần · ${item.sources?.[0]?.sentence ?? "Xem ví dụ bên dưới"}` : `${item.count} uses · ${item.sources?.[0]?.sentence ?? "See examples below"}`}</small>
          </button>)}</div>
        </section>}
        <div className="pattern-cards">
          {state.insights.map((item, index) => {
            const open = expanded === item.phrase,
              alt = item.alternatives[0];
            return (
              <article
                id={`pattern-${index}`}
                className={`pattern-card ${open ? "is-expanded" : ""}`}
                key={item.phrase}
              >
                <div className="pattern-main">
                  <div className="pattern-phrase">
                    <span>{t("You often use")}</span>
                    <h2 lang="en">“{item.phrase}”</h2>
                    <p>{t("used {count} times", { count: item.count })}</p>
                  </div>
                  <div className="pattern-alternative">
                    <span>{t("A more specific option")}</span>
                    {alt && option(alt)}
                    <button
                      className="text-button examples-toggle"
                      aria-expanded={open}
                      aria-controls={`pattern-evidence-${index}`}
                      onClick={() => {
                        setExpanded(open ? null : item.phrase);
                        setExampleLimit(3);
                      }}
                    >
                      {t("See examples from my writing")}
                      <ArrowRight size={16} />
                    </button>
                    {item.alternatives.length > 1 && (
                      <details className="pattern-more-options">
                        <summary>{t("More options")}</summary>
                        {item.alternatives.slice(1).map(option)}
                      </details>
                    )}
                  </div>
                  <button
                    className="icon-button pattern-expand"
                    aria-label={t(
                      open
                        ? "Collapse examples for {phrase}"
                        : "Expand examples for {phrase}",
                      { phrase: item.phrase },
                    )}
                    aria-expanded={open}
                    aria-controls={`pattern-evidence-${index}`}
                    onClick={() => {
                      setExpanded(open ? null : item.phrase);
                      setExampleLimit(3);
                    }}
                  >
                    <ChevronDown size={18} />
                  </button>
                </div>
                {open && (
                  <section
                    className="pattern-evidence"
                    id={`pattern-evidence-${index}`}
                  >
                    <header>
                      <h3>
                        <FileText size={18} aria-hidden="true" />
                        {t("Examples from your writing")}
                      </h3>
                      <span>
                        {t("{shown} of {total} examples", {
                          shown: Math.min(
                            exampleLimit,
                            item.sources?.length ?? 0,
                          ),
                          total: item.count,
                        })}
                      </span>
                    </header>
                    {item.sources?.length ? (
                      <ol>
                        {item.sources
                          .slice(0, exampleLimit)
                          .map((source, i) => (
                            <li key={`${source.sampleId}-${source.start}-${i}`}>
                              <button
                                className="excerpt-number"
                                aria-label={t(
                                  "View excerpt {number} in writing",
                                  { number: i + 1 },
                                )}
                                title={t("View in writing")}
                                onClick={() => {
                                  sessionStorage.setItem(
                                    "ownword:writing-intent",
                                    JSON.stringify({
                                      ...source,
                                      userId: state.profile.id,
                                    }),
                                  );
                                  navigate("write");
                                }}
                              >
                                {i + 1}
                              </button>
                              <blockquote lang="en">
                                <Excerpt source={source} />
                              </blockquote>
                            </li>
                          ))}
                      </ol>
                    ) : (
                      <p>
                        {t("No source excerpts were saved for this pattern.")}
                      </p>
                    )}
                    {(item.sources?.length ?? 0) > exampleLimit && (
                      <button
                        className="text-button"
                        onClick={() => setExampleLimit((n) => n + 3)}
                      >
                        {t("Show more examples")}
                      </button>
                    )}
                    {alt && (
                      <aside className="pattern-fit">
                        <Info size={19} aria-hidden="true" />
                        <div>
                          <strong>
                            {t(
                              fitGuidance[alt.word] ??
                                "Choose this option when it fits your intended meaning.",
                            )}
                          </strong>
                          <p>
                            {t(
                              "Keep your original wording when it is already the most natural choice.",
                            )}
                          </p>
                        </div>
                      </aside>
                    )}
                  </section>
                )}
              </article>
            );
          })}
        </div>
        </>
      )}
    </div>
  );
}

export function Settings({
  state,
  refresh,
  notify,
}: {
  state: AppState;
  refresh: () => Promise<AppState>;
  notify: Notify;
}) {
  const { t } = useI18n();
  const confirmAction = useConfirmAction();
  const [name, setName] = useState(state.profile.name),
    [limit, setLimit] = useState(state.profile.dailyLimit);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const [saved, setSaved] = useState(false),
    [help, setHelp] = useState(false);
  const queue = useRef(Promise.resolve());
  const revision = useRef(0),
    savedName = useRef(state.profile.name);
  const pending = useRef(false);
  const lastChanges = useRef<{ name?: string; dailyLimit?: number }>({});
  const draftName = useRef(name);
  useEffect(() => {
    draftName.current = name;
  }, [name]);
  useEffect(() => {
    if (!saved) return;
    const timer = setTimeout(() => setSaved(false), 3000);
    return () => clearTimeout(timer);
  }, [saved]);
  useEffect(() => {
    const unload = (event: BeforeUnloadEvent) => {
      if (pending.current || draftName.current.trim() !== savedName.current) {
        event.preventDefault();
        event.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", unload);
    return () => window.removeEventListener("beforeunload", unload);
  }, []);
  function save(changes: { name?: string; dailyLimit?: number }) {
    lastChanges.current = changes;
    const current = ++revision.current;
    setBusy(true);
    setError("");
    setSaved(false);
    pending.current = true;
    queue.current = queue.current.then(async () => {
      try {
        await api("settings", changes);
        if (changes.name !== undefined) savedName.current = changes.name;
        await refresh();
        if (current === revision.current) setSaved(true);
      } catch (e) {
        setError((e as Error).message);
        notify((e as Error).message);
      } finally {
        if (current === revision.current) {
          setBusy(false);
          pending.current = false;
        }
      }
    });
  }
  function saveName() {
    const trimmed = name.trim();
    if (!trimmed) {
      setError(t("Please enter a display name."));
      return;
    }
    setName(trimmed);
    if (trimmed !== savedName.current) save({ name: trimmed });
  }
  async function demoAction(action: "seed" | "clear") {
    setBusy(true);
    setError("");
    try {
      await api(`demo/${action}`, {});
      await refresh();
      notify(
        t(
          action === "clear"
            ? "Sample words and their illustrative history have been removed."
            : "Sample WordBoard is ready.",
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (help)
    return (
      <div className="settings-v2 settings-help-v2">
        <div className="settings-help-heading">
          <button
            className="icon-button"
            aria-label={t("Back to Settings")}
            onClick={() => setHelp(false)}
          >
            <ArrowLeft size={20} />
          </button>
          <h1>{t("How practice works")}</h1>
        </div>
        <p>
          {t(
            "Use flashcards for a quick check. In a longer session, recall words and choose whether to practice writing sentences.",
          )}
        </p>
        <ol>
          {[
            [
              "Write in context",
              "Write sentences in different situations, with a little guidance when you need it.",
            ],
            [
              "Get feedback",
              "Receive feedback on your word choice and discover natural ways to express your meaning.",
            ],
            [
              "Progress over time",
              "Your practice updates each word’s stage in WordBoard. You can review a saved word whenever you want.",
            ],
          ].map(([title, description], i) => (
            <li key={title}>
              <span>{i + 1}</span>
              <div>
                <h2>{t(title)}</h2>
                <p>{t(description)}</p>
              </div>
            </li>
          ))}
        </ol>
        <aside className="settings-tip">
          <Lightbulb size={24} />
          <div>
            <p>
              {t(
                "You can change your practice length in Settings at any time.",
              )}
            </p>
          </div>
        </aside>
      </div>
    );
  const displayLimit = limit <= 5 ? 5 : limit >= 9 ? 10 : 7;
  return (
    <div className="settings-layout settings-v2">
      <div className="page-heading">
        <div>
          <h1><LucianLanguageText value={t("Settings")} order={2} /></h1>
        </div>
      </div>
      {error && (
        <ErrorMessage
          message={error}
          retry={() => {
            if (!name.trim()) saveName();
            else save(lastChanges.current);
          }}
        />
      )}
      {saved && (
        <div className="settings-saved" role="status">
          <Check size={18} aria-hidden="true" />
          <span>{t("Changes saved")}</span>
          <button
            className="icon-button"
            aria-label={t("Dismiss notification")}
            onClick={() => setSaved(false)}
          >
            <X size={16} />
          </button>
        </div>
      )}
      <section className="settings-group">
        <UserRound size={28} strokeWidth={1.7} aria-hidden="true" />
        <div>
          <h2>{t("Profile")}</h2>
          <div className="settings-field-row">
            <label htmlFor="display-name">{t("Display name")}</label>
            <input
              id="display-name"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                setSaved(false);
              }}
              onBlur={saveName}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  saveName();
                }
              }}
              maxLength={60}
              required
              aria-invalid={!name.trim() || undefined}
            />
          </div>
        </div>
      </section>
      <section className="settings-group">
        <Settings2 size={28} strokeWidth={1.7} aria-hidden="true" />
        <div>
          <h2>{t("Practice")}</h2>
          <div className="settings-field-row">
            <div>
              <label htmlFor="practice-length">{t("Words per session")}</label>
              <p id="practice-length-help">{t("Applies to Recall and use your words.")}</p>
            </div>
            <select
              id="practice-length"
              aria-describedby="practice-length-help"
              value={displayLimit}
              disabled={busy}
              onChange={(e) => {
                const value = Number(e.target.value);
                setLimit(value);
                save({ dailyLimit: value });
              }}
            >
              <option value={5}>{t("Short (~5 words)")}</option>
              <option value={7}>{t("Standard (~7 words)")}</option>
              <option value={10}>{t("Longer (~10 words)")}</option>
            </select>
          </div>
        </div>
      </section>
      <section className="settings-group">
        <BookOpen size={28} strokeWidth={1.7} aria-hidden="true" />
        <div>
          <h2>{t("About & Support")}</h2>
          <button className="settings-link-row" onClick={() => setHelp(true)}>
            <FileText size={23} aria-hidden="true" />
            <span>
              <strong>{t("How practice works")}</strong>
            </span>
            <ChevronRight size={20} aria-hidden="true" />
          </button>
        </div>
      </section>
      <section className="settings-group">
        <ShieldCheck size={28} strokeWidth={1.7} aria-hidden="true" />
        <div>
          <h2>{t("Account")}</h2>
          {/* Authentication uses a full-document navigation, preserving the existing sign-out endpoint. */}
          {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
          <a
            className="settings-link-row settings-logout"
            href="/auth/signout?return_to=/"
            target="_top"
          >
            <LogOut size={23} aria-hidden="true" />
            <span>
              <strong>{t("Log out")}</strong>
            </span>
            <ChevronRight size={20} aria-hidden="true" />
          </a>
        </div>
      </section>
      {state.mockMode && process.env.NODE_ENV !== "production" && (
        <details className="settings-demo-tools">
          <summary>{t("Demo tools")}</summary>
          <p>
            {t(
              "Writing suggestions and feedback currently come from curated examples. They do not assess all of your language or writing quality.",
            )}
          </p>
          <Button secondary disabled={busy} onClick={() => demoAction("seed")}>
            {t("Load sample WordBoard")}
          </Button>
          {state.words.some((w) => w.demo) && (
            <button
              className="text-button"
              disabled={busy}
              onClick={async () => {
                if (await confirmAction({
                  title: t("Remove sample collection"),
                  message: t("Remove sample words and their practice history?"),
                  confirmLabel: t("Remove sample collection"),
                })) await demoAction("clear");
              }}
            >
              {t("Remove sample collection")}
            </button>
          )}
        </details>
      )}
    </div>
  );
}
