"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowRight, BookOpen, Clock3, Zap } from "lucide-react";
import { practiceCandidates } from "@/lib/domain/learning";
import type { AppState } from "@/lib/domain/types";
import { CollectionEmptyState } from "./kokonutui/collection-empty-state";
import { useI18n } from "./language-provider";
import { Button, type Navigate } from "./shared";

export function PracticeHub({
  state,
  now,
  navigate,
  onQuick,
  onFull,
  onResume,
}: {
  state: AppState;
  now: number;
  navigate: Navigate;
  onQuick: () => void;
  onFull: () => void;
  onResume?: () => void;
}) {
  const { locale, t } = useI18n();
  const vi = locale === "vi";
  const words = practiceCandidates(state.words, new Date(now), 6);
  const hasWords = state.words.length > 0;
  const modes = [
    {
      id: "quick",
      title: t("Quick flashcard review"),
      duration: t("1–2 min"),
      icon: Zap,
      description: vi ? "Đọc nghĩa, thử nhớ từ rồi lật thẻ để kiểm tra." : "Read the meaning, guess the word, then flip the card to check.",
      action: t("Start quick review"),
      run: onQuick,
      image: "/images/sprout-quick-review-flashcards.svg",
    },
    {
      id: "full",
      title: t("Recall and use your words"),
      icon: BookOpen,
      description: vi ? "Nhớ từ dựa vào nghĩa. Bạn cũng có thể luyện đặt câu với các từ đó." : "Recall words from their meanings. You can also practice using them in sentences.",
      action: t("Start practice"),
      run: onFull,
      image: "/images/sprout-full-practice-writing.svg",
    },
  ];

  return (
    <section className="practice-hub">
      <header className="ow-page-intro" data-align="center">
        <h1>{vi ? "Luyện từ vựng" : "Vocabulary practice"}</h1>
      </header>
      {onResume && (
        <button type="button" className="text-button practice-hub-resume" onClick={onResume}>
          {vi ? "Tiếp tục buổi luyện tập đang dở" : "Continue your unfinished practice"}<ArrowRight size={17} aria-hidden="true" />
        </button>
      )}
      {!words.length && <p className="practice-hub-availability" id="practice-hub-availability">{hasWords
        ? vi ? "Bạn có thể luyện khi các từ đã có nghĩa." : "You can practice once your saved words have definitions."
        : vi ? "Lưu một từ vào WordBoard để bắt đầu luyện." : "Save a word in WordBoard to start practicing."}</p>}
      <div className="practice-hub-grid">
        {modes.map(({ id, title, duration, icon: Icon, description, action, run, image }) => (
          <article className={`practice-hub-card ow-surface is-${id}`} data-tone={id === "quick" ? "soft" : "warm"} key={id} aria-labelledby={`practice-mode-${id}`}>
            <div className="practice-hub-card-top">
              <span className="practice-hub-icon"><Icon strokeWidth={1.75} aria-hidden="true" /></span>
              {duration && <span className="practice-hub-time"><Clock3 size={18} aria-hidden="true" />{duration}</span>}
            </div>
            <h2 id={`practice-mode-${id}`}>{title}</h2>
            <p className="practice-hub-card-copy">{description}</p>
            <Button className="practice-hub-cta ow-action-primary" disabled={!words.length} aria-describedby={!words.length ? "practice-hub-availability" : undefined} onClick={run}>
              {action}<ArrowRight size={21} aria-hidden="true" />
            </Button>
            <Image className="practice-hub-art" src={image} alt="" width={216} height={190} unoptimized />
          </article>
        ))}
      </div>
      <section className="practice-hub-board ow-surface" aria-labelledby="practice-hub-board-title">
        <header>
          <h2 id="practice-hub-board-title"><BookOpen size={30} strokeWidth={1.75} aria-hidden="true" />{vi ? "Từ trong WordBoard của bạn" : "Words from your WordBoard"}</h2>
          {!!words.length && <p>{vi ? "Đây là những từ có thể xuất hiện trong buổi luyện tập hôm nay." : "These words may appear in today’s practice."}</p>}
        </header>
        {words.length ? (
          <ul className="practice-hub-words">
            {words.map((word) => <li key={word.userWordId} lang="en">{word.word}</li>)}
          </ul>
        ) : (
          <CollectionEmptyState
            icon={BookOpen}
            title={hasWords
              ? vi ? "Định nghĩa đang được chuẩn bị" : "Definitions are being prepared"
              : t("No words yet")}
            description={hasWords
              ? vi ? "Bạn có thể luyện khi các từ đã có nghĩa." : "Practice will be available once the definitions are ready."
              : vi ? "Thêm một từ vào WordBoard để bắt đầu luyện tập." : "Add a word to WordBoard to start practicing."}
          >
            {!hasWords && <Button className="ow-action-primary" onClick={() => navigate("discover")}>{vi ? "Khám phá từ" : "Discover words"}<ArrowRight size={17} aria-hidden="true" /></Button>}
          </CollectionEmptyState>
        )}
        <Link href="/board" prefetch={false} onClick={(event) => {
          if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
          event.preventDefault();
          navigate("board");
        }}>
          {vi ? "Xem toàn bộ WordBoard" : "View all of WordBoard"}<ArrowRight size={17} aria-hidden="true" />
        </Link>
      </section>
    </section>
  );
}
