// Lucian UX/UI Prompt #235 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#235
"use client";

import { useEffect, useRef } from "react";
import type { Evaluation } from "@/lib/domain/types";
import { adjectiveAdverbForm } from "@/lib/llm/evaluation-guards";
import { useI18n } from "./language-provider";
import "@/app/lucian-235-practice.css";

export function sentenceParts(sentence: string, word: string) {
  if (!word) return [{ text: sentence, target: false }];
  const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const adverb = adjectiveAdverbForm(word).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = new RegExp(`\\b(?:${escaped}(?:s|es|ed|ing)?|${adverb})\\b`, "gi");
  const parts: { text: string; target: boolean }[] = [];
  let end = 0;
  for (const match of sentence.matchAll(pattern)) {
    const start = match.index ?? 0;
    if (start > end) parts.push({ text: sentence.slice(end, start), target: false });
    parts.push({ text: match[0], target: true });
    end = start + match[0].length;
  }
  if (end < sentence.length) parts.push({ text: sentence.slice(end), target: false });
  return parts;
}

export function LucianPracticeFeedback({
  sentence,
  word,
  evaluation,
}: {
  sentence: string;
  word: string;
  evaluation: Evaluation;
}) {
  const { t } = useI18n();
  const rootRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const sweepRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLOListElement>(null);
  const headingRef = useRef<HTMLElement>(null);
  const parts = sentenceParts(sentence, word);

  useEffect(() => {
    const root = rootRef.current!;
    const text = textRef.current!;
    const sweep = sweepRef.current!;
    const list = listRef.current!;
    const heading = headingRef.current!;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const spans = Array.from(text.querySelectorAll<HTMLSpanElement>("span[data-target]"));
    const points = [evaluation.feedback, evaluation.nuance].filter(Boolean).map((point) => t(point));
    const timers = new Set<ReturnType<typeof setTimeout>>();
    let frame = 0;
    let generation = 0;

    function later(g: number, ms: number, fn: () => void) {
      const timer = setTimeout(() => {
        timers.delete(timer);
        if (g === generation && root.isConnected) fn();
      }, reduceMotion ? 0 : ms);
      timers.add(timer);
    }
    function write(g: number) {
      list.replaceChildren();
      const lines = points.map(() => {
        const item = document.createElement("li");
        list.appendChild(item);
        return item;
      });
      if (reduceMotion) {
        lines.forEach((line, index) => { line.textContent = points[index]; });
        return;
      }
      let index = 0;
      let character = 0;
      function step() {
        if (g !== generation) return;
        if (index >= points.length) {
          lines.forEach((line) => line.classList.remove("u235-cu"));
          return;
        }
        lines.forEach((line, n) => line.classList.toggle("u235-cu", n === index));
        character++;
        lines[index].textContent = points[index].slice(0, character);
        if (character >= points[index].length) {
          index++;
          character = 0;
          later(g, 160, step);
        } else later(g, 22, step);
      }
      step();
    }
    function summarize() {
      const g = ++generation;
      const height = text.offsetHeight;
      const duration = 1700;
      const start = performance.now();
      if (!reduceMotion) {
        sweep.style.opacity = "1";
        function move(now: number) {
          if (g !== generation) return;
          const progress = Math.min(1, (now - start) / duration);
          sweep.style.transform = `translateY(${(progress * (height + 46)).toFixed(1)}px)`;
          spans.forEach((span) => {
            if (span.dataset.target === "true" && span.offsetTop + 8 < progress * height)
              span.classList.add("is-hl");
          });
          if (progress < 1) frame = requestAnimationFrame(move);
          else sweep.style.opacity = "0";
        }
        frame = requestAnimationFrame(move);
      } else spans.forEach((span) => {
        if (span.dataset.target === "true") span.classList.add("is-hl");
      });
      later(g, duration + 250, () => {
        root.classList.add("is-sum", "is-done");
        text.setAttribute("aria-hidden", "true");
        list.parentElement?.setAttribute("aria-hidden", "false");
        heading.textContent = t("AI feedback on word usage");
      });
      later(g, duration + 650, () => write(g));
    }
    later(generation, 90, summarize);
    return () => {
      generation++;
      cancelAnimationFrame(frame);
      timers.forEach(clearTimeout);
    };
  }, [sentence, word, evaluation.feedback, evaluation.nuance, t]);

  return (
    <div ref={rootRef} className="ux u235 practice-feedback">
      <div className="u235-hd">
        <div><b ref={headingRef}>{t("Reviewing your sentence…")}</b></div>
      </div>
      <div className="u235-bx">
        <div ref={textRef} className="u235-tx" lang="en" aria-hidden="false">
          <div ref={sweepRef} className="u235-sw" aria-hidden="true" />
          {parts.map((part, index) => <span key={index} data-target={String(part.target)}>{part.text}</span>)}
        </div>
        <div className="u235-sm" aria-live="polite" aria-hidden="true">
          <ol ref={listRef} />
        </div>
      </div>
    </div>
  );
}
