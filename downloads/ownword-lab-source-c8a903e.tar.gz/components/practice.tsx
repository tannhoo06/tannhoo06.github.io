"use client";
import { practiceCandidates } from "@/lib/domain/learning";
import { applySpellingHint } from "@/lib/domain/practice-hints";
import { QuickReview } from "./quick-review";
import { PracticeHub } from "./practice-hub";
import { PracticeSetup } from "./practice-setup";
import { WordRecallInput } from "./word-recall-input";
import { LucianPracticeFeedback, sentenceParts } from "./lucian-235-practice-feedback";
import Stepper, { Step } from "./Stepper";
import { useI18n } from "./language-provider";
import { useRequestLimitNotice } from "./request-limit-notice";
import { AnimatePresence, motion } from "motion/react";
import { useMotionTokens, useShouldReduceMotion } from "@animate-ui/react/utils/motion";
import { vietnameseDemoMeanings } from "@/lib/i18n/vocabulary";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import {
  ArrowRight,
  Check,
  ChevronRight,
  Eye,
  Info,
  Lightbulb,
  LoaderCircle,
  RotateCcw,
  Sprout,
} from "lucide-react";
import type {
  AppState,
  Evaluation,
  HintLevel,
  PracticeOutcome,
  PracticeSession,
  PracticeSetupOptions,
  PublicExercise,
} from "@/lib/domain/types";
import { api, Button, ErrorMessage, Loading, recallOnlySessionKey, type Navigate } from "./shared";

type AnswerResult = {
  evaluation: Evaluation;
  retry: boolean;
  target: string | null;
  revealed?: boolean;
  sentencePending?: boolean;
  incorrect?: boolean;
  skipped?: boolean;
};
type Cached = {
  exercise?: PublicExercise;
  answer?: string;
  result?: AnswerResult | null;
  previousAnswer?: string;
};
const outcomeLabels: Record<PracticeOutcome["outcome"], string> = {
  "recalled-used": "Recalled and used in a sentence.",
  "hinted-used": "Recalled with a hint; used in a sentence.",
  "recalled-skipped": "Recalled; sentence skipped.",
  reviewed: "Reviewed; needs more practice.",
};
export function Practice({
  sessionId,
  state,
  begin,
  busy,
  navigate,
  refresh,
  onComplete,
}: {
  sessionId: string | null;
  state: AppState;
  begin: (wordId?: string, quickSessionId?: string, fresh?: boolean, setup?: PracticeSetupOptions) => Promise<boolean>;
  busy: boolean;
  navigate: Navigate;
  refresh: () => Promise<AppState>;
  onComplete: () => void;
}) {
  const { t, locale } = useI18n();
  const { handle: showLimit } = useRequestLimitNotice();
  const { transition } = useMotionTokens();
  const reduceMotion = useShouldReduceMotion();
  const [activeSession, setActiveSession] = useState(sessionId);
  const [exercise, setExercise] = useState<PublicExercise | null>(null);
  const [session, setSession] = useState<PracticeSession | null>(null);
  const [mode, setMode] = useState<"choose" | "quick" | "full">("choose");
  const [started, setStarted] = useState(false);
  const [freshStart, setFreshStart] = useState(false);
  const [recallOnly, setRecallOnly] = useState(false);
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState("");
  const [result, setResult] = useState<AnswerResult | null>(null);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const hintSave = useRef<Promise<boolean>>(Promise.resolve(true));
  const recallSave = useRef<Promise<boolean>>(Promise.resolve(true));
  const optimisticSentence = useRef(false);
  const requestedHint = useRef<HintLevel>("none");
  const savedHint = useRef<{ id: string; hint: HintLevel; hintText: string } | null>(null);
  const activeExerciseId = useRef<string | null>(null);
  const [verified, setVerified] = useState(false);
  const [previousAnswer, setPreviousAnswer] = useState("");
  const [sentenceReview, setSentenceReview] = useState<{ text: string; result: AnswerResult; saved: boolean; key: number } | null>(null);
  const [sentenceHintOpen, setSentenceHintOpen] = useState(false);
  const reviewCount = useRef(0);
  const hintCursorCount = useRef(0);
  const [hintCursor, setHintCursor] = useState<{ id: number; position: number } | null>(null);
  const [now] = useState(() => Date.now());
  const [summaryWord, setSummaryWord] = useState<string | null>(null);
  const restored = useRef(false);
  const input = useRef<HTMLInputElement | HTMLTextAreaElement>(null);
  const recallNext = useRef<HTMLButtonElement>(null);
  const sessionKey = `ownword:session:${state.profile.id}`;
  const cacheKey = `ownword:practice:${state.profile.id}:`;
  const load = useCallback(
    async (id: string, advance = false) => {
      setLoading(true);
      setError("");
      try {
        const data = await api<PracticeSession>(
          `practice?sessionId=${encodeURIComponent(id)}`,
        );
        let cached: Cached | null = null;
        try {
          cached = JSON.parse(sessionStorage.getItem(cacheKey + id) ?? "null");
        } catch {
          /* Fetch remains authoritative. */
        }
        const matching =
          !advance &&
          cached?.exercise?.id === data.exercise?.id &&
          cached?.exercise?.sentencePending ===
            data.exercise?.sentencePending &&
          (cached?.exercise?.hint === "revealed") ===
            (data.exercise?.hint === "revealed");
        setRecallOnly(sessionStorage.getItem(recallOnlySessionKey(id)) === "1");
        setSession(data);
        setExercise(data.exercise);
        activeExerciseId.current = data.exercise?.id ?? null;
        requestedHint.current = data.exercise?.hint ?? "none";
        savedHint.current = data.exercise
          ? { id: data.exercise.id, hint: data.exercise.hint, hintText: data.exercise.hintText ?? "" }
          : null;
        hintSave.current = Promise.resolve(true);
        recallSave.current = Promise.resolve(true);
        optimisticSentence.current = false;
        setVerified(false);
        setSentenceReview(null);
        setSentenceHintOpen(false);
        const resumedAnswer = matching ? (cached?.answer ?? "") : "";
        const savedWord = data.exercise ? (data.words[data.exercise.position - 1]?.word ?? "") : "";
        const savedHintPrefix = applySpellingHint("", data.exercise?.hint ?? "none", savedWord);
        const prefilledAnswer = data.exercise?.sentencePending
          ? (resumedAnswer === savedHintPrefix ? "" : resumedAnswer)
          : applySpellingHint(resumedAnswer, data.exercise?.hint ?? "none", savedWord);
        setAnswer(prefilledAnswer);
        setHintCursor(!data.exercise?.sentencePending && (data.exercise?.hint === "letter" || data.exercise?.hint === "partial")
          ? { id: ++hintCursorCount.current, position: prefilledAnswer.length }
          : null);
        setResult(matching && cached?.result?.retry ? cached.result : null);
        setPreviousAnswer(matching ? (cached?.previousAnswer ?? "") : "");
        restored.current = true;
        if (data.complete) {
          sessionStorage.removeItem(cacheKey + id);
          sessionStorage.removeItem(sessionKey);
          if (window.location.pathname === "/practice") {
            const url = new URL(window.location.href);
            url.searchParams.set("session", id);
            window.history.replaceState({}, "", url);
          }
          onComplete();
          await refresh();
        }
      } catch (e) {
        setError((e as Error).message);
      } finally {
        setLoading(false);
      }
    },
    [refresh, cacheKey, sessionKey, onComplete],
  );
  useEffect(() => {
    const id =
      sessionId ||
      sessionStorage.getItem(sessionKey) ||
      new URLSearchParams(window.location.search).get("session");
    if (!id) return;
    let live = true;
    queueMicrotask(() => {
      if (live) {
        setActiveSession(id);
        void load(id);
      }
    });
    return () => {
      live = false;
    };
  }, [sessionId, load, sessionKey]);
  useEffect(() => {
    if (
      restored.current &&
      activeSession &&
      exercise &&
      !session?.complete &&
      !loading
    ) {
      sessionStorage.setItem(
        cacheKey + activeSession,
        JSON.stringify({ exercise, answer, result, previousAnswer }),
      );
    }
  }, [
    activeSession,
    exercise,
    answer,
    result,
    previousAnswer,
    session?.complete,
    loading,
    cacheKey,
  ]);
  const sentence =
    !!exercise && (exercise.sentencePending || exercise.hint === "revealed");
  const targetWord = exercise ? (session?.words[exercise.position - 1]?.word ?? "") : "";
  const visibleHint = exercise?.hintText?.replace(
    /^It starts with “([^”]+)”\.$/,
    (_, letter: string) => locale === "vi" ? `Bắt đầu bằng “${letter}”.` : `It starts with “${letter}”.`,
  );
  useEffect(() => {
    if (started && !loading) {
      if (sentence && recallOnly) recallNext.current?.focus();
      else input.current?.focus();
    }
  }, [exercise?.id, sentence, recallOnly, started, loading]);
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!exercise || submitting || loading || !answer.trim() || sentenceReview?.saved)
      return;
    const trigger = document.activeElement;
    const submittedAnswer = answer.trim();
    const exactRecall = !sentence && requestedHint.current !== "revealed" &&
      submittedAnswer.replace(/\s+/g, " ").toLocaleLowerCase("en") ===
        targetWord.trim().replace(/\s+/g, " ").toLocaleLowerCase("en");
    if (exactRecall) {
      // The server also checks exact recall without an LLM. Show the sentence
      // step immediately, then persist the hint and recall in that order.
      optimisticSentence.current = true;
      setVerified(true);
      setPreviousAnswer(answer);
      setAnswer("");
      setResult(null);
      setError("");
      setExercise((current) => current?.id === exercise.id
        ? { ...current, sentencePending: true, hintText: targetWord }
        : current);
      window.dispatchEvent(new Event("ownword:mascot-wag"));
      recallSave.current = (async () => {
        try {
          if (!(await hintSave.current)) throw new Error("The hint could not be saved. Please try again.");
          const response = await api<AnswerResult>("practice/answer", {
            exerciseId: exercise.id,
            answer: submittedAnswer,
          });
          if (!response.sentencePending || !response.evaluation.retrieved ||
              response.target?.toLocaleLowerCase("en") !== targetWord.toLocaleLowerCase("en"))
            throw new Error("The answer could not be confirmed. Please try again.");
          return true;
        } catch (cause) {
          if (activeExerciseId.current === exercise.id) {
            optimisticSentence.current = false;
            const confirmed = savedHint.current;
            setExercise((current) => current?.id === exercise.id
              ? { ...exercise, hint: confirmed?.hint ?? "none", hintText: confirmed?.hintText ?? "", sentencePending: false }
              : current);
            setAnswer(applySpellingHint("", confirmed?.hint ?? "none", targetWord));
            setVerified(false);
            setError((cause as Error).message);
          }
          return false;
        }
      })();
      return;
    }
    setSubmitting(true);
    if (sentence) setSentenceReview(null);
    setError("");
    try {
      // Hint credit must reach the server before an answer is graded.
      if (!(await hintSave.current)) return;
      if (!(await recallSave.current)) return;
      if (!sentence && requestedHint.current === "revealed") return;
      setVerified(!sentence && answer.trim().replace(/\s+/g, " ").toLocaleLowerCase("en") === (session?.words[exercise.position - 1]?.word ?? "").trim().replace(/\s+/g, " ").toLocaleLowerCase("en"));
      const response = await api<AnswerResult>("practice/answer", {
        exerciseId: exercise.id,
        answer: answer.trim(),
      });
      if (response.evaluation.retrieved && !sentence) window.dispatchEvent(new Event("ownword:mascot-wag"));
      if (sentence && !response.retry) window.dispatchEvent(new Event("ownword:mascot-wag"));
      if (!response.retry) {
        if (sentence) {
          setSentenceReview({ text: answer.trim(), result: response, saved: true, key: ++reviewCount.current });
          setResult(null);
        } else if (activeSession) await load(activeSession, true);
      } else {
        if (sentence) {
          setSentenceReview({ text: answer.trim(), result: response, saved: false, key: ++reviewCount.current });
        }
        if (
          response.target &&
          (response.sentencePending || response.revealed)
        ) {
          if (!sentence) {
            setVerified(true);
            setPreviousAnswer(answer);
            setAnswer("");
          }
          setExercise({
            ...exercise,
            sentencePending: !!response.sentencePending,
            hint: response.revealed ? "revealed" : exercise.hint,
            hintText: response.target,
          });
        }
        setResult(response);
      }
    } catch (e) {
      setVerified(false);
      if (!showLimit(e, trigger)) setError((e as Error).message);
    } finally {
      setSubmitting(false);
    }
  }
  async function skipSentence() {
    if (!exercise || submitting || loading) return;
    setSubmitting(true);
    setError("");
    try {
      if (!(await hintSave.current)) return;
      if (!(await recallSave.current)) return;
      await api("practice/skip", { exerciseId: exercise.id });
      if (activeSession) await load(activeSession, true);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSubmitting(false);
    }
  }
  function hint(reveal = false) {
    if (!exercise || submitting || loading || sentence || requestedHint.current === "revealed") return;
    const previousHint = requestedHint.current;
    const level = reveal
      ? "revealed"
      : previousHint === "none" || previousHint === "semantic"
        ? "letter"
        : previousHint === "letter"
          ? "partial"
          : "revealed";
    const exerciseId = exercise.id;
    requestedHint.current = level;
    const optimisticText = level === "letter"
      ? `It starts with “${targetWord[0] ?? ""}”.`
      : level === "partial"
        ? `${targetWord.slice(0, 3)}${"_".repeat(Math.max(0, targetWord.length - 3))}`
        : targetWord;
    setExercise((current) => current?.id === exerciseId
      ? { ...current, hint: level, hintText: optimisticText }
      : current);
    if (level !== "revealed") {
      setAnswer((current) => applySpellingHint(current, level, targetWord));
      setHintCursor({ id: ++hintCursorCount.current, position: Math.max(answer.length, level === "letter" ? 1 : 3) });
    }
    setResult(null);
    setVerified(false);
    if (level === "revealed") {
      setPreviousAnswer(answer);
      setAnswer("");
    }
    setError("");
    window.dispatchEvent(new Event("ownword:mascot-wag"));
    // Serialize rapid hint/reveal clicks so the server stores the strongest
    // requested level. The controls stay usable while the requests settle.
    hintSave.current = hintSave.current.then(async () => {
      try {
        const response = await api<{ hint: HintLevel; hintText: string }>(
          "practice/hint",
          { exerciseId, level },
        );
        if (activeExerciseId.current !== exerciseId) return true;
        savedHint.current = { id: exerciseId, ...response };
        if (requestedHint.current === level) {
          setExercise((current) => current?.id === exerciseId ? { ...current, ...response } : current);
          if (response.hint !== "revealed" && !optimisticSentence.current)
            setAnswer((current) => applySpellingHint(current, response.hint, targetWord));
          input.current?.focus();
        }
        return true;
      } catch (e) {
        if (activeExerciseId.current === exerciseId && requestedHint.current === level) {
          const confirmed = savedHint.current;
          requestedHint.current = confirmed?.hint ?? "none";
          setExercise((current) => current?.id === exerciseId && confirmed
            ? { ...current, hint: confirmed.hint, hintText: confirmed.hintText }
            : current);
          if (!optimisticSentence.current)
            setAnswer(applySpellingHint("", confirmed?.hint ?? "none", targetWord));
          setError((e as Error).message);
        }
        return false;
      }
    });
  }
  if (mode === "quick")
    return (
      <QuickReview
        state={state}
        back={() => setMode("choose")}
        full={async (id) => {
          if (await begin(undefined, id)) {
            setSession(null);
            setExercise(null);
            setRecallOnly(false);
            setMode("full");
            setStarted(true);
          }
        }}
      />
    );
  if (mode === "choose")
    return (
      <PracticeHub
        state={state}
        now={now}
        navigate={navigate}
        onQuick={() => {
          setMode("quick");
          window.scrollTo({ top: 0 });
        }}
        onFull={() => {
          setFreshStart(true);
          setMode("full");
          window.scrollTo({ top: 0 });
        }}
        onResume={activeSession && !session?.complete ? () => {
          setFreshStart(false);
          setMode("full");
          window.scrollTo({ top: 0 });
        } : undefined}
      />
    );
  const finish = session?.complete && (!freshStart || started);
  // Reloading a completed session retains the server-derived recap.
  if (finish)
    return (
      <div className="session-finish finish-v2">
        <span className="finish-symbol"><Sprout size={44} strokeWidth={1.4} aria-hidden="true" /></span>
        <h1>{t("Practice complete")}</h1>
        <p>
          {t("You practiced {count} words today.", {
            count: session.results.length,
          })}{" "}
          {t("Coming back after a little time helps them stay.")}
        </p>
        <section className="practice-recap" aria-label={t("Practice summary")}>
          <header>
            <h2>{t("Practice summary")}</h2>
            <span>
              {t("{count} words practiced", { count: session.results.length })}
            </span>
          </header>
          <div className="recap-summary">
            <p><strong>{locale === "vi" ? "Nhớ từ" : "Recall"}</strong><span>{session.results.filter((item) => item.outcome === "recalled-used" || item.outcome === "recalled-skipped").length} / {session.results.length} {recallOnly ? locale === "vi" ? "từ nhớ được" : "words recalled" : locale === "vi" ? "từ nhớ được không cần gợi ý" : "words recalled without a hint"}</span></p>
            {!recallOnly && <p><strong>{locale === "vi" ? "Đặt câu" : "Sentence use"}</strong><span>{session.results.filter((item) => item.outcome === "recalled-used" || item.outcome === "hinted-used").length} / {session.results.length} {locale === "vi" ? "từ được dùng trong câu" : "words used in a sentence"}</span></p>}
          </div>
          <details className="recap-disclosure"><summary>{locale === "vi" ? "Xem từng từ" : "Review each word"}</summary>
          <div className="recap-rows">
            {session.results.map((item) => {
              const recalled = recallOnly && item.outcome === "recalled-skipped";
              const success = item.outcome === "recalled-used" || recalled;
              const outcome = recalled ? locale === "vi" ? "Đã nhớ từ." : "Recalled." : t(outcomeLabels[item.outcome]);
              const word = state.words.find(
                (w) => w.userWordId === item.userWordId,
              );
              return (
                <div key={item.userWordId}>
                  <button
                    className={`recap-row ${success ? "is-recalled" : "needs-practice"}`}
                    aria-expanded={summaryWord === item.userWordId}
                    onClick={() =>
                      setSummaryWord(
                        summaryWord === item.userWordId
                          ? null
                          : item.userWordId,
                      )
                    }
                  >
                    <span className="recap-icon">
                      {success ? <Check size={24} /> : <RotateCcw size={23} />}
                    </span>
                    <strong lang="en">{item.word}</strong>
                    <span className="recap-outcome">
                      {outcome}
                    </span>
                    <ChevronRight size={20} aria-hidden="true" />
                  </button>
                  {summaryWord === item.userWordId && (
                    <div className="recap-detail">
                      <p lang="en">{word?.definition}</p>
                      <p>{outcome}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          </details>
          <p className="recap-note">
            <Info size={18} aria-hidden="true" />
            {t(
              "These words will return later if they still need reinforcement.",
            )}
          </p>
        </section>
        {error && (
          <ErrorMessage
            message={error}
            retry={activeSession ? () => load(activeSession) : undefined}
          />
        )}
        <div className="finish-actions">
          <Button
            onClick={async () => {
              setSession(null);
              setActiveSession(null);
              setStarted(false);
              setMode("choose");
              window.history.replaceState({}, "", "/practice");
            }}
          >
            {t("Practice again")}
          </Button>
          <Button className="button-accent" onClick={() => navigate("board")}>
            {t("Go to WordBoard")}
            <ArrowRight size={18} />
          </Button>
        </div>
      </div>
    );
  if (!started) {
    const resuming = !freshStart && !!activeSession;
    const words = resuming
      ? session?.words ?? []
      : practiceCandidates(state.words, new Date(now), state.profile.dailyLimit);
    return (
      <PracticeSetup
        key={resuming ? activeSession : "new-session"}
        words={words}
        resuming={resuming}
        sessionWriting={!recallOnly}
        busy={busy}
        loading={resuming && !error && (loading || !session)}
        preparing={!!state.words.length}
        error={resuming ? error : ""}
        onRetry={resuming ? () => load(activeSession) : undefined}
        onBack={() => setMode("choose")}
        onDiscover={() => navigate("discover")}
        onStart={async (setup) => {
          if (setup && !(await begin(undefined, undefined, true, setup))) return;
          if (setup) {
            setSession(null);
            setExercise(null);
            setRecallOnly(!setup.includeWriting);
          }
          setStarted(true);
          window.scrollTo({ top: 0 });
        }}
      />
    );
  }
  if (!exercise)
    return (
      <div className="practice-space practice-v2">
        {error ? (
          <ErrorMessage
            message={error}
            retry={activeSession ? () => load(activeSession) : begin}
          />
        ) : (
          <Loading text="Loading your practice…" />
        )}
      </div>
    );
  const failed = !!result?.incorrect;
  const alternative = result?.evaluation.validAlternative;
  const disabled = submitting || loading;
  return (
    <div className={`practice-space practice-v2 ${sentence ? "sentence-mode" : ""} ${sentenceReview && sentence ? "has-review" : ""}`}>
      <div className="practice-progress-row">
        <Stepper
          className="practice-stepper"
          step={sentence ? 2 : 1}
          indicator="bars"
          stepLabel={locale === "vi" ? "Bước" : "Step"}
          showFooter={false}
          disableStepIndicators
          frame={false}
          width="100%"
          theme="light"
          accentColor="#326044"
          contentClassName="practice-stepper-content"
          aria-label={t("Practice progress")}
        >
          <Step title={locale === "vi" ? "Nhớ từ" : "Recall"} />
          {!recallOnly && <Step title={locale === "vi" ? "Đặt câu" : "Sentence"} />}
          <Step title={t("Next word")} />
        </Stepper>
        <span>
          {t("Word {position} of {total}", {
            position: exercise.position,
            total: exercise.total,
          })}
        </span>
      </div>
      <AnimatePresence mode="wait" initial={false}>
      <motion.div key={`${exercise.id}-${sentence ? "sentence" : "recall"}`} initial={{ opacity: 0, y: reduceMotion ? 0 : 8 }} animate={{ opacity: 1, y: 0, transition: transition.panelIn }} exit={{ opacity: 0, y: reduceMotion ? 0 : -8, transition: transition.panelOut }}>
      {sentence ? (
        <>
          <div
            className={`recall-result ${exercise.hint === "revealed" ? "was-revealed" : "was-recalled"}`}
            role="status"
          >
            <span className="recall-success-symbol">
              {exercise.hint === "revealed" ? (
                <Eye size={26} />
              ) : (
                <svg className="recall-success-check" viewBox="0 0 48 48" aria-hidden="true">
                  <circle cx="24" cy="24" r="20" />
                  <path d="M13 24l7 7 15-16" />
                </svg>
              )}
            </span>
            <div>
              <h2>
                {exercise.hint === "revealed"
                  ? t("Answer: {word}", { word: exercise.hintText ?? "" })
                  : exercise.hintText}
              </h2>
              {exercise.hint === "revealed" ? (
                <p lang="en">{exercise.definition}</p>
              ) : (
                <p>{t("Correct!")}</p>
              )}
              {result?.evaluation.spellingCorrection && (
                <p>
                  {t("Right word; check the spelling")}:{" "}
                  {result.evaluation.spellingCorrection}
                </p>
              )}
            </div>
          </div>
          {!recallOnly && <div className="exercise-heading">
            <h1>{t("Use it in a sentence")}</h1>
            <p>
              {t("Write a complete sentence using")}{" "}
              <mark className="practice-target-word" lang="en">{targetWord}</mark>
            </p>
          </div>}
        </>
      ) : (
        <>
          {(failed || alternative) && (
            <div className="recall-recovery" role="status">
              <h2>
                {t(alternative ? "Another word also works" : "Not quite.")}
              </h2>
              <p>
                {alternative
                  ? t(result!.evaluation.feedback)
                  : t("Try again, get a hint, or reveal the word.")}
              </p>
            </div>
          )}
          <div className="exercise-heading">
            <span className="task-label">
              {t("Which word fits this meaning?")}
            </span>
            <h1 lang="en">
              {exercise.definition ??
                exercise.prompt.replace(
                  /^Bring to mind a word meaning:\\s*/i,
                  "",
                )}
            </h1>
            {exercise.definition &&
              vietnameseDemoMeanings[exercise.definition] && (
                <details className="practice-translation" key={exercise.id}>
                  <summary>{t("Show Vietnamese meaning")}</summary>
                  <p lang="vi">{vietnameseDemoMeanings[exercise.definition]}</p>
                </details>
              )}
          </div>
        </>
      )}
      </motion.div>
      </AnimatePresence>
      <motion.div layout={sentence ? "position" : false} transition={{ layout: { duration: reduceMotion ? 0 : 0.38, ease: "easeOut" } }} className={sentence ? `sentence-workspace ${sentenceReview ? "has-feedback" : ""}` : "recall-workspace"}>
      {sentence && recallOnly ? (
        <div className="practice-recall-next">
          {error && <ErrorMessage message={error} retry={activeSession ? () => load(activeSession) : undefined} />}
          <button type="button" ref={recallNext} className="sentence-next" disabled={disabled} onClick={skipSentence}>
            {exercise.position === exercise.total ? t("Finish this session") : t("Next word")}
            <ArrowRight size={17} aria-hidden="true" />
          </button>
        </div>
      ) : (sentence || !sentenceReview?.saved) && <motion.form layout={sentence ? "position" : false} onSubmit={submit} className={sentence ? "sentence-form" : "recall-form"}>
        {sentence ? <span className="sentence-field-label">{t("Your sentence")}</span> : <label htmlFor="practice-answer" className="sr-only">{t("Your answer")}</label>}
        {sentence && sentenceReview?.saved ? (
          <p className="sentence-written" lang="en">
            {sentenceParts(sentenceReview.text, targetWord).map((part, index) => part.target
              ? <mark key={index}>{part.text}</mark>
              : <span key={index}>{part.text}</span>)}
          </p>
        ) : sentence ? (
          <input
            id="practice-answer"
            ref={(el) => {
              input.current = el;
            }}
            lang="en"
            value={answer}
            onChange={(e) => {
              setAnswer(e.target.value);
              setResult(null);
            }}
            aria-invalid={failed || undefined}
            placeholder={t(
              sentence
                ? "Write your sentence in English…"
                : "Enter the English word…",
            )}
            className={`practice-answer ${sentence ? "sentence-answer" : "recall-answer"}`}
            aria-label={t("Your sentence")}
            maxLength={2000}
            disabled={submitting || loading}
          />
        ) : (
          <WordRecallInput
            id="practice-answer"
            word={targetWord}
            value={answer}
            onChange={(next) => {
              setAnswer(next);
              setResult(null);
            }}
            inputRef={(element) => {
              input.current = element;
            }}
            hint={exercise.hint}
            hintText={visibleHint ? t(visibleHint) : undefined}
            checking={submitting && !verified}
            verified={verified}
            incorrect={failed}
            disabled={submitting || loading}
            label={t("Enter the English word…")}
            cursorRequest={hintCursor}
          />
        )}
        {error && (
          <ErrorMessage
            message={error}
            retry={activeSession ? () => load(activeSession) : undefined}
          />
        )}
        {sentence && submitting && <p className="sentence-analyzing" role="status"><LoaderCircle size={16} aria-hidden="true" />{t("Analyzing your sentence…")}</p>}
        {sentence ? (!sentenceReview?.saved &&
          <div className="practice-actions">
            <div className="sentence-help">
              <button type="button" className="sentence-hint-trigger" aria-expanded={sentenceHintOpen} onClick={() => setSentenceHintOpen(!sentenceHintOpen)}>
                <Lightbulb size={17} aria-hidden="true" />
                {t("Hint")}
              </button>
              {sentenceHintOpen && <div className="sentence-hint-content">
                <p>{t("Try a different situation or topic.")}</p>
                <p lang="en">{state.words.find((w) => w.word === targetWord)?.collocations.join(" · ")}</p>
              </div>}
            </div>
            <button type="button" className="sentence-skip" onClick={skipSentence} disabled={disabled}>
              {t("Skip this step")}
            </button>
            <button
              className="sentence-check"
              type="submit"
              disabled={disabled || !answer.trim()}
            >
              {t("Check sentence")}
              <ArrowRight size={17} />
            </button>
          </div>
        ) : (
          <div className="practice-actions">
            <div className="recall-help-actions">
              <button type="button" className="recall-hint-trigger" disabled={disabled} onClick={() => hint()}>
                <Lightbulb size={17} aria-hidden="true" />
                {t("Hint")}
              </button>
              <button type="button" className="recall-reveal-trigger" disabled={disabled} onClick={() => hint(true)}><Eye size={16} aria-hidden="true" />{t("Reveal word")}</button>
            </div>
            <Button className="button-accent" type="submit" disabled={disabled || !answer.trim()}>
              {t("Check")}
              <ArrowRight size={17} />
            </Button>
          </div>
        )}
      </motion.form>}
      {sentenceReview && sentence && (
        <section className="sentence-review" aria-label={t("Sentence feedback")}>
          <p className={`sentence-verdict ${sentenceReview.result.evaluation.precise && !sentenceReview.result.evaluation.majorMisuse ? "is-good" : "needs-work"}`} role="status">
            {sentenceReview.result.evaluation.precise && !sentenceReview.result.evaluation.majorMisuse
              ? t("That sentence uses the word well.")
              : t("This use needs another try.")}
          </p>
          <LucianPracticeFeedback
            key={sentenceReview.key}
            sentence={sentenceReview.text}
            word={targetWord}
            evaluation={sentenceReview.result.evaluation}
          />
          {sentenceReview.saved && (
            <Button className="sentence-next" disabled={loading} onClick={() => activeSession && void load(activeSession, true)}>
              {exercise.position === exercise.total ? t("Finish this session") : t("Next word")}
              <ArrowRight size={17} />
            </Button>
          )}
        </section>
      )}
      </motion.div>
      {!!previousAnswer && !sentence && (
        <details className="previous-attempt">
          <summary>{t("Your previous attempt")}</summary>
          <p lang="en">{previousAnswer}</p>
        </details>
      )}
      <button
        className="text-button practice-exit"
        onClick={() => navigate("board")}
      >
        {t("Pause practice")}
      </button>
    </div>
  );
}
