// Lucian UX/UI Prompt #379 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#379
"use client";

import { useEffect, useId, useLayoutEffect, useRef, useState, type CSSProperties } from "react";
import { onStreakAward, onStreakDetails, openStreakDetails } from "@/lib/client/learning-streak";
import { learningDay, type LearningStreak } from "@/lib/domain/learning-streak";
import { useI18n } from "./language-provider";
import "./lucian-379-streak.css";

const layers = [
  { width: 40, height: 126, phase: 0, sway: 1 },
  { width: 28, height: 88, phase: 1.7, sway: 0.8 },
  { width: 15, height: 48, phase: 3.1, sway: 0.55 },
];
const profile = [[0.05, 0.6], [0.19, 0.96], [0.37, 1], [0.55, 0.8], [0.71, 0.52], [0.85, 0.26]];

function flameOutline(layer: typeof layers[number], time: number, flare: number) {
  const center = 60;
  const base = 138;
  const width = layer.width * (1 + flare * 0.08);
  const height = layer.height * (1 + flare * 0.2);
  const { phase, sway } = layer;
  const shift = (fraction: number) =>
    (Math.sin(time * 1.7 + phase) * 0.6 + Math.sin(time * 2.9 + phase * 2) * 0.4) *
    height * 0.13 * sway * fraction ** 1.5;
  const right = profile.map(([fraction, radius]) => [
    center + radius * width + shift(fraction) + Math.sin(time * 6.1 + fraction * 7 + phase) * width * 0.07 * fraction,
    base - fraction * height,
  ]);
  const left = profile.map(([fraction, radius]) => [
    center - radius * width + shift(fraction) - Math.sin(time * 5.3 + fraction * 6 + phase + 2) * width * 0.07 * fraction,
    base - fraction * height,
  ]).reverse();
  const tip = [
    center + shift(1) + Math.sin(time * 4.3 + phase) * width * 0.12,
    base - height * (1 + Math.sin(time * 5.2 + phase) * 0.035),
  ];
  const points = [[center, base], ...right, tip, tip, ...left];
  const size = points.length;
  const curves = points.map((point, index) => {
    const previous = points[(index - 1 + size) % size];
    const next = points[(index + 1) % size];
    const after = points[(index + 2) % size];
    return "C" + [
      point[0] + (next[0] - previous[0]) / 6, point[1] + (next[1] - previous[1]) / 6,
      next[0] - (after[0] - point[0]) / 6, next[1] - (after[1] - point[1]) / 6, ...next,
    ].map((value) => value.toFixed(1)).join(" ");
  });
  return "M60 138 " + curves.join(" ") + "Z";
}

const restPaths = layers.map((layer) => flameOutline(layer, 0, 0));

function StreakFlame({ motion = "still" }: { motion?: "still" | "idle" | "celebration" }) {
  const id = useId();
  const flame = useRef<SVGSVGElement>(null);
  useEffect(() => {
    if (motion === "still" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const paths = flame.current?.querySelectorAll("path");
    if (!paths) return;
    let start: number | undefined;
    let frame = requestAnimationFrame(paint);
    function paint(now: number) {
      start ??= now;
      const elapsed = now - start;
      const flare = motion === "celebration" ? Math.max(0, 1 - elapsed / 1500) : 0;
      paths?.forEach((path, index) => path.setAttribute("d", flameOutline(layers[index], elapsed / 1800, flare)));
      frame = requestAnimationFrame(paint);
    }
    return () => {
      cancelAnimationFrame(frame);
      paths.forEach((path, index) => path.setAttribute("d", restPaths[index]));
    };
  }, [motion]);

  return (
      <svg ref={flame} className="u379-fl" viewBox="0 0 120 144" aria-hidden="true">
        <defs>
          <linearGradient id={id + "-outer"} x1="0" y1="1" x2="0" y2="0"><stop stopColor="#f47772" /><stop offset="1" stopColor="#e44e56" /></linearGradient>
          <linearGradient id={id + "-inner"} x1="0" y1="1" x2="0" y2="0"><stop stopColor="#ffb5a7" /><stop offset="1" stopColor="#fa8984" /></linearGradient>
          <linearGradient id={id + "-core"} x1="0" y1="1" x2="0" y2="0"><stop stopColor="#fff2ed" /><stop offset="1" stopColor="#ffc5bb" /></linearGradient>
        </defs>
        {["outer", "inner", "core"].map((layer, index) =>
          <path key={layer} fill={`url(#${id}-${layer})`} d={restPaths[index]} />)}
      </svg>
  );
}

function streakTitle(count: number, vi: boolean) {
  return vi ? `Chuỗi ${count} ngày` : `${count}-day streak`;
}

type StreakPopup = { mode: "celebration"; streak: LearningStreak }
  | { mode: "details"; streak?: LearningStreak; unavailable?: boolean };

function visibleStreakOrigin() {
  for (const selector of ["[data-streak-trigger] .u379-fl", ".ownword-shell .shell-menu-trigger"]) {
    const bounds = document.querySelector(selector)?.getBoundingClientRect();
    if (bounds && bounds.width > 0 && bounds.height > 0 &&
      bounds.right > 0 && bounds.left < window.innerWidth &&
      bounds.bottom > 0 && bounds.top < window.innerHeight) return bounds;
  }
}

export function LucianStreak({ streak, vi }: { streak?: LearningStreak; vi: boolean }) {
  const today = streak?.week[streak.todayIndex] ?? false;
  const label = streak?.count ? streakTitle(streak.count, vi) : (vi ? "Chuỗi luyện tập" : "Learning streak");
  return (
    <button className="ux u379" type="button" aria-haspopup="dialog" aria-label={label} title={label}
      data-streak-trigger data-practiced={today} onClick={() => openStreakDetails(streak)}>
      <StreakFlame />
      <span className="u379-ct">
        <strong>{label}</strong>
        {streak && <small>{today ? (vi ? "Đã luyện tập hôm nay" : "Practiced today") :
          (vi ? "Hoàn thành một hoạt động hôm nay" : "Complete an activity today")}</small>}
      </span>
    </button>
  );
}

export function StreakCelebration() {
  const [popup, setPopup] = useState<StreakPopup>();
  const modal = useRef<HTMLDialogElement>(null);
  const pending = useRef<AbortController | null>(null);
  const title = useId();
  const description = useId();
  const { locale } = useI18n();
  const vi = locale === "vi";
  const open = popup !== undefined;
  const celebrating = popup?.mode === "celebration";
  const streak = popup?.streak;
  const count = streak?.count ?? 0;
  const today = streak?.week[streak.todayIndex] ?? false;
  const heading = count ? streakTitle(count, vi) : (vi ? "Chuỗi luyện tập" : "Learning streak");
  let status = vi ? "Đang tải chuỗi luyện tập…" : "Loading your streak…";
  if (streak) {
    status = today
      ? (vi ? "Chuỗi hôm nay đã được ghi nhận." : "Today’s streak is recorded.")
      : (vi ? "Hoàn thành một hoạt động học tập để ghi nhận hôm nay." : "Complete a learning activity to record today’s streak.");
  } else if (popup?.mode === "details" && popup.unavailable) {
    status = vi ? "Chưa tải được chuỗi luyện tập. Hãy thử lại." : "Couldn’t load your streak. Try opening it again.";
  }

  useEffect(() => {
    const unsubscribeAward = onStreakAward((streak) => {
      pending.current?.abort();
      setPopup({ mode: "celebration", streak });
    });
    const unsubscribeDetails = onStreakDetails((streak) => {
      pending.current?.abort();
      const request = new AbortController();
      pending.current = request;
      const current = streak?.day === learningDay(new Date()) ? streak : undefined;
      setPopup({ mode: "details", streak: current });
      void (async () => {
        try {
          const response = await fetch("/api/learning/streak", { cache: "no-store", signal: request.signal });
          if (!response.ok) throw new Error("Streak request failed.");
          const latest: LearningStreak = await response.json();
          if (!request.signal.aborted) setPopup({ mode: "details", streak: latest });
        } catch {
          if (!request.signal.aborted && !current) setPopup({ mode: "details", unavailable: true });
        }
      })();
    });
    return () => {
      pending.current?.abort();
      unsubscribeAward();
      unsubscribeDetails();
    };
  }, []);
  useLayoutEffect(() => {
    const dialog = modal.current;
    if (!open || !dialog || dialog.open) return;
    const origin = visibleStreakOrigin();
    dialog.showModal();
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const destination = dialog.getBoundingClientRect();
    let from: Keyframe = { opacity: 0 };
    if (origin) {
      const x = origin.left + origin.width / 2 - (destination.left + destination.width / 2);
      const y = origin.top + origin.height / 2 - (destination.top + destination.height / 2);
      from = { opacity: .2, transform: `translate(${x}px, ${y}px) scale(.18)` };
    }
    const animation = dialog.animate([from, { opacity: 1, transform: "none" }], {
      duration: 560,
      easing: "cubic-bezier(.25, .75, .3, 1)",
    });
    return () => animation.cancel();
  }, [open]);

  return <dialog ref={modal} className="u379-celebration" data-mode={popup?.mode}
    data-practiced={today} aria-labelledby={title} aria-describedby={description} onClose={() => {
      pending.current?.abort();
      setPopup(undefined);
    }}>
    {popup && <div className="u379-celebration-content" key={popup.mode}>
      {streak?.week.every(Boolean) && <span className="u379-week-badge">{vi ? "Trọn tuần!" : "Full week!"}</span>}
      <div className="u379-fire" style={{ "--flame-size": .8 + Math.min(7, count) * .05 } as CSSProperties}>
        <StreakFlame motion={celebrating ? "celebration" : today ? "idle" : "still"} />
        {celebrating && <div className="u379-sparks" aria-hidden="true">
          {Array.from({ length: Math.min(7, 2 + count) }, (_, index) =>
            <i key={index} style={{ "--spark-index": index, "--spark-drift": `${(index - 3) * 12}px` } as CSSProperties} />)}
        </div>}
      </div>
      <h2 id={title} aria-label={heading}>
        {count === 0 ? heading : <>
          {vi && <span aria-hidden="true">Chuỗi</span>}
          {celebrating ? <span className="u379-count-window" aria-hidden="true">
            <span className="u379-count u379-count-roll"><span>{count - 1}</span><span>{count}</span></span>
          </span> : <span className="u379-count" aria-hidden="true">{count}</span>}
          <span aria-hidden="true">{vi ? "ngày" : "day streak"}</span>
        </>}
      </h2>
      <p id={description} className="u379-status" aria-live="polite">{status}</p>
      {streak && <ul className="u379-week" aria-label={vi ? "Hoạt động tuần này" : "This week’s activity"}>
        {(vi ? ["T2", "T3", "T4", "T5", "T6", "T7", "CN"] : ["M", "T", "W", "T", "F", "S", "S"]).map((label, index) =>
          <li key={index} data-complete={streak.week[index]} aria-current={index === streak.todayIndex ? "date" : undefined}>
            <span>{label}</span>
            <span className="u379-day-check" aria-hidden="true" />
            {streak.week[index] && <span className="sr-only">{vi ? "Đã hoàn thành" : "Completed"}</span>}
          </li>)}
      </ul>}
      <form method="dialog">
        <button type="submit" autoFocus>{celebrating ? (vi ? "Tiếp tục" : "Continue") : (vi ? "Đóng" : "Close")}</button>
      </form>
    </div>}
  </dialog>;
}
