"use client";

import { RequestError } from "@/lib/client/request-error";
import { useI18n } from "./language-provider";
import { useConfirmAction } from "./lucian-269-confirmation";

export function useRequestLimitNotice() {
  const { t, dateLocale } = useI18n();
  const confirm = useConfirmAction();

  function withReset(message: string, resetAt?: string) {
    const time = resetAt ? Date.parse(resetAt) : NaN;
    if (!Number.isFinite(time)) return message;
    const date = new Intl.DateTimeFormat(dateLocale, { dateStyle: "medium", timeStyle: "short" }).format(time);
    return message + " " + t("You can try again after {time}.", { time: date });
  }

  function show(message: string, resetAt?: string, title = "Daily limit reached", returnFocusTo?: Element | null) {
    return confirm({
      title: t(title),
      message: withReset(message, resetAt),
      confirmLabel: t("Close"),
      notice: true,
      returnFocusTo,
    });
  }

  function handle(error: unknown, returnFocusTo?: Element | null) {
    if (!(error instanceof RequestError) || !error.limit) return false;
    void show(t(error.message), error.resetAt, error.limit === "service_daily_limit" ? "Daily capacity reached" : undefined, returnFocusTo);
    return true;
  }

  return { handle, show, withReset };
}
