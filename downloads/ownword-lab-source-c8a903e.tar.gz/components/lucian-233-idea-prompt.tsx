// Lucian UX/UI Prompt #233 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#233
"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp } from "lucide-react";
import { useReducedMotion } from "motion/react";
import { useI18n } from "./language-provider";
import "@/app/lucian-233-idea-prompt.css";

const examplesByLanguage = {
  en: ["A plan that’s easy to change", "Very tired after a long day", "Make a small problem sound worse"],
  vi: ["Một kế hoạch dễ thay đổi", "Rất mệt sau một ngày dài", "Nói quá lên về một chuyện nhỏ"],
};

export function LucianIdeaPrompt({ value, onChange, onSubmit, busy, disabled }: {
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  busy: boolean;
  disabled: boolean;
}) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const examples = examplesByLanguage[locale];
  const reduceMotion = useReducedMotion();
  const [placeholder, setPlaceholder] = useState("");
  const typingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const textarea = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (value || busy) return;
    let example = 0, position = 0, direction = 1;
    let timer: ReturnType<typeof setTimeout>;
    const tick = () => {
      if (reduceMotion) {
        setPlaceholder(examples[example]);
        example = (example + 1) % examples.length;
        timer = setTimeout(tick, 2600);
        return;
      }
      position += direction;
      setPlaceholder(examples[example].slice(0, position));
      let wait = 55;
      if (direction > 0 && position >= examples[example].length) { direction = -1; wait = 1500; }
      else if (direction < 0 && position <= 0) { direction = 1; example = (example + 1) % examples.length; wait = 350; }
      else if (direction < 0) wait = 22;
      timer = setTimeout(tick, wait);
    };
    tick();
    return () => clearTimeout(timer);
  }, [value, busy, reduceMotion, examples]);
  useEffect(() => () => { if (typingTimer.current) clearTimeout(typingTimer.current); }, []);

  function fillExample(text: string) {
    if (typingTimer.current) clearTimeout(typingTimer.current);
    if (reduceMotion) { onChange(text); textarea.current?.focus(); return; }
    let position = 0;
    onChange("");
    const type = () => {
      onChange(text.slice(0, ++position));
      if (position < text.length) typingTimer.current = setTimeout(type, 28);
      else textarea.current?.focus();
    };
    type();
  }

  return (
    <section className={`u233 idea-prompt${busy ? " is-run" : ""}`} aria-label={vi ? "Mô tả ý tưởng" : "Describe your idea"}>
      <div className="u233-g">
        <h2 className="u233-h">{vi ? "Bạn muốn nói điều gì?" : "What are you trying to say?"}</h2>
        <div className="u233-bx"><div className="u233-in">
          <textarea ref={textarea} className="u233-tx" value={value} onChange={(event) => onChange(event.target.value)} maxLength={500} rows={3} aria-label={vi ? "Điều bạn muốn nói" : "What you’re trying to say"} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); if (!disabled) onSubmit(); } }} />
          {!value && <span className="u233-ph" aria-hidden="true">{placeholder}</span>}
          <button className="u233-go" type="button" onClick={onSubmit} disabled={disabled} aria-label={busy ? (vi ? "Đang tìm từ" : "Finding words") : (vi ? "Tìm từ" : "Find words")}><ArrowUp aria-hidden="true" /><span className="u233-sp" /></button>
        </div></div>
        <div className="u233-chs" role="group" aria-label={vi ? "Ý tưởng mẫu" : "Example ideas"}>
          {examples.map((example) => <button key={example} className="u233-ch" type="button" onClick={() => fillExample(example)} lang={locale}>{example}</button>)}
        </div>
      </div>
      {busy && <div className="u233-gen" aria-live="polite">
        <div className="u233-gh"><i aria-hidden="true" /><span>{vi ? "Đang tìm từ phù hợp" : "Finding suitable words"}</span></div>
        <p className="u233-gs">{vi ? "Đang cân nhắc ý nghĩa và cách dùng…" : "Checking meaning and usage…"}</p>
        <div className="u233-ln" style={{ width: "92%" }} /><div className="u233-ln" style={{ width: "74%" }} /><div className="u233-ln" style={{ width: "84%" }} />
      </div>}
    </section>
  );
}
