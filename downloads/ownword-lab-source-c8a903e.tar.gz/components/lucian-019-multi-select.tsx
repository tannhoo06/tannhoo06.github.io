// Lucian UX/UI Prompt #019 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#019
"use client";

import { useEffect, useId, useRef, useState } from "react";
import "./lucian-019-multi-select.css";

export function InterestChips<Id extends string>({
  options, selected, onChange, title, hint, limitMessage, fullMessage,
}: {
  options: { id: Id; label: string }[];
  selected: readonly Id[];
  onChange: (next: Id[]) => void;
  title: string;
  hint: string;
  limitMessage: string;
  fullMessage: string;
}) {
  const max = 2;
  const hintId = useId();
  const root = useRef<HTMLDivElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [warning, setWarning] = useState(false);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);

  return (
    <div ref={root} className={`ux u019${warning ? " is-warn" : ""}`}>
      <div className="u019-head">
        <div><b>{title}</b><small id={hintId}>{hint}</small></div>
        <span className="u019-cnt"><span className="u019-dots" aria-hidden="true">
          <i className={selected.length > 0 ? "on" : undefined} />
          <i className={selected.length > 1 ? "on" : undefined} />
        </span><span className="u019-n">{selected.length}/{max}</span></span>
      </div>
      <div className="u019-list" role="group" aria-label={title} aria-describedby={hintId}>
        {options.map(({ id, label }) => {
          const pressed = selected.includes(id);
          return <button key={id} type="button" className="u019-chip" aria-pressed={pressed} onClick={(event) => {
            if (!pressed && selected.length >= max) {
              const button = event.currentTarget;
              button.classList.remove("is-no");
              void button.offsetWidth;
              button.classList.add("is-no");
              root.current?.classList.remove("is-warn");
              void root.current?.offsetWidth;
              root.current?.classList.add("is-warn");
              setWarning(true);
              if (timer.current) clearTimeout(timer.current);
              timer.current = setTimeout(() => setWarning(false), 1600);
              return;
            }
            if (timer.current) clearTimeout(timer.current);
            setWarning(false);
            onChange(pressed ? selected.filter((choice) => choice !== id) : [...selected, id]);
          }}>
            <i aria-hidden="true"><svg viewBox="0 0 16 16"><path d="M3.5 8.4l3 3 6-6.4" /></svg></i>
            {label}
          </button>;
        })}
      </div>
      <p className="u019-msg" aria-live="polite">{warning ? limitMessage : selected.length === max ? fullMessage : ""}</p>
    </div>
  );
}
