"use client";

import { ArrowLeft, ArrowRight, BookOpen, Check, Clock3, Pencil, Plus, RotateCcw, X } from "lucide-react";
import { useState } from "react";
import type { PracticeSetupOptions } from "@/lib/domain/types";
import { CollectionEmptyState } from "./kokonutui/collection-empty-state";
import { useI18n } from "./language-provider";
import { Button, ErrorMessage, Loading } from "./shared";

export function PracticeSetup({
  words,
  resuming,
  sessionWriting,
  busy,
  loading,
  preparing,
  error,
  onBack,
  onRetry,
  onDiscover,
  onStart,
}: {
  words: { word: string; userWordId: string }[];
  resuming: boolean;
  sessionWriting: boolean;
  busy: boolean;
  loading: boolean;
  preparing: boolean;
  error: string;
  onBack: () => void;
  onRetry?: () => void;
  onDiscover: () => void;
  onStart: (options?: PracticeSetupOptions) => void;
}) {
  const { t, locale } = useI18n();
  const vi = locale === "vi";
  const [includeWriting, setIncludeWriting] = useState(true);
  const [excluded, setExcluded] = useState<string[]>([]);
  const selected = words.filter((word) => !excluded.includes(word.userWordId));
  const removed = words.filter((word) => excluded.includes(word.userWordId));
  const count = selected.length;
  const writing = resuming ? sessionWriting : includeWriting;
  const unavailable = busy || loading;
  const listTitle = vi ? "Từ trong buổi luyện" : "Words in this session";

  return (
    <section className="practice-setup">
      <button type="button" className="text-button practice-setup-back" onClick={onBack} disabled={busy}>
        <ArrowLeft size={17} aria-hidden="true" />{t("Back to Practice")}
      </button>
      <header className="practice-setup-heading">
        <span className="practice-hub-icon"><BookOpen size={30} strokeWidth={1.75} aria-hidden="true" /></span>
        <h1>{t("Recall and use your words")}</h1>
        <p>{resuming
          ? vi ? "Tiếp tục buổi luyện tập đang dở của bạn." : "Pick up your practice session where you left off."
          : vi ? "Chọn từ bạn muốn ôn và cách bạn muốn luyện." : "Choose which words to review and how to practice them."}</p>
      </header>
      {error && <ErrorMessage message={error} retry={onRetry} />}
      {resuming && loading ? <Loading text="Loading your practice…" /> : !!words.length ? (
        <div className="practice-setup-panel">
          {!resuming && (
            <label className="practice-setup-option">
              <span className="practice-setup-option-icon"><Pencil size={20} aria-hidden="true" /></span>
              <span>
                <strong>{vi ? "Luyện viết câu" : "Practice sentence writing"}</strong>
                <small>{vi ? "Đặt một câu với mỗi từ sau khi nhớ lại." : "Write a sentence with each word after recalling it."}</small>
              </span>
              <input type="checkbox" checked={includeWriting} disabled={busy} onChange={(event) => setIncludeWriting(event.target.checked)} />
              <Check className="practice-setup-check" size={17} aria-hidden="true" />
            </label>
          )}
          <section className="practice-setup-words" aria-label={listTitle}>
            <header>
              <h2>{listTitle}</h2>
              <span role="status">{vi ? `${count} từ` : count === 1 ? "1 word" : `${count} words`}</span>
            </header>
            {count ? (
              <ul className="practice-setup-list">
                {selected.map((word) => (
                  <li key={word.userWordId}>
                    <strong lang="en">{word.word}</strong>
                    {!resuming && (
                      <button type="button" disabled={busy} className="practice-setup-remove" aria-label={vi ? `Bỏ qua từ ${word.word}` : `Skip ${word.word} for this session`}
                        onClick={(event) => {
                          const row = event.currentTarget.parentElement;
                          const next = (row?.nextElementSibling ?? row?.previousElementSibling)?.querySelector("button");
                          setExcluded((current) => [...current, word.userWordId]);
                          if (next instanceof HTMLButtonElement) next.focus();
                          else requestAnimationFrame(() => document.getElementById("practice-restore-words")?.focus());
                        }}>
                        <X size={17} aria-hidden="true" />
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <CollectionEmptyState
                icon={BookOpen}
                title={vi ? "Chưa chọn từ nào" : "No words selected"}
                description={vi ? "Thêm lại ít nhất một từ để bắt đầu." : "Add back at least one word to start."}
              />
            )}
            {!!removed.length && (
              <div className="practice-setup-excluded">
                <span>{vi ? "Bỏ qua lần này" : "Skipped this session"}</span>
                <div>
                  {removed.map((word) => (
                    <button key={word.userWordId} type="button" disabled={busy} aria-label={vi ? `Thêm lại từ ${word.word}` : `Add ${word.word} back`} onClick={() => setExcluded((current) => current.filter((id) => id !== word.userWordId))}>
                      <Plus size={14} aria-hidden="true" /><span lang="en">{word.word}</span>
                    </button>
                  ))}
                  <button id="practice-restore-words" type="button" disabled={busy} onClick={() => setExcluded([])}>{vi ? "Thêm lại tất cả" : "Restore all"}</button>
                </div>
              </div>
            )}
          </section>
          <footer className="practice-setup-footer">
            <p><Clock3 size={17} aria-hidden="true" />{writing ? t("About 2–5 minutes") : t("1–2 min")}</p>
            <Button className="practice-hub-cta" disabled={unavailable || !count}
              onClick={() => onStart(resuming ? undefined : { includeWriting, wordIds: selected.map((word) => word.userWordId) })}>
              {resuming ? vi ? "Tiếp tục luyện tập" : "Resume practice" : t("Start practice")}<ArrowRight size={18} aria-hidden="true" />
            </Button>
          </footer>
        </div>
      ) : !error ? (
        <CollectionEmptyState
          icon={BookOpen}
          title={preparing ? vi ? "Định nghĩa đang được chuẩn bị" : "Definitions are being prepared" : t("No words yet")}
          description={preparing
            ? vi ? "Bạn có thể luyện khi các từ đã có nghĩa." : "Practice will be available once the definitions are ready."
            : vi ? "Thêm một từ vào WordBoard để bắt đầu luyện tập." : "Add a word to WordBoard to start practicing."}
        >
          {!preparing && <Button onClick={onDiscover}>{vi ? "Khám phá từ" : "Discover words"}<ArrowRight size={17} aria-hidden="true" /></Button>}
        </CollectionEmptyState>
      ) : null}
      {!!count && !resuming && <p className="practice-setup-pause"><RotateCcw size={15} aria-hidden="true" />{vi ? "Bạn có thể rời trang rồi tiếp tục buổi luyện trong cùng thẻ này." : "You can leave and resume this session from this tab."}</p>}
    </section>
  );
}
