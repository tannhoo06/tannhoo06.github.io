"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Brand, Button } from "./shared";
import { useI18n } from "./language-provider";
import { LucianLanguageText } from "./lucian-267-language-switch";
import { LucianFaq } from "./lucian-faq";

export function LandingPublic({ start }: { start: () => void }) {
  const { locale } = useI18n();
  const copy = (vi: string, en: string) => (locale === "vi" ? vi : en);
  const questions = [
    {
      id: "pricing",
      question: copy("Ownword có miễn phí không?", "Is Ownword free?"),
      answer: copy(
        "Có. Bạn có thể dùng Ownword miễn phí. Các tính năng gợi ý từ và nhận xét bài viết có giới hạn lượt dùng mỗi ngày.",
        "Yes. Ownword is free. Word suggestions and essay feedback have daily limits.",
      ),
    },
    {
      id: "account",
      question: copy("Tôi có cần tài khoản để lưu từ không?", "Do I need an account to save words?"),
      answer: copy(
        "Có. Đăng nhập để lưu từ vào WordBoard và theo dõi các buổi luyện tập. Bạn có thể xem ví dụ ngay trên trang này trước khi đăng nhập.",
        "Yes. Sign in to save words to WordBoard and keep track of your practice. You can see how Ownword works on this page before signing in.",
      ),
    },
    {
      id: "find",
      question: copy("Chưa biết từ tiếng Anh thì tìm thế nào?", "What if I don't know the English word?"),
      answer: copy(
        "Vào Khám phá và chọn Tìm từ cho điều bạn muốn nói. Bạn có thể diễn tả ý bằng tiếng Việt hoặc tiếng Anh. Ownword gợi ý từ tiếng Anh kèm nghĩa và ví dụ để bạn chọn.",
        "Open Discover and choose Find a word for what you mean. Describe what you mean in Vietnamese or English. You'll get English suggestions with meanings and examples.",
      ),
    },
    {
      id: "suggestions",
      question: copy(
        "Gợi ý có tự sửa câu của tôi không?",
        "Will a suggestion change what I wrote?",
      ),
      answer: copy(
        "Ownword hiển thị gợi ý bên cạnh đoạn bạn viết. Bạn có thể lưu từ vào WordBoard hoặc giữ nguyên câu. Nếu có câu viết lại, bạn có thể xem trước rồi quyết định có áp dụng hay không.",
        "Ownword shows suggestions beside your draft. You can save a word to WordBoard or keep your sentence as it is. When a rewrite is available, you can preview it and choose whether to apply it.",
      ),
    },
    {
      id: "writing",
      question: copy(
        "Ownword nhận xét bài viết như thế nào?",
        "How does essay feedback work?",
      ),
      answer: copy(
        "Khi bạn gửi bài, AI của Ownword tìm những điểm có thể sửa và chỉ ra câu liên quan. Bạn có thể xem lại bài và góp ý trong Hồ sơ viết. Bạn cũng có thể xóa dữ liệu viết ở đó.",
        "Submit an essay and our AI detects issues you could work on, with feedback tied to your sentences. You can revisit the essay and its feedback in Writing Profile. You can delete your Writing data there too.",
      ),
    },
  ];
  return (
    <>
      <section
        className="ow-audience ow-public-width"
        aria-labelledby="ow-audience-title"
      >
        <div className="ow-audience-copy">
        <h2 id="ow-audience-title">
          <LucianLanguageText block value={copy("Ownword phù hợp với ai?", "Who is Ownword for?")} order={2} />
        </h2>
        <p>
          <LucianLanguageText block value={copy(
            "Có từ bạn nhận ra ngay khi đọc nhưng chưa dùng được khi cần? Thêm từ đó vào Ownword, hiểu cách dùng, luyện nhớ rồi đặt câu của riêng bạn.",
            "Know a word when you see it but struggle to use it yourself? Add it to Ownword, learn how it works, practice recalling it, then write your own sentence.",
          )} order={3} />
        </p>
        <p className="ow-audience-note">
          <em>
            {copy(
              "Từ khó hơn không phải lúc nào cũng tốt hơn. Hãy chọn từ phù hợp với ý bạn muốn nói.",
              "A more difficult word is not always better. Choose the one that fits what you want to say.",
            )}
          </em>
        </p>
        </div>
      </section>
      <section id="faq" className="ow-faq" aria-labelledby="ow-faq-title">
        <div className="ow-public-width ow-faq-grid">
          <div>
            <h2 id="ow-faq-title">
              <LucianLanguageText block value={copy("Câu hỏi thường gặp", "Frequently asked questions")} order={2} />
            </h2>
          </div>
          <LucianFaq questions={questions} />
        </div>
      </section>
      <section className="ow-invitation" aria-labelledby="ow-invitation-title">
        <h2 id="ow-invitation-title">
          <LucianLanguageText block value={copy(
            "Có từ nào bạn hay phải tra lại không?",
            "What’s a word you keep looking up?",
          )} order={2} />
        </h2>
        <Button onClick={start}>
          {copy("Thêm một từ", "Add a word")}
          <span className="ow-action-arrow">
            <ArrowRight size={22} aria-hidden="true" />
          </span>
        </Button>
        <a className="ow-feedback-link" href="mailto:ownword_support@gmail.com">
          {copy("Góp ý cho Ownword", "Share feedback with Ownword")}
        </a>
      </section>
    </>
  );
}

export function LandingFooter() {
  const { locale } = useI18n();
  const copy = (vi: string, en: string) => (locale === "vi" ? vi : en);
  return (
    <footer className="ow-footer ow-public-width">
      <Brand onClick={() => window.scrollTo({ top: 0 })} />
      <nav aria-label={copy("Thông tin Ownword", "Ownword information")}>
        <a href="mailto:ownword_support@gmail.com">
          {copy("Liên hệ", "Contact")}
        </a>
        <Link href="/privacy">{copy("Quyền riêng tư", "Privacy")}</Link>
        <Link href="/terms">{copy("Điều khoản", "Terms")}</Link>
      </nav>
      <small>© {new Date().getFullYear()} Ownword</small>
    </footer>
  );
}
