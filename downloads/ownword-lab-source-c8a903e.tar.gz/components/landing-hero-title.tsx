/* Lucian UX/UI Prompt #281 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#281 */

export function LandingHeroTitle({ locale }: { locale: string }) {
  return locale === "vi" ? <>
    <span className="ow-hero-title-line">Dùng <mark className="ow-hero-highlight">đúng từ</mark>,</span>{" "}
    <span className="ow-hero-title-line">diễn đạt <mark className="ow-hero-highlight ow-hero-highlight-green">đúng ý</mark></span>
  </> : <>
    <span className="ow-hero-title-line">Turn words <mark className="ow-hero-highlight">you encounter</mark></span>
    <span className="ow-hero-title-line">into words <mark className="ow-hero-highlight ow-hero-highlight-green">you can use</mark>.</span>
  </>;
}

export function LandingHeroDescription({ locale }: { locale: string }) {
  return locale === "vi" ? <>
    Chọn một từ tiếng Anh bạn muốn học. Ownword giúp bạn hiểu cách dùng, luyện nhớ và đặt câu với từ đó.
  </> : <>
    Choose an English word you want to learn. Ownword helps you understand it, recall it, and use it in a sentence of your own.
  </>;
}
