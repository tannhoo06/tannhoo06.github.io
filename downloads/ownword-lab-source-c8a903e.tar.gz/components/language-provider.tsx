"use client";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  LOCALE_COOKIE,
  translate,
  type Locale,
  type TranslationValues,
} from "@/lib/i18n/messages";

type LanguageContextValue = {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string, values?: TranslationValues) => string;
  dateLocale: string;
};
const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({
  initialLocale,
  children,
}: {
  initialLocale: Locale;
  children: ReactNode;
}) {
  const [locale, updateLocale] = useState(initialLocale);
  const setLocale = useCallback((next: Locale) => {
    updateLocale(next);
    document.cookie = `${LOCALE_COOKIE}=${next}; Path=/; Max-Age=31536000; SameSite=Lax${location.protocol === "https:" ? "; Secure" : ""}`;
  }, []);
  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);
  const t = useCallback(
    (key: string, values?: TranslationValues) => translate(locale, key, values),
    [locale],
  );
  const value = useMemo(
    () => ({
      locale,
      setLocale,
      t,
      dateLocale: locale === "vi" ? "vi-VN" : "en-US",
    }),
    [locale, setLocale, t],
  );
  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}
export function useI18n() {
  const value = useContext(LanguageContext);
  if (!value) throw new Error("LanguageProvider is required");
  return value;
}
export function LanguageSwitch({ compact = false }: { compact?: boolean }) {
  const { locale, setLocale } = useI18n();
  const chooseWithArrow = (event: React.KeyboardEvent<HTMLButtonElement>) => {
    if (event.key === "ArrowLeft" || event.key === "ArrowRight" || event.key === "Home" || event.key === "End") {
      event.preventDefault();
      const next = event.key === "Home" ? "vi" : event.key === "End" ? "en" : locale === "vi" ? "en" : "vi";
      setLocale(next);
      event.currentTarget.parentElement?.querySelector<HTMLButtonElement>(`[data-locale="${next}"]`)?.focus();
    }
  };
  return (
    <div
      className="language-switch"
      role="radiogroup"
      aria-label={locale === "vi" ? "Ngôn ngữ giao diện" : "Interface language"}
    >
      <button
        type="button"
        role="radio"
        data-locale="vi"
        lang="vi"
        aria-label={compact ? "Tiếng Việt" : undefined}
        title={compact ? "Tiếng Việt" : undefined}
        aria-checked={locale === "vi"}
        tabIndex={locale === "vi" ? 0 : -1}
        onKeyDown={chooseWithArrow}
        onClick={() => setLocale("vi")}
      >
        {compact ? "VN" : "Tiếng Việt"}
      </button>
      <button
        type="button"
        role="radio"
        data-locale="en"
        lang="en"
        aria-label={compact ? "English" : undefined}
        title={compact ? "English" : undefined}
        aria-checked={locale === "en"}
        tabIndex={locale === "en" ? 0 : -1}
        onKeyDown={chooseWithArrow}
        onClick={() => setLocale("en")}
      >
        {compact ? "EN" : "English"}
      </button>
    </div>
  );
}
