// Lucian UX/UI Prompt #009 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#009
"use client";
import type { CSSProperties } from "react";

export function LucianDictionaryLink({ word, label }: { word: string; label: string }) {
  return <a className="u009-dictionary" href={`https://www.oxfordlearnersdictionaries.com/search/english/?q=${encodeURIComponent(word)}`} target="_blank" rel="noopener noreferrer" aria-label={`${label}: ${word}`}>
    <span className="u009-dictionary-word" aria-hidden="true">{Array.from(label).map((letter, index) => <span key={`${letter}-${index}`} style={{ "--i": index } as CSSProperties} data-c={letter === " " ? "\u00a0" : letter}>{letter === " " ? "\u00a0" : letter}</span>)}</span>
    <span className="u009-dictionary-orb" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 17L17 7M9 7h8v8" /></svg><svg viewBox="0 0 24 24"><path d="M7 17L17 7M9 7h8v8" /></svg></span>
  </a>;
}
