"use client";

import Link from "next/link";
import { LocalizedPageTitle } from "./localized-page-title";
import { LanguageSwitch, useI18n } from "./language-provider";
import "@/app/landing.css";

type Section = { en: [string, string]; vi: [string, string] };

const privacy: Section[] = [
  {
    en: ["What we collect", "When you sign in, Ownword receives your account ID, email address, and display name where available. We save words you add, your preferences, your practice activity, and writing you submit along with its feedback. If you email us, we receive your message and contact details."],
    vi: ["Thông tin chúng tôi thu thập", "Khi bạn đăng nhập, Ownword nhận mã tài khoản, địa chỉ email và tên hiển thị nếu có. Chúng tôi lưu từ bạn thêm, tùy chọn, hoạt động luyện tập, bài viết đã gửi và góp ý. Khi bạn gửi email cho chúng tôi, chúng tôi nhận nội dung thư và thông tin liên hệ."],
  },
  {
    en: ["How we use it", "We use this information to run your account, save your work, suggest words, give feedback, and show your learning history. We also use it to answer support requests, troubleshoot problems, protect the service, and meet legal obligations."],
    vi: ["Cách chúng tôi sử dụng thông tin", "Chúng tôi dùng thông tin này để vận hành tài khoản, lưu bài, gợi ý từ, đưa ra góp ý và hiển thị lịch sử học tập. Chúng tôi cũng dùng thông tin để hỗ trợ bạn, xử lý sự cố, bảo vệ dịch vụ và thực hiện nghĩa vụ pháp lý."],
  },
  {
    en: ["Writing and AI", "When you request suggestions or feedback, our AI uses the text you submit and the context needed for that request. We may send this information to service providers that process it for Ownword. Please leave out passwords, sensitive personal information, and private information about other people."],
    vi: ["Bài viết và AI", "Khi bạn yêu cầu gợi ý hoặc góp ý, AI của Ownword sử dụng nội dung bạn gửi và ngữ cảnh cần thiết để xử lý yêu cầu. Chúng tôi có thể gửi thông tin này cho các đơn vị xử lý thay mặt Ownword. Vui lòng tránh nhập mật khẩu, dữ liệu cá nhân nhạy cảm hoặc thông tin riêng tư của người khác."],
  },
  {
    en: ["Cookies and drafts", "We use cookies to keep you signed in and remember settings such as your language. Your browser may also keep drafts and preferences locally. Clearing browser data removes those local copies. Saved account data is managed separately."],
    vi: ["Cookie và bài đang viết", "Chúng tôi dùng cookie để duy trì đăng nhập và ghi nhớ tùy chọn như ngôn ngữ. Trình duyệt cũng có thể lưu bài đang viết và tùy chọn trên thiết bị. Xóa dữ liệu trình duyệt sẽ xóa các bản lưu trên thiết bị. Dữ liệu đã lưu trong tài khoản được quản lý riêng."],
  },
  {
    en: ["Who receives information", "We share information as needed with providers that help us host Ownword, sign users in, process requests, or operate the service. We may also disclose information when required by law. Providers may process information in countries other than yours."],
    vi: ["Ai có thể nhận thông tin", "Chúng tôi chia sẻ thông tin khi cần với các đơn vị giúp lưu trữ Ownword, xác thực người dùng, xử lý yêu cầu hoặc vận hành dịch vụ. Chúng tôi cũng có thể cung cấp thông tin khi pháp luật yêu cầu. Các đơn vị này có thể xử lý thông tin ở quốc gia khác với nơi bạn sinh sống."],
  },
  {
    en: ["How long we keep your data and how to delete it", "We keep saved account information while you use Ownword and for as long as needed to operate and protect the service or meet legal obligations. You can delete saved Writing data in Writing Profile. Deleted data may remain temporarily in backups. Email us to request access, correction, or deletion of other personal information, or to exercise other rights available where you live."],
    vi: ["Chúng tôi lưu dữ liệu bao lâu và bạn có thể xóa thế nào", "Chúng tôi giữ thông tin đã lưu khi bạn dùng Ownword và trong thời gian cần thiết để vận hành, bảo vệ dịch vụ hoặc đáp ứng nghĩa vụ pháp lý. Bạn có thể xóa dữ liệu viết trong Hồ sơ viết. Dữ liệu đã xóa có thể còn tạm thời trong bản sao lưu. Hãy gửi email nếu bạn muốn truy cập, sửa hoặc xóa thông tin cá nhân khác, hoặc thực hiện các quyền theo pháp luật nơi bạn sinh sống."],
  },
];

const terms: Section[] = [
  {
    en: ["Using Ownword", "Ownword helps you practice English vocabulary and writing. It is free to use. Some features have daily limits. Keep your account secure and tell us if you think someone else has gained access."],
    vi: ["Sử dụng Ownword", "Ownword giúp bạn luyện từ vựng và viết tiếng Anh. Bạn có thể dùng dịch vụ miễn phí. Một số tính năng có giới hạn theo ngày. Hãy bảo vệ tài khoản và liên hệ với chúng tôi nếu bạn nghi ngờ người khác đã truy cập tài khoản của mình."],
  },
  {
    en: ["Your work", "You keep your rights to the content you submit. You give Ownword permission to store and process it as needed to provide the service, including generating feedback and showing your learning history. Only submit material you have permission to use."],
    vi: ["Nội dung của bạn", "Bạn giữ các quyền đối với nội dung mình gửi. Bạn cho phép Ownword lưu và xử lý nội dung đó trong phạm vi cần thiết để cung cấp dịch vụ, bao gồm tạo góp ý và hiển thị lịch sử học tập. Chỉ gửi nội dung bạn có quyền sử dụng."],
  },
  {
    en: ["Acceptable use", "Use Ownword lawfully and respect other people’s rights. Do not submit harmful or unlawful material, access another user’s account, bypass usage limits, or interfere with the service. We may restrict access when needed to address abuse or protect the service."],
    vi: ["Cách sử dụng được phép", "Hãy sử dụng Ownword đúng pháp luật và tôn trọng quyền của người khác. Không gửi nội dung gây hại hoặc trái pháp luật, truy cập tài khoản của người khác, vượt giới hạn sử dụng hoặc cản trở hoạt động của dịch vụ. Chúng tôi có thể hạn chế quyền truy cập khi cần để xử lý hành vi lạm dụng hoặc bảo vệ dịch vụ."],
  },
  {
    en: ["Using AI suggestions", "Our AI can miss errors or make unsuitable suggestions. Review the feedback and choose what fits your meaning. Ownword is a practice tool and does not certify your English level."],
    vi: ["Cách sử dụng gợi ý của AI", "AI của Ownword có thể bỏ sót lỗi hoặc đưa ra gợi ý chưa phù hợp. Hãy đọc góp ý và chọn cách diễn đạt đúng với ý bạn. Ownword là công cụ luyện tập và không cấp chứng nhận trình độ tiếng Anh."],
  },
  {
    en: ["Service changes and your rights", "Features and limits may change, and access can be interrupted. We will post changes to these terms on this page. These terms do not limit rights you have under applicable law."],
    vi: ["Thay đổi dịch vụ và quyền của bạn", "Tính năng và giới hạn sử dụng có thể thay đổi. Dịch vụ đôi lúc có thể bị gián đoạn. Chúng tôi sẽ đăng các thay đổi điều khoản trên trang này. Những điều khoản này không hạn chế các quyền của bạn theo pháp luật hiện hành."],
  },
];

export function LegalPage({ kind }: { kind: "privacy" | "terms" }) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const isPrivacy = kind === "privacy";
  return (
    <div className="ow-landing ow-legal">
      <LocalizedPageTitle name={kind} />
      <header className="ow-nav">
        <Link href="/">← Ownword</Link>
        <LanguageSwitch />
      </header>
      <main className="ow-public-width">
        <h1>{isPrivacy ? (vi ? "Chính sách quyền riêng tư" : "Privacy Policy") : (vi ? "Điều khoản sử dụng" : "Terms of Use")}</h1>
        <p><time dateTime="2026-11-21">{vi ? "Cập nhật ngày 21 tháng 11 năm 2026" : "Updated November 21, 2026"}</time></p>
        {(isPrivacy ? privacy : terms).map((section) => {
          const [heading, body] = section[locale];
          return <section key={section.en[0]}><h2>{heading}</h2><p>{body}</p></section>;
        })}
        <section>
          <h2>{vi ? "Liên hệ" : "Contact"}</h2>
          <p><a href="mailto:ownword_support@gmail.com">ownword_support@gmail.com</a></p>
          {!isPrivacy && <p><Link href="/privacy">{vi ? "Chính sách quyền riêng tư" : "Privacy Policy"}</Link></p>}
        </section>
      </main>
    </div>
  );
}
