/* Lucian UX/UI Prompt #211 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#211 */
"use client";

import type { ReactNode } from "react";
import "./lucian-211-start-button.css";

export function LucianStartButton({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return (
    <button className="ux u211-bt" type="button" onClick={onClick}>
      <span className="u211-in">
        <span className="u211-lb">{children}</span>
        <svg className="u211-ar" viewBox="0 0 14 14" aria-hidden="true">
          <path d="M3 7h8M7.5 3.5 11 7l-3.5 3.5" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
    </button>
  );
}
