/* Lucian UX/UI Prompt #363 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#363 */
"use client";

import { useEffect, useRef } from "react";
import "./lucian-363-dot-background.css";

type Wave = { x: number; y: number; t: number; a: number };

export function LucianDotBackground() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = rootRef.current;
    const canvas = root?.querySelector("canvas");
    const section = root?.parentElement;
    const context = canvas?.getContext("2d");
    if (!root || !canvas || !section || !context) return;

    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const gap = 17;
    let width = 0;
    let height = 0;
    let dots: Array<[number, number]> = [];
    let waves: Wave[] = [];
    let lastAdd = 0;
    let visible = true;
    let frameId = 0;

    function draw(now: number) {
      const idle = getComputedStyle(root!).getPropertyValue("--ux-ink-3").trim() || "#8fa88e";
      context!.clearRect(0, 0, width, height);
      waves = waves.filter((wave) => now - wave.t < 2600);
      for (const [x, y] of dots) {
        let h = 0;
        for (const wave of waves) {
          const age = (now - wave.t) / 1000;
          const distance = Math.hypot(x - wave.x, y - wave.y);
          const k = distance - age * 170;
          if (k > 0 || k < -90) continue;
          h += Math.sin(k / 14) * Math.exp(k / 60) * wave.a * Math.exp(-age * 1.3);
        }
        const m = Math.max(-1, Math.min(1.6, h));
        const radius = 1.6 + Math.max(0, m) * 3.4;
        const calm = Math.abs(m) < 0.04;
        context!.globalAlpha = calm ? .55 : 1;
        context!.fillStyle = calm ? idle : `hsl(${(145 - Math.max(0, m) * 14).toFixed(0)} 48% ${(48 - Math.min(0, m) * 10).toFixed(0)}%)`;
        context!.beginPath();
        context!.arc(x, y - m * 3, radius, 0, Math.PI * 2);
        context!.fill();
      }
      context!.globalAlpha = 1;
    }

    function frame(now: number) {
      frameId = 0;
      if (!visible || !root!.isConnected) return;
      draw(now);
      if (waves.length) frameId = requestAnimationFrame(frame);
    }

    function run() {
      if (motion.matches) {
        waves = [];
        draw(performance.now());
      } else if (visible && !frameId) {
        frameId = requestAnimationFrame(frame);
      }
    }

    function resize() {
      const bounds = root!.getBoundingClientRect();
      width = Math.max(1, bounds.width);
      height = Math.max(1, bounds.height);
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas!.width = Math.round(width * dpr);
      canvas!.height = Math.round(height * dpr);
      context!.setTransform(dpr, 0, 0, dpr, 0, 0);
      dots = [];
      for (let y = gap; y < height - 4; y += gap) {
        for (let x = gap; x < width - 4; x += gap) dots.push([x, y]);
      }
      draw(performance.now());
    }

    function add(event: PointerEvent, strength: number) {
      if (motion.matches || !visible) return;
      const bounds = canvas!.getBoundingClientRect();
      const x = event.clientX - bounds.left;
      const y = event.clientY - bounds.top;
      if (x < 0 || y < 0 || x > bounds.width || y > bounds.height) return;
      waves.push({ x, y, t: performance.now(), a: strength });
      if (waves.length > 14) waves.shift();
      run();
    }

    function onMove(event: PointerEvent) {
      const now = performance.now();
      if (now - lastAdd < 110) return;
      lastAdd = now;
      add(event, .55);
    }
    function onDown(event: PointerEvent) { add(event, 1.6); }

    const resizeObserver = new ResizeObserver(resize);
    const intersection = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (!visible && frameId) { cancelAnimationFrame(frameId); frameId = 0; }
      if (visible) run();
    });
    resizeObserver.observe(root);
    intersection.observe(root);
    section.addEventListener("pointermove", onMove);
    section.addEventListener("pointerdown", onDown);
    motion.addEventListener("change", run);
    resize();

    return () => {
      if (frameId) cancelAnimationFrame(frameId);
      resizeObserver.disconnect();
      intersection.disconnect();
      section.removeEventListener("pointermove", onMove);
      section.removeEventListener("pointerdown", onDown);
      motion.removeEventListener("change", run);
    };
  }, []);

  return <div ref={rootRef} className="ux u363" aria-hidden="true"><canvas className="u363-cv" /></div>;
}
