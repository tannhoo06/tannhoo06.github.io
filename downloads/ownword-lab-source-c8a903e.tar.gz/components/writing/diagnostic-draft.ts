import { writingAssistance, type WritingAssistance, type WritingTask } from "@/lib/writing/persistence";

export type DiagnosticDraft = {
  task: WritingTask;
  text: string;
  assistance?: WritingAssistance;
  pendingRequestId?: string;
};

const draftKey = (ownerId: string) => `ownword:writing-draft:v1:${ownerId}`;

export function readDiagnosticDraft(ownerId: string): DiagnosticDraft | null {
  try {
    const draft = JSON.parse(sessionStorage.getItem(draftKey(ownerId)) ?? "null") as DiagnosticDraft | null;
    if (draft && typeof draft.task?.id === "string" && typeof draft.task.snapshot?.prompt.scenario === "string" &&
      Array.isArray(draft.task.snapshot.interestIds) && typeof draft.text === "string") {
      return { ...draft, assistance: draft.assistance && writingAssistance.includes(draft.assistance) ? draft.assistance : "unknown" };
    }
  } catch {
    // If browser storage is unavailable, the editor still works in memory.
  }
  return null;
}

export function storeDiagnosticDraft(ownerId: string, draft: DiagnosticDraft | null) {
  try {
    if (draft) sessionStorage.setItem(draftKey(ownerId), JSON.stringify(draft));
    else sessionStorage.removeItem(draftKey(ownerId));
    return true;
  } catch {
    // The existing leave confirmation still protects an in-memory draft.
    return false;
  }
}
