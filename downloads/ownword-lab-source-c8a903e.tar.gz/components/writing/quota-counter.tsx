"use client";

import { Layers3 } from "lucide-react";
import { useEffect } from "react";
import { useI18n } from "../language-provider";
import { useRequestLimitNotice } from "../request-limit-notice";
import { useWritingResource, type WritingQuota } from "./writing-client";

export function WritingQuotaCounter() {
  const { locale } = useI18n();
  const { withReset } = useRequestLimitNotice();
  const { data: quota, reload } = useWritingResource<WritingQuota>("quotas");
  const resetAt = quota?.resetAt;

  useEffect(() => {
    window.addEventListener("focus", reload);
    return () => window.removeEventListener("focus", reload);
  }, [reload]);

  useEffect(() => {
    if (!resetAt) return;
    const delay = Date.parse(resetAt) - Date.now();
    if (!Number.isFinite(delay) || delay <= 0) return;
    const timer = window.setTimeout(reload, delay + 100);
    return () => window.clearTimeout(timer);
  }, [reload, resetAt]);

  if (!quota) return null;
  const { remaining, pending } = quota;
  const vi = locale === "vi";
  const count = vi ? `Còn ${remaining} lượt nhận xét hôm nay`
    : `${remaining} writing ${remaining === 1 ? "assessment" : "assessments"} left today`;
  const message = remaining > 0 ? count
    : pending ? count + (vi ? ". Đang nhận xét bài đã gửi." : ". Feedback is still in progress.")
      : withReset(count + ".", resetAt);
  return (
    <p className="writing-quota" data-empty={remaining === 0} role="status" aria-atomic="true">
      <Layers3 size={15} aria-hidden="true" />
      <span>{message}</span>
    </p>
  );
}
