import "./focus-buddy.css";

type FocusBuddyState = "empty" | "active" | "added";

export function FocusBuddy({ state }: { state: FocusBuddyState }) {
  return <span className="focus-buddy" data-state={state} aria-hidden="true" />;
}
