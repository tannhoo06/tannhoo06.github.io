"use client";

import { ArrowRight, ChevronLeft, ChevronRight, Notebook, Pin, Plus, Target, X } from "lucide-react";
import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import type { WritingFocusAction, WritingFocusBoard, WritingFocusCard, WritingFocusDetail, WritingFocusExcerpt } from "@/lib/writing/focus";
import { useI18n } from "../language-provider";
import { FocusBuddy } from "./focus-buddy";
import { replacementDiff, type TextPart } from "./replacement-diff";
import { useWritingResource, WritingLink, writingRequest } from "./writing-client";

function Quote({ example, parts }: { example: WritingFocusExcerpt; parts?: readonly TextPart[] }) {
  return <q lang="en">{example.before}{parts
    ? parts.map(({ text, changed }, index) => changed ? <mark key={index}>{text}</mark> : text)
    : <mark>{example.exact}</mark>}{example.after}</q>;
}

function sessionCount(count: number, vi: boolean) {
  return vi ? `Gặp trong ${count} bài viết` : `Seen in ${count} ${count === 1 ? "essay" : "essays"}`;
}

export function WritingFocus({ liveEvaluation }: { liveEvaluation: boolean }) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const copy = (value: { en: string; vi: string | null }) => vi ? value.vi || value.en : value.en;
  const resource = useWritingResource<WritingFocusBoard>("focus");
  const [updated, setUpdated] = useState<WritingFocusBoard>();
  const [selected, setSelected] = useState<WritingFocusCard>();
  const [celebrating, setCelebrating] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState(false);
  const [announcement, setAnnouncement] = useState("");
  const timer = useRef<number>(undefined);
  const workspace = useRef<HTMLDivElement>(null);
  const boardHeading = useRef<HTMLHeadingElement>(null);
  const notesHeading = useRef<HTMLHeadingElement>(null);
  const postAction = useRef<{ action: WritingFocusAction; index: number; top: number | undefined }>(undefined);
  const board = updated ?? resource.data;
  const buddy = celebrating ? "added" : board?.active.length ? "active" : "empty";

  useEffect(() => () => window.clearTimeout(timer.current), []);

  useLayoutEffect(() => {
    const change = postAction.current;
    const root = workspace.current;
    if (!change || !root) return;
    postAction.current = undefined;
    const { action, index, top } = change;
    const controls = root.querySelectorAll<HTMLElement>(
      action === "add" ? ".focus-add:not(:disabled)" : action === "dismiss" ? ".focus-note-details"
        : action === "remove" ? ".focus-active-open" : ".focus-dismissed button",
    );
    const next = controls[Math.min(index, controls.length - 1)];
    (next ?? (action === "remove" ? boardHeading.current : notesHeading.current))?.focus({ preventScroll: true });
    if (!next || top === undefined) return;
    const list = next.closest(".focus-notes-list");
    const card = next.closest(".focus-note");
    if (list && card) {
      const container = list.getBoundingClientRect();
      const bounds = card.getBoundingClientRect();
      if (bounds.left < container.left - 2 || bounds.right > container.right + 2) {
        list.scrollBy({ left: bounds.left - container.left, behavior: "instant" });
      }
    }
    const delta = next.getBoundingClientRect().top - top;
    if (Math.abs(delta) > 1) window.scrollBy({ top: delta, behavior: "instant" });
  }, [updated]);

  async function change(action: WritingFocusAction, problem: Pick<WritingFocusCard, "key" | "title">) {
    setPending(true);
    setError(false);
    setAnnouncement("");
    try {
      const next = await writingRequest<WritingFocusBoard>("focus", { body: { key: problem.key, action } });
      const previous = action === "remove" ? board?.active : action === "restore" ? board?.dismissed : board?.suggestions;
      const index = Math.max(0, previous?.findIndex(({ key }) => key === problem.key) ?? 0);
      const addControl = action === "add" ? workspace.current?.querySelectorAll(".focus-add")[index] : undefined;
      const top = addControl?.getBoundingClientRect().top;
      postAction.current = { action, index, top: top !== undefined && top >= 0 && top < window.innerHeight ? top : undefined };
      setUpdated(next);
      setSelected(undefined);
      if (action === "add") {
        window.clearTimeout(timer.current);
        setCelebrating(true);
        timer.current = window.setTimeout(() => setCelebrating(false), 1600);
      }
      const messages = vi ? {
        add: "Đã thêm vào Trọng tâm", remove: "Đã chuyển về Hộp ghi chú", dismiss: "Đã bỏ qua ghi chú", restore: "Đã khôi phục ghi chú",
      } : {
        add: "Added to Focus", remove: "Returned to the Note Box", dismiss: "Dismissed from the Note Box", restore: "Restored to the Note Box",
      };
      setAnnouncement(`${messages[action]}. ${copy(problem.title)}`);
    } catch {
      setError(true);
    } finally {
      setPending(false);
    }
  }

  function reload() {
    setUpdated(undefined);
    setSelected(undefined);
    setError(false);
    resource.reload();
  }

  function showDetails(problem: WritingFocusCard) {
    setError(false);
    setSelected(problem);
  }

  const emptyBoard = !!board && board.active.length === 0;
  const hasSuggestions = !!board?.suggestions.length;
  const atPinLimit = !!board && board.pinCount >= board.pinLimit;
  const coachingHint = board && liveEvaluation && board.coachingAvailable !== false
    ? (vi ? "Điểm có nhãn ‘Kiểm tra thêm’ có thể được xem kỹ hơn trong bài viết mới. Điểm có nhãn ‘Tự nhắc’ dành để bạn xem lại khi cần."
      : "Pins marked ‘Extra check’ may get a closer look in new essays. A ‘Reminder for you’ is there for you to revisit.")
    : null;
  const writeLabel = vi ? "Viết bài mới" : "Write a new essay";
  const addLabel = vi ? "Thêm vào Trọng tâm" : "Add to Focus";
  const removeLabel = vi ? "Bỏ khỏi Trọng tâm" : "Remove from Focus";
  const detailsLabel = vi ? "Xem chi tiết" : "View details";
  const retry = vi ? "Tải lại" : "Reload";
  const requestError = <>
    {vi ? "Không thể lưu thay đổi. Hãy tải lại và thử lại." : "Couldn’t save the change. Reload and try again."}
    <button type="button" className="writing-text-link" onClick={reload}>{retry}</button>
  </>;

  return <>
    <div className="writing-flow writing-focus" ref={workspace}>
      <header className="focus-intro writing-heading">
        <div>
          <h1><span>{vi ? "Trọng tâm của bạn" : "Your Writing Focus"}</span></h1>
          {!!board?.active.length && <p>{vi ? "Những điểm bạn muốn chú ý trong các bài viết tiếp theo." : "Choose what to pay closer attention to in your next essays."}</p>}
        </div>
        <FocusBuddy state={buddy} />
      </header>

      <section className="focus-board" aria-labelledby="focus-board-title">
        <div className="focus-board-heading">
          <h2 id="focus-board-title" ref={boardHeading} tabIndex={-1}>{vi ? "Đang tập trung" : "In focus"}</h2>
          {board && <span className="focus-pin-count" title={vi ? `Đã ghim ${board.pinCount} trên ${board.pinLimit} điểm` : `${board.pinCount} of ${board.pinLimit} pins used`}>
            <Pin size={14} aria-hidden="true" />
            <span aria-hidden="true">{board.pinCount}/{board.pinLimit}</span>
            <span className="sr-only">{vi ? `Đã ghim ${board.pinCount} trên ${board.pinLimit} điểm`
              : `${board.pinCount} of ${board.pinLimit} issues pinned`}</span>
          </span>}
        </div>
        {resource.loading && !board ? <p className="focus-board-empty" role="status">{vi ? "Đang tải Trọng tâm…" : "Loading Focus…"}</p>
          : resource.error && !board ? <p className="focus-board-empty focus-error" role="alert">
            {vi ? "Chưa thể tải Trọng tâm." : "Couldn’t load Focus."}
            <button type="button" className="writing-text-link" onClick={reload}>{retry}</button>
          </p>
          : board?.active.length ? <ul className="focus-active-list">
            {board.active.map((problem) => <li className="focus-active-card" key={problem.key}>
              <button className="focus-active-open" type="button" onClick={() => showDetails(problem)}>
                <strong id={`focus-card-${problem.key}`}>{copy(problem.title)}</strong>
                <span>{sessionCount(problem.sessionCount, vi)}</span>
                {liveEvaluation && <span className="focus-card-status" data-coached={problem.coached === true}>
                  {focusCheckLabel(vi, problem.coached)}
                </span>}
              </button>
              <button className="focus-icon focus-remove" type="button" disabled={pending} title={removeLabel}
                aria-label={removeLabel} aria-describedby={`focus-card-${problem.key}`}
                onClick={() => void change("remove", problem)}><X size={17} aria-hidden="true" /></button>
            </li>)}
          </ul> : emptyBoard && <div className="focus-first">
            <div className="focus-first-art" aria-hidden="true">
              <span className="focus-first-card"><Target size={23} strokeWidth={1.65} /></span>
              <span className="focus-first-plus"><Plus size={15} strokeWidth={2.35} /></span>
            </div>
            <div className="focus-first-content">
              <h3>{vi ? "Chưa có điểm nào trong Trọng tâm" : "Your Focus is empty"}</h3>
              <p>{hasSuggestions
                ? (vi ? "Chọn một điểm từ Hộp ghi chú bên dưới để chú ý khi viết bài tiếp theo."
                  : "Pick something from the Note Box below to work on in your next essay.")
                : (vi ? "Viết một bài để Ownword gợi ý điểm bạn có thể luyện thêm."
                  : "Write an essay to get suggestions for what to work on.")}</p>
            </div>
          </div>}
        {(!emptyBoard || hasSuggestions) && coachingHint && <p className="focus-board-hint">{coachingHint}</p>}
      </section>

      {error && !selected && <p className="focus-error" role="alert">{requestError}</p>}
      <NoteBox vi={vi} hasBoard={!!board} heading={notesHeading} count={board?.suggestions.length ?? 0} atPinLimit={atPinLimit}>
        {board?.suggestions.map((problem) => <li className="focus-note" key={problem.key}>
          <h3>{copy(problem.title)}</h3>
          <p className="focus-note-count">{sessionCount(problem.sessionCount, vi)}</p>
          <div className="focus-note-example"><Quote example={problem.example} /></div>
          <div className="focus-note-actions">
            <button className="focus-button focus-add" type="button" disabled={pending || atPinLimit}
              onClick={() => void change("add", problem)}><Plus size={16} aria-hidden="true" />{addLabel}</button>
            <button className="focus-button focus-note-details" type="button" onClick={() => showDetails(problem)}>{detailsLabel}</button>
          </div>
        </li>)}
      </NoteBox>
      {!!board?.dismissed?.length && <details className="focus-dismissed">
        <summary className="writing-text-link">{vi ? "Ghi chú đã bỏ qua" : "Dismissed notes"} ({board.dismissed.length})</summary>
        <ul>
          {board.dismissed.map((problem) => <li key={problem.key}>
            <span>{copy(problem.title)}</span>
            <button type="button" className="writing-text-link" disabled={pending}
              aria-label={vi ? `Khôi phục ${copy(problem.title)}` : `Restore ${copy(problem.title)}`}
              onClick={() => void change("restore", problem)}>{vi ? "Khôi phục" : "Restore"}</button>
          </li>)}
        </ul>
      </details>}
      <span className="sr-only" role="status">{announcement}</span>

      {selected && <FocusDetail key={selected.key} problem={selected} vi={vi} pending={pending}
        isSuggestion={!!board?.suggestions.some(({ key }) => key === selected.key)}
        showCheckLabel={liveEvaluation && !!board?.active.some(({ key }) => key === selected.key)}
        onClose={() => { setError(false); setSelected(undefined); }}
        onAction={(action) => void change(action, selected)}
        error={error ? requestError : undefined} />}
    </div>
    <div className="focus-page-actions">
      <WritingLink href="/writing/diagnostic" className="button-secondary">
        {writeLabel}<ArrowRight size={18} aria-hidden="true" />
      </WritingLink>
    </div>
  </>;
}

function NoteBox({ vi, hasBoard, heading, count, atPinLimit, children }: {
  vi: boolean; hasBoard: boolean; heading: React.RefObject<HTMLHeadingElement | null>; count: number; atPinLimit: boolean;
  children: ReactNode;
}) {
  const viewport = useRef<HTMLUListElement>(null);
  const [showAll, setShowAll] = useState(false);
  const [edges, setEdges] = useState({ start: true, end: true, first: 0 });
  const all = showAll && count > 0;
  const canScroll = !edges.start || !edges.end;

  useEffect(() => {
    const list = viewport.current;
    if (!list) return;
    const update = () => {
      const first = list.firstElementChild;
      const step = first ? first.getBoundingClientRect().width + Number.parseFloat(getComputedStyle(list).columnGap) : 0;
      setEdges({
        start: list.scrollLeft <= 2,
        end: list.scrollLeft >= list.scrollWidth - list.clientWidth - 2,
        first: step > 0 ? Math.min(count - 1, Math.round(list.scrollLeft / step)) : 0,
      });
    };
    update();
    list.addEventListener("scroll", update, { passive: true });
    const resize = new ResizeObserver(update);
    resize.observe(list);
    return () => {
      resize.disconnect();
      list.removeEventListener("scroll", update);
    };
  }, [count, all]);

  function scroll(direction: number) {
    const list = viewport.current;
    const first = list?.firstElementChild;
    if (!list || !first) return;
    const gap = Number.parseFloat(getComputedStyle(list).columnGap) || 0;
    const distance = first.getBoundingClientRect().width + gap;
    list.scrollTo({ left: (Math.round(list.scrollLeft / distance) + direction) * distance });
  }

  return <section className="focus-notes" aria-labelledby="focus-notes-title">
    <header className="focus-notes-heading">
      <div>
        <h2 id="focus-notes-title" ref={heading} tabIndex={-1}><Notebook size={24} aria-hidden="true" />
          {vi ? "Hộp ghi chú" : "Note Box"}</h2>
        {count > 0 && <p>{vi ? "Góp ý từ các bài trước mà bạn có thể ghim cho lần viết tiếp theo." : "Feedback from past essays that you can pin for next time."}</p>}
        {atPinLimit && count > 0 && <p>{vi ? "Bỏ ghim một điểm để thêm điểm khác." : "Unpin an issue to add another."}</p>}
      </div>
      {(all || canScroll) && <button type="button" className="writing-text-link focus-show-all" onClick={() => setShowAll(!all)}
        aria-controls="focus-notes-list" aria-expanded={all}>
        {all ? (vi ? "Dạng cuộn" : "Carousel view") : (vi ? "Xem tất cả" : "View all")}
      </button>}
    </header>
    {count > 0 ? <div className="focus-carousel" data-all={all} data-scroll={canScroll}>
      <ul className="focus-notes-list" id="focus-notes-list" ref={viewport}>{children}</ul>
      {canScroll && !all && <div className="focus-carousel-nav">
        <button type="button" className="focus-icon focus-prev" aria-disabled={edges.start} onClick={() => { if (!edges.start) scroll(-1); }}
          aria-label={vi ? "Ghi chú trước" : "Previous notes"} aria-controls="focus-notes-list"><ChevronLeft size={20} aria-hidden="true" /></button>
        <span className="focus-carousel-position">
          <span className="sr-only">{vi ? `Ghi chú ${edges.first + 1} trên ${count}` : `Note ${edges.first + 1} of ${count}`}</span>
          <span aria-hidden="true">{edges.first + 1} / {count}</span>
        </span>
        <button type="button" className="focus-icon focus-next" aria-disabled={edges.end} onClick={() => { if (!edges.end) scroll(1); }}
          aria-label={vi ? "Ghi chú tiếp theo" : "Next notes"} aria-controls="focus-notes-list"><ChevronRight size={20} aria-hidden="true" /></button>
      </div>}
    </div> : hasBoard && <p className="focus-notes-empty">{vi
      ? "Chưa có ghi chú mới. Ghi chú sẽ xuất hiện khi Ownword tìm thấy điểm cần sửa trong bài viết của bạn."
      : "No new notes yet. Notes appear when Ownword finds something you can work on in an essay."}</p>}
  </section>;
}

type FocusEvidence = WritingFocusDetail["evidence"][number];

function FocusExamples({ evidence, vi }: { evidence: FocusEvidence[]; vi: boolean }) {
  const copy = (value: { en: string; vi: string | null }) => (vi ? value.vi || value.en : value.en).replace(/\s+/gu, " ").trim();
  const entries = evidence.map((item) => {
    const explanation = copy(item.explanation);
    const cue = item.cue ? copy(item.cue) : "";
    return { item, explanation, cue: cue === explanation ? "" : cue };
  });
  const commonCue = entries.every(({ cue }) => cue === entries[0]?.cue) ? entries[0]?.cue : undefined;
  const groups = new Map<string, Map<string, FocusEvidence[]>>();
  for (const { item, explanation, cue } of entries) {
    const byCue = groups.get(explanation) ?? new Map<string, FocusEvidence[]>();
    const localCue = commonCue ? "" : cue;
    const items = byCue.get(localCue) ?? [];
    items.push(item);
    byCue.set(localCue, items);
    groups.set(explanation, byCue);
  }
  const formatDate = new Intl.DateTimeFormat(vi ? "vi-VN" : "en", { dateStyle: "medium" });
  return <>
    {groups.size > 1 && commonCue && <p className="focus-detail-cue">{commonCue}</p>}
    {[...groups].map(([explanation, byCue]) => <div className="focus-detail-group" key={explanation}>
      <p className="focus-detail-explanation">{explanation}</p>
      {groups.size === 1 && commonCue && <p className="focus-detail-cue">{commonCue}</p>}
      {[...byCue].map(([cue, items]) => <div className="focus-detail-case" key={cue}>
        {cue && <p className="focus-detail-cue">{cue}</p>}
        {items.map((item, index) => <article key={`${item.submissionId}:${index}`}>
          {item.examples.map((example, quoteIndex) => {
            const comparison = quoteIndex === 0 && item.replacement ? replacementDiff(example.exact, item.replacement) : null;
            return <blockquote key={quoteIndex}>
              {comparison ? <>
                <div className="focus-detail-original">
                  <span className="focus-version-label">{vi ? "Câu gốc" : "Original"}</span>
                  <Quote example={example} parts={comparison.removed} />
                </div>
                <div className="focus-detail-correction">
                  <span className="focus-version-label">{vi ? "Gợi ý sửa" : "Suggested correction"}</span>
                  <Quote example={example} parts={comparison.added} />
                </div>
              </> : <Quote example={example} />}
            </blockquote>;
          })}
          <div className="focus-detail-source">
            <WritingLink href={`/writing/submissions/${encodeURIComponent(item.submissionId)}`} className="writing-text-link">
              {item.sourceTitle}<ChevronRight size={15} aria-hidden="true" />
            </WritingLink>
            <time dateTime={item.createdAt}>{formatDate.format(new Date(item.createdAt))}</time>
          </div>
        </article>)}
      </div>)}
    </div>)}
  </>;
}

function focusCheckLabel(vi: boolean, coached?: boolean) {
  return coached ? (vi ? "Kiểm tra thêm" : "Extra check") : (vi ? "Tự nhắc" : "Reminder for you");
}

function FocusDetail({ problem, vi, isSuggestion, showCheckLabel, pending, onClose, onAction, error }: {
  problem: WritingFocusCard; vi: boolean; isSuggestion: boolean; showCheckLabel: boolean; pending: boolean;
  onClose: () => void; onAction: (action: "remove" | "dismiss") => void; error?: ReactNode;
}) {
  const detail = useWritingResource<WritingFocusDetail>(`focus?problem=${encodeURIComponent(problem.key)}`);
  const modal = useRef<HTMLDialogElement>(null);
  const copy = (value: { en: string; vi: string | null }) => vi ? value.vi || value.en : value.en;
  useEffect(() => {
    const dialog = modal.current;
    if (dialog && !dialog.open) dialog.showModal();
  }, []);

  return <dialog ref={modal} className="focus-detail" aria-labelledby="focus-detail-title" onClose={onClose}>
    <header>
      <div>
        <h2 id="focus-detail-title">{copy(problem.title)}</h2>
        <p>{sessionCount(problem.sessionCount, vi)}</p>
        {showCheckLabel && <span className="focus-card-status" data-coached={problem.coached === true}>{focusCheckLabel(vi, problem.coached)}</span>}
      </div>
      <button type="button" className="focus-icon" aria-label={vi ? "Đóng chi tiết" : "Close details"}
        onClick={() => modal.current?.close()}><X size={20} aria-hidden="true" /></button>
    </header>
    <div className="focus-detail-body" tabIndex={0} role="region" aria-label={vi ? "Góp ý và ví dụ" : "Feedback and examples"}>
      {detail.loading && <p role="status">{vi ? "Đang tải ví dụ…" : "Loading examples…"}</p>}
      {detail.error && <p className="focus-error" role="alert">
        {vi ? "Chưa thể tải chi tiết." : "Couldn’t load details."}
        <button type="button" className="writing-text-link" onClick={detail.reload}>{vi ? "Tải lại" : "Reload"}</button>
      </p>}
      {detail.data && <FocusExamples evidence={detail.data.evidence} vi={vi} />}
      {error && <p className="focus-error" role="alert">{error}</p>}
    </div>
    <footer>
      <button type="button" className={`writing-text-link${isSuggestion ? " focus-dismiss" : ""}`} disabled={pending}
        onClick={() => onAction(isSuggestion ? "dismiss" : "remove")}>
        {isSuggestion ? (vi ? "Bỏ qua ghi chú này" : "Dismiss this note")
          : (vi ? "Bỏ khỏi Trọng tâm" : "Remove from Focus")}
      </button>
      <p>{isSuggestion ? (vi ? "Bạn có thể khôi phục trong Ghi chú đã bỏ qua." : "You can restore it from Dismissed notes.")
        : (vi ? "Ghi chú sẽ trở về Hộp ghi chú." : "The note returns to the Note Box.")}</p>
    </footer>
  </dialog>;
}
