// Lucian UX/UI Prompt #015 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#015
"use client";

import { useLayoutEffect, useRef } from "react";
import type { DiagnosticPrompt } from "@/lib/writing/prompt-bank";
import "./prompt-choices.css";

export function PromptChoices({
  prompts, label, selected, onSelect, disabled,
}: {
  prompts: readonly DiagnosticPrompt[];
  label: string;
  selected: string;
  onSelect: (id: string) => void;
  disabled: boolean;
}) {
  const group = useRef<HTMLDivElement>(null);
  const frame = useRef<HTMLSpanElement>(null);

  useLayoutEffect(() => {
    const list = group.current;
    const indicator = frame.current;
    if (!list || !indicator) return;
    const chosen = list.querySelector<HTMLInputElement>("input:checked")?.closest<HTMLElement>("label");
    if (!chosen) {
      delete indicator.dataset.positioned;
      return;
    }
    const position = () => {
      indicator.style.top = `${chosen.offsetTop}px`;
      indicator.style.height = `${chosen.offsetHeight}px`;
    };
    const first = !indicator.dataset.positioned;
    if (first) indicator.style.transition = "none";
    position();
    indicator.dataset.positioned = "true";
    let animation = first ? requestAnimationFrame(() => {
      animation = requestAnimationFrame(() => { indicator.style.transition = ""; });
    }) : 0;
    if (!first) indicator.style.transition = "";
    const observer = new ResizeObserver(position);
    list.querySelectorAll("label").forEach((option) => observer.observe(option));
    return () => {
      observer.disconnect();
      cancelAnimationFrame(animation);
    };
  }, [prompts, selected]);

  return (
    <fieldset className="ux u015" disabled={disabled}>
      <legend className="writing-sr-only">{label}</legend>
      <div className="u015-grp" ref={group}>
        <span className="u015-frame" ref={frame} aria-hidden="true" />
        {prompts.map((prompt) => (
          <label key={prompt.id} className="u015-opt">
            <input type="radio" name="prompt" value={prompt.id} checked={selected === prompt.id} onChange={() => onSelect(prompt.id)} />
            <span className="u015-dot" aria-hidden="true" />
            <span lang="en" className="u015-txt">
              <strong>{prompt.title}</strong>
              <small>{prompt.scenario}</small>
            </span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}
