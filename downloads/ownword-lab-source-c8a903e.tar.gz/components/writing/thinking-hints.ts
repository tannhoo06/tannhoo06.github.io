import type { DiscussionPromptId } from "@/lib/writing/discussion-prompts";

// Editor-only questions that invite reflection. The assessment never reads them.
export const discussionThinkingHints = {
  "group-chat-expectations": [
    { en: "When does a reply matter?", vi: "Khi nào cần trả lời tin nhắn?" },
    { en: "What makes a group chat feel relaxed?", vi: "Điều gì giúp trò chuyện trong nhóm thoải mái hơn?" },
  ],
  "recorded-lectures": [
    { en: "What makes a lecture worth attending?", vi: "Điều gì khiến bạn muốn đến lớp nghe giảng?" },
    { en: "Would you feel the same about every class?", vi: "Bạn có nghĩ như vậy với mọi lớp học không?" },
  ],
  "reviews-before-films": [
    { en: "What do you want to know before watching?", vi: "Trước khi xem phim, bạn muốn biết điều gì?" },
    { en: "What would you rather discover as you watch?", vi: "Bạn muốn tự khám phá điều gì trong lúc xem?" },
  ],
  "choice-in-physical-education": [
    { en: "What makes a PE lesson worth joining in?", vi: "Điều gì khiến bạn muốn tham gia một buổi học thể dục?" },
    { en: "Would every student choose the same way?", vi: "Các bạn trong lớp có chọn giống nhau không?" },
  ],
  "sharing-quiet-places": [
    { en: "What makes a place worth sharing?", vi: "Điều gì khiến bạn muốn chia sẻ một địa điểm?" },
    { en: "Who might be affected by the post?", vi: "Bài đăng có thể ảnh hưởng đến ai?" },
  ],
  "repair-before-replacing": [
    { en: "What would you want to know before deciding?", vi: "Bạn muốn biết gì trước khi quyết định?" },
    { en: "Does it depend on what broke?", vi: "Nếu là món đồ khác, bạn có đổi ý không?" },
  ],
  "music-while-studying": [
    { en: "Does it depend on what you’re studying?", vi: "Điều đó có phụ thuộc vào việc bạn đang học không?" },
    { en: "Does the choice of music matter?", vi: "Thể loại nhạc có quan trọng không?" },
  ],
  "fair-group-plans": [
    { en: "What would make the choice feel fair?", vi: "Điều gì làm cả nhóm thấy lựa chọn công bằng?" },
    { en: "Would the occasion change your answer?", vi: "Nếu là dịp khác, bạn có đổi ý không?" },
  ],
} satisfies Record<DiscussionPromptId, { en: string; vi: string }[]>;
