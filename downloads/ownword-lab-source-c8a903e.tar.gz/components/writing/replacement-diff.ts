export type TextPart = { text: string; changed: boolean };

/** Match whole words and punctuation, then refine small edits within a word. */
export function replacementDiff(original: string, suggestion: string) {
  const tokenize = (text: string) => text.match(/[\p{L}\p{M}\p{N}]+|\s+|[^\p{L}\p{M}\p{N}\s]/gu) ?? [];
  const before = tokenize(original);
  const after = tokenize(suggestion);
  const matches = Array.from({ length: before.length + 1 }, () => new Uint16Array(after.length + 1));
  for (let i = before.length - 1; i >= 0; i--) {
    for (let j = after.length - 1; j >= 0; j--) {
      matches[i][j] = before[i] === after[j] ? 1 + matches[i + 1][j + 1]
        : Math.max(matches[i + 1][j], matches[i][j + 1]);
    }
  }

  const removed: TextPart[] = [];
  const added: TextPart[] = [];
  function append(parts: TextPart[], text: string, changed: boolean) {
    if (!text) return;
    const last = parts.at(-1);
    if (last?.changed === changed) last.text += text;
    else parts.push({ text, changed });
  }
  function appendEdit(oldText: string, newText: string) {
    if (oldText && newText && !/\s/u.test(oldText + newText)) {
      const oldChars = Array.from(oldText);
      const newChars = Array.from(newText);
      let prefix = 0;
      let suffix = 0;
      const sharedLimit = Math.min(oldChars.length, newChars.length);
      while (prefix < sharedLimit && oldChars[prefix] === newChars[prefix]) prefix++;
      while (prefix + suffix < sharedLimit &&
        oldChars[oldChars.length - 1 - suffix] === newChars[newChars.length - 1 - suffix]) suffix++;
      if (prefix + suffix >= Math.max(2, Math.ceil(sharedLimit / 2))) {
        for (const [parts, chars] of [[removed, oldChars], [added, newChars]] as const) {
          append(parts, chars.slice(0, prefix).join(""), false);
          append(parts, chars.slice(prefix, chars.length - suffix).join(""), true);
          append(parts, chars.slice(chars.length - suffix).join(""), false);
        }
        return;
      }
    }
    append(removed, oldText, true);
    append(added, newText, true);
  }

  let i = 0;
  let j = 0;
  while (i < before.length || j < after.length) {
    if (i < before.length && j < after.length && before[i] === after[j]) {
      append(removed, before[i++], false);
      append(added, after[j++], false);
      continue;
    }
    const startI = i;
    const startJ = j;
    while (i < before.length || j < after.length) {
      if (i < before.length && j < after.length && before[i] === after[j]) break;
      if (j >= after.length || (i < before.length && matches[i + 1][j] >= matches[i][j + 1])) i++;
      else j++;
    }
    appendEdit(before.slice(startI, i).join(""), after.slice(startJ, j).join(""));
  }
  return { removed, added };
}

