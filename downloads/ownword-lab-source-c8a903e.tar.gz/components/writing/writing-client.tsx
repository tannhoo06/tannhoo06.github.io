"use client";

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import type { WritingRun, WritingSubmission, WritingTask } from "@/lib/writing/persistence";
import { moduleNavigationEvent } from "../shared";
import { announceStreakAward } from "@/lib/client/learning-streak";
import { requestError } from "@/lib/client/request-error";

export type WritingQuota = { remaining: number; resetAt: string; pending?: number };

export type WritingRecord = {
  task: WritingTask;
  submission: WritingSubmission;
  run: WritingRun | null;
  latestRevisionId?: string | null;
  quota?: WritingQuota;
};
export type WritingProfileSummary = { latestSubmissionId: string | null };

export class WritingRequestError extends Error {
  constructor(readonly status: number, message: string) { super(message); }
}

export async function writingRequest<T>(
  path: string, options: { body?: unknown; signal?: AbortSignal; acceptQuota?: boolean } = {},
): Promise<T> {
  const { body, signal, acceptQuota } = options;
  const response = await fetch(`/api/writing/${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: body === undefined ? {} : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal,
    cache: "no-store",
  });
  const data: unknown = await response.json().catch(() => undefined);
  const record = data && typeof data === "object" ? data as Partial<WritingRecord> : undefined;
  const savedAtLimit = acceptQuota && response.status === 429 && record?.submission?.id && record.quota;
  if ((!response.ok && !savedAtLimit) || data === undefined) {
    throw new WritingRequestError(response.status, requestError(response.status, data).message);
  }
  announceStreakAward(response);
  return data as T;
}

export function useWritingResource<T>(path: string | null) {
  const [sequence, setSequence] = useState(0);
  const key = path === null ? null : `${path}:${sequence}`;
  const [result, setResult] = useState<{ path: string; key: string; data?: T; error?: Error }>();
  const reload = useCallback(() => setSequence((previous) => previous + 1), []);
  useEffect(() => {
    if (key === null || path === null) return;
    const controller = new AbortController();
    writingRequest<T>(path, { signal: controller.signal }).then(
      (data) => { if (!controller.signal.aborted) setResult({ path, key, data }); },
      (error: unknown) => {
        if (!controller.signal.aborted) setResult({ path, key, error: error instanceof Error ? error : new Error("Request failed.") });
      },
    );
    return () => controller.abort();
  }, [key, path]);
  return {
    data: result?.path === path ? result.data : undefined,
    error: result?.key === key ? result.error : undefined,
    loading: key !== null && result?.key !== key,
    reload,
  };
}

export function useWritingDraftGuard(dirty: boolean) {
  const saved = useRef(false);
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => {
      if (saved.current) return;
      event.preventDefault();
      event.returnValue = "";
    };
    const deleted = () => { saved.current = true; };
    const requestDocument = (event: Event) => { if (!saved.current) event.preventDefault(); };
    window.addEventListener("beforeunload", warn);
    window.addEventListener(moduleNavigationEvent, requestDocument);
    window.addEventListener("ownword:writing-deleted", deleted);
    return () => {
      window.removeEventListener("beforeunload", warn);
      window.removeEventListener(moduleNavigationEvent, requestDocument);
      window.removeEventListener("ownword:writing-deleted", deleted);
    };
  }, [dirty]);
  return () => { saved.current = true; };
}

const words = new Intl.Segmenter("en", { granularity: "word" });
export function writingWordCount(text: string) {
  return Array.from(words.segment(text)).filter(({ isWordLike }) => isWordLike).length;
}

/** Document navigation keeps the native unsaved-draft guard in effect. */
export function WritingLink({ href, children, className }: { href: string; children: ReactNode; className?: string }) {
  return <a href={href} className={className}>{children}</a>;
}
