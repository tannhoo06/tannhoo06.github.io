"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, ChevronDown, FileText, LoaderCircle, MessageSquareText, PenLine } from "lucide-react";
import Image from "next/image";
import type { DiagnosticReport, IssueFirstReportObservation } from "@/lib/writing/contracts";
import { validSource } from "@/lib/domain/anchors";
import { orderWritingFeedback } from "@/lib/writing/feedback-order";
import { replacementDiff, type TextPart } from "./replacement-diff";
import { diagnosticReportState, hasDiagnosticTaskEvidence } from "@/lib/writing/report-state";
import { getWritingPracticeRecommendations } from "@/lib/writing/personalized-practice";
import { writingPracticeHref } from "@/lib/writing/practice-path";
import { useI18n } from "../language-provider";
import { HighlightedWriting } from "../lucian-281-highlighted-writing";
import { useConfirmAction } from "../lucian-269-confirmation";
import { useRequestLimitNotice } from "../request-limit-notice";
import { LucianLanguageContent, LucianLanguageText } from "../lucian-267-language-switch";
import { Button } from "../shared";
import { storeDiagnosticDraft } from "./diagnostic-draft";
import { WritingQuotaCounter } from "./quota-counter";
import { clearRevisionSession } from "./revision-session";
import {
  WritingLink, WritingRequestError, useWritingResource, writingRequest,
  type WritingProfileSummary, type WritingRecord,
} from "./writing-client";

export type SkillLabels = Record<string, { en: string; vi: string }>;

export function WritingHome() {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const profile = useWritingResource<WritingProfileSummary>("profile");
  const hasWriting = !!profile.data?.latestSubmissionId;
  return (
    <div className="writing-flow writing-home">
      <header className="ow-page-intro" data-align="center">
        <h1><LucianLanguageContent locale={locale} render={(language) => language === "vi"
          ? <>Luyện viết tiếng Anh</>
          : <>Practice writing in English</>} /></h1>
      </header>
      <div className="writing-home-detail ow-surface" data-tone="soft">
        <span className="practice-hub-icon"><PenLine strokeWidth={1.7} aria-hidden="true" /></span>
        <div className="writing-home-copy">
          <p>{vi ? "Chọn đề, viết khoảng 130 đến 160 từ rồi xem góp ý ngay trên câu của bạn." : "Choose a prompt, write about 130 to 160 words, and get feedback on your sentences."}</p>
        </div>
        <Image className="writing-home-art" src="/images/sprout-writing-overview-task.svg" alt="" width={216} height={190} unoptimized />
        <div className="writing-actions">
          <div className="writing-home-primary">
            <WritingLink className="ow-action-primary writing-primary-action" href={hasWriting ? "/writing/profile" : "/writing/diagnostic"}>
              <PenLine size={17} aria-hidden="true" />{hasWriting ? (vi ? "Mở Hồ sơ viết" : "Open Writing Profile") : (vi ? "Bắt đầu viết" : "Start writing")}<ArrowRight size={17} aria-hidden="true" />
            </WritingLink>
            <WritingQuotaCounter />
          </div>
          <WritingLink className="writing-text-link" href={hasWriting ? "/writing/diagnostic" : "/writing/profile"}>
            {hasWriting ? (vi ? "Viết bài mới" : "Start a new response") : (vi ? "Hồ sơ viết" : "Writing Profile")}
          </WritingLink>
        </div>
      </div>
      {profile.error && <p className="writing-note" role="status">{vi ? "Chưa kiểm tra được bài đã lưu." : "We couldn’t check for a saved response."}</p>}
    </div>
  );
}

export function WritingResults({ id, labels, ownerId }: { id: string; labels: SkillLabels; ownerId: string }) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const requested = useWritingResource<WritingRecord>(`submissions/${id}`);
  const parentId = requested.data?.submission.parentSubmissionId;
  const parent = useWritingResource<WritingRecord>(parentId ? `submissions/${parentId}` : null);
  const original = parentId ? parent : requested;
  const revisionId = parentId ? requested.data?.submission.id : original.data?.latestRevisionId;
  const reloadOriginal = original.reload;
  const pending = original.data?.run?.status === "pending";
  useEffect(() => {
    if (!pending || original.loading) return;
    const timer = setTimeout(reloadOriginal, 1200);
    return () => clearTimeout(timer);
  }, [pending, original.loading, reloadOriginal]);

  const unavailable = requested.error ?? parent.error;
  return (
    <div className="writing-flow writing-flow-wide writing-notebook writing-submission-report">
      <WritingLink href="/writing/profile" className="writing-text-link">
        <ArrowLeft size={16} aria-hidden="true" />{vi ? "Hồ sơ viết" : "Writing Profile"}
      </WritingLink>
      <header className="writing-heading">
        <h1><LucianLanguageText value={vi ? "Nhận xét bài viết" : "Feedback on your response"} /></h1>
      </header>
      {unavailable && <div className="writing-alert" role="alert">
        {unavailable instanceof WritingRequestError && unavailable.status === 404
          ? (vi ? "Không tìm thấy bài viết này." : "This response couldn’t be found.")
          : (vi ? "Chưa tải được bài viết." : "We couldn’t load your writing.")}
        {!(unavailable instanceof WritingRequestError && unavailable.status === 404) &&
          <button className="writing-text-link" onClick={requested.error ? requested.reload : parent.reload}>{vi ? "Thử lại" : "Try again"}</button>}
      </div>}
      {!unavailable && !original.data && (requested.loading || parent.loading) && (
        <p className="writing-status" role="status"><LoaderCircle size={18} className="spin" />{vi ? "Đang tải bài viết…" : "Loading your writing…"}</p>
      )}
      {original.data && <SubmissionReport key={original.data.submission.id} record={original.data} labels={labels}
        revisionId={revisionId}
        reload={original.reload} ownerId={ownerId} />}
    </div>
  );
}

function SubmissionReport({ record, revisionId, labels, reload, ownerId }: {
  record: WritingRecord; revisionId?: string | null; labels: SkillLabels; reload: () => void; ownerId: string;
}) {
  const { locale, t } = useI18n();
  const vi = locale === "vi";
  const { show: showLimit, withReset } = useRequestLimitNotice();
  const [retrying, setRetrying] = useState(false);
  const [retryError, setRetryError] = useState("");
  const [quota, setQuota] = useState<WritingRecord["quota"]>();
  const retryId = useRef<string | null>(null);
  const report = record.run?.report;
  const status = record.run?.status;
  const allowance = useWritingResource<NonNullable<WritingRecord["quota"]>>(!report && status !== "pending" ? "quotas" : null);
  const allowanceLimit = quota ?? allowance.data;
  const limit = allowanceLimit?.remaining === 0 ? allowanceLimit : undefined;
  const limitMessage = t(limit?.pending
    ? "Your essay is saved. All assessment slots are in use. Check again when the current assessments finish."
    : "Your essay is saved. You’ve reached today’s writing assessment limit.");

  async function retry() {
    if (retrying) return;
    const trigger = document.activeElement;
    retryId.current ??= crypto.randomUUID();
    setRetrying(true);
    setRetryError("");
    try {
      const next = await writingRequest<WritingRecord>(`submissions/${record.submission.id}/retry`, {
        body: { requestId: retryId.current }, acceptQuota: true,
      });
      setQuota(next.quota);
      retryId.current = null;
      reload();
      if (next.quota && !next.run?.report) {
        const pending = !!next.quota.pending;
        void showLimit(t(pending
          ? "Your essay is saved. All assessment slots are in use. Check again when the current assessments finish."
          : "Your essay is saved. You’ve reached today’s writing assessment limit."),
          pending ? undefined : next.quota.resetAt, pending ? "Assessments in progress" : undefined, trigger);
      }
    } catch (error) {
      setRetryError(error instanceof WritingRequestError && error.status === 401
        ? "Your session has ended. Sign in and try again."
        : error instanceof TypeError
          ? "Couldn’t connect to Ownword. Your essay is saved. Check your connection and retry."
          : "We couldn’t confirm the assessment request. Your essay is saved. Please try again.");
    } finally {
      setRetrying(false);
    }
  }

  return (
    <>
      {report ? <Assessment report={report} record={record} labels={labels} revisionId={revisionId} /> : (
        <section className="writing-empty">
          <h2>{status === "pending" ? (vi ? "Đang chuẩn bị nhận xét" : "Preparing your feedback")
            : (vi ? "Bài đã lưu, chưa có nhận xét" : "Essay saved. No feedback yet.")}</h2>
          <p>{status === "pending" ? (vi ? "Bài của bạn đã được lưu. Bạn có thể quay lại đây để xem góp ý." : "Your essay is saved. Come back to this report to see the feedback.")
            : status === "failed" ? t("We couldn’t generate feedback for this essay. You can retry using the saved version.")
              : status === "expired" ? t("The assessment took too long. You can retry using the saved essay.")
                : t("You can request feedback for this saved essay.")}</p>
          {status === "pending" ? <p className="writing-status" role="status"><LoaderCircle size={18} className="spin" />{vi ? "Đang xử lý…" : "In progress…"}</p> : (
            <Button className="practice-hub-cta" type="button" onClick={() => void retry()} disabled={retrying}>{retrying ? (vi ? "Đang thử lại…" : "Retrying…") : (vi ? "Thử nhận xét lại" : "Retry assessment")}</Button>
          )}
          {limit && <p className="writing-alert" role="status">{withReset(limitMessage, limit.pending ? undefined : limit.resetAt)}</p>}
          {retryError && <p className="writing-alert" role="alert">{t(retryError)}</p>}
          <blockquote className="writing-original" lang="en">{record.submission.text}</blockquote>
        </section>
      )}
      <div className="writing-report-actions">
        <WritingLink href="/writing/diagnostic" className="writing-text-link">{vi ? "Viết bài mới" : "Start a new response"}<ArrowRight size={16} aria-hidden="true" /></WritingLink>
        <DeleteWriting id={record.submission.id} ownerId={ownerId} />
      </div>
    </>
  );
}

function Assessment({ report, record, labels, revisionId }: {
  report: DiagnosticReport; record: WritingRecord; labels: SkillLabels;
  revisionId?: string | null;
}) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const [active, setActive] = useState(-1);
  const [showMore, setShowMore] = useState(false);
  const pilot = report.issueFirstObservations;
  const ordered = pilot ? orderWritingFeedback(pilot) : [];
  const primary = ordered.filter((item) => item.kind === "problem" && item.feedback?.category !== "optional").slice(0, 3);
  const strengths = ordered.filter((item) => item.kind === "strength");
  const more = ordered.filter((item) => item.kind === "problem" && !primary.includes(item));
  const recommendations = getWritingPracticeRecommendations(report, record.submission.text);
  const practice = recommendations.filter(({ skill }, index) => recommendations.findIndex((item) => item.skill === skill) === index);
  const practiceLinks = practice.map((item) => <WritingLink key={item.skill} className="writing-feedback-practice-option"
    href={writingPracticeHref(record.submission.id, item.observationIndex)}>
    {item.label[locale]}<ArrowRight size={14} aria-hidden="true" />
  </WritingLink>);
  const legacyFindings = report.findings.slice(0, 3);
  const legacyStrengths = legacyFindings.filter(({ judgment }) => judgment === "positive");
  const focused: IssueFirstReportObservation[] = report.focusCheck?.version === 1 ? report.focusCheck.observations.filter(({ evidence }) =>
    evidence.length && evidence.every((anchor) => validSource(record.submission.text, record.submission.id, anchor))) : [];
  const ordinary = pilot ? ordered : legacyFindings;
  // Assign stable IDs regardless of which group is open.
  const evidenceList = [...ordinary, ...focused].flatMap((finding, index) => {
    const positive = "kind" in finding ? finding.kind === "strength" : finding.judgment === "positive";
    return finding.evidence.map((anchor) => ({
      source: anchor, label: anchor.exact, index, tone: positive ? "positive" as const : undefined,
    }));
  });
  const hidden = new Set(showMore ? [] : more.map((finding) => ordered.indexOf(finding)));
  const label = (id: string) => labels[id]?.[locale] ?? id;
  const reportState = diagnosticReportState(report);
  const insufficient = reportState === "insufficient_evidence";
  const localOnly = reportState === "observed" && !hasDiagnosticTaskEvidence(report);
  const limited = Object.entries(report.skills).filter(([, skill]) => skill.opportunity === "limited").map(([id]) => label(id));
  const taskChecks = Object.entries(report.taskFulfillment).filter(([, check]) => check.status !== "undetermined");
  const { prompt } = record.task.snapshot;
  const discussion = "interestIds" in prompt;
  const legacyRequirementNames = vi
    ? { position: "Nêu lựa chọn", reasons: "Giải thích hai lý do", trade_off: "Nêu một điểm bất lợi" }
    : { position: "Make a recommendation", reasons: "Explain two reasons", trade_off: "Acknowledge a drawback" };
  function locateEvidence(index: number) {
    setActive(index);
    requestAnimationFrame(() => document.getElementById("writing-original")
      ?.querySelector<HTMLButtonElement>(`[data-source-index="${index}"]`)?.focus());
  }
  function evidenceButtons(index: number, compact = false, originalParts?: ReturnType<typeof replacementDiff>["removed"]) {
    const anchors = evidenceList.map((evidence, evidenceIndex) => ({ ...evidence, evidenceIndex }))
      .filter((evidence) => evidence.index === index);
    return anchors.map(({ source: anchor, evidenceIndex }, position) => (
      <button key={evidenceIndex} id={`writing-evidence-${evidenceIndex}`} className="writing-evidence" type="button" lang="en"
        aria-label={compact || (pilot && position > 0)
          ? (vi ? `Xem trong bài: “${anchor.exact}”` : `See in your writing: “${anchor.exact}”`)
          : undefined}
        aria-pressed={active === evidenceIndex} onClick={() => locateEvidence(evidenceIndex)}>
        {compact || (pilot && position > 0)
          ? <span lang={locale}>{vi ? "Xem trong bài" : "See in your writing"}{anchors.length > 1 ? ` ${position + 1}` : ""}</span>
          : <span>“{originalParts ? diffText(originalParts) : anchor.exact}”</span>}
        {(!originalParts || position > 0) && <ArrowRight size={13} aria-hidden="true" />}
      </button>
    ));
  }
  function reviewItem(finding: IssueFirstReportObservation) {
    const focusIndex = focused.indexOf(finding);
    const index = focusIndex < 0 ? ordered.indexOf(finding) : ordinary.length + focusIndex;
    const { feedback } = finding;
    const category = feedback?.category ?? (finding.kind === "strength" ? "strength" : "suggestion");
    const copy = vi && feedback ? feedback.vi : finding;
    const language = vi && feedback ? "vi" : "en";
    const replacement = feedback?.replacement;
    const comparison = replacement && finding.evidence[0] ? replacementDiff(finding.evidence[0].exact, replacement) : null;
    const categoryLabel = {
      mistake: vi ? "Lỗi cần sửa" : "Mistake",
      clarity: vi ? "Cần làm rõ" : "Clarity",
      optional: vi ? "Có thể viết tự nhiên hơn" : "Optional polish",
      strength: vi ? "Điểm làm tốt" : "Strength",
      suggestion: vi ? "Góp ý" : "Suggestion",
    }[category];
    return (
      <article className="writing-feedback-item" key={index} data-category={category}
        data-current={evidenceList[active]?.index === index ? "" : undefined}>
        {finding.kind === "strength" ? <>
          <h3 lang={language}>{copy.problem}</h3>
          {copy.readerImpact.trim() !== copy.problem.trim() &&
            <p className="writing-feedback-reason" lang={language}>{copy.readerImpact}</p>}
          <div className="writing-feedback-passages">{evidenceButtons(index, true)}</div>
        </> : <>
          <div className="writing-feedback-category">{categoryLabel}</div>
          <div className={comparison ? "writing-feedback-comparison" : "writing-feedback-example"}>
            {comparison && <span className="writing-comparison-label">{vi ? "Bản gốc" : "Original"}</span>}
            <div>{evidenceButtons(index, false, comparison?.removed)}</div>
            {comparison && <>
              <span className="writing-comparison-label">{vi ? "Gợi ý" : "Suggestion"}</span>
              <p className="writing-feedback-suggestion" lang="en">{diffText(comparison.added)}</p>
              <span className="writing-comparison-turn" aria-hidden="true" />
            </>}
          </div>
          {!comparison && copy.revisionCue && <div className="writing-feedback-change">
            <ArrowRight size={14} aria-hidden="true" />
            <span className="writing-sr-only">{vi ? "Thử viết" : "Try this"}</span>
            <span lang={language}>{copy.revisionCue}</span>
          </div>}
          <p className="writing-feedback-reason" lang={language}>{copy.readerImpact}</p>
          {!feedback?.replacement && !copy.revisionCue && <p className="writing-feedback-reason" lang={language}>{copy.problem}</p>}
        </>}
      </article>
    );
  }

  return (
    <div className="writing-report-layout">
      {(strengths.length > 0 || legacyStrengths.length > 0) && <section className="writing-feedback-strengths" aria-labelledby="writing-strengths-title">
        <h2 id="writing-strengths-title">{vi ? "Bạn đã làm tốt" : "What you did well"}</h2>
        {strengths.map(reviewItem)}
        {legacyStrengths.map((finding) => (
          <article className="writing-feedback-item" data-category="strength" key={finding.skillId}
            data-current={evidenceList[active]?.index === legacyFindings.indexOf(finding) ? "" : undefined}>
            <p className="writing-feedback-reason" lang="en">{finding.readerImpact}</p>
            <div className="writing-feedback-passages">{evidenceButtons(legacyFindings.indexOf(finding), true)}</div>
          </article>
        ))}
      </section>}
      <section className="writing-findings" id="writing-feedback" tabIndex={-1}>
        {practice.length > 0 && <nav className="writing-feedback-practice-links" aria-labelledby="writing-practice-links-title">
          <h2 id="writing-practice-links-title">{vi ? "Luyện theo góp ý" : "Practice from your feedback"}</h2>
          {practiceLinks.slice(0, 3)}
          {practiceLinks.length > 3 && <details className="writing-feedback-more-practice">
            <summary>{vi ? `Xem thêm ${practiceLinks.length - 3} bài luyện` : `More practice (${practiceLinks.length - 3})`}
              <ChevronDown size={15} aria-hidden="true" /></summary>
            <div>{practiceLinks.slice(3)}</div>
          </details>}
        </nav>}
        <header className="writing-findings-heading">
          <MessageSquareText size={18} strokeWidth={1.7} aria-hidden="true" />
          <h2>{pilot && primary.length ? (vi ? "Nên sửa gì trước?" : "What to work on first") : (vi ? "Góp ý cho bài viết" : "Feedback on your response")}</h2>
          {pilot && <a href="#writing-original" className="writing-text-link writing-feedback-jump">
            {vi ? "Xem bài gốc" : "See original"}<ChevronDown size={15} aria-hidden="true" />
          </a>}
        </header>
        {pilot ? <>
          {primary.map(reviewItem)}
          <RevisionLinks originalId={record.submission.id} revisionId={revisionId} vi={vi} />
          {more.length > 0 && <>
            <button type="button" className="writing-feedback-more" aria-expanded={showMore} aria-controls="writing-more-feedback"
              onClick={() => {
                if (showMore && more.includes(ordered[evidenceList[active]?.index])) setActive(-1);
                setShowMore(!showMore);
              }}>
              {showMore ? (vi ? "Thu gọn góp ý" : "Show fewer suggestions")
                : (vi ? `Xem thêm ${more.length} góp ý` : `Show ${more.length} more ${more.length === 1 ? "suggestion" : "suggestions"}`)}
              <ChevronDown size={16} aria-hidden="true" />
            </button>
            <div id="writing-more-feedback" hidden={!showMore}>{showMore && more.map(reviewItem)}</div>
          </>}
        </> : legacyFindings.map((finding, index) => {
          const { judgment } = finding;
          if (judgment === "positive") return null;
          return (
            <article className={`writing-finding writing-finding-${judgment}`} key={index}
              data-current={evidenceList[active]?.index === index ? "" : undefined}>
              <div className="writing-finding-kind">{judgment === "mixed" ? (vi ? "Cần làm rõ" : "Clarity") : (vi ? "Góp ý" : "Suggestion")}</div>
              <h3>{label(finding.skillId)}</h3>
              {evidenceButtons(index)}
              <p lang="en">{finding.readerImpact}</p>
              {finding.revisionCue && <p className="writing-revision-cue" lang="en">{finding.revisionCue}</p>}
            </article>
          );
        })}
        {!pilot && <RevisionLinks originalId={record.submission.id} revisionId={revisionId} vi={vi} />}
        {reportState === "no_actionable_findings" && focused.length === 0 && <div className="writing-insufficient">
          <h3>{vi ? "Chưa có nhận xét cụ thể" : "No specific feedback for this response"}</h3>
          <p>{vi ? "Lần xem này xác định được quan điểm và lý lẽ."
            : "This review found a position with supporting reasoning."}</p>
        </div>}
        {(insufficient || localOnly || (!pilot && limited.length > 0)) && <div className="writing-insufficient">
          {insufficient ? <>
            <h3>{vi ? "Cần thêm nội dung để góp ý cho cả bài" : "We need more to give feedback on the whole essay"}</h3>
            <p>{vi ? "Lần xem này chưa có đủ căn cứ để nhận xét toàn bài. Hãy nêu rõ quan điểm và giải thích vì sao bạn nghĩ như vậy."
              : "This review didn’t establish enough evidence for overall feedback. A clear position and some reasoning give the review more to work with."}</p>
          </> : <>
            {localOnly && <p>{vi ? "Các góp ý này chỉ áp dụng cho những đoạn được đánh dấu."
              : "These suggestions apply to the highlighted passages."}</p>}
            {!pilot && limited.length > 0 && <>
              <h3>{vi ? "Kỹ năng chưa đủ căn cứ để nhận xét" : "Skills with limited evidence"}</h3>
              <p>{limited.join(" · ")}</p>
            </>}
          </>}
        </div>}
        {discussion && report.taskFulfillment.position.status === "missing" && (
          <p className="writing-note">{vi ? "Bài viết này chưa trả lời câu hỏi chính." : "This response didn’t address the main question."}</p>
        )}
        {!discussion && taskChecks.length > 0 && <div className="writing-task-check">
          <h3>{vi ? "Các yêu cầu của đề" : "Prompt requirements"}</h3>
          <ul>{taskChecks.map(([id, check]) => <li key={id}>
            {legacyRequirementNames[id as keyof typeof legacyRequirementNames]} <span>{check.status === "met"
              ? (vi ? "Đã đáp ứng" : "Met") : check.status === "partly_met" ? (vi ? "Đáp ứng một phần" : "Partly met")
                : (vi ? "Chưa thấy trong bài" : "Missing from this response")}</span>
          </li>)}</ul>
        </div>}
        {focused.length > 0 && <section className="writing-focus-feedback" aria-labelledby="writing-focus-feedback-title">
          <h2 id="writing-focus-feedback-title">{vi ? "Góp ý thêm về các điểm bạn đã ghim" : "Extra feedback on your pinned topics"}</h2>
          <p className="writing-note">{vi ? "Các góp ý này đến từ lượt kiểm tra riêng cho những điểm bạn đã ghim." : "These findings come from a separate check of your pinned topics."}</p>
          {focused.map(reviewItem)}
        </section>}
      </section>
      <section className="writing-reading" id="writing-original" tabIndex={-1}>
        <header className="writing-reading-heading">
          <span className="practice-hub-icon"><FileText aria-hidden="true" strokeWidth={1.7} /></span>
          <h2>{vi ? "Bài viết gốc của bạn" : "Your original essay"}</h2>
        </header>
        <details className="writing-guide writing-original-prompt">
          <summary>{vi ? "Xem đề bài" : "View prompt"}<ChevronDown size={15} aria-hidden="true" /></summary>
          <p lang="en">{prompt.scenario}</p>
          {"options" in prompt && !prompt.title && <ul className="writing-options" lang="en">
            {prompt.options.map((option) => <li key={option}>{option}</li>)}
          </ul>}
        </details>
        <HighlightedWriting text={record.submission.text}
          items={evidenceList.map((item) => hidden.has(item.index) ? { ...item, source: null } : item)} active={active}
          sourceVersion={record.submission.id} showNumbers={false} staggerHighlights={false}
          markLabel={(_, quote) => vi ? `Xem nhận xét cho “${quote}”` : `See observation for “${quote}”`}
          select={(index) => {
            setActive(index);
            document.getElementById(`writing-evidence-${index}`)?.focus();
          }} />
      </section>
    </div>
  );
}

function diffText(parts: readonly TextPart[]) {
  return parts.map(({ text, changed }, index) => changed
    ? <mark className="writing-edit-mark" key={index}>{text}</mark>
    : text);
}

function RevisionLinks({ originalId, revisionId, vi }: { originalId: string; revisionId?: string | null; vi: boolean }) {
  return <div className="writing-feedback-next">
    <WritingLink className="button-primary writing-feedback-revise" href={`/writing/submissions/${originalId}/revise`}>
      <PenLine size={16} aria-hidden="true" />{vi ? "Tự chỉnh sửa" : "Revise my response"}
    </WritingLink>
    {revisionId && <WritingLink className="writing-text-link" href={`/writing/submissions/${revisionId}/revise`}>
      {vi ? "Xem bản chỉnh sửa đã lưu" : "View saved revision"}
    </WritingLink>}
  </div>;
}

export function DeleteWriting({ id, parentId, draftOwnerId, ownerId }: {
  id?: string; parentId?: string; draftOwnerId?: string; ownerId?: string;
}) {
  const all = draftOwnerId !== undefined;
  const { locale } = useI18n();
  const vi = locale === "vi";
  const confirm = useConfirmAction();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);
  const title = all ? (vi ? "Xóa dữ liệu viết" : "Delete Writing data")
    : parentId ? (vi ? "Xóa bản chỉnh sửa" : "Delete revision") : (vi ? "Xóa bài viết" : "Delete response");
  async function remove() {
    if (!(await confirm({ title,
      message: all ? (vi ? "Thao tác này xóa bài đã gửi, bản chỉnh sửa, góp ý, xu hướng trong Hồ sơ viết và các ghi chú Trọng tâm. Các từ đã lưu trong WordBoard vẫn còn trong tài khoản." : "This deletes your essays, revisions, feedback, Writing Profile trends, and saved Focus notes. Words saved to WordBoard stay in your account.")
        : parentId ? (vi ? "Thao tác này xóa bản chỉnh sửa đã lưu." : "This removes the saved revision.")
          : (vi ? "Thao tác này xóa bài gốc, các bản chỉnh sửa và nhận xét của bài. Ghi chú Trọng tâm có thể biến mất nếu bài này là ví dụ duy nhất của ghi chú đó." : "This removes the original, its revisions and its feedback. A Focus note may disappear if this essay was its only example."),
      confirmLabel: vi ? "Xác nhận xóa" : "Confirm deletion" }))) return;
    setBusy(true);
    setError(false);
    try {
      await writingRequest(all ? "data/delete" : `submissions/${id}/delete`, { body: {} });
      if (all) storeDiagnosticDraft(draftOwnerId, null);
      const owner = draftOwnerId ?? ownerId;
      if (owner) clearRevisionSession(owner, parentId ?? id, parentId ? id : undefined);
      window.dispatchEvent(new Event("ownword:writing-deleted"));
      window.location.replace(parentId ? `/writing/submissions/${parentId}` : "/writing/profile");
    } catch {
      setError(true);
      setBusy(false);
    }
  }
  return <div className="writing-delete">
    <button className="writing-text-link writing-delete-button" type="button" disabled={busy} onClick={() => void remove()}>
      {busy ? (vi ? "Đang xóa…" : "Deleting…") : title}
    </button>
    {error && <p className="writing-alert" role="alert">{vi ? "Chưa xóa được dữ liệu. Bạn có thể thử lại." : "Deletion didn’t complete. You can try again."}</p>}
  </div>;
}
