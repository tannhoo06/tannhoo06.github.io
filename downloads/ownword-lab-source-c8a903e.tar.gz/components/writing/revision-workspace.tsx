"use client";

import { useEffect, useRef, useState, type FormEvent, type RefObject, type ReactNode } from "react";
import { ArrowLeft, ArrowRight, Check, ChevronDown, LoaderCircle, MessageSquareText, PenLine } from "lucide-react";
import type { DiagnosticReport } from "@/lib/writing/contracts";
import { orderWritingFeedback } from "@/lib/writing/feedback-order";
import type { SavedRevisionCheck } from "@/lib/writing/persistence";
import { getWritingPracticeRecommendations, type WritingPracticeRecommendation } from "@/lib/writing/personalized-practice";
import { writingPracticeHref } from "@/lib/writing/practice-path";
import type { WritingRevisionCheck } from "@/lib/writing/revision-check";
import { useI18n } from "../language-provider";
import { Button } from "../shared";
import { DeleteWriting } from "./report";
import { replacementDiff, type TextPart } from "./replacement-diff";
import { readRevisionDraft, storeRevisionDraft } from "./revision-session";
import {
  WritingLink, WritingRequestError, useWritingDraftGuard, useWritingResource, writingRequest,
  writingWordCount, type WritingRecord,
} from "./writing-client";

type RevisionLink = { id: string; createdAt: string; wordCount: number };
const path = (id: string) => `/writing/submissions/${id}`;

export function RevisionWorkspace({ id, ownerId, canCheck }: { id: string; ownerId: string; canCheck: boolean }) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const requested = useWritingResource<WritingRecord>(`submissions/${id}`);
  const parentId = requested.data?.submission.parentSubmissionId;
  const parent = useWritingResource<WritingRecord>(parentId ? `submissions/${parentId}` : null);
  const original = parentId ? parent.data : requested.data;
  const latestId = parentId ? null : original?.latestRevisionId;
  const latest = useWritingResource<WritingRecord>(latestId ? `submissions/${latestId}` : null);
  const revision = parentId ? requested.data : latest.data;
  const failed = requested.error ? requested : parent.error ? parent : latest.error ? latest : null;

  return <div className="writing-flow writing-flow-wide writing-submission-report writing-revision-workspace">
    <WritingLink href={original ? path(original.submission.id) : "/writing/profile"} className="writing-text-link">
      <ArrowLeft size={16} aria-hidden="true" />{vi ? "Về nhận xét bài viết" : "Back to feedback"}
    </WritingLink>
    {failed ? <div className="writing-alert" role="alert">
      {failed.error instanceof WritingRequestError && failed.error.status === 404
        ? (vi ? "Không tìm thấy bài viết này." : "This response couldn’t be found.")
        : (vi ? "Chưa tải được bản chỉnh sửa." : "We couldn’t load your revision.")}
      <button type="button" className="writing-text-link" onClick={failed.reload}>{vi ? "Thử lại" : "Try again"}</button>
    </div> : original && (!latestId || revision) ? (
      original.run?.report
        ? <RevisionActivity key={`${ownerId}:${id}`} ownerId={ownerId} routeId={id} original={original} revision={revision}
            report={original.run.report} editOnOpen={!parentId} canCheck={canCheck && !!original.run.report.issueFirstObservations} />
        : <p className="writing-note">{vi ? "Bạn có thể chỉnh sửa sau khi có nhận xét." : "You can revise once your feedback is ready."}</p>
    ) : <p className="writing-status" role="status"><LoaderCircle size={18} className="spin" aria-hidden="true" />
      {vi ? "Đang tải bài viết…" : "Loading your writing…"}</p>}
  </div>;
}

function RevisionActivity({ ownerId, routeId, original, revision, report, editOnOpen, canCheck }: {
  ownerId: string; routeId: string; original: WritingRecord; revision?: WritingRecord;
  report: DiagnosticReport; editOnOpen: boolean; canCheck: boolean;
}) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const originalId = original.submission.id;
  const revisionId = revision?.submission.id;
  const baseline = revision?.submission.text ?? original.submission.text;
  const [stored] = useState(() => readRevisionDraft(ownerId, originalId, routeId));
  const [editing, setEditing] = useState(editOnOpen || stored !== null);
  const [draft, setDraft] = useState(stored?.text ?? baseline);
  const requestId = useRef(stored?.requestId);
  const editor = useRef<HTMLTextAreaElement>(null);
  const resultHeading = useRef<HTMLHeadingElement>(null);
  const [saving, setSaving] = useState(false);
  const [checking, setChecking] = useState(false);
  const [saveError, setSaveError] = useState(false);
  const [checkError, setCheckError] = useState<number | null>(null);
  const [justChecked, setJustChecked] = useState<WritingRevisionCheck | null>(null);
  const checkPath = revisionId ? `submissions/${revisionId}/revision-check` : null;
  const savedCheck = useWritingResource<SavedRevisionCheck>(editing || justChecked ? null : checkPath);
  const check = justChecked ?? savedCheck.data?.check;
  const pending = !check && !!savedCheck.data?.pending;
  const { reload: reloadCheck } = savedCheck;
  useEffect(() => {
    if (!pending || savedCheck.loading) return;
    const timer = window.setTimeout(reloadCheck, 2500);
    return () => window.clearTimeout(timer);
  }, [pending, savedCheck.loading, reloadCheck]);
  const [compare, setCompare] = useState(false);
  const versions = useWritingResource<RevisionLink[]>(`submissions/${originalId}/revisions`);
  const savedVersions = versions.data ?? [];
  const dirty = editing && draft !== baseline;
  const leave = useWritingDraftGuard(dirty);

  function updateDraft(text: string) {
    setDraft(text);
    setSaveError(false);
    requestId.current = undefined;
    storeRevisionDraft(ownerId, originalId, routeId, text === baseline ? null : { text });
  }

  async function save(event: FormEvent) {
    event.preventDefault();
    if (saving || !dirty || !draft.trim()) return;
    requestId.current ??= crypto.randomUUID();
    storeRevisionDraft(ownerId, originalId, routeId, { text: draft, requestId: requestId.current });
    setSaving(true);
    setSaveError(false);
    try {
      const saved = await writingRequest<WritingRecord>("submissions", {
        body: { requestId: requestId.current, taskId: original.task.id, parentSubmissionId: originalId, text: draft },
      });
      storeRevisionDraft(ownerId, originalId, routeId, null);
      leave();
      // Full navigation opens the immutable saved version and resets the draft guard.
      // eslint-disable-next-line @next/next/no-location-assign-relative-destination
      window.location.assign(`${path(saved.submission.id)}/revise`);
    } catch {
      setSaveError(true);
      setSaving(false);
    }
  }

  async function checkChanges() {
    if (!checkPath || !canCheck || checking || savedCheck.loading || pending || check) return;
    setChecking(true);
    setCheckError(null);
    try {
      const result = await writingRequest<WritingRevisionCheck>(checkPath, { body: {} });
      if (result.revisionId !== revisionId || result.originalId !== originalId) throw new Error("Revision changed");
      setJustChecked(result);
      requestAnimationFrame(() => resultHeading.current?.focus());
    } catch (error) {
      const status = error instanceof WritingRequestError ? error.status : 503;
      setCheckError(status);
      if (status === 409) reloadCheck();
    } finally {
      setChecking(false);
    }
  }

  function editAgain() {
    setEditing(true);
    requestAnimationFrame(() => editor.current?.focus());
  }

  const comparison = !editing && compare && revision ? replacementDiff(original.submission.text, revision.submission.text) : null;
  const practice = check ? getWritingPracticeRecommendations(report, original.submission.text, check) : [];
  const practiceNext = practice.find((item) => item.revisionStatus === "still_present")
    ?? practice.find((item) => item.revisionStatus === "resolved");
  return <>
    <header className="writing-heading">
      <h1>{editing ? (vi ? "Chỉnh sửa bài viết" : "Revise your response")
        : (vi ? "Bản chỉnh sửa đã lưu" : "Saved revision")}</h1>
      {editing && <p>{vi ? "Chọn một góp ý và thử sửa theo cách của bạn." : "Pick one suggestion and revise in your own words."}</p>}
    </header>
    {editing ? <div className="writing-revision-layout">
      <RevisionCues report={report} locale={locale} />
      <form className="writing-revision-paper" onSubmit={(event) => void save(event)} aria-busy={saving}>
        <label htmlFor="revision-text">{vi ? "Bản chỉnh sửa của bạn" : "Your revision"}</label>
        <textarea id="revision-text" ref={editor} className="writing-textarea" lang="en" value={draft} maxLength={5000}
          onChange={(event) => updateDraft(event.target.value)} readOnly={saving} />
        <div className="writing-editor-meta">
          <span>{writingWordCount(draft)} {vi ? "từ" : "words"}</span>
          {dirty && <span>{vi ? "Bản nháp lưu trong thẻ này" : "Draft kept in this tab"}</span>}
        </div>
        {saveError && <p className="writing-alert" role="alert">{vi ? "Chưa lưu được bản chỉnh sửa. Bạn có thể thử lại."
          : "We couldn't save your revision. You can try again."}</p>}
        <div className="writing-actions">
          <Button type="submit" disabled={saving || !dirty || !draft.trim()}>
            {saving ? (vi ? "Đang lưu…" : "Saving…") : (vi ? "Lưu bản chỉnh sửa" : "Save revision")}
          </Button>
          {revisionId && routeId === revisionId && <button className="writing-text-link" type="button" disabled={saving}
            onClick={() => setEditing(false)}>{vi ? "Xem bản đã lưu" : "View saved version"}</button>}
        </div>
      </form>
    </div> : revision && <>
      {check ? <RevisionResult check={check} practice={practiceNext} heading={resultHeading} locale={locale} onEdit={editAgain} /> :
        <section className="writing-revision-check-invite">
          {pending || savedCheck.loading ? <p className="writing-status" role="status">
            <LoaderCircle size={16} className="spin" aria-hidden="true" />
            {pending ? (vi ? "Đang kiểm tra phần bạn đã sửa…" : "Checking your changes…")
              : (vi ? "Đang tải kết quả đã lưu…" : "Looking for saved feedback…")}
          </p> : savedCheck.error ? <p className="writing-alert" role="alert">
            {vi ? "Chưa tải được kết quả. Bản chỉnh sửa của bạn vẫn được lưu." : "We couldn’t load the feedback. Your revision is saved."}
          </p> : <p>{canCheck ? (vi ? "Ownword sẽ xem những chỗ bạn sửa và đối chiếu với góp ý trước đó." : "We’ll look at what you changed and revisit the earlier feedback.")
            : (vi ? "Bản chỉnh sửa này chưa có kết quả kiểm tra." : "This revision hasn’t been checked yet.")}</p>}
          <div className="writing-actions">
            {savedCheck.error ? <Button secondary onClick={reloadCheck}>{vi ? "Tải lại kết quả" : "Reload feedback"}</Button>
            : canCheck && !savedCheck.loading && !pending && <Button onClick={() => void checkChanges()} disabled={checking}>
              {checking && <LoaderCircle className="spin" size={16} aria-hidden="true" />}
              {checking ? (vi ? "Đang xem lại…" : "Checking…") : (vi ? "Nhận góp ý về bản chỉnh sửa này" : "Get feedback on this revision")}
            </Button>}
            <Button secondary onClick={editAgain}><PenLine size={16} aria-hidden="true" />{vi ? "Chỉnh sửa tiếp" : "Revise again"}</Button>
          </div>
          {checking && <p className="writing-sr-only" role="status">{vi ? "Đang kiểm tra những chỗ đã sửa." : "Checking your changes."}</p>}
          {checkError && !pending && !savedCheck.error && !savedCheck.loading && <p className="writing-alert" role="alert">{checkError === 429
            ? (vi ? "Bạn đã hết lượt kiểm tra hôm nay." : "You’ve used today’s revision checks.")
            : (vi ? "Lần kiểm tra chưa hoàn tất. Bản chỉnh sửa đã được lưu. Bạn có thể thử lại."
              : "The check couldn’t finish. Your revision is saved and you can try again.")}</p>}
        </section>}
      <div className="writing-saved-version">
        <header><h2>{vi ? "Bài bạn đã sửa" : "Your revised response"}</h2>
          <button type="button" className="writing-text-link" aria-expanded={compare} aria-controls="writing-saved-comparison"
            onClick={() => setCompare(!compare)}>{compare ? (vi ? "Ẩn bản gốc" : "Hide original") : (vi ? "So với bản gốc" : "Compare with original")}</button>
        </header>
        <div id="writing-saved-comparison" className={`writing-saved-comparison${comparison ? " is-comparing" : ""}`}>
          {comparison && <section><h3>{vi ? "Bản gốc" : "Original"}</h3><p lang="en">{renderChanges(comparison.removed)}</p></section>}
          <section className="writing-feedback-suggestion">
            {comparison && <h3>{vi ? "Bản chỉnh sửa" : "Revision"}</h3>}
            <p lang="en">{comparison ? renderChanges(comparison.added) : revision.submission.text}</p>
          </section>
        </div>
      </div>
    </>}
    <section className="writing-revision-versions">
      {savedVersions.length > 0 && <details>
        <summary>{vi ? "Các bản đã lưu" : "Saved versions"} <ChevronDown size={15} aria-hidden="true" /></summary>
        <ul>{savedVersions.map((item, index) => <li key={item.id}>
          <a href={`${path(item.id)}/revise`} aria-current={!editing && item.id === revisionId ? "page" : undefined}>
            {vi ? `Bản ${savedVersions.length - index}` : `Version ${savedVersions.length - index}`}
            <span>{new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeStyle: "short" }).format(new Date(item.createdAt))}</span>
            <ArrowRight size={14} aria-hidden="true" />
          </a>
        </li>)}</ul>
      </details>}
      {versions.error && <p className="writing-note">{vi ? "Chưa tải được các bản đã lưu." : "We couldn’t load your saved versions."}</p>}
      {!editing && revisionId && <DeleteWriting id={revisionId} parentId={originalId} ownerId={ownerId} />}
    </section>
  </>;
}

function renderChanges(parts: readonly TextPart[]) {
  return parts.map((part, index) => part.changed ? <mark className="writing-edit-mark" key={index}>{part.text}</mark> : part.text);
}

function RevisionCues({ report, locale }: { report: DiagnosticReport; locale: "en" | "vi" }) {
  const vi = locale === "vi";
  const [showOnDesktop] = useState(() => typeof window !== "undefined" && window.matchMedia("(min-width: 961px)").matches);
  const cues = report.issueFirstObservations
    ? orderWritingFeedback(report.issueFirstObservations).filter((item) => item.kind === "problem").map((item) => {
      const copy = vi && item.feedback ? item.feedback.vi : item;
      return { quote: item.evidence[0]?.exact, reason: copy.readerImpact, cue: copy.revisionCue,
        optional: item.feedback?.category === "optional", lang: vi && item.feedback ? "vi" : "en" };
    })
    : report.findings.filter((item) => item.judgment !== "positive").map((item) => ({
      quote: item.evidence[0]?.exact, reason: item.readerImpact, cue: item.revisionCue, optional: false, lang: "en",
    }));
  const renderCue = (item: (typeof cues)[number], index: number) => <li key={index}>
    {item.optional && <small>{vi ? "Có thể viết tự nhiên hơn" : "Optional polish"}</small>}
    {item.quote && <q lang="en">{item.quote}</q>}
    <p lang={item.lang}>{item.cue ?? item.reason}</p>
  </li>;
  return <aside className="writing-revision-cues" aria-label={vi ? "Góp ý khi chỉnh sửa" : "Feedback while revising"}>
    <details open={showOnDesktop}>
      <summary><MessageSquareText size={17} aria-hidden="true" />
        <span>{vi ? "Góp ý cho bản gốc" : "Feedback on your original"}</span><ChevronDown size={16} aria-hidden="true" /></summary>
      {cues.length ? <>
        <ol>{cues.slice(0, 3).map(renderCue)}</ol>
        {cues.length > 3 && <details className="writing-revision-more-cues">
          <summary><span>{vi ? "Xem thêm góp ý" : "More feedback"}</span><ChevronDown size={15} aria-hidden="true" /></summary>
          <ol start={4}>{cues.slice(3).map(renderCue)}</ol>
        </details>}
      </> : <p>{vi ? "Đọc lại bài và thử làm rõ một ý bạn muốn người đọc nhớ." : "Reread your response and clarify one idea you want readers to remember."}</p>}
    </details>
  </aside>;
}

function RevisionResult({ check, practice, heading, locale, onEdit }: {
  check: WritingRevisionCheck; practice?: WritingPracticeRecommendation;
  heading: RefObject<HTMLHeadingElement | null>; locale: "en" | "vi"; onEdit: () => void;
}) {
  const vi = locale === "vi";
  const fixed = check.items.filter(({ status }) => status === "resolved");
  const remaining = check.items.filter(({ status }) => status === "still_present");
  const uncertain = check.items.filter(({ status }) => status === "uncertain");
  const newIssues = check.introduced;
  const stats = [
    { kind: "resolved", count: fixed.length, label: vi ? "Đã sửa" : "Fixed" },
    { kind: "still_present", count: remaining.length, label: vi ? "Còn cần sửa" : "Still there" },
    { kind: "introduced", count: newIssues.length, label: vi ? "Lỗi mới" : "New issues" },
  ];
  function renderTracked(items: WritingRevisionCheck["items"]) {
    return items.map((item) => <li key={item.id}>
      <div className="writing-revision-result-quotes" lang="en">
        {item.status === "resolved" && item.after && item.after !== item.before
          ? <><q>{item.before}</q><ArrowRight size={14} aria-hidden="true" /><q>{item.after}</q></>
          : <q>{item.after ?? item.before}</q>}
      </div>
      <p>{item.note[locale]}</p>
    </li>);
  }
  return <section className="writing-revision-results" aria-labelledby="revision-check-title">
    <h2 id="revision-check-title" ref={heading} tabIndex={-1}><Check size={20} aria-hidden="true" />
      {vi ? "Kết quả kiểm tra bản chỉnh sửa" : "Your revision results"}</h2>
    <dl className="writing-revision-stats">
      {stats.map(({ kind, count, label }) => <div key={kind} data-result={kind}>
        <dt>{label}</dt><dd>{count}</dd>
      </div>)}
    </dl>
    <p>{vi ? "Bản kiểm tra dựa trên chỗ bạn đã sửa và góp ý trước đó." : "This check covers your edits and earlier feedback."}
      {uncertain.length > 0 && (vi ? ` Có ${uncertain.length} chỗ chưa thể kết luận.`
        : ` ${uncertain.length} ${uncertain.length === 1 ? "point needs" : "points need"} a closer look.`)}</p>
    <div className="writing-revision-result-next">
      <div><h3>{vi ? "Bạn có thể thử tiếp" : "What to try next"}</h3><p>{check.nextStep[locale]}</p></div>
      <Button secondary onClick={onEdit}>{vi ? "Thử sửa tiếp" : "Revise again"}</Button>
    </div>
    <div className="writing-revision-result-groups">
      <RevisionDetails count={remaining.length} title={vi ? "Chỗ vẫn cần sửa" : "Issues that still need work"}>
        {renderTracked(remaining)}
      </RevisionDetails>
      <RevisionDetails count={newIssues.length} title={vi ? "Lỗi mới trong phần đã sửa" : "New issues in changed passages"}>
        {newIssues.map((item, index) => <li key={index}><q lang="en">{item.quote}</q><p>{item.note[locale]}</p></li>)}
      </RevisionDetails>
      <RevisionDetails count={uncertain.length} title={vi ? "Cần xem kỹ thêm" : "Needs a closer look"}>
        {renderTracked(uncertain)}
      </RevisionDetails>
      <RevisionDetails count={fixed.length} title={vi ? "Chỗ bạn đã sửa được" : "What you fixed"}>
        {renderTracked(fixed)}
      </RevisionDetails>
    </div>
    {practice && <div className="writing-revision-practice">
      <p>{practice.revisionStatus === "resolved"
        ? (vi ? "Bạn đã sửa được chỗ này. Thử áp dụng cách sửa trong một tình huống mới." : "You fixed this in your revision. Try using the same skill in a new situation.")
        : (vi ? "Bạn có thể luyện với một tình huống ngắn trước." : "Try the skill in a short exercise first.")}</p>
      <WritingLink className="writing-text-link writing-feedback-practice" href={writingPracticeHref(check.originalId, practice.observationIndex)}>
        <PenLine size={14} aria-hidden="true" />{practice.title[locale]}<ArrowRight size={14} aria-hidden="true" />
      </WritingLink>
    </div>}
  </section>;
}

function RevisionDetails({ count, title, children }: { count: number; title: string; children: ReactNode }) {
  if (!count) return null;
  return <details>
    <summary><span>{title}</span><span className="writing-revision-detail-count">{count}</span><ChevronDown size={16} aria-hidden="true" /></summary>
    <ul>{children}</ul>
  </details>;
}
