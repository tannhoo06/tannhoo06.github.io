export type RevisionDraft = { text: string; requestId?: string };

const prefix = (owner: string) => `ownword:revision:v1:${encodeURIComponent(owner)}:`;
const draftKey = (owner: string, original: string, id: string) => `${prefix(owner)}${original}:draft:${id}`;

function read<T>(storageKey: string): T | null {
  try {
    return JSON.parse(sessionStorage.getItem(storageKey) ?? "null") as T | null;
  } catch {
    return null;
  }
}

function write(storageKey: string, value: unknown) {
  try {
    if (value === null) sessionStorage.removeItem(storageKey);
    else sessionStorage.setItem(storageKey, JSON.stringify(value));
  } catch {
    // The in-memory editor and navigation guard still work when storage is unavailable.
  }
}

export function readRevisionDraft(owner: string, original: string, id: string) {
  const draft = read<RevisionDraft>(draftKey(owner, original, id));
  return draft && typeof draft.text === "string" && draft.text.length <= 5000 ? draft : null;
}

export function storeRevisionDraft(owner: string, original: string, id: string, draft: RevisionDraft | null) {
  write(draftKey(owner, original, id), draft);
}

export function clearRevisionSession(owner: string, original?: string, revision?: string) {
  try {
    const start = original ? `${prefix(owner)}${original}:` : prefix(owner);
    for (let index = sessionStorage.length - 1; index >= 0; index--) {
      const storageKey = sessionStorage.key(index);
      if (storageKey?.startsWith(start) && (!revision || storageKey.endsWith(`:${revision}`))) {
        sessionStorage.removeItem(storageKey);
      }
    }
  } catch {
    // Nothing to clear when storage is unavailable.
  }
}
