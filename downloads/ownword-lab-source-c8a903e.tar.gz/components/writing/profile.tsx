"use client";

import { useEffect, useId, useRef, useState } from "react";
import { useMotionTokens, useShouldReduceMotion } from "@animate-ui/react/utils/motion";
import { useAnimate } from "motion/react";
import { ArrowRight, ChevronDown, ChevronRight, FileText, Layers3,
  LoaderCircle, PenLine, Repeat2, Search, Sparkles, Sprout, Target, TrendingUp } from "lucide-react";
import Image from "next/image";
import type { WritingService } from "@/lib/services/writing";
import type { WritingProfileAssessment, WritingProfileEvidence } from "@/lib/writing/profile";
import { useI18n } from "../language-provider";
import { DeleteWriting } from "./report";
import { WritingLink, WritingRequestError, useWritingResource, writingRequest } from "./writing-client";
import "@/app/writing/writing-profile.css";

type Profile = Awaited<ReturnType<WritingService["profileOverview"]>>;
type Language = "en" | "vi";
type Copy = { en: string; vi: string | null };
const skills = [
  { id: "LEX.PRECISION", label: { en: "Vocabulary", vi: "Từ vựng" } },
  { id: "GRAM.ACCURACY", label: { en: "Grammar", vi: "Ngữ pháp" } },
  { id: "ARG.SUPPORT", label: { en: "Argument", vi: "Lập luận" } },
  { id: "ORG.PROGRESSION", label: { en: "Organization", vi: "Tổ chức ý" } },
] as const;
const judgments = {
  weak: { en: "Needs work", vi: "Cần luyện thêm" },
  mixed: { en: "Strengths and things to work on", vi: "Có điểm tốt và điểm cần sửa" },
  positive: { en: "Examples of what worked", vi: "Có ví dụ làm tốt" },
  undetermined: { en: "Not enough to assess", vi: "Chưa đủ để đánh giá" },
};
const bands = { weak: 0.34, mixed: 0.67, positive: 1, undetermined: null };
const trendKinds = {
  recurring_issue: { en: "Recurring issue", vi: "Thường gặp trong bài", icon: Repeat2 },
  consistent_strength: { en: "Consistent strength", vi: "Điểm mạnh qua nhiều bài", icon: Sprout },
  improvement: { en: "Signs of improvement", vi: "Có dấu hiệu tiến bộ", icon: TrendingUp },
  persistent_issue: { en: "Worth revisiting", vi: "Nên luyện thêm", icon: Target },
};
const positions = [[0, -1], [1, 0], [0, 1], [-1, 0]];
const plot = (i: number, level: number) => [170 + positions[i][0] * level * 104, 125 + positions[i][1] * level * 87];
const dateLabel = (date: string, locale: Language) => new Intl.DateTimeFormat(locale, { dateStyle: "medium" }).format(new Date(date));
const feedbackHref = (id: string) => `/writing/submissions/${id}`;

function LocalCopy({ value, locale }: { value: Copy; locale: Language }) {
  return <span lang={locale === "vi" && !value.vi ? "en" : locale}>{value[locale] ?? value.en}</span>;
}

function Evidence({ items, locale, showDescription = true }: { items: readonly WritingProfileEvidence[]; locale: Language; showDescription?: boolean }) {
  const vi = locale === "vi";
  return <ul className="wp-evidence">
    {items.map((item, index) => <li key={item.id}>
      <div className="wp-evidence-meta"><time dateTime={item.createdAt}>{dateLabel(item.createdAt, locale)}</time>
        <span lang="en">{item.sessionTitle}</span></div>
      {item.anchors.slice(0, 2).map((anchor) => {
        const start = anchor.start - anchor.sentenceStart;
        const end = start + anchor.exact.length;
        return <blockquote key={`${anchor.start}:${anchor.end}`} lang="en">{anchor.sentence.slice(0, start)}<mark>{anchor.exact}</mark>{anchor.sentence.slice(end)}</blockquote>;
      })}
      {showDescription && items.findIndex(({ description }) => (description[locale] ?? description.en) === (item.description[locale] ?? item.description.en)) === index &&
        <p><LocalCopy value={item.description} locale={locale} /></p>}
      {item.cue && items.findIndex(({ cue }) => (cue?.[locale] ?? cue?.en) === (item.cue?.[locale] ?? item.cue?.en)) === index &&
        <p><LocalCopy value={item.cue} locale={locale} /></p>}
      <WritingLink href={feedbackHref(item.submissionId)} className="writing-text-link">{vi ? "Mở nhận xét bài viết" : "Open writing feedback"}<ArrowRight size={15} aria-hidden="true" /></WritingLink>
    </li>)}
  </ul>;
}

function ProfileRadar({ current, previous, locale }: {
  current: WritingProfileAssessment | null; previous: WritingProfileAssessment | null; locale: Language;
}) {
  const vi = locale === "vi";
  const list = new Intl.ListFormat(locale, { style: "long", type: "conjunction" });
  const [active, setActive] = useState<number | null>(null);
  const selected = active === null ? null : skills[active];
  const currentSkill = selected && current?.skills[selected.id];
  const previousSkill = selected && previous?.skills[selected.id];
  const series = skills.map((skill) => ({ ...skill, judgment: current?.skills[skill.id].judgment ?? "undetermined" }));
  const unknown = series.filter(({ judgment }) => judgment === "undetermined").length;
  const hasEvidence = unknown < skills.length;
  const renderSet = (assessment: WritingProfileAssessment, className: string) => {
    const points = skills.map(({ id }, index) => {
      const band = bands[assessment.skills[id].judgment];
      return band === null ? null : plot(index, band);
    });
    return <g className={className}>
      {points.every((point) => point !== null) && <polygon points={points.map((point) => point.join(",")).join(" ")} />}
      {points.map((point, index) => point && <circle key={index} cx={point[0]} cy={point[1]} r={className === "wp-radar-previous" ? 4 : 5} />)}
    </g>;
  };

  return <section className="wp-panel wp-skills" aria-labelledby="wp-skills-title">
    <header className="wp-section-heading">
      <Layers3 aria-hidden="true" size={25} />
      <div><h2 id="wp-skills-title">{vi ? "Kỹ năng viết" : "Writing skills"}</h2>
        <p>{vi ? "Ví dụ từ các bài đã nhận xét." : "Examples from your assessed essays."}</p></div>
    </header>
    {hasEvidence && current ? <>
      <div className="wp-chart" role="group" aria-label={vi ? "Chọn một kỹ năng để xem ví dụ" : "Choose a skill to see examples"}>
        <svg viewBox="0 0 340 250" aria-hidden="true">
          {[.34, .67, 1].map((radius) => <polygon key={radius} className="wp-radar-grid"
            points={positions.map((_, index) => plot(index, radius).join(",")).join(" ")} />)}
          {positions.map((_, index) => {
            const [x, y] = plot(index, 1);
            return <line key={index} x1="170" y1="125" x2={x} y2={y} className="wp-radar-grid" data-active={active === index} />;
          })}
          {previous && renderSet(previous, "wp-radar-previous")}
          {current && renderSet(current, "wp-radar-current")}
        </svg>
        {series.map(({ id, label, judgment }, index) => <button type="button" key={id} className={`wp-axis wp-axis-${index}`}
          data-missing={judgment === "undetermined"}
          aria-pressed={active === index} aria-controls="wp-skill-detail"
          aria-label={`${label[locale]}, ${judgments[judgment][locale]}`}
          onClick={() => setActive(active === index ? null : index)}>{label[locale]}
          {judgment === "undetermined" && <span aria-hidden="true">–</span>}</button>)}
      </div>
      <div className="wp-chart-key">
        <ul className="wp-legend" aria-label={vi ? "Chú giải" : "Legend"}>
          <li><span className="wp-legend-current" aria-hidden="true" /><time dateTime={current.createdAt}>{vi ? "Mới nhất" : "Latest"} · {dateLabel(current.createdAt, locale)}</time></li>
          {previous && <li><span className="wp-legend-previous" aria-hidden="true" /><time dateTime={previous.createdAt}>{vi ? "Bài trước" : "Earlier"} · {dateLabel(previous.createdAt, locale)}</time></li>}
          {unknown > 0 && <li><span aria-hidden="true">–</span>{judgments.undetermined[locale]}</li>}
        </ul>
        <details className="wp-chart-method">
          <summary><span>{vi ? "Cách đọc biểu đồ" : "How to read this chart"}</span><ChevronDown size={15} aria-hidden="true" /></summary>
          <p>{vi ? "Các vòng từ trong ra ngoài lần lượt là " : "From the inner ring out, the bands are "}{list.format((["weak", "mixed", "positive"] as const).map((band) => judgments[band][locale].toLocaleLowerCase(locale)))}.</p>
          <p>{vi ? "Kỹ năng không có chấm là kỹ năng chưa đủ ví dụ để đánh giá. Mỗi mức chỉ mô tả bài viết tương ứng."
            : "A missing dot means there wasn’t enough to assess that skill. Each band describes work in one essay."}</p>
          {!previous && <p>{vi ? "Bài trước sẽ hiện khi cả hai bài có thể được đánh giá theo cùng cách." : "We’ll show an earlier essay when both essays can be assessed in the same way."}</p>}
        </details>
      </div>
      <div id="wp-skill-detail" className="wp-skill-detail">
        {selected ? <>
          <h3>{selected.label[locale]}</h3>
          <p className="wp-skill-status"><b>{vi ? "Bài mới nhất" : "Latest response"}</b> · {judgments[currentSkill?.judgment ?? "undetermined"][locale]}</p>
          {previousSkill && <p><b>{vi ? "Bài trước" : "Earlier response"}</b> · {judgments[previousSkill.judgment][locale]}</p>}
          {currentSkill?.evidence.length || previousSkill?.evidence.length ? <details className="wp-chart-evidence" key={selected.id}>
            <summary>{vi ? "Xem ví dụ" : "See examples"}<ChevronDown size={16} aria-hidden="true" /></summary>
            <Evidence items={[...(currentSkill?.evidence ?? []), ...(previousSkill?.evidence ?? [])]} locale={locale} />
          </details> : <p>{vi ? "Chưa có ví dụ đủ rõ cho kỹ năng này." : "There isn’t a clear example for this skill yet."}</p>}
        </> : <>
          <h3>{vi ? "Trong bài được đánh giá gần nhất" : "In the latest assessed response"}</h3>
          <dl className="wp-skill-summary">{(["positive", "mixed", "weak"] as const).map((band) => {
            const labels = series.filter(({ judgment }) => judgment === band).map(({ label }) => label[locale]);
            return labels.length > 0 && <div key={band}><dt>{judgments[band][locale]}</dt><dd>{list.format(labels)}</dd></div>;
          })}</dl>
        </>}
      </div>
    </> : <p className="wp-quiet wp-radar-empty">{vi ? "Chưa đủ minh chứng để vẽ biểu đồ kỹ năng. Bạn vẫn có thể xem góp ý hiện có cho từng bài." : "There isn’t enough evidence for a skill chart yet. You can still see any available feedback on individual responses."}</p>}
  </section>;
}

function Insight({ title, description, items, locale, theme, trendKind, revisionId }: {
  title: Copy; description: Copy; items: WritingProfileEvidence[]; locale: Language; theme: "trend" | "strength" | "problem";
  trendKind?: keyof typeof trendKinds; revisionId?: string | null;
}) {
  const vi = locale === "vi";
  const trend = trendKind && trendKinds[trendKind];
  const Icon = trend ? trend.icon : theme === "strength" ? Sprout : Target;
  return <details className="wp-insight" data-tone={theme} data-trend={trendKind}>
    <summary><span className="wp-insight-icon"><Icon size={19} aria-hidden="true" /></span>
      <span className="wp-insight-copy">{trend && <small>{trend[locale]}</small>}
        <strong><LocalCopy value={title} locale={locale} /></strong>
        <span><LocalCopy value={description} locale={locale} /></span></span>
      <ChevronRight className="wp-open-icon" size={18} aria-hidden="true" />
    </summary>
    <Evidence items={items} locale={locale} showDescription={!!trend} />
    {revisionId && <WritingLink href={`${feedbackHref(revisionId)}/revise`} className="writing-text-link">
      {vi ? "Mở bản sửa đã kiểm tra" : "Open the checked revision"}<ArrowRight size={15} aria-hidden="true" />
    </WritingLink>}
  </details>;
}

function ProfileInsights({ profile, locale, reload }: { profile: Profile; locale: Language; reload: () => void }) {
  const vi = locale === "vi";
  const [updating, setUpdating] = useState(false);
  const [error, setError] = useState<number | null>(null);
  const [cooldownDone, setCooldownDone] = useState<string | null>(null);
  const { state, items, retryAt } = profile.trends;
  useEffect(() => {
    if (state !== "pending" || updating) return;
    const timer = window.setTimeout(reload, 3500);
    return () => window.clearTimeout(timer);
  }, [state, profile, reload, updating]);
  useEffect(() => {
    if (!retryAt) return;
    const timeout = window.setTimeout(() => setCooldownDone(retryAt), Math.max(0, Date.parse(retryAt) - Date.now()));
    return () => window.clearTimeout(timeout);
  }, [retryAt]);

  async function refresh() {
    setError(null);
    setUpdating(true);
    try {
      await writingRequest<Profile>("profile/trends", { body: {} });
      reload();
    } catch (failure) {
      setError(failure instanceof WritingRequestError ? failure.status : 503);
    } finally {
      setUpdating(false);
    }
  }

  return <section className="wp-panel wp-insights" aria-labelledby="wp-insights-title">
    <header className="wp-insights-header"><Sparkles size={24} aria-hidden="true" /><h2 id="wp-insights-title">{vi ? "Nhận xét bài viết" : "Writing observations"}</h2></header>
    <div className="wp-insights-body">
      <section className="wp-insight-group" aria-labelledby="wp-trends-title">
        <h3 id="wp-trends-title">{vi ? "Điểm lặp lại qua các bài viết" : "What comes up across your essays"}</h3>
        {items.map((item) => <Insight key={item.id} items={item.evidence} title={item.title} description={item.description}
          locale={locale} theme="trend" trendKind={item.kind} revisionId={item.revisionId} />)}
        {items.length === 0 && <p className="wp-quiet wp-trend-status" role="status"><Search size={16} aria-hidden="true" /><span>
          {updating || state === "pending" ? (vi ? "Đang đối chiếu ví dụ giữa các bài…" : "Comparing examples from your essays…")
            : state === "disabled" ? (vi ? "Chưa có tính năng phân tích xu hướng cho hồ sơ này. Bạn vẫn có thể xem góp ý từng bài." : "Patterns across responses aren’t available here yet. You can still see feedback on each response.")
            : state === "retry" || state === "unavailable" ? (vi ? "Chưa thể phân tích xu hướng lúc này. Bạn vẫn có thể xem nhận xét từng bài." : "Trend analysis is temporarily unavailable. Feedback on each response is still here.")
            : state === "available" ? (vi ? "Có ví dụ mới để đối chiếu." : "There are new examples to compare.")
            : state === "ready" ? (vi ? "Các ví dụ hiện có chưa cho thấy một xu hướng đủ rõ." : "The available examples don’t yet support a clear pattern.")
            : (vi ? "Cần thêm ví dụ từ các bài viết riêng biệt để nhận ra điều gì lặp lại." : "We need examples from separate essays we can compare to see what repeats.")}
          </span>
        </p>}
        {error && <p className="wp-trend-error" role="alert">{error === 429
          ? (vi ? "Bạn đã đạt giới hạn phân tích hôm nay. Hãy thử lại vào ngày mai." : "You’ve reached today’s analysis limit. Try again tomorrow.")
          : (vi ? "Chưa cập nhật được xu hướng. Bạn có thể thử lại." : "The update didn’t finish. You can try again.")}</p>}
        {(state === "available" || state === "retry") && !updating && error !== 429 && <button type="button" className="writing-text-link" onClick={refresh}
          disabled={!!retryAt && cooldownDone !== retryAt}>
          {state === "retry" ? (vi ? "Thử phân tích lại" : "Retry analysis") : (vi ? "Cập nhật xu hướng" : "Update patterns")}<ArrowRight size={15} aria-hidden="true" />
        </button>}
      </section>
      <section className="wp-insight-group" aria-labelledby="wp-recent-title">
        <h3 id="wp-recent-title">{profile.recentSessionIds.length === 0
          ? (vi ? "Từ bài viết của bạn" : "From your writing") : profile.recentSessionIds.length === 1
            ? (vi ? "Từ bài viết gần nhất" : "From your latest response")
            : (vi ? "Từ 2 bài viết gần nhất" : "From your 2 latest responses")}</h3>
        {profile.recentInsights.length ? profile.recentInsights.map((item) => <Insight key={item.id} title={item.title}
          description={item.description} items={[item]} locale={locale} theme={item.kind === "strength" ? "strength" : "problem"} />)
          : <p className="wp-quiet">{vi ? "Khi có nhận xét gắn với câu chữ của bạn, ví dụ sẽ xuất hiện ở đây." : "This is where you’ll find examples from feedback on your own words."}</p>}
      </section>
    </div>
  </section>;
}

function ProfileHistory({ history, locale }: { history: Profile["history"]; locale: Language }) {
  const vi = locale === "vi";
  const [expanded, setExpanded] = useState(false);
  return <section className="wp-panel wp-history writing-history" aria-labelledby="wp-history-title">
    <header className="wp-history-header"><div className="wp-section-heading"><FileText size={23} aria-hidden="true" />
      <h2 id="wp-history-title">{vi ? "Các bài viết gần đây" : "Recent writing"}</h2></div>
      <div className="wp-history-actions"><WritingLink href="/writing/diagnostic" className="writing-text-link">{vi ? "Viết bài mới" : "Write a new essay"}<PenLine size={15} aria-hidden="true" /></WritingLink>
      {history.length > 3 && <button className="writing-text-link" type="button" aria-expanded={expanded} aria-controls="wp-history-list" onClick={() => setExpanded(!expanded)}>
        {expanded ? (vi ? "Thu gọn" : "Show less") : (vi ? "Xem tất cả" : "View all")}<ChevronDown className="wp-open-icon" size={16} aria-hidden="true" />
      </button>}</div>
    </header>
    <ul id="wp-history-list">{history.slice(0, expanded ? undefined : 3).map((item) => <li key={item.id}>
      <WritingLink href={feedbackHref(item.id)} className="wp-history-link">
        <FileText size={17} aria-hidden="true" /><strong lang="en">{item.title}</strong>
        <time dateTime={item.createdAt}>{dateLabel(item.createdAt, locale)}</time><ChevronRight size={16} aria-hidden="true" />
      </WritingLink>
      {item.latestRevisionId && <WritingLink href={`${feedbackHref(item.latestRevisionId)}/revise`} className="wp-history-revision">{vi ? "Bản chỉnh sửa" : "Revision"}<ChevronRight size={14} aria-hidden="true" /></WritingLink>}
    </li>)}</ul>
  </section>;
}

function ProfileNextStep({ profile, locale, placement }: { profile: Profile; locale: Language; placement?: "early" | "after" }) {
  const vi = locale === "vi";
  const { nextStep, latestSubmissionId } = profile;
  const titleId = useId();
  const Icon = latestSubmissionId ? Target : PenLine;
  return <section className="wp-next" data-placement={placement} aria-labelledby={titleId}>
    <Icon size={27} aria-hidden="true" /><div><h2 id={titleId}>{latestSubmissionId ? (vi ? "Bước tiếp theo dành cho bạn" : "Your next step")
      : (vi ? "Chưa có bài viết đã gửi" : "No submitted writing yet")}</h2>
      {nextStep ? <><p className="wp-next-topic"><LocalCopy value={nextStep.title} locale={locale} /></p><p><LocalCopy value={nextStep.reason} locale={locale} /></p></>
        : <p>{latestSubmissionId ? (vi ? "Mở bài viết gần nhất để xem bài và nhận xét hiện có." : "Open your latest response to revisit your writing and available feedback.")
          : (vi ? "Viết một đoạn ngắn để nhận góp ý dựa trên chính câu chữ của bạn." : "Write a short response to get feedback on your own words.")}</p>}</div>
    <WritingLink className="ow-action-primary writing-primary-action wp-next-action" href={nextStep?.href ?? (latestSubmissionId ? feedbackHref(latestSubmissionId) : "/writing/diagnostic")}>
      <PenLine size={17} aria-hidden="true" />{nextStep?.kind === "practice" ? (vi ? "Bắt đầu luyện tập" : "Start practice")
        : latestSubmissionId ? (vi ? "Mở bài viết" : "Open response") : (vi ? "Bắt đầu viết" : "Start writing")}<ArrowRight size={17} aria-hidden="true" />
    </WritingLink>
  </section>;
}

function ProfileReadingArt({ ownerId, assessedAt }: { ownerId: string; assessedAt?: string }) {
  const reduceMotion = useShouldReduceMotion();
  const { transition } = useMotionTokens();
  const [page, animate] = useAnimate<HTMLSpanElement>();
  const lastAssessment = useRef({ ownerId, date: "" });
  useEffect(() => {
    if (!assessedAt) return;
    let finish: (() => void) | undefined;
    // Wait a frame to avoid consuming the one-time reaction on a discarded render.
    const frame = requestAnimationFrame(() => {
      const key = `ownword:profile:last-assessment:${ownerId}`;
      const previous = lastAssessment.current.ownerId === ownerId ? lastAssessment.current.date : "";
      if (previous >= assessedAt) return;
      lastAssessment.current = { ownerId, date: assessedAt };
      try {
        if ((localStorage.getItem(key) ?? "") >= assessedAt) return;
        localStorage.setItem(key, assessedAt);
      } catch { /* In restricted browsers, remember the assessment for this visit. */ }
      const overlay = page.current;
      if (reduceMotion || !overlay) return;
      const playback = animate(overlay, { opacity: [0, 1, 1, 0], rotateY: [65, 8, -28, -68] },
        { ...transition.reveal, times: [0, .24, .66, 1] });
      finish = () => { playback.stop(); overlay.style.opacity = "0"; };
    });
    return () => { cancelAnimationFrame(frame); finish?.(); };
  }, [animate, assessedAt, ownerId, page, reduceMotion, transition.reveal]);

  return <>
    <Image src="/images/writing-profile-hero.svg" className="wp-hero-art" alt="" width={900} height={210} unoptimized />
    <span ref={page} className="wp-page-turn" aria-hidden="true">
      <Image src="/images/writing-profile-page-turn.svg" alt="" width={900} height={210} loading="eager" unoptimized />
    </span>
  </>;
}

export function WritingProfile({ ownerId }: { ownerId: string }) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const { data, loading, error, reload } = useWritingResource<Profile>("profile/overview");
  return <div className="writing-flow writing-profile">
    <header className="wp-hero">
      <div className="wp-hero-copy"><h1>{vi ? "Hồ sơ viết" : "Writing Profile"}</h1>
        <p>{vi ? "Xem lại bài đã viết và những điểm lặp lại ở các bài có thể đối chiếu." : "Reopen your essays and see what comes up across the ones we can compare."}</p>
      </div>
      <ProfileReadingArt ownerId={ownerId} assessedAt={data?.radar.current?.createdAt} />
    </header>
    {error && <div role="alert" className="writing-alert">{vi ? "Chưa tải được Hồ sơ viết." : "We couldn’t load your Writing Profile."}
      <button type="button" className="writing-text-link" onClick={reload}>{vi ? "Thử lại" : "Try again"}</button></div>}
    {!data && loading && <p className="wp-loading" role="status"><LoaderCircle size={18} className="spin" aria-hidden="true" />{vi ? "Đang tải Hồ sơ viết…" : "Loading your Writing Profile…"}</p>}
    {data && (data.latestSubmissionId ? <>
      <ProfileNextStep profile={data} locale={locale} placement="early" />
      <div className="wp-primary">
        <ProfileRadar current={data.radar.current} previous={data.radar.previous} locale={locale} />
        <ProfileInsights profile={data} locale={locale} reload={reload} />
      </div>
      <ProfileNextStep profile={data} locale={locale} placement="after" />
      {data.history.length > 0 && <><ProfileHistory history={data.history} locale={locale} /><DeleteWriting draftOwnerId={ownerId} /></>}
    </> : <ProfileNextStep profile={data} locale={locale} />)}
  </div>;
}
