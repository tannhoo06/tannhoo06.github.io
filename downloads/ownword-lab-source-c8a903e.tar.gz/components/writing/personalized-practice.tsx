"use client";

import { useEffect, useRef, useState, type FormEvent, type RefObject } from "react";
import { Button as AnimateButton } from "@animate-ui/react/primitives/buttons/button";
import { useMotionTokens, useShouldReduceMotion } from "@animate-ui/react/utils/motion";
import { motion } from "motion/react";
import { ArrowLeft, ArrowRight, Check, ChevronDown, Lightbulb, LoaderCircle } from "lucide-react";
import type { SourceAnchor } from "@/lib/domain/types";
import {
  checkWritingPracticeAttempt, getWritingPracticeExercises, getWritingPracticeRecommendations, writingPracticeAnswerLimit,
  type WritingPracticeExercise, type WritingPracticeRecommendation, type WritingPracticeResult,
} from "@/lib/writing/personalized-practice";
import {
  checkWritingPracticeRepair, getWritingPracticeRepair, getWritingPracticeRepairTakeaway, writingPracticeRepairLimit,
  type WritingPracticeRepair, type WritingPracticeRepairResult,
} from "@/lib/writing/practice-repair";
import { useI18n } from "../language-provider";
import { Button } from "../shared";
import { WritingLink, WritingRequestError, useWritingResource, writingRequest, type WritingRecord } from "./writing-client";

type Locale = "en" | "vi";
type Heading = RefObject<HTMLHeadingElement | null>;
type RepairSuccess = Extract<WritingPracticeRepairResult, { status: "successful" }>;
type Pass = { name: "write" } | { name: "repair" } | { name: "done"; repair: RepairSuccess | null };

export function WritingPractice({ id, observationIndex }: { id: string; observationIndex: number }) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const feedbackPath = `/writing/submissions/${encodeURIComponent(id)}`;
  const resource = useWritingResource<WritingRecord>(`submissions/${encodeURIComponent(id)}`);
  const record = resource.data;
  const report = record?.run?.report;
  const unavailable = resource.error instanceof WritingRequestError && resource.error.status === 404;
  const recommendation = record && report?.submissionId === id && !record.submission.parentSubmissionId
    ? getWritingPracticeRecommendations(report, record.submission.text).find((item) => item.observationIndex === observationIndex)
    : undefined;
  const source = recommendation && report?.issueFirstObservations?.[recommendation.observationIndex]?.evidence[0];

  return <div className="writing-flow writing-submission-report writing-personal-practice">
    <WritingLink href={unavailable ? "/writing/profile" : feedbackPath} className="writing-text-link">
      <ArrowLeft size={16} aria-hidden="true" />
      {unavailable ? (vi ? "Về Hồ sơ viết" : "Back to Writing Profile") : (vi ? "Về nhận xét bài viết" : "Back to feedback")}
    </WritingLink>
    <header className="writing-heading">
      <h1>{recommendation?.title[locale] ?? (vi ? "Luyện theo góp ý" : "Practice from your feedback")}</h1>
    </header>
    {resource.loading ? <p className="writing-status" role="status">
      <LoaderCircle size={18} className="spin" aria-hidden="true" />{vi ? "Đang tải bài luyện…" : "Loading your practice…"}
    </p> : resource.error && !unavailable ? <div className="writing-alert" role="alert">
      <p>{vi ? "Chưa tải được góp ý cho bài luyện này." : "We couldn’t load the feedback for this exercise."}</p>
      <button type="button" className="writing-text-link" onClick={resource.reload}>{vi ? "Thử lại" : "Try again"}</button>
    </div> : recommendation && source ? <PracticeExercise key={`${id}:${observationIndex}`} submissionId={id} recommendation={recommendation} source={source} locale={locale} />
      : <p className="writing-note">{vi ? "Chưa có bài luyện cho góp ý này. Bạn vẫn có thể đọc lại góp ý gốc."
        : "There’s no exercise for this note. You can still read the original feedback."}</p>}
  </div>;
}

function RepairPass({ exercise, locale, heading, clarify, onSkip, onSuccess }: {
  exercise: WritingPracticeRepair; locale: Locale; heading: Heading;
  clarify: boolean; onSkip: () => void; onSuccess: (result: RepairSuccess, segment: string, replacement: string) => void;
}) {
  const vi = locale === "vi";
  const [selection, setSelection] = useState<string | null>(null);
  const [replacement, setReplacement] = useState("");
  const [result, setResult] = useState<Exclude<WritingPracticeRepairResult, RepairSuccess> | null>(null);
  const current = exercise.segments.find(({ id }) => id === selection);
  const { transition } = useMotionTokens();
  const reduce = useShouldReduceMotion();

  function select(id: string) {
    if (id === selection) return;
    setSelection(id);
    setReplacement("");
    setResult(null);
  }

  function checkRepair(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selection || !replacement.trim()) return;
    const checked = checkWritingPracticeRepair(exercise, selection, replacement);
    if (checked.status === "successful") onSuccess(checked, selection, replacement.trim());
    else setResult(checked);
  }

  return <section aria-labelledby="writing-repair-title">
    <header className="writing-practice-task">
      <h2 id="writing-repair-title" ref={heading} tabIndex={-1}>
        {clarify ? (vi ? "Chỗ nào cần làm rõ?" : "What could be clearer?") : (vi ? "Bạn sẽ sửa chỗ nào?" : "What would you change?")}
      </h2>
      {exercise.context && <p className="writing-practice-context" lang="en">{exercise.context}</p>}
      <p>{vi ? "Chọn phần bạn muốn sửa ngay trong câu." : "Select the part you’d change in the sentence."}</p>
    </header>
    <div className="writing-practice-segments" role="group" aria-label={vi ? "Các phần của câu" : "Selectable parts of the sentence"}>
      {exercise.segments.map(({ id, text }) => (
        <AnimateButton key={id} type="button" className="writing-practice-segment" aria-pressed={selection === id}
          aria-label={text.startsWith(",") ? (vi ? `Dấu phẩy và “${text.slice(1).trim()}”` : `Comma and “${text.slice(1).trim()}”`) : undefined}
          onClick={() => select(id)}>
          <span lang="en">{text}</span>
        </AnimateButton>
      ))}
    </div>
    {current && <motion.form className="writing-practice-repair-form" onSubmit={checkRepair}
      initial={{ opacity: .75, y: reduce ? 0 : 5 }} animate={{ opacity: 1, y: 0 }} transition={transition.swap}>
      <label htmlFor="writing-practice-replacement">{vi ? "Viết phần thay cho" : "Replace"} <q lang="en">{current.text}</q></label>
      <div className="writing-practice-repair-input" data-contextual={exercise.context ? "" : undefined}>
        <input id="writing-practice-replacement" type="text" lang="en" value={replacement} maxLength={writingPracticeRepairLimit}
          spellCheck={false} autoCorrect="off" autoCapitalize="off" autoComplete="off"
          aria-invalid={result?.status === "wrong-correction" || undefined}
          aria-describedby={current.text.startsWith(",") ? "writing-practice-punctuation writing-practice-repair-feedback" : "writing-practice-repair-feedback"}
          onChange={(event) => { setReplacement(event.target.value); setResult(null); }} />
        <AnimateButton type="submit" className="button-primary" disabled={!replacement.trim()}>
          {vi ? "Kiểm tra" : "Check fix"}<ArrowRight size={16} aria-hidden="true" />
        </AnimateButton>
      </div>
      {current.text.startsWith(",") && <p id="writing-practice-punctuation" className="writing-practice-punctuation">
        {vi ? "Bạn có thể chỉ nhập dấu câu để giữ nguyên các từ trong phần đã chọn." : "You can type just the punctuation to keep the words in your selection."}
      </p>}
      <div id="writing-practice-repair-feedback" role="status" data-status={result?.status}>
        {result && <motion.p initial={{ opacity: .55 }} animate={{ opacity: 1 }} transition={transition.swap}>
          {result.feedback[locale]}
        </motion.p>}
      </div>
    </motion.form>}
    <button type="button" className="writing-text-link writing-practice-skip" onClick={onSkip}>
      {vi ? "Bỏ qua lượt này" : "Skip this pass"}
    </button>
  </section>;
}

function PracticeTakeaway({ heading, locale, repair, skill, clarify, onAnother }: {
  heading: Heading; locale: Locale; repair: RepairSuccess | null;
  skill: WritingPracticeRecommendation["skill"]; clarify: boolean; onAnother: () => void;
}) {
  const vi = locale === "vi";
  return <section className="writing-practice-takeaway" aria-labelledby="writing-practice-takeaway-title">
    <h2 id="writing-practice-takeaway-title" ref={heading} tabIndex={-1}>
      {repair && <Check size={19} aria-hidden="true" />}
      {repair ? (clarify ? (vi ? "Câu đã rõ hơn" : "That makes it clear") : (vi ? "Bạn đã sửa đúng" : "You fixed it"))
        : (vi ? "Điều cần nhớ" : "Take this with you")}
    </h2>
    {repair && <>
      <p className="writing-practice-corrected" lang="en">
        {repair.correctedParts.before}<mark>{repair.correctedParts.replacement}</mark>{repair.correctedParts.after}
      </p>
      <p>{repair.feedback[locale]}</p>
    </>}
    <p>{(repair?.takeaway ?? getWritingPracticeRepairTakeaway(skill))[locale]}</p>
    <div className="writing-practice-result-actions">
      <AnimateButton type="button" className="button-secondary" onClick={onAnother}>
        {vi ? "Thử tình huống khác" : "Try another situation"}
      </AnimateButton>
      <WritingLink href="/writing/diagnostic" className="writing-text-link">
        {vi ? "Viết bài mới" : "Start a new response"}<ArrowRight size={16} aria-hidden="true" />
      </WritingLink>
    </div>
  </section>;
}

function PracticeExercise({ submissionId, recommendation, source, locale }: {
  submissionId: string; recommendation: WritingPracticeRecommendation; source: SourceAnchor; locale: Locale;
}) {
  const vi = locale === "vi";
  const clarify = recommendation.category === "clarity";
  const exercises = getWritingPracticeExercises(recommendation.skill);
  const [session, setSession] = useState<{ index: number; pass: Pass; moved: boolean }>({ index: 0, pass: { name: "write" }, moved: false });
  const { index, pass, moved } = session;
  const heading = useRef<HTMLHeadingElement>(null);
  const [showOrigin] = useState(() => typeof window !== "undefined" && window.matchMedia("(min-width: 961px)").matches);
  const reduce = useShouldReduceMotion();
  const { transition } = useMotionTokens();
  const start = source.start - source.sentenceStart;
  const end = source.end - source.sentenceStart;
  const showSentence = source.sentence.length <= 180;

  useEffect(() => {
    if (moved) heading.current?.focus();
  }, [index, pass.name, moved]);

  function open(next: Pass) {
    setSession((current) => ({ ...current, pass: next, moved: true }));
  }

  function tryAnother() {
    setSession((current) => ({ index: (current.index + 1) % exercises.length, pass: { name: "write" }, moved: true }));
  }

  function finishRepair(repair: RepairSuccess, segment: string, replacement: string) {
    open({ name: "done", repair });
    void writingRequest(`submissions/${encodeURIComponent(submissionId)}/practice`, {
      body: { observationIndex: recommendation.observationIndex, exerciseIndex: index, segment, replacement },
    }).catch(() => {});
  }

  return <div className="writing-practice-layout">
    <div className="writing-practice-card">
      <ol className="writing-practice-steps" aria-label={vi ? "Các bước luyện tập" : "Practice steps"}>
        <li aria-current={pass.name === "write" ? "step" : undefined}>
          <span aria-hidden="true">{pass.name === "write" ? "1" : <Check size={14} />}</span>
          {vi ? "Điền vào chỗ trống" : "Complete the sentence"}
        </li>
        <li aria-current={pass.name === "repair" ? "step" : undefined}>
          <span aria-hidden="true">{pass.name === "done" && pass.repair ? <Check size={14} /> : "2"}</span>
          {vi ? "Tìm và sửa lỗi" : "Find and fix"}
        </li>
      </ol>
      <motion.div key={`${index}:${pass.name}`} className="writing-practice-pass"
        initial={moved ? { opacity: .72, x: reduce ? 0 : pass.name === "write" ? -8 : 8 } : false}
        animate={{ opacity: 1, x: 0 }} transition={transition.panelIn}>
        {pass.name === "write" ? <WritePass key={exercises[index].id} exercise={exercises[index]} locale={locale} heading={heading}
          onNext={() => open({ name: "repair" })} onAnother={tryAnother} />
          : pass.name === "repair" ? <RepairPass exercise={getWritingPracticeRepair(recommendation.skill, index)} locale={locale} heading={heading} clarify={clarify}
            onSkip={() => open({ name: "done", repair: null })} onSuccess={finishRepair} />
          : <PracticeTakeaway heading={heading} locale={locale} repair={pass.repair} skill={recommendation.skill} clarify={clarify} onAnother={tryAnother} />}
      </motion.div>
    </div>
    {pass.name === "write" && <aside className="writing-practice-origin" aria-labelledby="writing-practice-origin-title">
      <details open={showOrigin}>
        <summary id="writing-practice-origin-title">
          {vi ? "Góp ý từ bài của bạn" : "From your feedback"}<ChevronDown size={16} aria-hidden="true" />
        </summary>
        <blockquote lang="en">{showSentence && source.sentence.slice(0, start)}
          <mark>{source.exact}</mark>{showSentence && source.sentence.slice(end)}</blockquote>
        <p>{recommendation.reason[locale]}</p>
      </details>
    </aside>}
  </div>;
}

function WritePass({ exercise, locale, heading, onNext, onAnother }: {
  exercise: WritingPracticeExercise; locale: Locale; heading: Heading; onNext: () => void; onAnother: () => void;
}) {
  const vi = locale === "vi";
  const [answer, setAnswer] = useState("");
  const [afterConnector, setAfterConnector] = useState("");
  const [result, setResult] = useState<WritingPracticeResult | null>(null);
  const answerField = useRef<HTMLInputElement>(null);
  const afterField = useRef<HTMLInputElement>(null);
  const resultHeading = useRef<HTMLHeadingElement>(null);
  const however = exercise.format === "however";
  const startsSentence = answer.trim() === ".";
  const ready = !!answer.trim() && (!however || !!afterConnector.trim());
  const tryAfter = however && /^[.;]$/u.test(answer.trim());
  const needsEdit = !!result && result.status !== "successful";
  const after = !however && startsSentence ? exercise.after[0].toUpperCase() + exercise.after.slice(1) : exercise.after;

  function checkSentence(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!ready || result) return;
    const checked = checkWritingPracticeAttempt(exercise.id, answer, afterConnector);
    if (!checked) return;
    if (checked.answer) setAnswer(checked.answer);
    setResult(checked);
    requestAnimationFrame(() => resultHeading.current?.focus());
  }

  const resultLabel = result?.status === "successful" ? (vi ? "Bạn dùng đúng trong câu này" : "You used it correctly here")
    : result?.status === "revise" ? (vi ? "Thử sửa một chỗ" : "One thing to change")
      : (vi ? "Chưa xác nhận được cách viết này" : "This wording is unverified");

  const inputLabel = exercise.format === "verb" ? (vi ? "Động từ còn thiếu" : "Missing verb") : however
    ? (vi ? "Dấu câu trước however" : "Punctuation before however") : exercise.format === "join"
      ? (vi ? "Phần nối hai vế" : "Connection between the clauses") : (vi ? "Từ hoặc cụm từ còn thiếu" : "Missing word or phrase");
  const fieldProps = {
    autoComplete: "off", autoCorrect: "off", autoCapitalize: "off", spellCheck: false,
    readOnly: result?.status === "successful",
    "aria-describedby": needsEdit ? "writing-practice-prompt writing-practice-result-copy" : "writing-practice-prompt",
  };
  return <section aria-labelledby="writing-practice-prompt">
    <header className="writing-practice-task">
      {exercise.context && <p className="writing-practice-context" lang="en">{exercise.context}</p>}
      <h2 id="writing-practice-prompt" ref={heading} tabIndex={-1}>{exercise.prompt[locale]}</h2>
    </header>
    <form onSubmit={checkSentence} className="writing-practice-form">
      <div className="writing-practice-sentence" lang="en" data-format={exercise.format} data-state={result?.status}>
        {exercise.before}{" "}
        <span className="writing-practice-slot">
          <input {...fieldProps} id="writing-practice-answer" ref={answerField} aria-label={inputLabel}
            aria-invalid={result?.status === "revise" && !tryAfter || undefined}
            maxLength={however ? 1 : writingPracticeAnswerLimit} value={answer}
            onChange={(event) => { setAnswer(event.target.value); setResult(null); }} />
          {however && <>
            {" "}<span>{startsSentence ? "However" : "however"}</span>{" "}
            <input {...fieldProps} id="writing-practice-after-connector" ref={afterField} aria-label={vi ? "Dấu câu sau however" : "Punctuation after however"}
              aria-invalid={result?.status === "revise" && tryAfter || undefined} maxLength={1} value={afterConnector}
              onChange={(event) => { setAfterConnector(event.target.value); setResult(null); }} />
          </>}
        </span>{" "}{after}
      </div>
      {!result && <div className="writing-practice-controls">
        <Button type="submit" disabled={!ready}>
          {vi ? "Kiểm tra bài làm" : "Check my answer"}<ArrowRight size={16} aria-hidden="true" />
        </Button>
        <details className="writing-practice-hint">
          <summary><Lightbulb size={16} aria-hidden="true" />{vi ? "Xem gợi ý" : "Show a hint"}<ChevronDown size={15} aria-hidden="true" /></summary>
          <p>{exercise.hint[locale]}</p>
        </details>
      </div>}
    </form>
    {result && <div className="writing-practice-outcome" data-status={result.status}>
      <h3 ref={resultHeading} tabIndex={-1} aria-describedby="writing-practice-result-copy">
        {result.status === "successful" && <Check size={18} aria-hidden="true" />}{resultLabel}
      </h3>
      <div id="writing-practice-result-copy">
        <p>{result.feedback[locale]}</p>
        {result.status !== "successful" && <p>{result.nextStep[locale]}</p>}
      </div>
      <div className="writing-practice-result-actions">
        {result.status === "successful" ? <AnimateButton className="button-primary" type="button" onClick={onNext}>
          {vi ? "Tiếp tục: tìm và sửa lỗi" : "Continue to find and fix"}<ArrowRight size={16} aria-hidden="true" />
        </AnimateButton> : <Button secondary onClick={() => {
          const field = (tryAfter ? afterField : answerField).current;
          field?.focus();
          field?.select();
        }}>
          {vi ? "Sửa câu trả lời" : "Edit my answer"}
        </Button>}
        <button className="writing-text-link" type="button" onClick={onAnother}>
          {vi ? "Thử tình huống khác" : "Try another situation"}
        </button>
      </div>
    </div>}
  </section>;
}
