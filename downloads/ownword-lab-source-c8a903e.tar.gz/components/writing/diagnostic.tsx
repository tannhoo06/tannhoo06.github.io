"use client";

import { useEffect, useRef, useState, useSyncExternalStore, type FormEvent } from "react";
import { ArrowLeft, ArrowRight, ChevronDown, LoaderCircle } from "lucide-react";
import type { WritingService } from "@/lib/services/writing";
import type { WritingAssistance, WritingTask, WritingTaskSnapshot } from "@/lib/writing/persistence";
import { useI18n } from "../language-provider";
import { InterestChips } from "../lucian-019-multi-select";
import { LucianLanguageText } from "../lucian-267-language-switch";
import { useConfirmAction } from "../lucian-269-confirmation";
import { Button } from "../shared";
import { useRequestLimitNotice } from "../request-limit-notice";
import { readDiagnosticDraft, storeDiagnosticDraft } from "./diagnostic-draft";
import { PromptChoices as PromptPicker } from "./prompt-choices";
import { WritingQuotaCounter } from "./quota-counter";
import { discussionThinkingHints } from "./thinking-hints";
import {
  WritingLink, WritingRequestError, useWritingDraftGuard, useWritingResource,
  writingRequest, writingWordCount, type WritingRecord,
} from "./writing-client";

type Interest = WritingTaskSnapshot["interestIds"][number];
type PromptChoices = ReturnType<WritingService["prompts"]>;
type SubmitDraft = { taskId: string; requestId: string; text: string; assistance?: WritingAssistance };

type DiagnosticProps = { interests: PromptChoices["interests"]; ownerId: string; liveEvaluation?: boolean };
const subscribeToHydration = () => () => {};
const promptSentences = new Intl.Segmenter("en", { granularity: "sentence" });
const assistanceOptions = {
  unknown: ["Chưa chọn", "Not specified"],
  unassisted: ["Tự viết, không dùng trợ giúp", "I wrote it without help"],
  ownword_hint: ["Có dùng gợi ý của Ownword", "I used Ownword hints"],
  external_help: ["Có người hoặc công cụ hỗ trợ", "A person or tool helped me"],
} satisfies Record<WritingAssistance, readonly [string, string]>;

export function WritingDiagnostic(props: DiagnosticProps) {
  const { locale } = useI18n();
  const hydrated = useSyncExternalStore(subscribeToHydration, () => true, () => false);
  if (hydrated) return <DiagnosticFlow key={props.ownerId} {...props} />;
  return <div className="writing-flow">
    <p className="writing-status" role="status">{locale === "vi" ? "Đang mở phần Viết…" : "Opening Writing…"}</p>
  </div>;
}

function DiagnosticFlow({ interests, ownerId, liveEvaluation = false }: DiagnosticProps) {
  const { locale, t } = useI18n();
  const vi = locale === "vi";
  const { show: showLimit } = useRequestLimitNotice();
  const confirm = useConfirmAction();
  const [initialDraft] = useState(() => readDiagnosticDraft(ownerId));
  const [picked, setPicked] = useState<Interest[]>(initialDraft?.task.snapshot.interestIds ?? []);
  const [filter, setFilter] = useState<Interest[] | null>(initialDraft?.task.snapshot.interestIds ?? null);
  const [choice, setChoice] = useState(initialDraft?.task.promptId ?? "");
  const [task, setTask] = useState<WritingTask | null>(initialDraft?.task ?? null);
  const [text, setText] = useState(initialDraft?.text ?? "");
  const [draftStored, setDraftStored] = useState<boolean | null>(initialDraft ? true : null);
  const [assistance, setAssistance] = useState<WritingAssistance>(initialDraft?.assistance ?? "unknown");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<"assign" | "unknown" | "invalid" | "missing" | null>(
    initialDraft?.pendingRequestId ? "unknown" : null,
  );
  const [submitError, setSubmitError] = useState("");
  const assignment = useRef<{ key: string; id: string } | null>(null);
  const submission = useRef<SubmitDraft | null>(initialDraft?.pendingRequestId
    ? { taskId: initialDraft.task.id, requestId: initialDraft.pendingRequestId, text: initialDraft.text,
      assistance: initialDraft.assistance === "unknown" ? undefined : initialDraft.assistance } : null);
  const heading = useRef<HTMLHeadingElement>(null);
  const step = task ? "editor" : filter ? "prompts" : "interests";
  const leave = useWritingDraftGuard(step === "editor" && text.trim().length > 0);
  const query = new URLSearchParams();
  for (const id of filter ?? []) query.append("interest", id);
  const available = useWritingResource<PromptChoices>(filter && !task ? `prompts?${query}` : null);

  useEffect(() => {
    heading.current?.focus();
  }, [step]);

  function chooseTopics(next: Interest[]) {
    setChoice("");
    setError(null);
    setFilter(next);
  }

  async function openEditor(event: FormEvent) {
    event.preventDefault();
    if (!filter || !choice || busy) return;
    const key = JSON.stringify([choice, filter, locale]);
    if (assignment.current?.key !== key) assignment.current = { key, id: crypto.randomUUID() };
    setBusy(true);
    setError(null);
    try {
      const assigned = await writingRequest<WritingTask>("tasks", {
        body: { promptId: choice, interestIds: filter, locale, requestId: assignment.current.id },
      });
      setDraftStored(storeDiagnosticDraft(ownerId, { task: assigned, text: "" }));
      setTask(assigned);
    } catch {
      setError("assign");
    } finally {
      setBusy(false);
    }
  }

  async function backToPrompts() {
    if (text.trim() && !(await confirm({
      title: vi ? "Bỏ bài đang viết?" : "Discard this draft?",
      message: vi ? "Phần bạn đang viết chưa được xác nhận đã lưu." : "Your current draft has no confirmed save.",
      confirmLabel: vi ? "Bỏ bài đang viết" : "Discard draft",
    }))) return;
    storeDiagnosticDraft(ownerId, null);
    setText("");
    setAssistance("unknown");
    setTask(null);
    setError(null);
    submission.current = null;
    // A draft whose save was unconfirmed may already belong to its assignment.
    assignment.current = null;
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!task || !text.trim() || busy || error === "missing") return;
    submission.current ??= { taskId: task.id, requestId: crypto.randomUUID(), text,
      assistance: assistance === "unknown" ? undefined : assistance };
    setDraftStored(storeDiagnosticDraft(ownerId, { task, text, assistance, pendingRequestId: submission.current.requestId }));
    setBusy(true);
    setError(null);
    try {
      const saved = await writingRequest<WritingRecord>("submissions", {
        body: submission.current, acceptQuota: true,
      });
      storeDiagnosticDraft(ownerId, null);
      leave();
      if (saved.quota && !saved.run?.report) {
        const pending = !!saved.quota.pending;
        await showLimit(t(pending
          ? "Your essay is saved. All assessment slots are in use. Check again when the current assessments finish."
          : "Your essay is saved. You’ve reached today’s writing assessment limit."),
          pending ? undefined : saved.quota.resetAt, pending ? "Assessments in progress" : undefined);
      }
      window.location.replace(`/writing/submissions/${saved.submission.id}`);
    } catch (failure) {
      const status = failure instanceof WritingRequestError ? failure.status : null;
      if (status === 400 || status === 404) {
        submission.current = null;
        setDraftStored(storeDiagnosticDraft(ownerId, { task, text, assistance }));
      }
      setSubmitError(status === 401 ? "Your session has ended. Sign in and try again."
        : failure instanceof TypeError ? "Couldn’t connect to Ownword. Your draft is still here. Check your connection and retry."
          : "");
      setError(status === 400 ? "invalid" : status === 404 ? "missing" : "unknown");
      setBusy(false);
    }
  }

  if (task) {
    const { prompt, blueprint } = task.snapshot;
    const discussion = "interestIds" in prompt;
    const questionStart = discussion
      ? Array.from(promptSentences.segment(prompt.scenario)).find(({ segment }) => segment.trimEnd().endsWith("?"))?.index ?? 0
      : 0;
    const count = writingWordCount(text);
    const range = `${blueprint.wordRange.min}–${blueprint.wordRange.max}`;
    return (
      <div className="writing-flow writing-flow-wide writing-compose">
        <button className="writing-text-link" type="button" onClick={() => void backToPrompts()} disabled={busy}>
          <ArrowLeft size={16} aria-hidden="true" />{vi ? "Chọn đề khác" : "Back to prompts"}
        </button>
        <div className="writing-editor-layout">
          <section className="writing-brief" aria-labelledby="diagnostic-question">
            {prompt.title && <p className="writing-brief-topic" lang="en">{prompt.title}</p>}
            <h1 ref={heading} tabIndex={-1} id="diagnostic-question" lang="en">
              {questionStart > 0 && <span className="writing-brief-context">{prompt.scenario.slice(0, questionStart)}</span>}
              {prompt.scenario.slice(questionStart)}
            </h1>
            {"options" in prompt && !prompt.title && <ul className="writing-options" lang="en">{prompt.options.map((option) => <li key={option}>{option}</li>)}</ul>}
            {!discussion && <div className="writing-brief-guidance">
              <h2>{vi ? "Trong bài viết, hãy" : "In your response"}</h2>
              <ul>
                <li>{vi ? "Nêu lựa chọn của bạn." : "Say which option you prefer."}</li>
                <li>{vi ? "Giải thích khoảng hai lý do." : "Give two reasons and explain them."}</li>
                <li>{vi ? "Nêu một điểm bất tiện hoặc hạn chế của lựa chọn đó." : "Mention one drawback of that option."}</li>
              </ul>
            </div>}
            <p className="writing-note">{vi ? "Không có đáp án đúng hay sai." : "There’s no right or wrong answer."}</p>
            {discussion && <details className="writing-guide writing-thinking-hints">
              <summary>{vi ? "Gợi ý" : "Hints"}
                <ChevronDown size={15} aria-hidden="true" />
              </summary>
              <ul>
                {discussionThinkingHints[prompt.id].map((hint) => <li key={hint.en}>{hint[locale]}</li>)}
              </ul>
            </details>}
          </section>
          <form className="writing-editor" onSubmit={(event) => void submit(event)} aria-busy={busy}>
            <div className="writing-compose-paper">
              <div className="writing-editor-label">
                <label htmlFor="diagnostic-text">{vi ? "Bài viết tiếng Anh của bạn" : "Your response in English"}</label>
                <span id="diagnostic-length">{vi ? `Gợi ý ${range} từ` : `Suggested length ${range} words`}</span>
              </div>
              <textarea id="diagnostic-text" className="writing-textarea" lang="en" value={text} maxLength={5000}
                onChange={(event) => {
                  const next = event.target.value;
                  setText(next);
                  setDraftStored(storeDiagnosticDraft(ownerId, { task, text: next, assistance }));
                }} readOnly={busy || error === "unknown"}
                placeholder={discussion ? "Start with what you think about the question." : "Start with what you’d choose and why."}
                aria-describedby="diagnostic-length diagnostic-question" spellCheck autoComplete="off" />
              <div className="writing-editor-meta">
                <span>{vi ? `${count} từ` : `${count} ${count === 1 ? "word" : "words"}`}</span>
                {text.length === 5000 && <span>{vi ? "Đã đạt 5.000 ký tự" : "5,000 character limit reached"}</span>}
              </div>
            </div>
            {error && <p className="writing-alert" role="alert">{error === "invalid"
              ? (vi ? "Hãy kiểm tra nội dung bài viết rồi gửi lại." : "Check your response and try again.")
              : error === "missing"
                ? (vi ? "Đề này không còn mở. Hãy sao chép phần bạn đã viết trước khi chọn đề khác." : "This task is no longer available. Copy your draft before choosing another prompt.")
                : submitError ? t(submitError) : (vi ? "Chưa xác nhận được lần gửi này. Thử lại sẽ gửi đúng bản đang hiển thị." : "We couldn’t confirm this submission. Retrying checks the same draft.")}</p>}
            <WritingQuotaCounter />
            <div className="writing-actions ux">
              <button className="ow-action-primary writing-primary-action" type="submit" disabled={!text.trim() || busy || error === "missing"}>
                {busy && <LoaderCircle className="spin" size={16} aria-hidden="true" />}
                {busy ? (vi ? "Đang gửi…" : "Submitting…") : error === "unknown"
                  ? (vi ? "Thử gửi lại" : "Retry submission")
                  : (vi ? "Gửi bài và xem nhận xét" : "Submit for feedback")}
                {!busy && <ArrowRight size={16} aria-hidden="true" />}
              </button>
              <div className="writing-assistance">
                <label htmlFor="diagnostic-assistance">{vi ? "Bạn có dùng trợ giúp khi viết bài này không? (không bắt buộc)" : "Did you get help writing this? (optional)"}</label>
                <select id="diagnostic-assistance" className="u267-gb" value={assistance}
                  aria-describedby="diagnostic-assistance-help" disabled={busy || error === "unknown"}
                  onChange={(event) => {
                    const next = event.currentTarget.value as WritingAssistance;
                    setAssistance(next);
                    setDraftStored(storeDiagnosticDraft(ownerId, { task, text, assistance: next }));
                  }}>
                  {Object.entries(assistanceOptions).map(([value, labels]) => (
                    <option key={value} value={value}>{labels[vi ? 0 : 1]}</option>
                  ))}
                </select>
              </div>
            </div>
            <p id="diagnostic-assistance-help" className="writing-note">{vi ? "Thông tin này giúp Ownword chọn những bài có thể đối chiếu." : "This helps Ownword decide which essays it can compare."}</p>
            {draftStored === false && <p className="writing-note" role="status">{vi
              ? "Trình duyệt chưa lưu được bài đang viết. Hãy giữ thẻ này mở hoặc sao chép phần bạn đã viết."
              : "Your browser couldn’t keep this draft. Leave this tab open or copy what you’ve written."}</p>}
            <p className="writing-note">
              {draftStored === true && (vi ? "Bài đang viết được lưu trong thẻ này. " : "This draft is kept in this tab. ")}
              {vi
                ? `Để xóa một bài đã gửi, hãy mở bài đó từ Hồ sơ viết. ${liveEvaluation ? "Ownword dùng AI để nhận xét bài viết của bạn." : "Bản xem thử dùng nhận xét mô phỏng."} Hãy tránh thông tin cá nhân.`
                : `To delete a submitted essay, open it from Writing Profile. ${liveEvaluation ? "Ownword uses AI to review your writing." : "This preview uses simulated feedback."} Avoid sharing personal details.`}
            </p>
          </form>
        </div>
      </div>
    );
  }

  if (filter) return (
    <div className="writing-flow writing-setup">
      <button className="writing-text-link" type="button" disabled={busy} onClick={() => { setFilter(null); setError(null); }}>
        <ArrowLeft size={16} aria-hidden="true" />{vi ? "Quay lại chọn chủ đề" : "Back to topics"}
      </button>
      <header className="writing-heading practice-hub-heading">
        <h1 ref={heading} tabIndex={-1}><LucianLanguageText value={vi ? "Chọn đề bài" : "Choose a prompt"} /></h1>
        <p>{vi ? "Bạn sẽ trả lời bằng tiếng Anh." : "You’ll answer in English."}</p>
      </header>
      {available.loading && <p className="writing-status" role="status"><LoaderCircle size={18} className="spin" />{vi ? "Đang tải đề bài…" : "Loading prompts…"}</p>}
      {available.error && <div role="alert" className="writing-alert">
        {vi ? "Chưa tải được đề bài." : "The prompts didn’t load."}
        <button className="writing-text-link" onClick={available.reload}>{vi ? "Thử lại" : "Try again"}</button>
      </div>}
      {available.data && (
        <form className="writing-setup-paper writing-prompt-paper" onSubmit={(event) => void openEditor(event)} aria-busy={busy}>
          <PromptPicker prompts={available.data.choices} label={vi ? "Đề bài bằng tiếng Anh" : "Prompts in English"}
            selected={choice} onSelect={setChoice} disabled={busy} />
          {error === "assign" && <p className="writing-alert" role="alert">{vi ? "Chưa mở được đề bài. Bạn có thể thử lại." : "This prompt didn’t open. You can try again."}</p>}
          <div className="writing-actions">
            <Button className="practice-hub-cta" type="submit" disabled={!choice || busy}>{busy ? (vi ? "Đang mở đề…" : "Opening prompt…") : (vi ? "Mở đề và viết" : "Open writing editor")} <ArrowRight size={16} aria-hidden="true" /></Button>
          </div>
        </form>
      )}
    </div>
  );

  return (
    <div className="writing-flow writing-setup">
      <WritingLink href="/writing" className="writing-text-link"><ArrowLeft size={16} aria-hidden="true" />{vi ? "Về trang Viết" : "Back to Writing"}</WritingLink>
      <header className="writing-heading practice-hub-heading">
        <h1 ref={heading} tabIndex={-1}><LucianLanguageText value={vi ? "Bạn muốn viết về chủ đề nào?" : "What would you like to write about?"} /></h1>
      </header>
      <div className="writing-setup-paper">
        <InterestChips options={(Object.keys(interests) as Interest[]).map((id) => ({ id, label: interests[id][locale] }))}
          selected={picked} onChange={setPicked} title={vi ? "Chủ đề" : "Writing topics"}
          hint={vi ? "Chọn một hoặc hai chủ đề." : "Choose one or two topics."}
          limitMessage={vi ? "Bạn có thể chọn tối đa hai chủ đề." : "You can choose up to two topics."}
          fullMessage={vi ? "Đã chọn hai chủ đề." : "Two topics selected."} />
        <div className="writing-actions">
          <Button className="practice-hub-cta" disabled={!picked.length} onClick={() => chooseTopics(picked)}>{vi ? "Xem đề viết" : "See writing prompts"} <ArrowRight size={16} aria-hidden="true" /></Button>
          <button type="button" className="writing-text-link" onClick={() => chooseTopics([])}>{vi ? "Dùng đề chung" : "Use general prompts"}</button>
        </div>
      </div>
    </div>
  );
}
