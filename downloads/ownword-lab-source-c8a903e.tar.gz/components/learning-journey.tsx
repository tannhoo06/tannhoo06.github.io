// Lucian UX/UI Prompt #318 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#318
// Lucian UX/UI Prompt #260 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#260
// Lucian UX/UI Prompt #281 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#281
// Lucian UX/UI Prompt #002 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#002
"use client";

import { Fragment, useEffect, useRef, useState, type CSSProperties, type PointerEvent } from "react";
import { ArrowDown, Check, Feather, Plus } from "lucide-react";
import { useI18n } from "./language-provider";
import { LucianLanguageContent } from "./lucian-267-language-switch";
import Aurora from "./reactbits-aurora";
import "@/app/learning-journey.css";

type RoutePoint = { x: number; y: number };
type RouteGeometry = { d: string; width: number; height: number; stops: RoutePoint[] };

function FillWords({ text }: { text: string }) {
  return <>{text.split(" ").map((word, index) => <Fragment key={index}>{index > 0 ? " " : null}<span className="u260-w">{word}</span></Fragment>)}</>;
}

const clamp = (value: number) => Math.max(0, Math.min(1, value));

export function LearningJourney({ start }: { start: () => void }) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const root = useRef<HTMLElement>(null);
  const steps = useRef<HTMLDivElement>(null);
  const path = useRef<SVGPathElement>(null);
  const magnet = useRef<HTMLDivElement>(null);
  const labelNode = useRef<HTMLSpanElement>(null);
  const orb = useRef<HTMLSpanElement>(null);
  const button = useRef<HTMLButtonElement>(null);
  const startTimer = useRef<number>(0);
  const resetTimer = useRef<number>(0);
  const [geometry, setGeometry] = useState<RouteGeometry | null>(null);
  const [progress, setProgress] = useState(0);
  const [reachedStops, setReachedStops] = useState([false, false, false, false]);
  const [highlighted, setHighlighted] = useState(false);
  const [headingHighlighted, setHeadingHighlighted] = useState(false);
  const [ctaState, setCtaState] = useState<"idle" | "go">("idle");
  const label = vi ? "Bắt đầu với một từ" : "Start with one word";

  useEffect(() => {
    const map = steps.current;
    if (!map) return;
    const cards = Array.from(map.querySelectorAll<HTMLElement>(".ow-journey-step"));
    const measure = () => {
      const mapRect = map.getBoundingClientRect();
      const points = cards.map((card, index) => {
        const rect = card.getBoundingClientRect();
        const number = card.querySelector(".ow-journey-number")?.getBoundingClientRect();
        return {
          x: index % 2 === 0 ? rect.right - mapRect.left + 10 : rect.left - mapRect.left - 10,
          y: (number?.top ?? rect.top) - mapRect.top + (number?.height ?? 42) / 2,
        };
      });
      if (points.length !== 4) return;
      const [a, b, c, d] = points;
      const right = mapRect.width * .27;
      const left = mapRect.width * .19;
      // A broad right turn, a left return, and a final right turn mirror the
      // reference. Each numbered step has a real endpoint on the SVG path.
      const curve = [
        `M${a.x} ${a.y}`,
        `C${a.x + right * .55} ${a.y + 8} ${b.x + right} ${a.y + (b.y - a.y) * .3} ${b.x + right} ${a.y + (b.y - a.y) * .43}`,
        `C${b.x + right} ${b.y - (b.y - a.y) * .3} ${b.x - 76} ${b.y - 78} ${b.x} ${b.y}`,
        `C${b.x - left} ${b.y + 42} ${c.x - left} ${c.y - 90} ${c.x - left} ${c.y - 50}`,
        `C${c.x - left} ${c.y - 18} ${c.x + 70} ${c.y - 10} ${c.x} ${c.y}`,
        `C${c.x + right * .55} ${c.y + 8} ${d.x + right} ${c.y + (d.y - c.y) * .3} ${d.x + right} ${c.y + (d.y - c.y) * .43}`,
        `C${d.x + right} ${d.y - (d.y - c.y) * .3} ${d.x - 76} ${d.y - 78} ${d.x} ${d.y}`,
      ].join(" ");
      setGeometry((previous) => previous?.d === curve && previous.height === mapRect.height ? previous : { d: curve, width: mapRect.width, height: mapRect.height, stops: points });
    };
    const observer = new ResizeObserver(measure);
    observer.observe(map);
    cards.forEach((card) => observer.observe(card));
    measure();
    return () => observer.disconnect();
  }, [locale]);

  useEffect(() => {
    const section = root.current;
    const map = steps.current;
    const line = path.current;
    if (!section || !map || !line || !geometry) return;
    const length = line.getTotalLength();
    line.style.strokeDasharray = `${length} ${length}`;
    const table = Array.from({ length: 201 }, (_, index) => {
      const at = length * index / 200;
      return [line.getPointAtLength(at).y, at] as const;
    });
    const lengthAt = (y: number) => {
      if (y <= table[0][0]) return 0;
      for (let index = 1; index < table.length; index++) {
        if (table[index][0] >= y) {
          const before = table[index - 1];
          const after = table[index];
          return before[1] + (after[1] - before[1]) * (y - before[0]) / Math.max(.01, after[0] - before[0]);
        }
      }
      return length;
    };
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    const draw = () => {
      frame = 0;
      const sectionTop = section.getBoundingClientRect().top;
      if (sectionTop <= innerHeight * .18) setHeadingHighlighted(true);
      const mapRect = map.getBoundingClientRect();
      const readingY = innerHeight * .45 - mapRect.top;
      const drawn = reduced.matches ? length : lengthAt(readingY);
      line.style.strokeDashoffset = (length - drawn).toFixed(1);
      setProgress(reduced.matches ? 1 : clamp((readingY - geometry.stops[0].y) / Math.max(1, geometry.stops[3].y - geometry.stops[0].y)));
      const reachedNow = geometry.stops.map((stop) => drawn >= lengthAt(stop.y) - 1);
      setReachedStops((previous) => reachedNow.every((value, index) => value === previous[index]) ? previous : reachedNow);
      // #260: each visible sentence fills one word at a time as it crosses the
      // reading line. Scrolling back restores the unfilled words.
      section.querySelectorAll<HTMLElement>(".ow-journey-fill").forEach((sentence) => {
        const words = sentence.querySelectorAll<HTMLElement>(".u260-w");
        const t = reduced.matches ? 1 : clamp((innerHeight * .58 - sentence.getBoundingClientRect().top) / (innerHeight * .3));
        const fill = t * 1.15 * words.length;
        words.forEach((word, index) => word.style.setProperty("--f", clamp(fill - index).toFixed(2)));
      });
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(draw); };
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
    reduced.addEventListener("change", schedule);
    draw();
    return () => { cancelAnimationFrame(frame); window.removeEventListener("scroll", schedule); window.removeEventListener("resize", schedule); reduced.removeEventListener("change", schedule); };
  }, [geometry, locale]);

  useEffect(() => {
    const section = root.current;
    if (!section) return;
    const marks = section.querySelectorAll(".u281-p mark");
    let highlightDelay = .25;
    marks.forEach((mark) => {
      const element = mark as HTMLElement;
      const duration = Math.min(1.4, .25 + (element.textContent?.length ?? 0) * .045);
      element.style.setProperty("--d", `${duration.toFixed(2)}s`);
      element.style.setProperty("--w", `${highlightDelay.toFixed(2)}s`);
      highlightDelay += duration + .12;
    });
    const highlightObserver = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) { setHighlighted(true); highlightObserver.disconnect(); } }, { rootMargin: "0px 0px -30% 0px", threshold: .45 });
    const highlightTarget = section.querySelector(".ow-journey-step--two");
    if (highlightTarget) highlightObserver.observe(highlightTarget);
    return () => highlightObserver.disconnect();
  }, [locale]);

  useEffect(() => () => {
    window.clearTimeout(startTimer.current);
    window.clearTimeout(resetTimer.current);
  }, []);

  const magneticMove = (event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType === "touch" || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const rect = button.current?.getBoundingClientRect();
    if (!rect) return;
    const dx = event.clientX - rect.left - rect.width / 2;
    const dy = event.clientY - rect.top - rect.height / 2;
    const pull = Math.max(0, 1 - Math.hypot(dx, dy) / 240);
    if (magnet.current) magnet.current.style.translate = `${(dx * .12 * pull).toFixed(1)}px ${(dy * .22 * pull).toFixed(1)}px`;
    if (labelNode.current) labelNode.current.style.translate = `${(dx * .05 * pull).toFixed(1)}px ${(dy * .08 * pull).toFixed(1)}px`;
    if (orb.current) orb.current.style.translate = `${(dx * .1 * pull).toFixed(1)}px ${(dy * .14 * pull).toFixed(1)}px`;
  };
  const resetMagnet = () => {
    if (magnet.current) magnet.current.style.translate = "0px 0px";
    if (labelNode.current) labelNode.current.style.translate = "0px 0px";
    if (orb.current) orb.current.style.translate = "0px 0px";
  };
  const activate = () => {
    if (ctaState === "go") return;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    setCtaState("go");
    startTimer.current = window.setTimeout(start, reduced ? 0 : 620);
    resetTimer.current = window.setTimeout(() => setCtaState("idle"), reduced ? 900 : 1900);
  };
  const reached = (index: number) => reachedStops[index] ?? false;

  return <section ref={root} id="how-it-works" className={`ow-journey${headingHighlighted ? " is-heading-visible" : ""}`} aria-labelledby="ow-how-title">
    {(["start", "end"] as const).map((edge) => <div key={edge} className={`ow-journey-aurora ow-journey-aurora--${edge}`} aria-hidden="true">
      <Aurora lightMode intro={false} colorStops={["#a8dccb", "#f5dc91", "#b9e5d1", "#c7ddb4"]} amplitude={0.65} blend={0.7} height={0.8} glow={0.65} brightness={0.9} layers={2} speed={0.4} opacity={0.72} mouseInteraction />
    </div>)}
    <div className="ow-journey-shell">
      <header className="ow-journey-heading">
        <div className="u260-run">
          <div className="u260-pin">
            <h2 id="ow-how-title"><LucianLanguageContent locale={locale} render={(shown) => shown === "vi" ? <>Cách học với <mark className="ow-hero-highlight ow-journey-title-mark">Ownword</mark></> : <>How <mark className="ow-hero-highlight ow-journey-title-mark">Ownword</mark> works</>} /></h2>
            <a className="ow-journey-scroll" href="#ow-journey-steps"><ArrowDown size={19} aria-hidden="true" />{vi ? "Xem các bước" : "See the steps"}</a>
          </div>
        </div>
      </header>
      <div ref={steps} id="ow-journey-steps" className="ow-journey-steps" style={{ "--journey-progress": progress } as CSSProperties}>
        <svg className="ow-journey-route" viewBox={`0 0 ${geometry?.width ?? 1} ${geometry?.height ?? 1}`} preserveAspectRatio="none" aria-hidden="true"><path className="u318-guide" d={geometry?.d ?? ""} /><path ref={path} className="u318-route" d={geometry?.d ?? ""} />{geometry?.stops.map(({ x, y }, index) => <g key={index}><circle className={`u318-dot${reached(index) ? " on" : ""}`} cx={x} cy={y} r="13" /><circle className={`u318-dotc${reached(index) ? " on" : ""}`} cx={x} cy={y} r="7" /></g>)}</svg>
        <article className={`ow-journey-step ow-journey-step--one${reached(0) ? " is-reached" : ""}`}>
          <div className="ow-journey-copy"><span className="ow-journey-number">1</span><div><h3 className="ow-journey-fill"><FillWords text={vi ? "Lưu một từ bạn muốn dùng" : "Save a word you want to use"} /></h3><p className="ow-journey-fill"><FillWords text={vi ? "Thêm một từ bạn đã từng gặp hoặc muốn dùng thành thạo." : "Add a word you've seen before or want to use confidently."} /></p></div></div>
          <div className="ow-journey-example ow-journey-save"><span className="ow-journey-save-icon"><Plus size={20} aria-hidden="true" /></span><strong lang="en">negligible</strong><span className="ow-journey-save-check"><Check size={18} aria-hidden="true" /></span></div>
        </article>
        <article className={`ow-journey-step ow-journey-step--two u281${highlighted ? " is-on" : ""}${reached(1) ? " is-reached" : ""}`}>
          <div className="ow-journey-copy"><span className="ow-journey-number">2</span><div><h3 className="ow-journey-fill"><FillWords text={vi ? "Hiểu cách dùng" : "Understand how to use it"} /></h3><p className="ow-journey-fill"><FillWords text={vi ? "Nắm rõ nghĩa, sắc thái và xem cách dùng trong ngữ cảnh thực tế." : "Learn its meaning and nuance, then see it in a real context."} /></p></div></div>
          <div className="ow-journey-example ow-journey-suggestion u281-p"><div><strong lang="en">negligible</strong><small lang="en">/ˈneɡlɪdʒəbəl/</small><span>{vi ? "nhỏ đến mức không đáng kể" : "too small to matter"}</span></div><p lang="en">The cost difference is <mark>negligible</mark>.</p></div>
        </article>
        <article className={`ow-journey-step ow-journey-step--three${reached(2) ? " is-reached" : ""}`}>
          <div className="ow-journey-copy"><span className="ow-journey-number">3</span><div><h3 className="ow-journey-fill"><FillWords text={vi ? "Tự nhớ lại" : "Recall it yourself"} /></h3><p className="ow-journey-fill"><FillWords text={vi ? "Ôn tập bằng cách chủ động nhớ và điền từ còn thiếu." : "Practice retrieving the word and filling in what's missing."} /></p></div></div>
          <div className="ow-journey-example ow-journey-practice"><p>{vi ? "Nhỏ đến mức không đáng kể là _______?" : "Too small to matter is _______?"}</p><div><strong lang="en">negligible</strong><Check size={19} aria-hidden="true" /></div></div>
        </article>
        <article className={`ow-journey-step ow-journey-step--four${reached(3) ? " is-reached" : ""}`}>
          <div className="ow-journey-copy"><span className="ow-journey-number">4</span><div><h3 className="ow-journey-fill"><FillWords text={vi ? "Dùng trong ngữ cảnh mới" : "Use it in a new context"} /></h3><p className="ow-journey-fill"><FillWords text={vi ? "Viết một câu của riêng bạn để thực sự vận dụng từ." : "Write your own sentence to put the word to use."} /></p></div></div>
          <div className="ow-journey-example ow-journey-writing"><span>{vi ? "Câu của bạn" : "Your sentence"}</span><p lang="en">The time difference is <mark>negligible</mark> in this case.</p><Feather size={18} aria-hidden="true" /></div>
        </article>
      </div>
      <div className="ux u002 ow-journey-cta" data-state={ctaState} onPointerMove={magneticMove} onPointerLeave={resetMagnet}>
        <span className="u002-glow" aria-hidden="true" />
        <div ref={magnet} className="u002-mag">
          <button ref={button} type="button" className="u002-btn" onClick={activate} disabled={ctaState === "go"}>
            <span className="u002-fill" aria-hidden="true" />
            <span ref={labelNode} className="u002-txt"><span>{label}</span><span aria-hidden="true">{vi ? "Đang mở..." : "Opening..."}</span></span>
            <span ref={orb} className="u002-orb" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M5 12h13M13 6l6 6-6 6" /></svg><svg viewBox="0 0 24 24"><path d="M5 12h13M13 6l6 6-6 6" /></svg></span>
          </button>
        </div>
        <span className="u002-live" aria-live="polite">{ctaState === "go" ? (vi ? "Đang mở" : "Opening") : ""}</span>
      </div>
    </div>
  </section>;
}
