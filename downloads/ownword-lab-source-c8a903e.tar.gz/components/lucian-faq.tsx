// Lucian UX/UI Prompt #044 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#044
"use client";

import { useRef, useState, type KeyboardEvent } from "react";
import "./lucian-faq.css";

type Question = { id: string; question: string; answer: string };

export function LucianFaq({ questions }: { questions: Question[] }) {
  const [expanded, setExpanded] = useState<string | null>(questions[0]?.id ?? null);
  const triggers = useRef<(HTMLButtonElement | null)[]>([]);

  function moveFocus(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    const next =
      event.key === "ArrowDown" ? index + 1 :
      event.key === "ArrowUp" ? index - 1 :
      event.key === "Home" ? 0 :
      event.key === "End" ? questions.length - 1 : null;
    if (next === null) return;
    event.preventDefault();
    triggers.current[(next + questions.length) % questions.length]?.focus();
  }

  return (
    <div className="ux u044 ow-faq-rows">
      {questions.map(({ id, question, answer }, index) => {
        const open = expanded === id;
        return (
          <div className={`u044-it${open ? " open" : ""}`} key={id}>
            <h3>
              <button
                ref={(node) => { triggers.current[index] = node; }}
                className="u044-q"
                type="button"
                id={`faq-${id}-trigger`}
                aria-expanded={open}
                aria-controls={`faq-${id}-answer`}
                onClick={() => setExpanded(open ? null : id)}
                onKeyDown={(event) => moveFocus(event, index)}
              >
                <span className="u044-t">{question}</span>
                <span className="u044-pm" aria-hidden="true" />
              </button>
            </h3>
            <div
              className="u044-body"
              id={`faq-${id}-answer`}
              role="region"
              aria-labelledby={`faq-${id}-trigger`}
              aria-hidden={!open}
              inert={!open}
            >
              <div><div className="u044-a"><p>{answer}</p></div></div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
