"use client";

import { useEffect } from "react";
import { pageTitle, type PageTitleName } from "@/lib/i18n/page-titles";
import { useI18n } from "./language-provider";

export function LocalizedPageTitle(props: { name: PageTitleName } | { title: string }) {
  const { locale } = useI18n();
  const title = "title" in props ? `${props.title} | Ownword` : pageTitle(props.name, locale);
  useEffect(() => {
    document.title = title;
  }, [title]);
  return null;
}
