"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import { motion } from "motion/react";
import {
  ArrowRight,
  ArrowLeft,
  BookOpen,
  Check,
  Eye,
  Keyboard,
  RotateCcw,
  SkipForward,
  X,
  Zap,
} from "lucide-react";
import type { AppState, PracticeSession } from "@/lib/domain/types";
import { api, Button, ErrorMessage, Loading } from "./shared";
import { useI18n } from "./language-provider";
import { LucianLanguageText } from "./lucian-267-language-switch";
import { useMotionTokens, useShouldReduceMotion } from "@animate-ui/react/utils/motion";
import { vietnameseDemoMeanings } from "@/lib/i18n/vocabulary";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import FlipCard from "./FlipCard";
import { StudyCardStack } from "./kokonutui/study-card-stack";
export function QuickReview({
  state,
  full,
  back,
}: {
  state: AppState;
  full: (sessionId: string) => void;
  back: () => void;
}) {
  const { t } = useI18n();
  const reduceMotion = useShouldReduceMotion();
  const { spring, transition } = useMotionTokens();
  const [session, setSession] = useState<PracticeSession | null>(null);
  const [id, setId] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [cardIndex, setCardIndex] = useState(0);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  const startingSession = useRef<string | null>(null);
  const recapHeading = useRef<HTMLHeadingElement>(null);
  const [results, setResults] = useState<
    { word: string; id: string; rating: string }[]
  >([]);
  const start = useCallback(async () => {
    setBusy(true);
    setError("");
    try {
      startingSession.current ??= (await api<{ sessionId: string }>("practice/start", {
        quick: true,
      })).sessionId;
      const sessionId = startingSession.current;
      const next = await api<PracticeSession>(`practice?sessionId=${encodeURIComponent(sessionId)}`);
      startingSession.current = null;
      setId(sessionId);
      setSession(next);
      setResults([]);
      setCardIndex(0);
      setRevealed(false);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }, []);
  useEffect(() => {
    let mounted = true;
    queueMicrotask(() => {
      if (mounted) void start();
    });
    return () => { mounted = false; };
  }, [start]);
  const entry = session?.words[cardIndex];
  const word = state.words.find((w) => w.userWordId === entry?.userWordId);
  const ex =
    session && !session.complete && entry
      ? {
          id:
            entry.exerciseId ??
            (session.exercise?.position === cardIndex + 1
              ? session.exercise.id
              : ""),
          position: cardIndex + 1,
          total: session.total,
          definition: word?.definition ?? session.exercise?.definition,
        }
      : null;
  const savedRating = results.find((r) => r.id === entry?.userWordId);
  const complete = session?.complete;
  const ratedCount = Math.max(0, results.length - (busy ? 1 : 0));
  useEffect(() => {
    if (complete) recapHeading.current?.focus({ preventScroll: true });
  }, [complete]);
  useEffect(() => {
    if (!ex?.id) return;
    const cards = document.querySelectorAll<HTMLElement>(".quick-deck-top .quick-reactbits-card");
    cards.item(cards.length - 1)?.focus({ preventScroll: true });
  }, [ex?.id]);
  function moveCard(direction: number) {
    if (busy || !session || session.complete) return;
    const nextIndex = Math.max(
      0,
      Math.min(session.words.length - 1, cardIndex + direction),
    );
    if (nextIndex === cardIndex) return;
    setCardIndex(nextIndex);
    setRevealed(false);
  }
  useEffect(() => {
    if (!session || session.complete || busy) return;
    function handleKey(event: KeyboardEvent) {
      if (
        event.repeat ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey ||
        event.shiftKey ||
        event.isComposing ||
        event.defaultPrevented
      )
        return;
      const target = event.target;
      if (
        target instanceof HTMLElement &&
        target.closest(
          'input, textarea, select, [contenteditable]:not([contenteditable="false"]), summary, a, [role="textbox"], [role="dialog"]',
        )
      )
        return;
      if (event.code === "Space" || event.key === " " || event.key === "Spacebar") {
        // Native buttons retain Space activation, including the card's flip button.
        if (
          target instanceof HTMLElement &&
          target.closest('button, [role="button"]')
        )
          return;
        event.preventDefault();
        setRevealed((value) => !value);
      } else if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        event.preventDefault();
        moveCard(event.key === "ArrowLeft" ? -1 : 1);
      }
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  });
  const forgottenCount = results.filter((r) => r.rating === "forgot").length;
  async function rate(rating: "got" | "forgot" | "skip") {
    if (!ex?.id || !entry || busy || savedRating) return;
    setBusy(true);
    setError("");
    const nextResults = [...results, { word: entry.word, id: entry.userWordId, rating }];
    setResults(nextResults);
    const nextIndexLocal = session?.words.findIndex((w, index) => index > cardIndex && !nextResults.some((r) => r.id === w.userWordId)) ?? -1;
    if (nextIndexLocal >= 0) { setCardIndex(nextIndexLocal); setRevealed(false); }
    if (rating === "got") window.dispatchEvent(new Event("ownword:mascot-wag"));
    try {
      await api("practice/quick-rate", { exerciseId: ex.id, rating });
      const nextSession = await api<PracticeSession>(
        "practice?sessionId=" + id,
      );
      setSession(nextSession);
      const unrated = (w: PracticeSession["words"][number]) =>
        !nextResults.some((r) => r.id === w.userWordId);
      const nextIndex = nextSession.words.findIndex(
        (w, index) => index > cardIndex && unrated(w),
      );
      const firstUnrated = nextSession.words.findIndex(unrated);
      setCardIndex(nextIndex >= 0 ? nextIndex : Math.max(0, firstUnrated));
      setRevealed(false);
    } catch (e) {
      setResults(results);
      setCardIndex(cardIndex);
      setRevealed(true);
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section
      className={`quick-review ${!session || session.complete ? "quick-complete" : "quick-session"}`}
    >
      {error && <ErrorMessage message={error} retry={!session && !busy ? start : undefined} />}
      {!session && busy && <Loading text="Loading your practice…" />}
      {ex && (
        <>
          <header className="quick-session-heading">
            <div className="quick-session-title">
              <h1>
                <Zap size={18} aria-hidden="true" />
                <LucianLanguageText value={t("Quick flashcard review")} order={2} />
              </h1>
              <Popover>
                <PopoverTrigger asChild>
                  <button
                    type="button"
                    className="quick-shortcuts-trigger"
                    aria-label={t("Shortcuts")}
                  >
                    <Keyboard size={16} aria-hidden="true" />
                  </button>
                </PopoverTrigger>
                <PopoverContent
                  className="quick-shortcuts-content"
                  align="start"
                  sideOffset={8}
                  aria-label={t("Shortcuts")}
                >
                  <h2>{t("Shortcuts")}</h2>
                  <p>
                    <kbd>{t("Space")}</kbd>
                    <span>{t("Flip card")}</span>
                  </p>
                  <p>
                    <span>
                      <kbd>←</kbd> <kbd>→</kbd>
                    </span>
                    <span>{t("Flashcard navigation")}</span>
                  </p>
                  <small>{t("Click or tap the card to flip")}</small>
                </PopoverContent>
              </Popover>
            </div>
            <span>{t("1–2 min")}</span>
          </header>
          <div className="quick-progress-row">
            <div
              className="quick-progress"
              role="progressbar"
              aria-label={t("Practice progress")}
              aria-valuemin={0}
              aria-valuemax={ex.total}
              aria-valuenow={ratedCount}
            >
              <motion.span initial={false} animate={{ scaleX: ratedCount / ex.total }}
                transition={reduceMotion ? transition.instant : spring.selection} />
            </div>
            <span aria-live="polite" aria-atomic="true">
              {t("Card {position} of {total}", {
                position: ex.position,
                total: ex.total,
              })}
            </span>
          </div>
          <article className={`quick-card ${revealed ? "is-revealed" : "is-front"}`}>
            <StudyCardStack cardKey={ex.id} reduceMotion={reduceMotion}>
            <FlipCard
              className="quick-reactbits-card"
              front={<div className="quick-flip-face"><div className="quick-flip-art"><p className="quick-definition" lang="en">{ex.definition}</p></div><div className="quick-flip-caption"><span>{t("Flip card")}</span></div></div>}
              back={<div className="quick-flip-face quick-flip-face-back"><div className="quick-flip-art"><h2 lang="en">{word?.word}</h2><p className="quick-definition" lang="en">{ex.definition}</p>{word?.examples[0] && <blockquote className="quick-example" lang="en">{word.examples[0]}</blockquote>}</div></div>}
              flipped={revealed}
              onFlipChange={setRevealed}
              flipOnClick
              draggable={false}
              tilt={false}
              glare={false}
              hoverScale={1}
              shadow={false}
              width={380}
              height={400}
              radius={20}
              background="#fffdf7"
              color="#1d3028"
              disabled={busy}
              ariaLabel={`${t("Flip card")}: ${revealed ? `${word?.word}. ` : ""}${ex.definition}`}
            />
            </StudyCardStack>
          </article>
          <nav
            className="quick-card-navigation"
            aria-label={t("Flashcard navigation")}
          >
            <button
              type="button"
              aria-label={t("Previous card")}
              aria-keyshortcuts="ArrowLeft"
              disabled={busy || cardIndex === 0}
              onClick={() => moveCard(-1)}
            >
              <ArrowLeft size={16} aria-hidden="true" />
              {t("Previous")}
            </button>
            <span className="quick-deck-count" aria-live="polite" aria-atomic="true">
              <strong>{String(ex.position).padStart(2, "0")}</strong>
              <span> / </span>
              {String(ex.total).padStart(2, "0")}
            </span>
            <button
              type="button"
              aria-label={t("Next card")}
              aria-keyshortcuts="ArrowRight"
              disabled={busy || cardIndex === ex.total - 1}
              onClick={() => moveCard(1)}
            >
              {t("Next")}
              <ArrowRight size={16} aria-hidden="true" />
            </button>
          </nav>
          <div className="quick-response">
            {savedRating ? (
              <p className="quick-note quick-saved-rating">
                <Check size={15} aria-hidden="true" />
                {t("Saved rating:")}{" "}
                {t(
                  savedRating.rating === "got"
                    ? "Got it"
                    : savedRating.rating === "forgot"
                      ? "Needs another look"
                      : "Skipped",
                )}
              </p>
            ) : revealed ? (
              <div className="quick-actions quick-rating-actions">
                <Button
                  secondary
                  className="quick-forgot"
                  disabled={busy || !ex.id}
                  onClick={() => rate("forgot")}
                >
                  <X size={19} aria-hidden="true" />
                  {t("Forgot")}
                </Button>
                <Button
                  secondary
                  className="quick-got"
                  disabled={busy || !ex.id}
                  onClick={() => rate("got")}
                >
                  <Check size={19} aria-hidden="true" />
                  {t("Got it")}
                </Button>
              </div>
            ) : (
              <div className="quick-actions quick-front-actions">
                <Button
                  disabled={busy}
                  onClick={() => setRevealed((value) => !value)}
                >
                  <Eye size={19} aria-hidden="true" />
                  {t("Reveal word")}
                </Button>
                <Button
                  secondary
                  disabled={busy || !ex.id}
                  onClick={() => rate("skip")}
                >
                  <SkipForward size={18} aria-hidden="true" />
                  {t("Skip")}
                </Button>
              </div>
            )}
          </div>
          <button type="button" className="text-button quick-pause" onClick={back}>
            {t("Pause review")}
          </button>
          {revealed && ex.definition && vietnameseDemoMeanings[ex.definition] && (
            <details className="suggestion-translation quick-card-translation">
              <summary>{t("Show Vietnamese meaning")}</summary>
              <p lang="vi">{vietnameseDemoMeanings[ex.definition]}</p>
            </details>
          )}
        </>
      )}
      {session?.complete && (
        <>
          <motion.header className="quick-recap-heading"
            initial={{ opacity: .85, y: reduceMotion ? 0 : 6 }} animate={{ opacity: 1, y: 0 }}
            transition={reduceMotion ? transition.fade : spring.entrance}>
            <span className="quick-recap-buddy" aria-hidden="true">
              <Image src="/images/sprout-buddy-review.svg" alt="" width={180} height={176} unoptimized />
              <motion.span className="quick-recap-leaves" initial={{ rotate: 0 }}
                animate={reduceMotion ? { rotate: 0 } : { rotate: [0, -4, 2, 0] }} transition={transition.reveal}>
                <Image src="/images/sprout-buddy-review-leaves.svg" alt="" width={180} height={176} unoptimized />
              </motion.span>
            </span>
            <div>
              <h1 ref={recapHeading} tabIndex={-1}><LucianLanguageText block value={t("Flashcard review complete")} order={2} /></h1>
              <p className="quick-description">{t("{count} cards in this review", { count: results.length })}</p>
            </div>
          </motion.header>
          <ul className="quick-results">
            {session.words
              .flatMap((w) => results.filter((r) => r.id === w.userWordId))
              .map((r) => (
                <li key={r.id}>
                  <span lang="en">{r.word}</span>
                  <span className={`quick-result-status is-${r.rating}`}>
                    {r.rating === "got" ? (
                      <Check size={14} aria-hidden="true" />
                    ) : r.rating === "skip" ? (
                      <SkipForward size={14} aria-hidden="true" />
                    ) : (
                      <RotateCcw size={14} aria-hidden="true" />
                    )}
                    {t(
                      r.rating === "got"
                        ? "Got it"
                        : r.rating === "skip"
                          ? "Skipped"
                          : "Needs another look",
                    )}
                  </span>
                </li>
              ))}
          </ul>
          {!!forgottenCount && (
            <div className="quick-handoff">
              <BookOpen size={22} aria-hidden="true" />
              <div>
                <strong>
                  {t(
                    forgottenCount === 1
                      ? "{count} word to revisit"
                      : "{count} words to revisit",
                    { count: forgottenCount },
                  )}
                </strong>
                <p>
                  {t(
                    "Recall them again and try using them in sentences.",
                  )}
                </p>
              </div>
            </div>
          )}
          <div className="quick-actions quick-recap-actions">
            {results.some((r) => r.rating === "forgot") && (
              <Button onClick={() => full(id)}>
                {t("Practice the words you missed")}
                <ArrowRight size={18} aria-hidden="true" />
              </Button>
            )}
            <Button
              secondary={results.some((r) => r.rating === "forgot")}
              disabled={busy}
              onClick={start}
            >
              <RotateCcw size={17} aria-hidden="true" />
              {t("Review again")}
            </Button>
          </div>
        </>
      )}
      {!ex && (
        <button className="text-button quick-back" onClick={back}>
          {t("Back to Practice")}
        </button>
      )}
    </section>
  );
}
