// Lucian UX/UI Prompt #399 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#399
"use client";

import { useLayoutEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { ArrowRight, Cloud } from "lucide-react";
import type { AppState, Stage } from "@/lib/domain/types";
import { wordCloud, type CloudWord } from "@/lib/domain/word-cloud";
import { useI18n } from "./language-provider";
import { Button, type Navigate } from "./shared";
import { LucianLanguageText } from "./lucian-267-language-switch";
import "@/app/lucian-399-word-cloud.css";

type Position = { x: number; y: number; k: number };
type Focus = { word: string } | { stage: Stage } | null;
const stages: Stage[] = ["new", "practicing", "active"];
const colors: Record<Stage, string> = { new: "#a78b35", practicing: "#4e9b7d", active: "#315b43" };

function placeWords(words: CloudWord[], period: number, width: number, height: number, family: string): Record<string, Position> {
  const canvas = document.createElement("canvas");
  const measure = canvas.getContext("2d");
  const scale = Math.min(width / 340, 1.45);
  const max = Math.max(3, ...words.map((item) => item.counts[period]));
  const box = [14 * scale, 55 * scale, width - 14 * scale, height - 85];
  const center = [width / 2, (box[1] + box[3]) / 2];
  const placed: [number, number, number, number][] = [];
  const result: Record<string, Position> = {};
  const ordered = words.filter((item) => item.counts[period] > 0)
    .sort((a, b) => b.counts[period] - a.counts[period] || a.word.localeCompare(b.word));

  for (const item of ordered) {
    const value = Math.max(1, item.counts[period]);
    const base = (11 + Math.pow(value / max, .85) * 22) * scale;
    for (let shrink = 0; shrink < 4 && !result[item.word]; shrink++) {
      const fontSize = base * (1 - shrink * .12);
      if (measure) measure.font = `850 ${fontSize}px ${family}`;
      const measuredWidth = (measure?.measureText(item.word).width ?? item.word.length * fontSize * .55) + 4;
      const measuredHeight = fontSize * 1.15;
      for (let t = 0; t < 140; t += .12) {
        const r = 3.2 * scale * t;
        const x = center[0] + r * Math.cos(t) * 1.45 - measuredWidth / 2;
        const y = center[1] + r * Math.sin(t) - measuredHeight / 2;
        if (x < box[0] || y < box[1] || x + measuredWidth > box[2] || y + measuredHeight > box[3]) continue;
        if (placed.some(([px, py, pw, ph]) => !(x + measuredWidth + 3 < px || px + pw + 3 < x || y + measuredHeight + 1 < py || py + ph + 1 < y))) continue;
        placed.push([x, y, measuredWidth, measuredHeight]);
        result[item.word] = { x, y, k: fontSize / 34 };
        break;
      }
    }
  }
  return result;
}

export function Insights({ state, navigate }: { state: AppState; navigate: Navigate }) {
  const { locale } = useI18n();
  const vi = locale === "vi";
  const [now] = useState(() => Date.now());
  const words = useMemo(() => state.cloudWords ?? wordCloud(state.words, now), [state.cloudWords, state.words, now]);
  const [period, setPeriod] = useState(0);
  const [focus, setFocus] = useState<Focus>(null);
  const [width, setWidth] = useState(340);
  const [height, setHeight] = useState(340);
  const [fontReady, setFontReady] = useState(false);
  const [positions, setPositions] = useState<Record<string, Position>>({});
  const [lastPositions, setLastPositions] = useState<Record<string, Position>>({});
  const root = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const node = root.current;
    if (!node) return;
    const measure = () => {
      const rect = node.getBoundingClientRect();
      setWidth(Math.round(rect.width));
      setHeight(Math.round(rect.height));
    };
    const observer = new ResizeObserver(measure);
    observer.observe(node);
    measure();
    let mounted = true;
    document.fonts?.ready.then(() => { if (mounted) setFontReady(true); });
    return () => { mounted = false; observer.disconnect(); };
  }, [words.length]);

  useLayoutEffect(() => {
    if (!root.current || !words.length || width < 100) return;
    const next = placeWords(words, period, width, height, getComputedStyle(root.current).fontFamily);
    setLastPositions((previous) => ({ ...previous, ...next }));
    setPositions(next);
  }, [words, period, width, height, fontReady]);

  const countFor = (item: CloudWord) => item.counts[period];
  const stageName = (stage: Stage) => vi
    ? ({ new: "Mới học", practicing: "Đang luyện", active: "Đã vận dụng" })[stage]
    : ({ new: "New", practicing: "Practicing", active: "Active" })[stage];
  const info = (() => {
    if (focus && "word" in focus) {
      const item = words.find((entry) => entry.word === focus.word);
      if (item) return vi ? `${item.word} · ${countFor(item)} lần sử dụng` : `${item.word} · ${countFor(item)} ${countFor(item) === 1 ? "use" : "uses"}`;
    }
    if (focus && "stage" in focus) {
      const count = words.filter((item) => item.stage === focus.stage).reduce((sum, item) => sum + countFor(item), 0);
      return vi ? `${stageName(focus.stage)} · ${count} lần sử dụng` : `${stageName(focus.stage)} · ${count} ${count === 1 ? "use" : "uses"}`;
    }
    return "";
  })();
  const visible = words.some((item) => countFor(item) > 0);

  return <div className="ow-wordcloud-page">
    <div className="page-heading">
      <div>
        <h1><LucianLanguageText value="WordCloud" order={2} /></h1>
        {words.length > 0 && <p><LucianLanguageText block value={vi
          ? "Từ càng lớn thì càng xuất hiện nhiều trong những đoạn bạn viết ở mục Từ vựng và trong các câu luyện tập đã lưu."
          : "Larger words appear more often in your saved vocabulary drafts and practice sentences."} order={3} /></p>}
      </div>
    </div>
    {!words.length ? <div className="ow-wordcloud-empty">
      <Cloud size={38} strokeWidth={1.4} aria-hidden="true" />
      <h2>{vi ? "Lưu một từ để bắt đầu theo dõi số lần dùng" : "Save a word to start tracking its use"}</h2>
      <Button onClick={() => navigate("discover")}>{vi ? "Thêm một từ" : "Add a word"}<ArrowRight size={18} aria-hidden="true" /></Button>
    </div> : <div className="ow-wordcloud-wrap">
      <div ref={root} className={`ux u399${focus ? " is-f" : ""}`}>
        <div className="u399-hd"><b>{vi ? "Vốn từ của bạn" : "Your vocabulary"}</b><div className="u399-sg" role="group" aria-label={vi ? "Khoảng thời gian" : "Time period"}>
          {(vi ? ["Tất cả", "30 ngày", "7 ngày"] : ["All", "30d", "7d"]).map((label, index) => <button key={index} type="button" className={`u399-mo${period === index ? " is-on" : ""}`} aria-label={index === 0 ? (vi ? "Toàn bộ thời gian" : "All time") : (vi ? `${index === 1 ? 30 : 7} ngày qua` : `Last ${index === 1 ? 30 : 7} days`)} aria-pressed={period === index} onClick={() => { setPeriod(index); setFocus(null); }}>{label}</button>)}
        </div></div>
        <div className="u399-ws">
          {words.map((item, index) => {
            const position = positions[item.word];
            const last = lastPositions[item.word];
            const shown = !!position && countFor(item) > 0;
            const fallback = last ?? { x: width / 2, y: height / 2, k: .2 };
            const transform = shown
              ? `translate(${position.x.toFixed(1)}px,${position.y.toFixed(1)}px) scale(${position.k.toFixed(3)})`
              : `translate(${(fallback.x + 20 * fallback.k).toFixed(1)}px,${(fallback.y + 10 * fallback.k).toFixed(1)}px) scale(${(fallback.k * .3).toFixed(3)})`;
            return <button key={item.word} type="button" lang="en" className={`u399-w${shown ? "" : " is-out"}${focus && item.stage === ("stage" in focus ? focus.stage : words.find((entry) => entry.word === focus.word)?.stage) ? " is-hl" : ""}`} style={{ "--c": colors[item.stage], transform, transitionDelay: `${(index % 7) * .025}s` } as CSSProperties} tabIndex={shown ? 0 : -1} aria-label={vi ? `${item.word}, ${countFor(item)} lần sử dụng` : `${item.word}, ${countFor(item)} ${countFor(item) === 1 ? "use" : "uses"}`} onPointerEnter={() => setFocus({ word: item.word })} onPointerLeave={() => setFocus(null)} onFocus={() => setFocus({ word: item.word })} onBlur={() => setFocus(null)} onClick={() => setFocus({ word: item.word })}>{item.word}</button>;
          })}
        </div>
        {!visible && <p className="u399-empty-period">{period === 0
          ? vi ? "Chưa ghi nhận lần dùng nào. Thử gửi vài câu có dùng từ đã lưu để nhận gợi ý từ, hoặc dùng từ đó khi luyện đặt câu."
            : "No recorded uses yet. Submit a few sentences with a saved word for vocabulary suggestions, or use it in a practice sentence."
          : vi ? `Chưa ghi nhận lần dùng nào trong ${period === 1 ? 30 : 7} ngày qua.`
            : `No uses recorded in the last ${period === 1 ? 30 : 7} days.`}</p>}
        <div className="u399-ft"><span className="u399-in" aria-live="polite">{info}</span><div className="u399-lg">
          {stages.map((stage) => <button key={stage} type="button" className={focus && "stage" in focus && focus.stage === stage ? "g-hov" : ""} onPointerEnter={() => setFocus({ stage })} onPointerLeave={() => setFocus(null)} onFocus={() => setFocus({ stage })} onBlur={() => setFocus(null)} onClick={() => setFocus({ stage })}><i style={{ background: colors[stage] }} aria-hidden="true" />{stageName(stage)}</button>)}
        </div></div>
      </div>
    </div>}
  </div>;
}
