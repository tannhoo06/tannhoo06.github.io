"use client";
import Image from "next/image";
import { useI18n } from "./language-provider";
import { LucianLanguageText } from "./lucian-267-language-switch";
import { WordBoardControls } from "./lucian-wordboard-controls";
import { PronunciationButton } from "./pronunciation-button";
import { useConfirmAction } from "./lucian-269-confirmation";
import { CollectionEmptyState } from "./kokonutui/collection-empty-state";
import { useEffect, useRef, useState, type RefObject } from "react";
import {
  Plus,
  Lightbulb,
  Search,
  ArrowRight,
  Check,
  Clock3,
  X,
} from "lucide-react";
import { Dialog as Modal } from "radix-ui";
import { motion } from "motion/react";
import { useMotionTokens, useShouldReduceMotion } from "@animate-ui/react/utils/motion";
import type { AppState, Stage, UserWord } from "@/lib/domain/types";
import { evidence } from "@/lib/domain/learning";
import { Button, FriendlyDate, stageLabels } from "./shared";
export function Board({
  state,
  select,
  addWord,
}: {
  state: AppState;
  select: (word: UserWord) => void;
  addWord: () => void;
}) {
  const { t, locale } = useI18n();
  const vi = locale === "vi";
  const [now] = useState(() => Date.now());
  const [query, setQuery] = useState("");
  const [dueOnly, setDueOnly] = useState(false);
  const [sort, setSort] = useState("recent");
  const [stageFilter, setStageFilter] = useState<Stage | "all">(() =>
    state.words.some((word) => word.stage === "new") ? "new" : "all",
  );
  const [filtersReady, setFiltersReady] = useState(false);
  useEffect(() => {
    queueMicrotask(() => {
      const params = new URLSearchParams(window.location.search);
      setQuery(params.get("q") ?? "");
      setDueOnly(params.get("due") === "1");
      const stage = params.get("stage");
      if (
        stage === "new" ||
        stage === "practicing" ||
        stage === "active" ||
        stage === "all"
      )
        setStageFilter(stage);
      setSort(
        params.get("sort") === "alphabetical" ? "alphabetical" : "recent",
      );
      setFiltersReady(true);
    });
  }, []);
  useEffect(() => {
    if (!filtersReady) return;
    const url = new URL(window.location.href);
    for (const [key, value] of Object.entries({
      q: query,
      due: dueOnly ? "1" : "",
      stage: stageFilter,
      sort: sort === "recent" ? "" : sort,
    })) {
      if (value) url.searchParams.set(key, value);
      else url.searchParams.delete(key);
    }
    window.history.replaceState({}, "", url);
  }, [query, dueOnly, stageFilter, sort, filtersReady]);
  const visible = state.words
    .filter(
      (w) =>
        (stageFilter === "all" || w.stage === stageFilter) &&
        `${w.word} ${w.definition}`
          .toLowerCase()
          .includes(query.toLowerCase()) &&
        (!dueOnly || (!!w.introducedAt && Date.parse(w.nextReviewAt) <= now)),
    )
    .sort((a, b) =>
      sort === "alphabetical"
        ? a.word.localeCompare(b.word)
        : b.addedAt.localeCompare(a.addedAt),
    );
  return (
    <div className="board-v2">
      <header className="ow-page-intro board-intro">
        <div>
          <h1><LucianLanguageText value={t("WordBoard")} order={2} /></h1>
        </div>
        {!!state.words.length && <Button className="ow-action-primary" onClick={addWord}>
          <Plus size={18} aria-hidden="true" />{vi ? "Thêm một từ" : "Add a word"}
        </Button>}
      </header>
      {!state.words.length ? (
        <CollectionEmptyState variant="collection" icon={Plus} title={t("No words yet")}
          illustration={<Image src="/images/sprout-wordboard-empty.svg" width={216} height={190} alt="" unoptimized />}
          description={vi ? "Khi có nghĩa, các từ bạn lưu ở đây sẽ xuất hiện trong phần luyện tập." : "Words you save here are ready to review once their meanings are available."}>
          <Button className="ow-action-primary" onClick={addWord}>
            {vi ? "Thêm một từ" : "Add a word"}
            <ArrowRight size={18} aria-hidden="true" />
          </Button>
        </CollectionEmptyState>
      ) : (
        <>
          <WordBoardControls words={state.words} stage={stageFilter} onStage={setStageFilter} query={query} onQuery={setQuery} sort={sort} onSort={setSort} />
          {dueOnly && (
            <button className="text-button" onClick={() => setDueOnly(false)}>
              {t("Clear due filter")}
              <X size={15} />
            </button>
          )}
          {!visible.length ? (
            <CollectionEmptyState variant="search" icon={Search} title={stageFilter === "all" ? t("No matching words") : ({
              new: vi ? "Không có từ mới nào khớp với bộ lọc này" : "No new words match these filters",
              practicing: vi ? "Không có từ đang luyện nào khớp với bộ lọc này" : "No words you’re practicing match these filters",
              active: vi ? "Không có từ đã vận dụng nào khớp với bộ lọc này" : "No active words match these filters",
            })[stageFilter]}
              description={t("Try another search or clear your filters.")}>
              <Button
                secondary
                onClick={() => {
                  setQuery("");
                  setDueOnly(false);
                  setStageFilter("all");
                }}
              >
                {t("Clear filters")}
              </Button>
            </CollectionEmptyState>
          ) : (
            <div className="word-grid-v2">
              {visible.map((word) => (
                <div className="word-card-shell" key={word.userWordId}>
                  <button
                    className="word-card-v2 u328-word-card ux"
                    onClick={() => select(word)}
                  >
                    <div className="u328-word-hero">
                      <div className="u328-word-heading">
                        <h2 lang="en">{word.word}</h2>
                        <span className="part-of-speech" lang="en">{word.partOfSpeech}</span>
                      </div>
                      <ArrowRight className="u328-word-arrow" size={21} aria-hidden="true" />
                    </div>
                    <div className="u328-word-body">
                      <p lang={word.definition ? "en" : undefined}>{word.definition || (locale === "vi" ? "Đang chuẩn bị định nghĩa…" : "Preparing definition…")}</p>
                      <div className="word-card-meta">
                        <span
                          className={
                            word.introducedAt &&
                            Date.parse(word.nextReviewAt) <= now
                              ? "is-due"
                              : ""
                          }
                        >
                          <Clock3 size={18} aria-hidden="true" />
                          {word.introducedAt ? (
                            <FriendlyDate value={word.nextReviewAt} />
                          ) : (
                            t("In your queue")
                          )}
                        </span>
                        <span className={`stage-badge ${word.stage}`}>
                          {t(stageLabels[word.stage])}
                        </span>
                      </div>
                      {!word.demo && <small className="word-card-origin">{word.source === "Manual" ? (locale === "vi" ? "Tự thêm" : "Added by you") : word.source === "Concept" ? (locale === "vi" ? "Từ ý tưởng" : "From an idea") : word.source.startsWith("Writing suggestion:") ? (locale === "vi" ? "Qua bài viết" : "From writing") : word.source === "Your patterns" ? (locale === "vi" ? "Từ thói quen viết" : "From patterns") : word.source} · {word.addedAt.slice(0, 10)}</small>}
                    </div>
                  </button>
                  <PronunciationButton word={word.word} compact />
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
export function WordDetail({
  word,
  origin,
  close,
  practice,
  busy,
  restoreFocus,
  remove,
}: {
  word: UserWord | null;
  origin: RefObject<HTMLElement | null>;
  close: () => void;
  practice: (id: string) => void;
  busy: boolean;
  restoreFocus: () => void;
  remove: (id: string) => Promise<void>;
}) {
  const { t, dateLocale, locale } = useI18n();
  const confirmAction = useConfirmAction();
  const { spring } = useMotionTokens();
  const reduceMotion = useShouldReduceMotion();
  const [removing, setRemoving] = useState(false);
  const [removeError, setRemoveError] = useState("");
  const contentRef = useRef<HTMLDivElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const closing = useRef(false);
  useEffect(() => {
    const sourceCard = origin.current;
    if (!word || !sourceCard || !contentRef.current) return;
    const content = contentRef.current;
    sourceCard.classList.add("is-expanded");
    const source = sourceCard.getBoundingClientRect();
    const target = content.getBoundingClientRect();
    if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches && source.width && target.width) {
      content.animate([
        { transform: `translate(${source.left - target.left}px, ${source.top - target.top}px) scale(${source.width / target.width}, ${source.height / target.height})`, borderRadius: "20px", opacity: .8 },
        { transform: "none", borderRadius: "0px", opacity: 1 },
      ], { duration: 560, easing: "cubic-bezier(.3,1.05,.35,1)" });
    }
    return () => sourceCard.classList.remove("is-expanded");
  }, [word, origin]);
  const requestClose = () => {
    if (closing.current) return;
    if (!contentRef.current || window.matchMedia("(prefers-reduced-motion: reduce)").matches) { close(); return; }
    closing.current = true;
    const content = contentRef.current;
    overlayRef.current?.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 260, easing: "ease-in", fill: "forwards" });
    content.animate([
      { transform: "translateX(0%)" },
      { transform: "translateX(100%)" },
    ], { duration: 260, easing: "cubic-bezier(.4,0,1,1)", fill: "forwards" }).finished.then(close).catch(close);
  };
  const e = word ? evidence(word.attempts) : null;
  return (
    <Modal.Root open={!!word} onOpenChange={(open) => !open && requestClose()}>
      <Modal.Portal>
        <Modal.Overlay ref={overlayRef} className="modal-overlay" />
        <Modal.Content
          ref={contentRef}
          className="word-detail word-detail-v2 u328-detail"
          onCloseAutoFocus={(event) => {
            event.preventDefault();
            restoreFocus();
          }}
        >
          {word && e && (
            <>
              <div className="detail-topline">
                <span className={`stage-label ${word.stage}`}>
                  <span className={`stage-dot ${word.stage}`} />
                  {t(stageLabels[word.stage])}
                </span>
                <Modal.Close
                  className="icon-button"
                  aria-label={t("Close word details")}
                >
                  <X size={20} />
                </Modal.Close>
              </div>
              <div className="detail-word-heading">
                <PronunciationButton word={word.word} />
                <Modal.Title asChild><motion.h2 className="detail-title" lang="en" initial={{ opacity: 0, y: reduceMotion ? 0 : 9 }} animate={{ opacity: 1, y: 0 }} transition={spring.selection}>{word.word}</motion.h2></Modal.Title>
              </div>
              <span className="part-of-speech">{word.partOfSpeech}</span>
              <Modal.Description className="detail-definition" lang={word.definition ? "en" : undefined}>
                {word.definition || (locale === "vi" ? "Đang chuẩn bị định nghĩa…" : "Preparing definition…")}
              </Modal.Description>
              <section className="detail-section">
                <h3>{t("From your writing")}</h3>
                <p lang="en">
                  {word.sourceText ||
                    t("No source passage was saved with this word.")}
                </p>
              </section>
              <section className="detail-section">
                <h3>{locale === "vi" ? "Những từ thường dùng cùng từ này" : "Words often used with this one"}</h3>
                <div className="collocations">
                  {word.collocations.map((c) => (
                    <span key={c} lang="en">
                      {c}
                    </span>
                  ))}
                </div>
              </section>
              <section className="detail-section">
                <h3>{t("Example sentence")}</h3>
                <blockquote className="detail-example" lang="en">
                  {word.examples[0] ||
                    t("No example sentence was saved for this word.")}
                </blockquote>
              </section>
              <section className="detail-guidance">
                <h3>
                  <Lightbulb size={18} aria-hidden="true" />
                  {t("What to work on next")}
                </h3>
                <div>
                  <Clock3 size={24} aria-hidden="true" />
                  <div>
                    <strong>
                      {t(
                        e.successes >= 2 && e.precise < 2
                          ? "You recall this reliably; now focus on using it naturally."
                          : "Use this word in more contexts.",
                      )}
                    </strong>
                    <p>
                      {t("Try writing it in a different situation or topic.")}
                    </p>
                  </div>
                </div>
              </section>
              <div className="detail-next-review">
                <Clock3 size={23} aria-hidden="true" />
                <div>
                  <span>{t("Next review")}</span>
                  <strong>
                    {word.introducedAt ? (
                      <FriendlyDate value={word.nextReviewAt} />
                    ) : (
                      t("Waiting in your introduction queue")
                    )}
                  </strong>
                </div>
              </div>
              <div className="detail-footer">
                <Button
                  className="ow-action-primary"
                  onClick={() => practice(word.userWordId)}
                  disabled={busy || !word.definition.trim()}
                >
                  {t("Practice this word")}
                  <ArrowRight size={18} aria-hidden="true" />
                </Button>
              </div>
              {removeError && <p role="alert">{t(removeError)}</p>}
              <button
                type="button"
                className="text-button remove-word-button"
                disabled={removing}
                onClick={async () => {
                  if (!(await confirmAction({
                    title: t("Remove this word?"),
                    message: t("Remove “{word}” from WordBoard? Your writing and practice history will stay saved.", { word: word.word }),
                    confirmLabel: t("Remove from WordBoard"),
                    nameToConfirm: word.word,
                  })))
                    return;
                  setRemoving(true);
                  setRemoveError("");
                  try {
                    await remove(word.userWordId);
                  } catch (error) {
                    setRemoveError((error as Error).message);
                  } finally {
                    setRemoving(false);
                  }
                }}
              >
                {removing ? t("Removing…") : t("Remove from WordBoard")}
              </button>
              <details className="detail-history">
                <summary>{t("Practice history")}</summary>
                {word.attempts.length ? (
                  <div className="history-list">
                    {word.attempts
                      .slice(-8)
                      .reverse()
                      .map((a) => (
                        <div key={a.id}>
                          <span
                            className={
                              a.retrieved ? "history-check" : "history-circle"
                            }
                          >
                            {a.retrieved ? (
                              <Check size={14} />
                            ) : (
                              <Clock3 size={14} />
                            )}
                          </span>
                          <div>
                            <strong>
                              {t(
                                a.hint === "revealed"
                                  ? "Practiced with the word revealed"
                                  : a.retrieved
                                    ? "Brought it to mind"
                                    : "A word to revisit",
                              )}
                            </strong>
                            <small>
                              {new Date(a.at).toLocaleDateString(dateLocale, {
                                month: "short",
                                day: "numeric",
                              })}{" "}
                              · {a.context}
                            </small>
                            {a.answer && <p lang="en">{a.answer}</p>}
                            <p>{t(a.feedback)}</p>
                          </div>
                        </div>
                      ))}
                  </div>
                ) : (
                  <p>{t("Your first retrieval is the beginning.")}</p>
                )}
              </details>
            </>
          )}
        </Modal.Content>
      </Modal.Portal>
    </Modal.Root>
  );
}
