// Lucian UX/UI Prompt #235 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#235
"use client";

import { useEffect, useRef } from "react";
import { Button as AnimateButton } from "@animate-ui/react/primitives/buttons/button";
import { Shine } from "@animate-ui/react/primitives/effects/shine";
import { useI18n } from "./language-provider";

function sentences(text: string) {
  return text.match(/[^.!?]+[.!?]*\s*/g) ?? [text];
}

export function WritingScan({
  text,
  onTextChange,
  busy,
  ready,
  scanning,
  folded,
  storageError,
  draftSaved,
}: {
  text: string;
  onTextChange: (text: string) => void;
  busy: boolean;
  ready: boolean;
  scanning: boolean;
  folded: boolean;
  storageError: boolean;
  draftSaved: boolean;
}) {
  const { t } = useI18n();
  const root = useRef<HTMLDivElement>(null);
  const status = storageError ? t("Draft not saved") : draftSaved ? t("Draft saved in this tab") : null;

  useEffect(() => {
    if (!scanning) return;
    const element = root.current;
    if (!element) return;
    const copy = element.querySelector<HTMLElement>(".u235-scan-copy");
    const sweep = element.querySelector<HTMLElement>(".u235-sw");
    if (!copy || !sweep) return;
    const spans = Array.from(copy.querySelectorAll<HTMLElement>("span"));
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      spans.forEach((span) => span.classList.add("is-hl"));
      return;
    }
    const height = copy.offsetHeight;
    const duration = 1700;
    const start = performance.now();
    let frame = 0;
    sweep.style.opacity = "1";
    function animate(now: number) {
      const progress = Math.min(1, (now - start) / duration);
      sweep!.style.transform = `translateY(${(progress * (height + 46)).toFixed(1)}px)`;
      spans.forEach((span) => {
        if (span.offsetTop + 8 < progress * height) span.classList.add("is-hl");
      });
      if (progress < 1) frame = requestAnimationFrame(animate);
      else sweep!.style.opacity = "0";
    }
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [scanning, text]);

  return (
    <>
      <div ref={root} className={`ux u235 ownword-writing-scan${scanning ? " is-reading" : ""}${folded ? " is-sum" : ""}`}>
        <div className="u235-hd">
          <div className="u235-title">
            <label htmlFor="writing-text">{t("Your English draft")}</label>
            <small>
              <span id="writing-help">{t("Start with two or three sentences in English. Ownword suggests words for phrases in your draft.")}</span>
              <span className="u235-rt">{t("{count} / 5,000 characters", { count: text.length.toLocaleString() })}</span>
            </small>
          </div>
          <div className="writing-editor-footer u235-actions">
            <Shine asChild enableOnHover color="#fff" opacity={0.28} duration={700}>
              <AnimateButton type="submit" className="u235-go" disabled={busy || !ready || text.trim().length < 10}>
                <svg viewBox="0 0 12 12" aria-hidden="true"><path d="M6 1l1.2 3.3L10.5 5.5 7.2 6.7 6 10 4.8 6.7 1.5 5.5l3.3-1.2z" fill="currentColor" /></svg>
                {busy ? t("Reviewing your writing…") : t("Get word suggestions")}
              </AnimateButton>
            </Shine>
          </div>
        </div>
        <div className="u235-bx">
          <div className="u235-tx">
            <textarea
              lang="en"
              id="writing-text"
              className="writing-textarea"
              value={text}
              onChange={(event) => onTextChange(event.target.value)}
              maxLength={5000}
              disabled={busy || !ready}
              aria-describedby={status ? "writing-help draft-status" : "writing-help"}
              placeholder={t("For example, describe something that happened today.")}
            />
            {scanning && (
              <div className="u235-scan-copy" aria-hidden="true" lang="en">
                <div className="u235-sw" />
                {sentences(text).map((sentence, index) => <span key={index}>{sentence}</span>)}
              </div>
            )}
          </div>
        </div>
      </div>
      {status && <div className="writing-field-meta" id="draft-status">{status}</div>}
    </>
  );
}
