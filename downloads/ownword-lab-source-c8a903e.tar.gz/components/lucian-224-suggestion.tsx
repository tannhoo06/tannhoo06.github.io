// Lucian UX/UI Prompt #224 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#224
"use client";

import { useRef, useState } from "react";

const OXFORD = "https://www.oxfordlearnersdictionaries.com";

/** Oxford uses numbered entry slugs for some homographs. */
export function oxfordEntryUrl(word: string) {
  const query = word.trim();
  const slug = query.toLowerCase().replace(/\s+/g, "-");
  if (!/^[a-z]+(?:-[a-z]+)*$/.test(slug))
    return `${OXFORD}/search/english/?q=${encodeURIComponent(query)}`;
  return `${OXFORD}/definition/english/${slug === "miniature" ? "miniature_1" : slug}`;
}

export function TraceableSuggestion({
  phrase,
  word,
  definition,
  reason,
  locale,
}: {
  phrase: string;
  word: string;
  definition: string;
  reason: string;
  locale: "en" | "vi";
}) {
  const root = useRef<HTMLElement>(null);
  const [active, setActive] = useState<"citation" | "source" | null>(null);
  const [preview, setPreview] = useState({ left: 150, top: 75, below: true });
  const copy = (vi: string, en: string) => (locale === "vi" ? vi : en);
  const href = oxfordEntryUrl(word);

  function cite(button: HTMLElement) {
    const rr = root.current?.getBoundingClientRect();
    if (!rr) return;
    const br = button.getBoundingClientRect();
    const top = br.top - rr.top;
    setPreview({
      left: Math.max(112, Math.min(rr.width - 112, br.left + br.width / 2 - rr.left)),
      top,
      below: top < 125,
    });
    setActive("citation");
  }

  return (
    <aside ref={root} className="ux u224 ownword-trace" aria-label={copy("Gợi ý từ trong bài viết", "Suggestion in your writing")}>
      <p className="u224-k">{copy("Gợi ý trong câu", "Suggestion in context")}</p>
      <p className="u224-an" lang="en">
        <span className={active ? "is-hl" : ""}>
          <span className="u224-original">{phrase}</span>
          <span className="u224-arrow" aria-hidden="true">→</span>
          <strong>{word}</strong>
        </span>{" "}
        <button
          type="button"
          className={`u224-ct${active === "citation" ? " is-on" : ""}`}
          aria-label={copy(`Xem thông tin cho từ ${word}`, `View details for ${word}`)}
          aria-describedby="ownword-citation-preview"
          onPointerEnter={(event) => cite(event.currentTarget)}
          onFocus={(event) => cite(event.currentTarget)}
          onPointerLeave={() => setActive(null)}
          onBlur={() => setActive(null)}
          onClick={(event) => cite(event.currentTarget)}
        >1</button>
      </p>
      <p className="u224-reason" lang="en">{reason}</p>
      <div
        id="ownword-citation-preview"
        role="tooltip"
        aria-hidden={active !== "citation"}
        className={`u224-pv${active === "citation" ? " is-on" : ""}${preview.below ? " is-below" : ""}`}
        style={{ left: preview.left, top: preview.top }}
      >
        <header><i>1</i><span>{copy("Gợi ý của Ownword", "Ownword suggestion")}</span></header>
        <b lang="en">{word}</b>
        <p lang="en"><mark>{phrase}</mark> → {word}. {definition}</p>
      </div>
      <div className="u224-sr">
        <small>{copy("Tra cứu từ", "Word lookup")}</small>
        <a
          className={`u224-sc${active ? " is-on" : ""}`}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={copy(`Tra ${word} trong Oxford Learner’s Dictionaries (mở thẻ mới)`, `Look up ${word} in Oxford Learner’s Dictionaries (opens in a new tab)`)}
          onPointerEnter={() => setActive("source")}
          onFocus={() => setActive("source")}
          onPointerLeave={() => setActive(null)}
          onBlur={() => setActive(null)}
        >
          <header><i>O</i><em>1</em></header>
          <b lang="en">{word}</b>
          <small>Oxford Learner’s Dictionaries ↗</small>
        </a>
      </div>
    </aside>
  );
}
