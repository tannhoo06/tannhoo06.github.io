// Lucian UX/UI Prompt #026 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#026
"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import type { HintLevel } from "@/lib/domain/types";
import "@/app/word-recall-input.css";

export function WordRecallInput({
  id,
  word,
  value,
  onChange,
  inputRef,
  hint,
  hintText,
  checking,
  verified,
  incorrect,
  disabled,
  label,
  cursorRequest,
}: {
  id: string;
  word: string;
  value: string;
  onChange: (value: string) => void;
  inputRef: (element: HTMLInputElement | null) => void;
  hint: HintLevel;
  hintText?: string;
  checking: boolean;
  verified: boolean;
  incorrect: boolean;
  disabled: boolean;
  label: string;
  cursorRequest?: { id: number; position: number } | null;
}) {
  const [focused, setFocused] = useState(false);
  const [caret, setCaret] = useState(0);
  const realInput = useRef<HTMLInputElement>(null);
  const root = useRef<HTMLDivElement>(null);
  const overflowTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const length = Math.max(word.length, 1);
  function flashOverLimit() {
    const element = root.current;
    if (!element) return;
    element.classList.remove("is-overflow");
    void element.offsetWidth;
    element.classList.add("is-overflow");
    if (overflowTimer.current) clearTimeout(overflowTimer.current);
    overflowTimer.current = setTimeout(() => element.classList.remove("is-overflow"), 300);
  }
  useEffect(() => () => {
    if (overflowTimer.current) clearTimeout(overflowTimer.current);
  }, []);
  useEffect(() => {
    if (!cursorRequest) return;
    const frame = requestAnimationFrame(() => {
      const field = realInput.current;
      if (!field) return;
      const position = Math.min(cursorRequest.position, length);
      field.focus();
      field.setSelectionRange(position, position);
      setCaret(position);
    });
    return () => cancelAnimationFrame(frame);
  }, [cursorRequest, length]);
  const hintId = `${id}-hint`;
  // A retry clears the controlled value from the parent. Keep the visual caret
  // in sync instead of leaving it on the last slot from the failed attempt.
  const activeCaret = value ? Math.min(caret, length - 1) : 0;

  return (
    <div
      ref={root}
      className={`ux u026 ${checking ? "is-check" : ""} ${verified ? "is-ok" : ""} ${incorrect ? "is-bad" : ""}`}
      style={{ "--u026-count": length } as CSSProperties}
    >
      <div className="u026-field">
        <div
          className="u026-row"
          onClick={() => realInput.current?.focus()}
        >
          {Array.from({ length }, (_, index) => {
            const character = value[index] ?? "";
            const separator = word[index] === " " && !character;
            return separator ? (
              <i className="sep" aria-hidden="true" key={index} />
            ) : (
              <span
                aria-hidden="true"
                key={index}
                className={`u026-c ${focused && index === activeCaret ? "cur" : ""} ${character ? "has" : ""}`}
                style={{ "--i": Math.min(index, 5) } as CSSProperties}
              >
                {character ? (
                  <span key={`${index}:${character}`}>{character}</span>
                ) : null}
              </span>
            );
          })}
        </div>
        <input
          id={id}
          ref={(element) => {
            realInput.current = element;
            inputRef(element);
          }}
          className="u026-real"
          type="text"
          lang="en"
          autoComplete="off"
          autoCapitalize="none"
          spellCheck={false}
          maxLength={length}
          value={value}
          onBeforeInput={(event) => {
            const field = event.currentTarget;
            const inserted = (event.nativeEvent as InputEvent).data ?? "";
            const selected = (field.selectionEnd ?? value.length) - (field.selectionStart ?? value.length);
            if (inserted && value.length - selected + inserted.length > length) flashOverLimit();
          }}
          onPaste={(event) => {
            const field = event.currentTarget;
            const selected = (field.selectionEnd ?? value.length) - (field.selectionStart ?? value.length);
            if (value.length - selected + event.clipboardData.getData("text").length > length) flashOverLimit();
          }}
          onChange={(event) => {
            if (event.target.value.length > length) flashOverLimit();
            const next = event.target.value.slice(0, length);
            onChange(next);
            setCaret(Math.min(event.target.selectionStart ?? next.length, length));
          }}
          onSelect={(event) =>
            setCaret(event.currentTarget.selectionStart ?? value.length)
          }
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          aria-label={label}
          aria-describedby={hint !== "none" ? hintId : undefined}
          aria-invalid={incorrect || undefined}
          disabled={disabled}
        />
        {hint !== "none" && hintText && (
          <p
            id={hintId}
            className="u026-hint sr-only"
          >
            {hintText}
          </p>
        )}
      </div>
    </div>
  );
}
