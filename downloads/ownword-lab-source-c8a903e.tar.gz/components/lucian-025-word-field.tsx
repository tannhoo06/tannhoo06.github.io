// Lucian UX/UI Prompt #025 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#025
"use client";

import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from "react";
import "@/app/lucian-025-word-field.css";

export function LucianWordField({ value, onChange, onBlur, error, vi }: {
  value: string;
  onChange: (value: string) => void;
  onBlur: () => void;
  error: string;
  vi: boolean;
}) {
  const [focused, setFocused] = useState(false);
  const [labelWidth, setLabelWidth] = useState(0);
  const [shake, setShake] = useState(false);
  const labelRef = useRef<HTMLLabelElement>(null);
  const up = focused || value.length > 0;

  useLayoutEffect(() => {
    setLabelWidth(labelRef.current?.offsetWidth ?? 0);
  }, [vi]);
  useEffect(() => {
    if (!error) return;
    const start = requestAnimationFrame(() => setShake(true));
    const stop = setTimeout(() => setShake(false), 420);
    return () => { cancelAnimationFrame(start); clearTimeout(stop); };
  }, [error]);

  return (
    <div className={`u025 u025-f${up ? " is-up" : ""}${focused ? " is-focus" : ""}${error ? " is-bad" : ""}${shake ? " is-shake" : ""}`}>
      <div className="u025-box">
        <input
          id="discover-word"
          className="u025-in"
          type="text"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => { setFocused(false); onBlur(); }}
          maxLength={45}
          autoComplete="off"
          autoCapitalize="none"
          autoCorrect="off"
          spellCheck
          lang="en"
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={error ? "discover-word-error" : undefined}
        />
        <span className="u025-line" aria-hidden="true" style={{ "--gap": up ? `${labelWidth * .8 + 2}px` : "0px" } as CSSProperties}>
          <i className="l" /><i className="g" /><i className="r" />
        </span>
        <label ref={labelRef} className="u025-lab" htmlFor="discover-word">
          {vi ? "Từ hoặc cụm từ tiếng Anh" : "English word or short phrase"}
        </label>
        <span className="discover-word-count" aria-hidden="true">{value.length}/45</span>
      </div>
      <div className="u025-help" aria-live="polite"><span id="discover-word-error">{error}</span></div>
    </div>
  );
}
