"use client";

import { useEffect, type RefObject } from "react";

/** Native scrolling only: observe direction; never consume input or set scroll position. */
export function useLandingScroll(root: RefObject<HTMLDivElement | null>) {
  useEffect(() => {
    const page = root.current;
    const scroller = document.scrollingElement;
    if (!page || !(scroller instanceof HTMLElement)) return;
    const sections = [
      ...page.querySelectorAll<HTMLElement>(".ow-intro, .ow-journey"),
    ];
    const desktop = matchMedia("(min-width: 900px) and (pointer: fine)");
    let frame = 0;
    let disposed = false;
    let previousY = window.scrollY;
    scroller.classList.add("ow-page-scroll");
    scroller.dataset.owDirection = previousY > 1 ? "up" : "down";
    const measure = () => {
      frame = 0;
      if (disposed) return;
      const viewport = Math.min(
        innerHeight,
        visualViewport?.height ?? innerHeight,
      );
      const textSize = parseFloat(
        getComputedStyle(document.documentElement).fontSize,
      );
      const fits =
        desktop.matches &&
        textSize <= 18 &&
        sections.every(
          (section) =>
            Math.max(
              section.scrollHeight,
              section.getBoundingClientRect().height,
            ) <=
            viewport + 1,
        );
      scroller.classList.toggle("ow-page-snap", fits);
    };
    const schedule = () => {
      if (!disposed && !frame) frame = requestAnimationFrame(measure);
    };
    // A departed section must not remain a nearby snap destination: that causes
    // small wheel/trackpad movements to bounce back. Only the approached section
    // is eligible. CSS proximity still decides whether and where to settle.
    const direction = () => {
      const y = window.scrollY;
      const lastStart = sections[1]?.offsetTop ?? Infinity;
      // Beyond the two opening sections, all public content scrolls normally.
      scroller.classList.toggle("ow-reading-public", y > lastStart + 2);
      if (y <= 1) scroller.dataset.owDirection = "down";
      else if (y >= lastStart - 1) scroller.dataset.owDirection = "up";
      else if (Math.abs(y - previousY) > 1)
        scroller.dataset.owDirection = y > previousY ? "down" : "up";
      previousY = y;
    };
    const observer = new ResizeObserver(schedule);
    sections.forEach((section) => observer.observe(section));
    const textObserver = new MutationObserver(schedule);
    textObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["style", "lang"],
    });
    window.addEventListener("scroll", direction, { passive: true });
    window.addEventListener("resize", schedule);
    visualViewport?.addEventListener("resize", schedule);
    desktop.addEventListener("change", schedule);
    document.fonts.ready.then(schedule);
    schedule();
    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      textObserver.disconnect();
      window.removeEventListener("scroll", direction);
      window.removeEventListener("resize", schedule);
      visualViewport?.removeEventListener("resize", schedule);
      desktop.removeEventListener("change", schedule);
      scroller.classList.remove(
        "ow-page-scroll",
        "ow-page-snap",
        "ow-reading-public",
      );
      delete scroller.dataset.owDirection;
    };
  }, [root]);
}
