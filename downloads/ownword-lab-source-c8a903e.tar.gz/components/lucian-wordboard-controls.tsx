// Lucian UX/UI Prompt #039 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#039
// Lucian UX/UI Prompt #027 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#027
// Lucian UX/UI Prompt #031 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#031
"use client";

import { useEffect, useId, useRef, useState, type CSSProperties } from "react";
import { ArrowDownWideNarrow, Check, ChevronDown, Search, X } from "lucide-react";
import type { Stage, UserWord } from "@/lib/domain/types";
import { stageLabels } from "./shared";
import { useI18n } from "./language-provider";
import "@/app/lucian-wordboard.css";

type Filter = Stage | "all";
const stages: Filter[] = ["new", "practicing", "active", "all"];

export function WordBoardControls({ words, stage, onStage, query, onQuery, sort, onSort }: {
  words: UserWord[];
  stage: Filter;
  onStage: (stage: Filter) => void;
  query: string;
  onQuery: (query: string) => void;
  sort: string;
  onSort: (sort: string) => void;
}) {
  const { t, locale } = useI18n();
  const tabs = useRef<HTMLDivElement>(null);
  const searchRoot = useRef<HTMLDivElement>(null);
  const searchInput = useRef<HTMLInputElement>(null);
  const sortRoot = useRef<HTMLDivElement>(null);
  const sortButton = useRef<HTMLButtonElement>(null);
  const sortList = useRef<HTMLUListElement>(null);
  const [pill, setPill] = useState({ x: 0, width: 0 });
  const [searchOpen, setSearchOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);
  const [sortActive, setSortActive] = useState(0);
  const searchId = useId();
  const sortId = useId();
  const options = [t("Newest first"), t("Alphabetical")];
  const matches = words.filter((word) => word.word.toLowerCase().includes(query.toLowerCase())).slice(0, 4);

  useEffect(() => {
    const bar = tabs.current;
    if (!bar) return;
    const measure = () => {
      const active = bar.querySelector<HTMLElement>('[aria-selected="true"]');
      if (active) setPill({ x: active.offsetLeft, width: active.offsetWidth });
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(bar);
    return () => observer.disconnect();
  }, [stage, locale]);

  useEffect(() => {
    const outside = (event: PointerEvent) => {
      if (!searchRoot.current?.contains(event.target as Node)) setSearchOpen(false);
      if (!sortRoot.current?.contains(event.target as Node)) setSortOpen(false);
    };
    document.addEventListener("pointerdown", outside);
    return () => document.removeEventListener("pointerdown", outside);
  }, []);

  const chooseSort = (index: number) => {
    onSort(index === 0 ? "recent" : "alphabetical");
    setSortOpen(false);
    sortButton.current?.focus();
  };
  const openSearch = () => {
    setSearchOpen(true);
    window.setTimeout(() => searchInput.current?.focus(), 120);
  };
  const closeSearch = () => {
    setSearchOpen(false);
    onQuery("");
  };
  const searchExpanded = searchOpen || !!query;

  return <div className="ow-board-toolbar">
    <div className="ux u039 ow-stage-tabs" ref={tabs} role="tablist" aria-label={t("Filter by learning stage")}>
      <span className="u039-pill" style={{ "--x": `${pill.x}px`, "--w": `${pill.width}px` } as CSSProperties} aria-hidden="true" />
      {stages.map((item, index) => <button key={item} type="button" className="u039-tab" role="tab" aria-selected={stage === item} tabIndex={stage === item ? 0 : -1} onClick={() => onStage(item)} onKeyDown={(event) => {
        const delta = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0;
        if (!delta) return;
        event.preventDefault();
        const next = (index + delta + stages.length) % stages.length;
        onStage(stages[next]);
        tabs.current?.querySelectorAll<HTMLButtonElement>(".u039-tab")[next]?.focus();
      }}>
        <span className={`stage-dot ${item}`} aria-hidden="true" />
        <span>{item === "all" ? t("All") : t(stageLabels[item])}</span>
        <span className="stage-count">{item === "all" ? words.length : words.filter((word) => word.stage === item).length}</span>
      </button>)}
    </div>
    <div className="ow-board-tools">
      <div ref={searchRoot} className={`ux u027 ow-board-search${searchExpanded ? " is-open" : ""}`}>
        <div className="u027-field">
          <button type="button" className="u027-go" aria-label={t("Search words")} aria-expanded={searchExpanded} onClick={() => searchExpanded ? searchInput.current?.focus() : openSearch()}><Search size={20} /></button>
          <input ref={searchInput} id={searchId} className="u027-in" value={query} onChange={(event) => { onQuery(event.target.value); setSearchOpen(true); }} onKeyDown={(event) => { if (event.key === "Escape") { closeSearch(); searchRoot.current?.querySelector<HTMLButtonElement>(".u027-go")?.focus(); } }} placeholder={t("Search words…")} aria-label={t("Search words")} tabIndex={searchExpanded ? 0 : -1} autoComplete="off" />
          <button type="button" className="u027-x" aria-label={t("Clear filters")} tabIndex={searchExpanded ? 0 : -1} onClick={closeSearch}><X size={18} /></button>
        </div>
        {searchOpen && query && <div className="u027-pop"><p className="u027-sec">{t("Search words")}</p><ul className="u027-list">{matches.length ? matches.map((word, index) => <li key={word.userWordId} className="u027-opt" style={{ transitionDelay: `${index * 40}ms` }}><button type="button" onClick={() => { onQuery(word.word); setSearchOpen(false); }}><strong lang="en">{word.word}</strong><small lang="en">{word.definition}</small></button></li>) : <li className="u027-empty">{t("No matching words")}</li>}</ul></div>}
      </div>
      <div ref={sortRoot} className={`ux u031 ow-board-sort${sortOpen ? " is-open" : ""}`}>
        <button ref={sortButton} type="button" className="u031-btn" aria-haspopup="listbox" aria-expanded={sortOpen} aria-controls={sortId} aria-label={t("Sort words")} onClick={() => { setSortActive(sort === "recent" ? 0 : 1); setSortOpen(!sortOpen); if (!sortOpen) requestAnimationFrame(() => sortList.current?.focus()); }} onKeyDown={(event) => { if (event.key === "ArrowDown" || event.key === "ArrowUp") { event.preventDefault(); setSortOpen(true); setSortActive(sort === "recent" ? 0 : 1); requestAnimationFrame(() => sortList.current?.focus()); } }}>
          <ArrowDownWideNarrow size={19} aria-hidden="true" /><span className="u031-v"><b>{sort === "recent" ? options[0] : options[1]}</b></span><ChevronDown className="u031-car" size={17} aria-hidden="true" />
        </button>
        <ul ref={sortList} id={sortId} className={`u031-list${sortOpen ? " is-open" : ""}`} role="listbox" tabIndex={-1} aria-label={t("Sort words")} aria-activedescendant={`${sortId}-${sortActive}`} onKeyDown={(event) => {
          if (event.key === "ArrowDown" || event.key === "ArrowUp") { event.preventDefault(); setSortActive((current) => Math.max(0, Math.min(1, current + (event.key === "ArrowDown" ? 1 : -1)))); }
          else if (event.key === "Home" || event.key === "End") { event.preventDefault(); setSortActive(event.key === "Home" ? 0 : 1); }
          else if (event.key === "Enter" || event.key === " ") { event.preventDefault(); chooseSort(sortActive); }
          else if (event.key === "Escape") { event.preventDefault(); setSortOpen(false); sortButton.current?.focus(); }
          else if (event.key === "Tab") setSortOpen(false);
        }}>
          <li className="u031-hl" role="presentation" aria-hidden="true" style={{ "--i": sortActive } as CSSProperties} />
          {options.map((option, index) => <li key={index} id={`${sortId}-${index}`} className="u031-o" role="option" aria-selected={(sort === "recent" ? 0 : 1) === index} onPointerMove={() => setSortActive(index)} onClick={() => chooseSort(index)}><span>{option}</span><Check className="u031-ck" size={17} aria-hidden="true" /></li>)}
        </ul>
      </div>
    </div>
  </div>;
}
