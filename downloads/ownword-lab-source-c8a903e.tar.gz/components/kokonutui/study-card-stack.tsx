"use client";

/**
 * Ownword study adaptation of Kokonut UI's Throw Deck (MIT, @dorianbaffier).
 * Keeps the source deck's resting slot poses and layered card treatment while
 * letting the existing review session own navigation and the two-sided card.
 * Source: https://kokonutui.com/docs/cards/card-stack
 */
import { AnimatePresence, motion } from "motion/react";
import type { ReactNode } from "react";

const TILTS = [0, -2, 1.5, -1];
const SLOT_Y = 9;
const SLOT_SCALE = 0.035;

function slotPose(depth: number) {
  const d = Math.min(depth, TILTS.length - 1);
  return { y: d * SLOT_Y, rotate: TILTS[d], scale: 1 - d * SLOT_SCALE };
}

export function StudyCardStack({
  children,
  cardKey,
  reduceMotion,
}: {
  children: ReactNode;
  cardKey: string;
  reduceMotion: boolean;
}) {
  return (
    <div className="quick-deck">
      <div className="quick-deck-pile">
        {[2, 1].map((depth) => (
          <motion.div
            aria-hidden="true"
            className="quick-deck-under-card"
            key={depth}
            initial={false}
            animate={reduceMotion ? {} : slotPose(depth)}
            style={reduceMotion ? { transform: `translateY(${depth * SLOT_Y}px) rotate(${TILTS[depth]}deg) scale(${1 - depth * SLOT_SCALE})` } : undefined}
            transition={{ type: "spring", bounce: 0.19, duration: 0.4 }}
          >
            <span className="quick-deck-under-mark" />
          </motion.div>
        ))}
        <AnimatePresence mode="sync" initial={false}>
          <motion.div
            className="quick-deck-top"
            key={cardKey}
            initial={reduceMotion ? { opacity: 0 } : { opacity: 0, x: 56, rotate: 5 }}
            animate={{ opacity: 1, x: 0, rotate: 0 }}
            exit={reduceMotion ? { opacity: 0 } : { opacity: 0, x: -70, rotate: -7 }}
            transition={{ type: "spring", bounce: 0.12, duration: reduceMotion ? 0.15 : 0.38 }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
