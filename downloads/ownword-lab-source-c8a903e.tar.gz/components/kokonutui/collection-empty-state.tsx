import { type ReactNode } from "react";
import type { LucideIcon } from "lucide-react";

// Adapts Kokonut UI's illustrated Empty State to actions on a real collection.
export function CollectionEmptyState({
  icon: Icon,
  title,
  description,
  illustration,
  children,
  variant = "inline",
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  illustration?: ReactNode;
  children?: ReactNode;
  variant?: "inline" | "collection" | "search";
}) {
  return (
    <section className="ow-collection-empty" data-variant={variant}>
      <div className="ow-empty-art" data-illustrated={illustration ? "true" : undefined} aria-hidden="true">
        {illustration ?? <div className="ow-empty-art-card">
          <Icon size={21} strokeWidth={1.7} />
          {variant === "collection" && <><span /><span /></>}
        </div>}
      </div>
      <div className="ow-empty-copy"><h2>{title}</h2>{description && <p>{description}</p>}</div>
      {children && <div className="ow-empty-actions">{children}</div>}
    </section>
  );
}
