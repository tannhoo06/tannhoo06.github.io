"use client";
import { useI18n } from "./language-provider";
import { LucianLanguageText } from "./lucian-267-language-switch";
import Link from "next/link";
import { vietnameseDemoMeanings } from "@/lib/i18n/vocabulary";
import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import {
  ArrowLeft,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Lightbulb,
  PenLine,
  Plane,
  PawPrint,
  BookOpen,
  Target,
} from "lucide-react";
import { Button as AnimateButton } from "@animate-ui/react/primitives/buttons/button";
import { validSource as isValidSource } from "@/lib/domain/anchors";
import type {
  AppState,
  Opportunity,
  Suggestion,
} from "@/lib/domain/types";
import { HighlightedWriting } from "./lucian-281-highlighted-writing";
import { TraceableSuggestion } from "./lucian-224-suggestion";
import { WritingScan } from "./lucian-235-writing-scan";
import { SampleToggle } from "./lucian-009-sample-button";
import { useConfirmAction } from "./lucian-269-confirmation";
import { useRequestLimitNotice } from "./request-limit-notice";
import {
  api,
  Button,
  ErrorMessage,
  type Navigate,
  type Notify,
} from "./shared";

const prompts = [
  "What’s something you’ve been interested in recently, and why?",
  "What is a small change that has made your day better?",
  "Tell us about an idea you changed your mind about.",
];
const topicSamples = [
  { label: "A recent trip", icon: Plane, text: "Before our trip to Da Nang, she was careful about checking every reservation, train time, and address. Our first plan was not final; we could change it if the weather got worse." },
  { label: "A favorite animal", icon: PawPrint, text: "My favorite animal is the elephant. The veterinarian was careful about checking every injury, movement, and sign of pain before treating an injured elephant." },
  { label: "A book or movie", icon: BookOpen, text: "The detective found new evidence that supported the earlier findings. The book also showed how a small but meaningful difference can change a person’s decision." },
  { label: "A personal goal", icon: Target, text: "My goal is to write better in English. I was careful about checking every spelling, example, and detail before submitting my essay. My study plan is not final; I may revise it next month." },
];
const anotherExample =
  "I made an intentional choice to change my routine. Our possible plan for next month is still flexible. I want to explain clearly why this matters.";
type Review = {
  sampleId: string;
  text: string;
  suggestions: Suggestion[];
  opportunities: Opportunity[];
  usages: { word: string; feedback: string; correct: boolean }[];
  summary: string;
};
type Intent = {
  userId?: string;
  word?: string;
  sampleId?: string;
  text?: string;
  sentence?: string;
};
type Revision = { before: string; after: string };
type Saved = {
  text: string;
  review: Review | null;
  cursor: number;
  editing: boolean;
  revisions: Revision[];
  intent?: Intent | null;
};
function ChangedSentence({ proposed, word }: { proposed: string; word: string }) {
  const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = new RegExp(`\\b${escaped}\\b`, "i").exec(proposed);
  if (!match) return <p lang="en">{proposed}</p>;
  return (
    <p lang="en">
      {proposed.slice(0, match.index)}
      <mark>{match[0]}</mark>
      {proposed.slice(match.index + match[0].length)}
    </p>
  );
}
export function Writing({
  onboarding,
  mock,
  refresh,
  notify,
  navigate,
  practice,
  userId = "local",
}: {
  onboarding: boolean;
  mock: boolean;
  refresh: () => Promise<AppState>;
  notify: Notify;
  navigate: Navigate;
  practice: (id?: string) => Promise<unknown>;
  userId?: string;
}) {
  const { t, locale } = useI18n();
  const confirmAction = useConfirmAction();
  const { handle: showLimit } = useRequestLimitNotice();
  const key = `ownword:writing:${userId}`;
  const showDemoControls = mock && process.env.NODE_ENV !== "production";
  const [ready, setReady] = useState(false),
    [text, setText] = useState(""),
    [savedDraftText, setSavedDraftText] = useState<string | null>(null),
    [result, setResult] = useState<Review | null>(null),
    [cursor, setCursor] = useState(0),
    [editing, setEditing] = useState(true),
    [revisions, setRevisions] = useState<Revision[]>([]);
  const [busy, setBusy] = useState(false),
    [scanning, setScanning] = useState(false),
    [folded, setFolded] = useState(false),
    [decisionBusy, setDecisionBusy] = useState(false),
    [error, setError] = useState(""),
    [storageError, setStorageError] = useState(false),
    [preview, setPreview] = useState(false),
    [promptIndex, setPromptIndex] = useState(0),
    [intent, setIntent] = useState<Intent | null>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  // Publish successful analysis even when navigation unmounts this component
  // before the request completes. The latest draft is never overwritten.
  function persistReview(review: Review, position: number) {
    try {
      const cached = JSON.parse(
        sessionStorage.getItem(key) ?? "null",
      ) as Saved | null;
      sessionStorage.setItem(
        key,
        JSON.stringify({
          text: cached?.text ?? text,
          review,
          cursor: position,
          editing: false,
          revisions: cached?.revisions ?? [],
          intent: cached?.intent ?? intent,
        } satisfies Saved),
      );
      window.dispatchEvent(
        new CustomEvent("ownword:review-updated", { detail: { key, review } }),
      );
    } catch {
      setStorageError(true);
    }
  }
  useEffect(() => {
    const receive = (event: Event) => {
      const detail = (event as CustomEvent<{ key: string; review: Review }>)
        .detail;
      if (detail.key === key) setResult(detail.review);
    };
    window.addEventListener("ownword:review-updated", receive);
    return () => window.removeEventListener("ownword:review-updated", receive);
  }, [key]);
  useEffect(() => {
    let live = true;
    queueMicrotask(() => {
      if (!live) return;
      try {
        const raw = sessionStorage.getItem(key);
        if (raw) {
          const saved = JSON.parse(raw) as Saved;
          setText(saved.text ?? "");
          setResult(saved.review);
          setCursor(saved.cursor ?? 0);
          setEditing(saved.editing);
          setRevisions(saved.revisions ?? []);
          setIntent(saved.intent ?? null);
          if (saved.review?.sampleId)
            api<Review>(
              `writing/review?sampleId=${encodeURIComponent(saved.review.sampleId)}`,
            )
              .then((review) => {
                if (live) setResult(review);
              })
              .catch(() => {
                if (live)
                  setError(
                    "Could not refresh this review. Your saved view is here; reconnect before changing decisions.",
                  );
              });
        } else
          setText(
            sessionStorage.getItem(
              onboarding ? "ownword:onboarding-draft" : "ownword:writing-draft",
            ) ?? "",
          );
        const rawIntent = sessionStorage.getItem("ownword:writing-intent");
        if (rawIntent) {
          const nextIntent = JSON.parse(rawIntent) as Intent;
          if (!nextIntent.userId || nextIntent.userId === userId)
            setIntent(nextIntent);
          sessionStorage.removeItem("ownword:writing-intent");
        }
      } catch {
        setStorageError(true);
      }
      setReady(true);
    });
    return () => {
      live = false;
    };
  }, [key, onboarding, userId]);
  useEffect(() => {
    if (!ready) return;
    try {
      sessionStorage.setItem(
        key,
        JSON.stringify({
          text,
          review: result,
          cursor,
          editing,
          revisions,
          intent,
        } satisfies Saved),
      );
      queueMicrotask(() => setSavedDraftText(text));
    } catch {
      queueMicrotask(() => setStorageError(true));
    }
  }, [key, ready, text, result, cursor, editing, revisions, intent]);
  const select = (i: number) => {
    setCursor(i);
    setPreview(false);
    setError("");
  };
  function startNewDraft(nextText = "") {
    setText(nextText);
    setEditing(true);
    setRevisions([]);
    setError("");
    setPreview(false);
    requestAnimationFrame(() =>
      document.getElementById("writing-text")?.focus(),
    );
  }
  async function analyze(e: FormEvent) {
    e.preventDefault();
    if (busy || text.trim().length < 10) return;
    const trigger = document.activeElement;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const scanDuration = reducedMotion
      ? Promise.resolve()
      : new Promise<void>((resolve) => window.setTimeout(resolve, 1950));
    setBusy(true);
    setScanning(true);
    setFolded(false);
    setError("");
    try {
      const [review] = await Promise.all([
        api<Review>("analyze", { text, prompt: prompts[promptIndex] }),
        scanDuration,
      ]);
      const completedReview = { ...review, text: review.text ?? text };
      persistReview(completedReview, 0);
      setFolded(true);
      if (!reducedMotion)
        await new Promise<void>((resolve) => window.setTimeout(resolve, 550));
      setResult(completedReview);
      setCursor(0);
      setEditing(false);
      setRevisions([]);
      setPreview(false);
      setScanning(false);
      setFolded(false);
      requestAnimationFrame(() => heading.current?.focus());
      await refresh();
    } catch (e) {
      setScanning(false);
      setFolded(false);
      if (!showLimit(e, trigger)) setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function decide(
    decision: "added" | "dismissed" | "already" | "pending",
  ) {
    const suggestion = result?.suggestions[cursor];
    if (!suggestion || !result || decisionBusy) return;
    setDecisionBusy(true);
    setError("");
    try {
      const response = await api<{
        userWordId?: string;
        queued: boolean;
        status: Suggestion["status"];
      }>("suggestions/decide", { id: suggestion.id, decision });
      setResult({
        ...result,
        suggestions: result.suggestions.map((s) =>
          s.id === suggestion.id
            ? {
                ...s,
                status: decision,
                savedWordId: response.userWordId,
                queued: response.queued,
              }
            : s,
        ),
      });
      if (decision === "pending") notify(t("Decision undone."));
      if (decision !== "pending") setCursor(cursor + 1);
      await refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setDecisionBusy(false);
    }
  }
  const allItems = result
    ? result.suggestions.map((s) => ({
          source: isValidSource(result.text, result.sampleId, s.source)
            ? s.source
            : null,
          label: s.originalText,
        }))
    : [];
  const current = result?.suggestions[cursor];
  const source = current?.source;
  const validSource =
    result && isValidSource(result.text, result.sampleId, source)
      ? source
      : null;
  const saved = result?.suggestions.filter((s) => s.status === "added") ?? [],
    queued = saved.filter((s) => s.queued),
    available = saved.filter((s) => !s.queued),
    pending =
      result?.suggestions.filter((s) => s.status === "pending").length ?? 0;
  const canApply = !!(
    validSource &&
    current?.suggestedSentence &&
    result &&
    text === result.text
  );
  function applyRevision() {
    if (!canApply || !validSource || !current?.suggestedSentence) return;
    const after =
      text.slice(0, validSource.sentenceStart) +
      current.suggestedSentence +
      text.slice(validSource.sentenceEnd);
    setRevisions((r) => [...r, { before: text, after }]);
    setText(after);
    setPreview(false);
    notify(
      t("Revision applied to your draft. The analyzed original is preserved."),
    );
  }
  const finished =
    !!result &&
    (cursor >= result.suggestions.length || !result.suggestions.length);
  return (
    <div
      className={`writing-layout writing-v2 ${editing ? "is-editing" : "is-reviewing"}`}
    >
      {!onboarding && (
        <Link className="shell-context-back" href="/discover" prefetch={false} onClick={(event) => {
          if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey || event.button !== 0) return;
          event.preventDefault();
          navigate("discover");
        }}>
          <ArrowLeft size={16} aria-hidden="true" />{locale === "vi" ? "Về Khám phá" : "Back to Discover"}
        </Link>
      )}
      {editing && (
        <div className="page-heading">
          <div>
            <h1 ref={heading} tabIndex={-1}>
              <LucianLanguageText block value={t("Find words for your draft")} order={2} />
            </h1>
          </div>
        </div>
      )}
      {storageError && (
        <p role="status">
          {t(
            "Browser storage is unavailable. Keep this page open to retain your draft and review position.",
          )}
        </p>
      )}
      {intent && (
        <section className="writing-intent">
          <h2>
            {intent.word
              ? t("Try “{word}” in your writing", { word: intent.word })
              : t("From your patterns")}
          </h2>
          <p>
            {intent.sentence ??
              t("Use a context that makes the meaning clear.")}
          </p>
          {intent.text && (
            <Button
              secondary
              onClick={async () => {
                if (
                  !text ||
                  await confirmAction({
                    title: t("Replace the draft?"),
                    message: t("Replace the current draft with this source passage? Your analyzed original will be kept."),
                    confirmLabel: t("Replace draft"),
                  })
                ) {
                  setText(intent.text!);
                  setEditing(true);
                }
              }}
            >
              {t("Use this passage")}
            </Button>
          )}
          <button className="text-button" onClick={() => setIntent(null)}>
            {t("Dismiss context")}
          </button>
        </section>
      )}
      {editing ? (
        <form className="writing-paper" onSubmit={analyze} aria-busy={busy}>
          <WritingScan
            text={text}
            onTextChange={setText}
            busy={busy}
            ready={ready}
            scanning={scanning}
            folded={folded}
            storageError={storageError}
            draftSaved={!!text.trim() && text === savedDraftText}
          />
          <details className="writing-samples">
            <SampleToggle label={t("Use a sample?")} />
            <aside className="writing-prompts">
              <div className="prompt-intro">
                <span className="prompt-intro-icon"><Lightbulb size={24} aria-hidden="true" /></span>
                <div>
                  <h2>{t("Not sure what to write?")}</h2>
                  <p>{t("Choose a topic below to try a sample paragraph.")}</p>
                </div>
              </div>
              <div className="prompt-chips">
                {topicSamples.map(({ label, icon: Icon, text: sample }, i) => (
                  <AnimateButton
                    type="button"
                    className={`writing-sample-option${text === sample ? " is-selected" : ""}`}
                    key={label}
                    aria-pressed={text === sample}
                    disabled={busy || !ready}
                    onClick={async () => {
                      if (text.trim() && text !== sample && !(await confirmAction({
                        title: t("Replace the draft?"),
                        message: t("Replace your draft with the example?"),
                        confirmLabel: t("Replace draft"),
                      }))) return;
                      setPromptIndex(i % prompts.length);
                      setText(sample);
                      setError("");
                    }}
                  >
                    <span className="writing-sample-option-icon"><Icon size={18} aria-hidden="true" /></span>
                    {t(label)}
                  </AnimateButton>
                ))}
              </div>
            </aside>
          </details>
          {error && <ErrorMessage message={t(error)} />}
        </form>
      ) : (
        result && (
          <div className="review-v2-grid">
            <section className="review-writing" aria-label={t("Your writing")}>
              <header>
                <h2>{t("Your writing")}</h2>
                <span role="status">
                  {t("{count} suggestions found", {
                    count: result.suggestions.length,
                  })}
                </span>
              </header>
              <HighlightedWriting
                key={result.sampleId}
                text={result.text}
                items={allItems}
                active={cursor}
                select={select}
              />
              {current && validSource && !finished && (
                <TraceableSuggestion
                  key={current.id}
                  phrase={validSource.exact}
                  word={current.word}
                  definition={current.definition}
                  reason={current.reason}
                  locale={locale}
                />
              )}
              <footer>
                <span>
                  {t("{count} characters", { count: result.text.length })}
                </span>
                <button
                  className="text-button"
                  onClick={() => setEditing(true)}
                >
                  <PenLine size={16} aria-hidden="true" />
                  {t("Edit")}
                </button>
              </footer>
              {text !== result.text && (
                <details className="draft-revision">
                  <summary>{t("View current draft")}</summary>
                  <p>{text}</p>
                  {!!revisions.length && text === revisions.at(-1)?.after && (
                    <button
                      className="text-button"
                      onClick={() => {
                        setText(revisions.at(-1)!.before);
                        setRevisions((r) => r.slice(0, -1));
                      }}
                    >
                      {t("Undo revision")}
                    </button>
                  )}
                </details>
              )}
            </section>
            <section
              className="review-suggestion"
              aria-label={t("Word suggestions")}
            >
              {!finished && current ? (
                <>
                  <nav
                    className="suggestion-progress"
                    aria-label={t("Review suggestions")}
                  >
                    <span role="status">
                      {t("Suggestion {number} of {total}", {
                        number: cursor + 1,
                        total: result.suggestions.length,
                      })}
                    </span>
                    <div className="suggestion-dots" aria-hidden="true">
                      {result.suggestions.map((s, i) => (
                        <i
                          key={s.id}
                          className={i === cursor ? "current" : ""}
                        />
                      ))}
                    </div>
                    <button
                      className="icon-button"
                      aria-label={t("Previous suggestion")}
                      disabled={!cursor || decisionBusy}
                      onClick={() => select(cursor - 1)}
                    >
                      <ChevronLeft size={18} />
                    </button>
                    <button
                      className="icon-button"
                      aria-label={t("Next suggestion")}
                      disabled={
                        decisionBusy || cursor >= result.suggestions.length - 1
                      }
                      onClick={() => select(cursor + 1)}
                    >
                      <ChevronRight size={18} />
                    </button>
                  </nav>
                  <article className="suggestion-card" key={current.id}>
                    <span className="suggestion-caption">
                      {t("Your phrase")}
                    </span>
                    <p className="original-phrase" lang="en">
                      {current.originalText}
                    </p>
                    <span className="suggestion-caption">
                      {t("Suggested word")}
                    </span>
                    <h1
                      className="suggested-word"
                      ref={heading}
                      tabIndex={-1}
                      lang="en"
                    >
                      {current.word}
                    </h1>
                    <h2>{t("Meaning")}</h2>
                    <p lang="en">{current.definition}</p>
                    {vietnameseDemoMeanings[current.definition] && (
                      <details className="suggestion-translation">
                        <summary>{t("Show Vietnamese meaning")}</summary>
                        <p lang="vi">{vietnameseDemoMeanings[current.definition]}</p>
                      </details>
                    )}
                    <h2>{t(current.suggestedSentence && validSource ? "Your sentence with this word" : "Example sentence")}</h2>
                    <div className="suggestion-example">
                      {current.suggestedSentence && validSource ? (
                        <ChangedSentence
                          word={current.word}
                          proposed={current.suggestedSentence}
                        />
                      ) : (
                        <p lang="en">{current.examples[0]}</p>
                      )}
                    </div>
                    <details className="suggestion-why">
                      <summary>{t("Why this word?")}</summary>
                      <p lang="en">{current.reason}</p>
                      <p lang="en">{current.nuance}</p>
                      <p lang="en">{current.collocations.join(" · ")}</p>
                      {current.examples.slice(1).map((e) => (
                        <p key={e} lang="en">
                          {e}
                        </p>
                      ))}
                      {canApply && (
                        <>
                          <button
                            className="text-button"
                            onClick={() => setPreview(!preview)}
                          >
                            {t("Preview the change to your draft")}
                          </button>
                          {preview && (
                            <div className="revision-preview">
                              <p>{current.suggestedSentence}</p>
                              <Button secondary onClick={applyRevision}>
                                {t("Apply to draft")}
                              </Button>
                            </div>
                          )}
                        </>
                      )}
                      {current.status !== "pending" && (
                        <button
                          className="text-button"
                          disabled={decisionBusy}
                          onClick={() => decide("pending")}
                        >
                          {t("Undo decision")}
                        </button>
                      )}
                    </details>
                  </article>
                  {error && <ErrorMessage message={t(error)} />}
                  <div className="suggestion-decisions">
                    <Button
                      onClick={() => decide("added")}
                      disabled={decisionBusy}
                    >
                      {t("Add to practice")}
                    </Button>
                    <Button
                      secondary
                      onClick={() => decide("dismissed")}
                      disabled={decisionBusy}
                    >
                      {t("Skip")}
                    </Button>
                  </div>
                </>
              ) : (
                <section className="review-complete">
                  <h1 ref={heading} tabIndex={-1}>
                    {result.suggestions.length
                      ? t("Done reviewing word suggestions")
                      : t(
                          mock
                            ? "No matching demo suggestions"
                            : "No new words to suggest",
                        )}
                  </h1>
                  <p>
                    {saved.length
                      ? t("{count} words added to your WordBoard.", {
                          count: saved.length,
                        })
                      : !result.suggestions.length
                        ? t("Try adding what happened or how you felt.")
                        : t(
                          "No words were added to WordBoard.",
                        )}
                  </p>
                  {queued.length > 0 && (
                    <p>
                      {t(
                        "Some words will be introduced gradually. They’re safely on your WordBoard.",
                      )}
                    </p>
                  )}
                  {!result.suggestions.length && result.summary !== "No vocabulary options met the precision and source checks for this passage." && <p>{t(result.summary)}</p>}
                  {error && <ErrorMessage message={t(error)} />}
                  {available.length > 0 && (
                    <Button onClick={() => practice()}>
                      {t("Start practice")}
                      <ArrowRight size={17} />
                    </Button>
                  )}
                  <Button secondary onClick={() => navigate("board")}>
                    {t("Go to WordBoard")}
                  </Button>
                  <button
                    className="text-button"
                    onClick={() => startNewDraft()}
                  >
                    {t("Continue writing")}
                  </button>
                  {!!result.suggestions.length && (
                    <button className="text-button" onClick={() => select(0)}>
                      {t("Review suggestions again")}
                    </button>
                  )}
                  {showDemoControls && !result.suggestions.length && (
                    <button
                      className="text-button"
                      onClick={() => startNewDraft(anotherExample)}
                    >
                      {t("Try another demo example")}
                    </button>
                  )}
                  {!!pending && (
                    <button
                      className="text-button"
                      onClick={() =>
                        select(
                          result.suggestions.findIndex(
                            (s) => s.status === "pending",
                          ),
                        )
                      }
                    >
                      {t("Continue reviewing")}
                    </button>
                  )}
                </section>
              )}
              {!!result.opportunities.length && (
                <details className="existing-opportunities">
                  <summary>{t("Words already on your WordBoard")}</summary>
                  {result.opportunities.map((o) => (
                    <div key={o.userWordId}>
                      <p>{o.prompt}</p>
                      <button
                        className="text-button"
                        onClick={() => practice(o.userWordId)}
                      >
                        {t("Practice this word")}
                      </button>
                    </div>
                  ))}
                </details>
              )}
              {!!result.usages.length && (
                <details className="writing-signals">
                  <summary>{t("Words you used from your collection")}</summary>
                  {result.usages.map((u) => (
                    <p key={u.word}>
                      <strong>{u.word}</strong>: {u.feedback}
                    </p>
                  ))}
                </details>
              )}
            </section>
          </div>
        )
      )}
    </div>
  );
}
