// Lucian UX/UI Prompt #281 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#281
"use client";

import { useEffect, useRef, type ReactNode } from "react";
import type { SourceAnchor } from "@/lib/domain/types";
import { useI18n } from "./language-provider";

/** Preserve the application's validated, possibly overlapping source ranges. */
export function HighlightedWriting({
  text,
  items,
  active,
  select,
  sourceVersion,
  markLabel,
  showNumbers = true,
  staggerHighlights = true,
}: {
  text: string;
  items: { source?: SourceAnchor | null; label: string; tone?: "positive" }[];
  active: number;
  select: (index: number) => void;
  sourceVersion?: string;
  markLabel?: (index: number, label: string) => string;
  showNumbers?: boolean;
  staggerHighlights?: boolean;
}) {
  const { t } = useI18n();
  const root = useRef<HTMLDivElement>(null);
  const valid = items.flatMap((item, index) =>
    item.source && (!sourceVersion || item.source.version === sourceVersion) &&
      text.slice(item.source.start, item.source.end) === item.source.exact
      ? [{ ...item.source, index }]
      : [],
  );
  const bounds = [...new Set([0, text.length, ...valid.flatMap((a) => [a.start, a.end])])].sort((a, b) => a - b);
  const nodes: ReactNode[] = [];
  bounds.slice(0, -1).forEach((start, i) => {
    const end = bounds[i + 1];
    const covering = valid.filter((a) => a.start <= start && a.end >= end);
    if (!covering.length) {
      nodes.push(text.slice(start, end));
      return;
    }
    const chosen = covering.find((a) => a.index === active) ?? covering[0];
    nodes.push(
      <button
        key={start}
        type="button"
        className={`source-mark u281-mark${covering.some((a) => a.index === active) ? " selected" : ""}`}
        data-tone={items[chosen.index].tone}
        aria-label={markLabel?.(chosen.index, items[chosen.index].label) ?? t("Suggestion {number}: {phrase}", { number: chosen.index + 1, phrase: items[chosen.index].label })}
        data-source-index={chosen.index}
        aria-pressed={covering.some((a) => a.index === active)}
        onClick={() => select(chosen.index)}
      >
        {text.slice(start, end)}
        {showNumbers && <sup>{covering.map((a) => a.index + 1).join(", ")}</sup>}
      </button>,
    );
  });

  useEffect(() => {
    const element = root.current;
    if (!element) return;
    if (staggerHighlights) {
      let at = 0.25;
      for (const mark of element.querySelectorAll<HTMLElement>(".u281-mark")) {
        const duration = Math.min(1.4, 0.25 + (mark.textContent?.length ?? 0) * 0.045);
        mark.style.setProperty("--d", duration.toFixed(2) + "s");
        mark.style.setProperty("--w", at.toFixed(2) + "s");
        at += duration + 0.12;
      }
    }
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      element.classList.add("is-on");
      return () => element.classList.remove("is-on");
    }
    let second = 0;
    const first = requestAnimationFrame(() => {
      second = requestAnimationFrame(() => element.classList.add("is-on"));
    });
    return () => {
      cancelAnimationFrame(first);
      cancelAnimationFrame(second);
      element.classList.remove("is-on");
    };
  }, [text, staggerHighlights]);

  return (
    <div ref={root} className="ux u281 ownword-highlight">
      <p className="annotated-paragraph u281-p" lang="en">{nodes}</p>
    </div>
  );
}
