"use client";

import { useEffect, useState, type CSSProperties, type ReactNode } from "react";
import { ArrowLeft, Check, ChevronDown, Languages, Layers3, Sparkles } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import UndoButton from "./kokonutui/undo-button";
import { LucianIdeaPrompt } from "./lucian-233-idea-prompt";
import { LucianDictionaryLink } from "./lucian-009-dictionary-link";
import { useI18n } from "./language-provider";
import { useRequestLimitNotice } from "./request-limit-notice";
import { LucianLanguageText } from "./lucian-267-language-switch";
import type { AppState, ConceptDiscovery, Lexeme } from "@/lib/domain/types";
import { api, type Navigate } from "./shared";
import "@/app/idea-discovery.css";

type Quotas = { concept: number; limits: { concept: number } };
function highlightedExample(example: string, word: string) {
  const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const matches = [...example.matchAll(new RegExp(`\\b${escaped}\\b`, "gi"))];
  if (!matches.length) return example;
  let cursor = 0;
  const pieces: ReactNode[] = [];
  for (const [index, match] of matches.entries()) {
    const start = match.index ?? 0;
    pieces.push(example.slice(cursor, start));
    pieces.push(<mark key={`${start}-${index}`} style={{ "--d": `${Math.min(1.4, .25 + match[0].length * .045).toFixed(2)}s`, "--w": `${(.25 + index * .25).toFixed(2)}s` } as CSSProperties}>{match[0]}</mark>);
    cursor = start + match[0].length;
  }
  pieces.push(example.slice(cursor));
  return pieces;
}
function HighlightedExample({ example, word }: { example: string; word: string }) {
  const [active, setActive] = useState(false);
  useEffect(() => {
    const frame = requestAnimationFrame(() => setActive(true));
    return () => cancelAnimationFrame(frame);
  }, [example, word]);
  return <blockquote className={`idea-example${active ? " is-on" : ""}`} lang="en">“{highlightedExample(example, word)}”</blockquote>;
}

export function IdeaDiscovery({ state, refresh, navigate }: { state: AppState; refresh: () => Promise<AppState>; navigate: Navigate }) {
  const { locale, t } = useI18n();
  const vi = locale === "vi";
  const reducedMotion = useReducedMotion();
  const [concept, setConcept] = useState("");
  const { handle: showLimit } = useRequestLimitNotice();
  const [discovery, setDiscovery] = useState<ConceptDiscovery | null>(null);
  const [quotas, setQuotas] = useState<Quotas | null>(null);
  const [busy, setBusy] = useState(false);
  const [saving, setSaving] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [undo, setUndo] = useState<{ candidateId: string; userWordId: string } | null>(null);
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [openTranslation, setOpenTranslation] = useState<string | null>(null);
  const [translating, setTranslating] = useState<string | null>(null);

  useEffect(() => {
    void Promise.all([api<ConceptDiscovery | null>("discovery/concept/latest"), api<Quotas>("discovery/quotas")])
      .then(([previous, nextQuotas]) => { setDiscovery(previous); setQuotas(nextQuotas); })
      .catch((cause) => setError((cause as Error).message));
  }, []);

  async function search() {
    if (busy || concept.trim().length < 3) return;
    const trigger = document.activeElement;
    setBusy(true); setError(""); setUndo(null);
    try {
      const result = await api<ConceptDiscovery>("discovery/concept", { concept: concept.trim() });
      setDiscovery(result);
      void api<Quotas>("discovery/quotas").then(setQuotas).catch(() => {});
    } catch (cause) {
      if (showLimit(cause, trigger)) void api<Quotas>("discovery/quotas").then(setQuotas).catch(() => {});
      else setError((cause as Error).message);
    }
    finally { setBusy(false); }
  }

  async function save(candidate: Lexeme) {
    if (!discovery || saving) return;
    setSaving(candidate.id); setError(""); setUndo(null);
    try {
      const result = await api<{ status: "added" | "already"; userWordId: string }>("discovery/concept/save", { discoveryId: discovery.id, candidateId: candidate.id });
      if (result.status === "added") setUndo({ candidateId: candidate.id, userWordId: result.userWordId });
      await refresh();
    } catch (cause) { setError((cause as Error).message); }
    finally { setSaving(null); }
  }

  async function undoSave() {
    if (!undo) return;
    const saved = undo;
    setUndo(null); setError("");
    try { await api("words/remove", { id: saved.userWordId }); await refresh(); }
    catch (cause) { setError((cause as Error).message); }
  }
  async function toggleTranslation(candidateId: string) {
    if (!discovery) return;
    if (openTranslation === candidateId) { setOpenTranslation(null); return; }
    setOpenTranslation(candidateId);
    const candidate = discovery.candidates.find((item) => item.id === candidateId);
    if (candidate?.vietnameseMeaning?.trim() || translations[candidateId]) return;
    const trigger = document.activeElement;
    setTranslating(candidateId); setError("");
    try {
      const result = await api<{ meaning: string }>("discovery/concept/translate", { discoveryId: discovery.id, candidateId });
      setTranslations((previous) => ({ ...previous, [candidateId]: result.meaning }));
    } catch (cause) { if (!showLimit(cause, trigger)) setError((cause as Error).message); setOpenTranslation(null); }
    finally { setTranslating(null); }
  }

  return <main className="idea-page">
    <div className="idea-inner">
      <button type="button" className="idea-back" onClick={() => navigate("discover")}><ArrowLeft size={17} aria-hidden="true" />{vi ? "Về Khám phá" : "Back to Discover"}</button>
      <header className="idea-heading"><h1><LucianLanguageText block value={t("Find a word for what you mean")} order={2} /></h1><p>{vi ? "Diễn tả bằng tiếng Việt hoặc tiếng Anh để nhận gợi ý từ tiếng Anh, kèm nghĩa và ví dụ." : "Describe it in Vietnamese or English. Get English words with meanings and examples."}</p></header>
      {quotas && <div className="idea-quota" role="status"><Layers3 size={16} aria-hidden="true" />{quotas.concept > 0
        ? t(quotas.concept === 1 ? "1 search left today" : "{count} searches left today", { count: quotas.concept }) : t("You’ve reached today’s word search limit.")}</div>}
      <LucianIdeaPrompt value={concept} onChange={setConcept} onSubmit={() => void search()} busy={busy} disabled={busy || concept.trim().length < 3} />
      {error && <div className="idea-error" role="alert">{t(error)}</div>}
      {discovery && <section className="idea-results" aria-label={vi ? "Các từ gợi ý" : "Suggested words"}>
        <div className="idea-results-heading"><h2>“{discovery.concept}”</h2><button type="button" className="idea-new" onClick={() => { setConcept(""); setDiscovery(null); setError(""); setOpenTranslation(null); requestAnimationFrame(() => document.querySelector<HTMLTextAreaElement>(".u233-tx")?.focus()); }}>{vi ? "Ý tưởng mới" : "New idea"}</button></div>
        {discovery.candidates.length === 0 ? <div className="idea-empty"><strong>{vi ? "Chưa tìm được từ phù hợp" : "No fitting words yet"}</strong><p>{vi ? "Thử nói rõ bạn sẽ dùng từ trong tình huống nào." : "Add where or when you’d say it."}</p></div> : <div className="idea-cards">{discovery.candidates.map((candidate, index) => {
          const owned = state.words.some((word) => word.word.toLowerCase() === candidate.word.toLowerCase());
          const pendingUndo = undo?.candidateId === candidate.id;
          return <motion.article key={candidate.id} className="idea-card" initial={reducedMotion ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .35, delay: reducedMotion ? 0 : index * .06 }}>
            <div className="idea-card-head"><div><h3 lang="en">{candidate.word}</h3><span className="idea-pos">{candidate.partOfSpeech}</span></div><LucianDictionaryLink word={candidate.word} label={vi ? "Từ điển" : "Dictionary"} /></div>
            <p className="idea-definition">{candidate.definition}</p>
            {candidate.nuance && <p className="idea-nuance">{candidate.nuance}</p>}
            {vi && <div className="idea-translation"><button type="button" className="idea-translation-toggle" aria-expanded={openTranslation === candidate.id} onClick={() => void toggleTranslation(candidate.id)}><Languages size={14} aria-hidden="true" />{openTranslation === candidate.id ? "Ẩn nghĩa tiếng Việt" : "Hiện nghĩa tiếng Việt"}<ChevronDown size={14} aria-hidden="true" /></button>{openTranslation === candidate.id && <div className="idea-translation-content" role="status" lang="vi">{translating === candidate.id ? "Đang tải nghĩa…" : candidate.vietnameseMeaning?.trim() || translations[candidate.id]}</div>}</div>}
            {candidate.examples[0] && <HighlightedExample example={candidate.examples[0]} word={candidate.word} />}
            {candidate.collocations.length > 0 && <div className="idea-collocations">{candidate.collocations.slice(0, 3).map((item) => <span key={item} lang="en">{item}</span>)}</div>}
            <div className="idea-card-footer">{pendingUndo ? <UndoButton key={undo.userWordId} className="idea-undo" icon={Check} label={vi ? "Đã lưu vào WordBoard" : "Saved to WordBoard"} doneLabel={vi ? "Đã lưu vào WordBoard" : "Saved to WordBoard"} undoLabel={vi ? "Hoàn tác" : "Undo"} locale={locale} startPending duration={5000} resetAfter={null} onCommit={() => setUndo(null)} onUndo={() => void undoSave()} /> : owned ? <span className="idea-owned"><Check size={16} aria-hidden="true" />{vi ? "Đã có trong WordBoard" : "On WordBoard"}</span> : <button type="button" className="idea-save" disabled={saving !== null} onClick={() => void save(candidate)}><Sparkles size={15} aria-hidden="true" />{saving === candidate.id ? (vi ? "Đang lưu…" : "Saving…") : (vi ? "Lưu từ này" : "Save this word")}</button>}</div>
          </motion.article>;
        })}</div>}
      </section>}
    </div>
  </main>;
}
