"use client";

import { useState, useSyncExternalStore } from "react";
import { Volume2 } from "lucide-react";
import { useI18n } from "./language-provider";

export function PronunciationButton({ word, compact = false }: { word: string; compact?: boolean }) {
  const { locale } = useI18n();
  const supported = useSyncExternalStore(
    () => () => {},
    () => "speechSynthesis" in window && "SpeechSynthesisUtterance" in window,
    () => true,
  );
  const [speaking, setSpeaking] = useState(false);

  const label = supported
    ? locale === "vi" ? `Nghe phát âm ${word}` : `Hear ${word} pronounced`
    : locale === "vi" ? "Trình duyệt không hỗ trợ phát âm" : "Pronunciation is unavailable in this browser";

  return <button
    type="button"
    className={`pronunciation-button${compact ? " is-compact" : ""}${speaking ? " is-speaking" : ""}`}
    aria-label={label}
    title={label}
    disabled={!supported}
    onClick={() => {
      if (!supported) return;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(word);
      utterance.lang = "en-US";
      utterance.rate = 0.9;
      const voices = window.speechSynthesis.getVoices();
      const voice = voices.find((item) => item.lang.toLowerCase() === "en-us") ?? voices.find((item) => item.lang.toLowerCase().startsWith("en"));
      if (voice) utterance.voice = voice;
      utterance.onstart = () => setSpeaking(true);
      utterance.onend = () => setSpeaking(false);
      utterance.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }}
  ><Volume2 size={compact ? 17 : 20} aria-hidden="true" /></button>;
}
