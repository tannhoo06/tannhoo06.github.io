"use client";

import { AnimateUIProvider } from "@animate-ui/react/provider";
import { ReducedMotionConfig } from "@animate-ui/react/utils/motion";
import type { ReactNode } from "react";

export function OwnwordMotionProvider({ children }: { children: ReactNode }) {
  return <AnimateUIProvider reducedMotion="user"><ReducedMotionConfig>{children}</ReducedMotionConfig></AnimateUIProvider>;
}
