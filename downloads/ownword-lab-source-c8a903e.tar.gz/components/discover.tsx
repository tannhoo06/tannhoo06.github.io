"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { ArrowRight, Check, Layers3, Lightbulb, PenLine, Plus } from "lucide-react";
import { useMotionTokens, useShouldReduceMotion } from "@animate-ui/react/utils/motion";
import { motion } from "motion/react";
import UndoButton from "./kokonutui/undo-button";
import ParticleButton from "./kokonutui/particle-button";
import { LucianWordField } from "./lucian-025-word-field";
import type { AppState, WordCheck } from "@/lib/domain/types";
import { api, type Navigate } from "./shared";
import { useI18n } from "./language-provider";
import { useRequestLimitNotice } from "./request-limit-notice";
import { LucianLanguageContent } from "./lucian-267-language-switch";
import "@/app/discover.css";

type Quotas = { concept: number; writing: number; limits: { concept: number; writing: number } };

export function Discover({ refresh, navigate }: { refresh: () => Promise<AppState>; navigate: Navigate }) {
  const { locale, t } = useI18n();
  const { handle: showLimit } = useRequestLimitNotice();
  const vi = locale === "vi";
  const reduceMotion = useShouldReduceMotion();
  const { spring, transition } = useMotionTokens();
  const [word, setWord] = useState("");
  const [quotas, setQuotas] = useState<Quotas | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ vi: string; en: string } | null>(null);
  const [error, setError] = useState("");
  const [review, setReview] = useState<{ word: string; check: WordCheck } | null>(null);
  const [fieldInvalid, setFieldInvalid] = useState(false);
  const fieldError = fieldInvalid
    ? vi ? "Dùng 2–45 ký tự: chữ cái tiếng Anh, dấu cách, nháy đơn hoặc gạch nối." : "Use 2–45 characters: English letters, spaces, apostrophes or hyphens."
    : "";
  const [saved, setSaved] = useState<{ id: string; word: string; undoAvailable: boolean } | null>(null);
  const savedLabel = vi ? "Đã thêm vào WordBoard" : "Added to WordBoard";
  useEffect(() => { api<Quotas>("discovery/quotas").then(setQuotas).catch(() => {}); }, []);
  function invalidWordInput(value: string) {
    const normalized = value.normalize("NFKC").trim().replace(/\s+/g, " ");
    return normalized.length < 2 || normalized.length > 45 || !/^[a-z][a-z' -]*$/i.test(normalized);
  }
  async function add(override = false) {
    if (busy) return;
    if (invalidWordInput(word)) { setFieldInvalid(true); throw new Error("Invalid word input"); }
    const trigger = document.activeElement;
    setBusy(true); setError(""); setMessage(null); setSaved(null); setReview(null);
    try {
      const addedWord = word.trim();
      const result = await api<{ status: "added" | "already"; userWordId: string } | { status: "review"; check: WordCheck }>("words/manual", { word, override });
      if (result.status === "review") { setReview({ word: addedWord, check: result.check }); return; }
      await refresh();
      if (result.status === "already") {
        setMessage({ vi: "Từ này đã có trong WordBoard.", en: "This word is already on your WordBoard." });
      } else {
        setWord((current) => current === word ? "" : current);
        setSaved({ id: result.userWordId, word: addedWord, undoAvailable: true });
      }
    } catch (cause) { if (!showLimit(cause, trigger)) setError((cause as Error).message); setSaved(null); throw cause; }
    finally { setBusy(false); }
  }
  async function undoAdd() {
    if (!saved?.undoAvailable || busy) return;
    setBusy(true); setError("");
    try {
      await api("words/remove", { id: saved.id });
      if (document.activeElement?.closest(".discover-saved-word")) document.getElementById("discover-word")?.focus();
      setSaved(null);
      setMessage({ vi: `Đã hoàn tác thêm “${saved.word}”.`, en: `Removed “${saved.word}” from WordBoard.` });
      await refresh();
    } catch (cause) { setError((cause as Error).message); setSaved(null); }
    finally { setBusy(false); }
  }
  return (
    <div className="discover-page">
      <div className="discover-inner">
        <header className="discover-hero ow-page-intro">
          <h1><LucianLanguageContent locale={locale} render={(language) => language === "vi"
            ? <>Tìm và lưu <mark>từ tiếng Anh</mark></>
            : <>Find and save <mark>English words</mark></>} /></h1>
          <p>{vi ? "Lưu từ bạn đã biết, hoặc diễn tả điều bạn muốn nói để tìm từ phù hợp." : "Save a word you know, or describe what you want to say to find one."}</p>
        </header>
        <form className="discover-entry ow-surface" data-tone="soft" onSubmit={(event) => event.preventDefault()}>
          <div className="discover-entry-heading">
            <span className="discover-entry-mark"><Plus size={19} strokeWidth={2} aria-hidden="true" /></span>
            <strong>{vi ? "Lưu từ bạn đã biết" : "Save a word you know"}</strong>
            <Image className="discover-entry-buddy" src="/images/sprout-discovery-add-word.svg" width={216} height={190} alt="" unoptimized />
          </div>
          <div className="discover-add">
            <LucianWordField value={word} onChange={(value) => { setWord(value); setFieldInvalid(false); setReview(null); }} onBlur={() => { if (word.trim()) setFieldInvalid(invalidWordInput(word)); }} error={fieldError} vi={vi} />
            <ParticleButton className="discover-submit ow-action-primary" type="submit" onClick={() => add(false)} disabled={busy || !word.trim()} pendingLabel={vi ? "Đang kiểm tra" : "Checking"} successLabel={vi ? "Đã kiểm tra" : "Checked"} errorLabel={vi ? "Thử lại" : "Try again"} successDuration={1400} errorDuration={2200}>
              <span className="discover-submit-copy">{vi ? "Thêm từ" : "Add word"}<ArrowRight size={17} aria-hidden="true" /></span>
            </ParticleButton>
          </div>
        </form>
        {review && <div className="discover-word-review" role="status">
          <strong>{review.check.status === "correction" ? (vi ? "Có phải bạn muốn viết từ này?" : "Did you mean this word?") : review.check.status === "invalid" ? (vi ? "Chúng tôi chưa nhận ra từ hoặc cụm từ này" : "We didn’t recognize this word or phrase") : (vi ? "Chưa thể xác nhận từ này" : "We could not verify this word")}</strong>
          <p>{review.check.status === "correction" && review.check.suggestion ? <><span lang="en">{review.word}</span> → <b lang="en">{review.check.suggestion}</b></> : review.check.status === "invalid" ? (vi ? "Hãy kiểm tra chính tả hoặc thử một từ khác trước khi lưu." : "Check the spelling or try another word before saving.") : (vi ? "Kiểm tra chính tả. Nếu bạn muốn giữ nguyên cách viết, bạn vẫn có thể lưu." : "Check the spelling. If you meant to type it this way, you can still save it.")}</p>
          <div className="discover-word-review-actions">
            {review.check.status === "correction" && review.check.suggestion && <button type="button" onClick={() => { setWord(review.check.suggestion!); setReview(null); document.getElementById("discover-word")?.focus(); }}>{vi ? `Dùng “${review.check.suggestion}”` : `Use “${review.check.suggestion}”`}</button>}
            {review.check.status === "uncertain" && <button type="button" onClick={() => { void add(true).catch(() => {}); }} disabled={busy}>{vi ? "Lưu nguyên từ" : "Save as written"}</button>}
            <button type="button" className="is-secondary" onClick={() => { setReview(null); document.getElementById("discover-word")?.focus(); }}>{vi ? "Chỉnh sửa" : "Edit word"}</button>
          </div>
        </div>}
        <p className="sr-only" role="status" aria-atomic="true">
          {saved && <>{savedLabel}. <span lang="en">{saved.word}</span></>}
        </p>
        {saved && !error && (
          <motion.div key={saved.id} className="discover-saved-word ow-surface"
            initial={{ opacity: .85, y: reduceMotion ? 0 : 5 }} animate={{ opacity: 1, y: 0 }}
            transition={reduceMotion ? transition.fade : spring.toast}>
            <span className="discover-saved-mark" aria-hidden="true"><Check size={17} /></span>
            <div className="discover-saved-copy"><strong lang="en">{saved.word}</strong><span>{savedLabel}</span></div>
            {saved.undoAvailable && <UndoButton className="ow-discover-undo" compact doneLabel={savedLabel}
              undoLabel={vi ? "Hoàn tác" : "Undo"} locale={locale} startPending duration={5000} resetAfter={null}
              onCommit={() => setSaved((current) => current?.id === saved.id ? { ...current, undoAvailable: false } : current)} onUndo={undoAdd} />}
          </motion.div>
        )}
        {(message || error) && <div className={`discover-feedback${error ? " is-error" : ""}`} role={error ? "alert" : "status"}>
          {error ? t(error) : message?.[locale]}
        </div>}
        <div className="discover-options">
          <button type="button" className="discover-option ow-surface" onClick={() => navigate("idea")}>
            <Lightbulb className="discover-option-icon" size={36} strokeWidth={1.7} aria-hidden="true" />
            <span className="discover-option-copy"><strong>{t("Find a word for what you mean")}</strong><small>{vi ? "Diễn tả bằng tiếng Việt hoặc tiếng Anh" : "Describe it in Vietnamese or English"}</small>{quotas && <span className="discover-quota"><Layers3 size={14} aria-hidden="true" />{quotas.concept > 0 ? t(quotas.concept === 1 ? "1 search left today" : "{count} searches left today", { count: quotas.concept }) : t("You’ve reached today’s word search limit.")}</span>}</span>
            <ArrowRight size={25} strokeWidth={1.7} aria-hidden="true" />
          </button>
          <button type="button" className="discover-option ow-surface" onClick={() => navigate("write")}>
            <PenLine className="discover-option-icon" size={38} strokeWidth={1.7} aria-hidden="true" />
            <span className="discover-option-copy"><strong>{t("Find words for your draft")}</strong><small>{vi ? "Viết vài câu tiếng Anh để tìm từ hợp với ý bạn." : "Write a few English sentences and find words that fit what you’re saying."}</small>{quotas && <span className="discover-quota"><Layers3 size={14} aria-hidden="true" />{vi ? `Còn ${quotas.writing} lượt hôm nay` : `${quotas.writing} uses left today`}</span>}</span>
            <ArrowRight size={25} strokeWidth={1.7} aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
}
