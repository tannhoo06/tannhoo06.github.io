"use client";

import { useRef, useState } from "react";
import Link from "next/link";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { LandingPublic, LandingFooter } from "./landing-public";
import ShapeHero, { type HeroShape } from "./kokonutui/shape-hero";
import { useLandingScroll } from "./use-landing-scroll";
import { Brand } from "./shared";
import { useI18n } from "./language-provider";
import { LucianLanguageContent, LucianLanguageSwitch, LucianLanguageText } from "./lucian-267-language-switch";
import { LandingHeroDescription, LandingHeroTitle } from "./landing-hero-title";
import { LearningJourney } from "./learning-journey";
import { LucianStartButton } from "./lucian-211-start-button";
import { LucianDotBackground } from "./lucian-363-dot-background";
import "@/app/landing-legacy.css";
import "@/app/lucian-suggestions.css";

const heroWords = [
  "equanimity", "meticulous", "serendipity", "articulate", "perspicacious",
  "ubiquitous", "contemplate", "assiduous", "nuance", "resilient",
  "lucid", "discern", "tenacious", "eloquent",
  "perceptive", "subtle", "insightful", "deliberate",
];
const heroShapes: HeroShape[] = heroWords.map((word, index) => ({
  id: word,
  content: word,
  className: `ow-hero-shape ow-hero-shape-${index % 3}`,
}));

// Public demonstration only: no API, storage, or learner-record writes.
export function Landing() {
  const { locale } = useI18n();
  const copy = (vi: string, en: string) => (locale === "vi" ? vi : en);
  const [mobileOpen, setMobileOpen] = useState(false);
  const page = useRef<HTMLDivElement>(null);
  const start = () => window.location.assign("/auth/signin?return_to=/discover");
  useLandingScroll(page);
  return (
    <div
      ref={page}
      className="ow-landing"
    >
      <a className="skip-link" href="#main-content">
        {copy("Đến nội dung", "Skip to content")}
      </a>
      <main id="main-content">
        <section
          id="introduction"
          className="ow-intro"
          aria-labelledby="ow-title"
        >
          <LucianDotBackground />
          <header className="ow-nav">
            <Brand onClick={() => window.scrollTo({ top: 0 })} />
            <nav className="ow-public-links" aria-label={copy("Điều hướng chính", "Main navigation")}>
              <div className="ow-nav-links">
                <a href="#how-it-works"><LucianLanguageText value={copy("Cách học", "How it works")} order={0} /></a>
                <a href="#faq"><LucianLanguageText value={copy("FAQ", "FAQ")} order={1} /></a>
              </div>
              <div className="ow-nav-utilities">
                <LucianLanguageSwitch />
                <Link className="ow-login-button" href="/account">
                  <span>{copy("Đăng nhập", "Sign in")}</span>
                  <ArrowUpRight size={15} strokeWidth={1.8} aria-hidden="true" />
                </Link>
              </div>
            </nav>
            <button className="mobile-menu-trigger ow-mobile-menu-trigger" type="button" aria-expanded={mobileOpen} aria-controls="ow-mobile-destinations" onClick={() => setMobileOpen((open) => !open)}>
              {mobileOpen ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
              <span>{copy("Danh mục", "Menu")}</span>
            </button>
          </header>
          {mobileOpen && <nav id="ow-mobile-destinations" className="ow-mobile-destinations" aria-label={copy("Điều hướng di động", "Mobile navigation")} onKeyDown={(event) => { if (event.key === "Escape") { setMobileOpen(false); document.querySelector<HTMLElement>(".ow-mobile-menu-trigger")?.focus(); } }}>
            <a href="#how-it-works" onClick={() => setMobileOpen(false)}><LucianLanguageText value={copy("Cách học", "How it works")} order={0} /></a>
            <a href="#faq" onClick={() => setMobileOpen(false)}><LucianLanguageText value={copy("FAQ", "FAQ")} order={1} /></a>
            <LucianLanguageSwitch />
            <Link className="ow-login-button" href="/account">
              <span>{copy("Đăng nhập", "Sign in")}</span>
              <ArrowUpRight size={15} strokeWidth={1.8} aria-hidden="true" />
            </Link>
          </nav>}
          <ShapeHero
            className="ow-hero"
            headingId="ow-title"
            title={<LucianLanguageContent locale={locale} order={3} render={(shown) => <LandingHeroTitle locale={shown} />} />}
            description={<LucianLanguageContent locale={locale} order={4} render={(shown) => <LandingHeroDescription locale={shown} />} />}
            actions={<LucianStartButton onClick={start}>
              <LucianLanguageText value={copy("Bắt đầu với một từ", "Start with one word")} order={5} />
            </LucianStartButton>}
            shapes={heroShapes}
            fill={0.95}
          />
        </section>
        <LearningJourney start={start} />
        <LandingPublic start={start} />
      </main>
      <LandingFooter />
    </div>
  );
}
