// Lucian UX/UI Prompt #269 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#269
"use client";

import { AlertDialog as Dialog } from "radix-ui";
import { Button as AnimateButton } from "@animate-ui/react/primitives/buttons/button";
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { useI18n } from "./language-provider";

type ConfirmOptions = {
  title: string;
  message: string;
  confirmLabel: string;
  nameToConfirm?: string;
  notice?: boolean;
  returnFocusTo?: Element | null;
};

const ConfirmContext = createContext<((options: ConfirmOptions) => Promise<boolean>) | null>(null);

export function useConfirmAction() {
  const value = useContext(ConfirmContext);
  if (!value) throw new Error("ConfirmProvider is required");
  return value;
}

export function ConfirmProvider({ children }: { children: ReactNode }) {
  const { locale } = useI18n();
  const [active, setActive] = useState<ConfirmOptions | null>(null);
  const [typed, setTyped] = useState("");
  const resolver = useRef<((confirmed: boolean) => void) | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const previousLength = useRef(0);
  const returnFocus = useRef<HTMLElement | null>(null);

  const settle = useCallback((confirmed: boolean) => {
    const resolve = resolver.current;
    resolver.current = null;
    setActive(null);
    setTyped("");
    resolve?.(confirmed);
  }, []);

  const confirmAction = useCallback((options: ConfirmOptions) => {
    resolver.current?.(false);
    setTyped("");
    previousLength.current = 0;
    const trigger = options.returnFocusTo ?? document.activeElement;
    returnFocus.current = trigger instanceof HTMLElement ? trigger : null;
    setActive(options);
    return new Promise<boolean>((resolve) => { resolver.current = resolve; });
  }, []);

  useEffect(() => () => {
    resolver.current?.(false);
    resolver.current = null;
  }, []);

  const name = active?.nameToConfirm;
  const allowed = !name || typed === name;
  const onType = (value: string) => {
    setTyped(value);
    if (name && value.length > previousLength.current && !name.startsWith(value) && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      input.current?.classList.remove("is-shake");
      if (input.current) {
        void input.current.offsetWidth;
        input.current.classList.add("is-shake");
      }
    }
    previousLength.current = value.length;
  };

  return (
    <ConfirmContext.Provider value={confirmAction}>
      {children}
      <Dialog.Root open={!!active} onOpenChange={(open) => { if (!open) settle(false); }}>
        {active && (
          <Dialog.Portal>
            <Dialog.Overlay className="ux u269-dim" />
            <Dialog.Content className="ux u269-md" onCloseAutoFocus={active.notice ? (event) => {
              const trigger = returnFocus.current;
              if (trigger?.isConnected) {
                event.preventDefault();
                trigger.focus();
              }
            } : undefined}>
              <Dialog.Title className="u269-ht"><i aria-hidden="true">!</i>{active.title}</Dialog.Title>
              <Dialog.Description className="u269-message">{active.message}</Dialog.Description>
              {name && (
                <>
                  <p className="u269-instruction">{locale === "vi" ? "Nhập đúng từ để xác nhận:" : "Type the word to confirm:"}</p>
                  <div className="u269-nm" aria-hidden="true">
                    {Array.from(name).map((character, index) => (
                      <span key={`${index}-${character}`} className={name.slice(0, index + 1) === typed.slice(0, index + 1) && typed.length > index ? "is-ok" : ""}>{character}</span>
                    ))}
                  </div>
                  <input
                    ref={input}
                    className="u269-in"
                    value={typed}
                    onChange={(event) => onType(event.target.value)}
                    onKeyDown={(event) => { if (event.key === "Enter" && allowed) settle(true); }}
                    aria-label={locale === "vi" ? `Nhập từ ${name} để xác nhận` : `Type ${name} to confirm`}
                    autoComplete="off"
                    spellCheck={false}
                  />
                </>
              )}
              <div className="u269-bs">
                {active.notice ? (
                  <Dialog.Cancel asChild>
                    <AnimateButton type="button" className="u269-go">{active.confirmLabel}</AnimateButton>
                  </Dialog.Cancel>
                ) : (
                  <>
                    <Dialog.Cancel asChild>
                      <AnimateButton type="button" className="u269-cx" onClick={() => settle(false)}>{locale === "vi" ? "Hủy" : "Cancel"}</AnimateButton>
                    </Dialog.Cancel>
                    <Dialog.Action asChild>
                      <AnimateButton type="button" className={`u269-go${name ? " is-danger" : ""}`} disabled={!allowed} onClick={() => settle(true)}>{active.confirmLabel}</AnimateButton>
                    </Dialog.Action>
                  </>
                )}
              </div>
            </Dialog.Content>
          </Dialog.Portal>
        )}
      </Dialog.Root>
    </ConfirmContext.Provider>
  );
}
