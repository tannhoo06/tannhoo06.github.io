"use client";
import { useI18n } from "./language-provider";
import { useState, type ReactNode } from "react";
import Image from "next/image";
import { ArrowRight, LoaderCircle } from "lucide-react";
import type { Stage } from "@/lib/domain/types";
import { announceStreakAward } from "@/lib/client/learning-streak";
import { requestError } from "@/lib/client/request-error";
export type View =
  | "home"
  | "start"
  | "board"
  | "write"
  | "discover"
  | "idea"
  | "practice"
  | "insights"
  | "settings";
export type Navigate = (view: View) => void;
export type Notify = (text: string) => void;
export function recallOnlySessionKey(sessionId: string) {
  return `ownword:recall-only:${sessionId}`;
}
export const stageLabels: Record<Stage, string> = {
  new: "New",
  practicing: "Practicing",
  active: "Active",
};
export async function api<T>(path: string, body?: unknown): Promise<T> {
  const response = await fetch(`/api/${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: body === undefined ? {} : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  }).catch((error: unknown) => {
    if (error instanceof TypeError) throw new Error("Failed to fetch", { cause: error });
    throw error;
  });
  const data: unknown = await response.json().catch(() => undefined);
  if (!response.ok || data === undefined) throw requestError(response.status, data);
  announceStreakAward(response);
  return data as T;
}
export function Loading({
  text = "Getting your space ready…",
}: {
  text?: string;
}) {
  const { t } = useI18n();
  return (
    <div className="loading" role="status">
      <LoaderCircle className="spin" size={22} />
      <span>{t(text)}</span>
    </div>
  );
}
export function ErrorMessage({
  message,
  retry,
}: {
  message: string;
  retry?: () => void;
}) {
  const { t } = useI18n();
  return (
    <div className="error-message" role="alert">
      <span>{t(message)}</span>
      {retry && (
        <button className="text-button" onClick={retry}>
          {t("Try again")}
          <ArrowRight size={15} />
        </button>
      )}
    </div>
  );
}
export function Brand({ onClick }: { onClick: () => void }) {
  const { t } = useI18n();
  return (
    <button className="brand" onClick={onClick} aria-label={t("Ownword home")}>
      <Image className="brand-symbol" src="/images/ownword-brand.svg" alt="" width={64} height={64} unoptimized />
      <span>
        ownword<span className="brand-period">.</span>
      </span>
    </button>
  );
}

// Draft guards can ask a module switch to use a full navigation and its native confirmation.
export const moduleNavigationEvent = "ownword:module-navigate";
export function Button({
  children,
  onClick,
  secondary = false,
  disabled = false,
  type = "button",
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  secondary?: boolean;
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  return (
    <button
      type={type}
      className={`${secondary ? "button-secondary" : "button-primary"} ${className}`}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}
export function FriendlyDate({ value }: { value: string }) {
  const { t } = useI18n();
  const [now] = useState(() => Date.now());
  const date = new Date(value);
  const today = new Date(now);
  // Calendar labels describe the learner's day; scheduling timestamps stay intact.
  const days = Math.round(
    (Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) -
      Date.UTC(today.getFullYear(), today.getMonth(), today.getDate())) /
      86_400_000,
  );
  return (
    <>
      {days <= 0
        ? t("Today")
        : days === 1
          ? t("Tomorrow")
          : days === 7
            ? t("In 1 week")
            : t("In {days} days", { days })}
    </>
  );
}
export function ArrowUpRight() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      aria-hidden
    >
      <path d="M6 18 18 6M6 6h12v12" />
    </svg>
  );
}
