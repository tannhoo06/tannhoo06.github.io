"use client";

import { useEffect, useRef, useState, useSyncExternalStore, useTransition, type CSSProperties, type KeyboardEvent, type MouseEvent, type PointerEvent, type ReactNode } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight, BookOpen, ChevronDown, ChevronsLeft, ChevronsRight, Cloud,
  Crosshair, FileText, LogOut, Menu, Notebook, PenLine, Settings2, Sparkles, Sprout, X,
} from "lucide-react";
import type { LearningJourneySummary } from "@/lib/domain/types";
import { learningDay, type LearningStreak } from "@/lib/domain/learning-streak";
import { onStreakAward } from "@/lib/client/learning-streak";
import { LanguageSwitch, useI18n } from "./language-provider";
import { LucianLanguageSwitch } from "./lucian-267-language-switch";
import { LucianStreak } from "./lucian-379-streak";
import { api, Brand, moduleNavigationEvent, type Navigate, type View } from "./shared";
import "@/app/writing-review.css";
import "@/app/mvp-v2.css";
import "@/app/lucian-suggestions.css";
import "@/app/practice-rework.css";
import "@/app/practice-hub.css";
import "./app-navigation.css";

const collapseKey = "ownword:sidebar-collapsed";
const widthKey = "ownword:sidebar-width";
const minSidebarWidth = 222;
const maxSidebarWidth = 420;
let collapsedInMemory = false;
let widthInMemory: number | null = null;

function readCollapsed() {
  try { return localStorage.getItem(collapseKey) === "true"; }
  catch { return collapsedInMemory; }
}

function subscribeToCollapse(update: () => void) {
  window.addEventListener(collapseKey, update);
  window.addEventListener("storage", update);
  return () => {
    window.removeEventListener(collapseKey, update);
    window.removeEventListener("storage", update);
  };
}

function readSidebarWidth() {
  try {
    const value = Number(localStorage.getItem(widthKey));
    return Number.isFinite(value) && value >= minSidebarWidth && value <= maxSidebarWidth ? value : null;
  } catch { return widthInMemory; }
}

function subscribeToWidth(update: () => void) {
  window.addEventListener(widthKey, update);
  window.addEventListener("storage", update);
  return () => {
    window.removeEventListener(widthKey, update);
    window.removeEventListener("storage", update);
  };
}

function constrainSidebarWidth(width: number) {
  return Math.min(Math.max(minSidebarWidth, width), maxSidebarWidth);
}

type Account = { id?: string; name?: string; email?: string; avatarUrl?: string } | null;
type JourneyForAccount = { ownerId: string; summary: LearningJourneySummary };
let lastJourney: JourneyForAccount | undefined;

function AccountAvatar({ name, locale, src }: { name: string; locale: string; src?: string }) {
  const [failedSrc, setFailedSrc] = useState<string>();
  return (
    <span className="shell-avatar" aria-hidden="true">
      {Array.from(name)[0]?.toLocaleUpperCase(locale)}
      {src && src !== failedSrc && (
        // The verified Google URL loads directly, without an image proxy or referrer.
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" width={36} height={36} referrerPolicy="no-referrer" onError={() => setFailedSrc(src)} />
      )}
    </span>
  );
}

type ShellProps = {
  account?: Account;
  writingEnabled: boolean;
  children: ReactNode;
} & (
  | { activeModule: "vocabulary"; vocabularyView: View; navigate: Navigate; journey?: LearningJourneySummary }
  | { activeModule: "writing"; writingView: "home" | "diagnostic" | "profile" | "submission" | "focus" }
);

export function AppShell(props: ShellProps) {
  const { account, activeModule, children, writingEnabled } = props;
  const { locale, t } = useI18n();
  const vi = locale === "vi";
  const vocabulary = activeModule === "vocabulary";
  const view = vocabulary ? props.vocabularyView : undefined;
  const ownerId = account?.id;
  const [streak, setStreak] = useState<{ ownerId: string; summary: LearningStreak }>();
  const fromStudio = vocabulary ? props.journey : undefined;
  const [fetchedJourney, setFetchedJourney] = useState(() =>
    typeof window !== "undefined" && lastJourney?.ownerId === ownerId ? lastJourney : undefined);
  const journey = fromStudio ?? (fetchedJourney?.ownerId === ownerId ? fetchedJourney?.summary : undefined);
  const router = useRouter();
  const [switching, startSwitch] = useTransition();
  const displayedModule = switching ? (vocabulary ? "writing" : "vocabulary") : activeModule;
  const [drawerOpen, setDrawerOpen] = useState(false);
  const collapsed = useSyncExternalStore(subscribeToCollapse, readCollapsed, () => false);
  const savedSidebarWidth = useSyncExternalStore(subscribeToWidth, readSidebarWidth, () => null);
  const [dragWidth, setDragWidth] = useState<number | null>(null);
  const dragWidthRef = useRef<number | null>(null);
  const sidebarRef = useRef<HTMLElement>(null);
  const menuTrigger = useRef<HTMLButtonElement>(null);
  const accountMenu = useRef<HTMLDetailsElement>(null);

  useEffect(() => {
    const close = () => {
      setDrawerOpen(false);
      if (accountMenu.current) accountMenu.current.open = false;
    };
    window.addEventListener("popstate", close);
    return () => window.removeEventListener("popstate", close);
  }, []);

  useEffect(() => {
    function closeAccountOnOutsidePress(event: Event) {
      const menu = accountMenu.current;
      if (menu?.open && event.target instanceof Node && !menu.contains(event.target)) menu.open = false;
    }
    document.addEventListener("pointerdown", closeAccountOnOutsidePress);
    return () => document.removeEventListener("pointerdown", closeAccountOnOutsidePress);
  }, []);

  useEffect(() => () => { document.body.classList.remove("shell-is-resizing"); }, []);
  useEffect(() => {
    if (!ownerId) return;
    let revision = 0;
    let midnight: number;
    const update = (summary: LearningStreak) => setStreak({ ownerId, summary });
    function refresh() {
      const requested = ++revision;
      api<LearningStreak>("learning/streak").then((summary) => {
        if (requested === revision) update(summary);
      }).catch(() => {});
      window.clearTimeout(midnight);
      const now = new Date();
      const tomorrow = Date.parse(`${learningDay(now)}T00:00:00+07:00`) + 86_400_000;
      midnight = window.setTimeout(refresh, Math.max(0, tomorrow - now.getTime()));
    }
    const unsubscribe = onStreakAward((summary) => { revision++; update(summary); });
    refresh();
    window.addEventListener("focus", refresh);
    return () => {
      revision++;
      window.clearTimeout(midnight);
      window.removeEventListener("focus", refresh);
      unsubscribe();
    };
  }, [ownerId]);
  const dueCount = fromStudio?.dueCount;
  const practicedToday = fromStudio?.practicedToday;
  useEffect(() => {
    if (!ownerId) return;
    if (vocabulary) {
      if (dueCount !== undefined && practicedToday !== undefined) {
        lastJourney = { ownerId, summary: { dueCount, practicedToday } };
      }
      return;
    }
    let current = true;
    api<LearningJourneySummary>("learning/journey").then((summary) => {
      if (!current) return;
      lastJourney = { ownerId, summary };
      setFetchedJourney(lastJourney);
    }).catch(() => {});
    return () => { current = false; };
  }, [ownerId, vocabulary, dueCount, practicedToday]);

  function toggleSidebar() {
    collapsedInMemory = !collapsed;
    try { localStorage.setItem(collapseKey, String(collapsedInMemory)); } catch {}
    window.dispatchEvent(new Event(collapseKey));
  }

  function saveSidebarWidth(width: number) {
    widthInMemory = width;
    try { localStorage.setItem(widthKey, String(width)); } catch {}
    window.dispatchEvent(new Event(widthKey));
  }

  function startSidebarResize(event: PointerEvent<HTMLDivElement>) {
    if (event.button !== 0 || collapsed) return;
    event.preventDefault();
    const width = sidebarRef.current?.getBoundingClientRect().width ?? minSidebarWidth;
    dragWidthRef.current = width;
    setDragWidth(width);
    event.currentTarget.setPointerCapture(event.pointerId);
    document.body.classList.add("shell-is-resizing");
  }

  function moveSidebarResize(event: PointerEvent<HTMLDivElement>) {
    if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
    const width = constrainSidebarWidth(event.clientX);
    dragWidthRef.current = width;
    setDragWidth(width);
  }

  function finishSidebarResize(event: PointerEvent<HTMLDivElement>) {
    if (dragWidthRef.current === null) return;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    document.body.classList.remove("shell-is-resizing");
    if (dragWidthRef.current !== null) saveSidebarWidth(Math.round(dragWidthRef.current));
    dragWidthRef.current = null;
    setDragWidth(null);
  }

  function resizeSidebarWithKeyboard(event: KeyboardEvent<HTMLDivElement>) {
    const currentWidth = sidebarRef.current?.getBoundingClientRect().width ?? minSidebarWidth;
    const step = event.shiftKey ? 40 : 10;
    const nextWidth = event.key === "ArrowLeft" ? currentWidth - step
      : event.key === "ArrowRight" ? currentWidth + step
      : event.key === "Home" ? minSidebarWidth
      : event.key === "End" ? maxSidebarWidth : null;
    if (nextWidth === null) return;
    event.preventDefault();
    saveSidebarWidth(Math.round(constrainSidebarWidth(nextWidth)));
  }

  function follow(route?: View) {
    setDrawerOpen(false);
    if (accountMenu.current) accountMenu.current.open = false;
    if (vocabulary && route) props.navigate(route);
  }

  function home() {
    if (vocabulary) follow("discover");
    else window.location.assign(new URL("/writing", window.location.href));
  }

  function switchWorkspace(path: "/discover" | "/writing") {
    setDrawerOpen(false);
    if (view === "settings" || !window.dispatchEvent(new Event(moduleNavigationEvent, { cancelable: true }))) {
      window.location.assign(path);
      return;
    }
    startSwitch(() => router.push(path));
  }

  const vocabularyLabel = vi ? "Từ vựng" : "Vocabulary";
  const writingLabel = vi ? "Viết" : "Writing";
  const settingsLabel = t("Settings");
  const accountLabel = vi ? "Tài khoản" : "Account";
  const name = account?.name?.trim() || accountLabel;
  const destinations = [
    { view: "discover", label: vi ? "Khám phá" : "Discover", icon: <Sparkles size={19} />, active: view === "discover" || view === "idea" || view === "write" || view === "start" },
    { view: "practice", label: t("Practice"), icon: <Sprout size={19} />, active: view === "practice" },
    { view: "board", label: t("WordBoard"), icon: <Notebook size={19} />, active: view === "board" },
    { view: "insights", label: "WordCloud", icon: <Cloud size={19} />, active: view === "insights" },
  ] as const;

  return (
    <div className={`studio ownword-shell${vocabulary ? "" : " writing-module"}`}>
      <a className="skip-link" href="#main-content">{t("Skip to content")}</a>
      <div className="shell-frame" data-collapsed={collapsed} data-drawer-open={drawerOpen}
        style={savedSidebarWidth !== null || dragWidth !== null ? { "--shell-expanded-rail": `${dragWidth ?? savedSidebarWidth}px` } as CSSProperties : undefined}>
        <header className="shell-topbar">
          <div className="shell-mobile-brand"><Brand onClick={home} /></div>
          <nav className="shell-modules" aria-label={t("Main navigation")} data-module={displayedModule} data-single={!writingEnabled}>
            <span className="shell-module-indicator" aria-hidden="true" />
            <ShellLink href="/discover" label={vocabularyLabel} icon={<BookOpen size={19} />}
              active={vocabulary} current="location" prefetch={!vocabulary}
              onClick={vocabulary ? () => follow("discover") : () => switchWorkspace("/discover")} />
            {writingEnabled && <ShellLink href="/writing" label={writingLabel} icon={<PenLine size={19} />}
              active={!vocabulary} current="location" prefetch={vocabulary}
              onClick={vocabulary ? () => switchWorkspace("/writing") : undefined} />}
          </nav>
          <div className="shell-language"><LucianLanguageSwitch /></div>
          <button type="button" className="shell-icon-button shell-menu-trigger" ref={menuTrigger}
            aria-label={vi ? "Danh mục" : "Menu"} aria-expanded={drawerOpen} aria-controls="ownword-sidebar"
            onClick={() => setDrawerOpen((open) => !open)}
            onKeyDown={(event) => { if (event.key === "Escape") setDrawerOpen(false); }}>
            {drawerOpen ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
          </button>
        </header>
        <aside id="ownword-sidebar" className="shell-sidebar" ref={sidebarRef} aria-label={vi ? "Điều hướng ứng dụng" : "Workspace sidebar"}
          onKeyDown={(event) => {
            if (event.key === "Escape" && !event.defaultPrevented && drawerOpen) {
              setDrawerOpen(false);
              menuTrigger.current?.focus();
            }
          }}>
          <div className="shell-rail-header">
            <Brand onClick={home} />
            <button className="shell-icon-button shell-collapse" type="button" onClick={toggleSidebar}
              aria-expanded={!collapsed} aria-controls="ownword-sidebar-links"
              aria-label={collapsed ? (vi ? "Mở rộng thanh bên" : "Expand sidebar") : (vi ? "Thu gọn thanh bên" : "Collapse sidebar")}
              title={collapsed ? (vi ? "Mở rộng thanh bên" : "Expand sidebar") : (vi ? "Thu gọn thanh bên" : "Collapse sidebar")}>
              {collapsed ? <ChevronsRight size={17} aria-hidden="true" /> : <ChevronsLeft size={17} aria-hidden="true" />}
            </button>
          </div>
          <div className="shell-rail-body" id="ownword-sidebar-links">
            {vocabulary ? (
                <nav className="shell-section" aria-label={vi ? "Điều hướng từ vựng" : "Vocabulary navigation"}>
                  <h2 className="shell-section-label">{vi ? "Mục từ vựng" : "Vocabulary"}</h2>
                  {destinations.map(({ view, ...item }) => <ShellLink key={view} href={`/${view}`} {...item} onClick={() => follow(view)} />)}
                </nav>
            ) : (
              <nav className="shell-section" aria-label={vi ? "Điều hướng viết" : "Writing navigation"}>
                <h2 className="shell-section-label">{vi ? "Góc viết" : "Writing workspace"}</h2>
                <ShellLink href="/writing" label={vi ? "Tổng quan" : "Overview"} icon={<PenLine size={19} />}
                  active={props.writingView === "home" || props.writingView === "diagnostic"} />
                <ShellLink href="/writing/profile" label={vi ? "Hồ sơ viết" : "Writing Profile"} icon={<FileText size={19} />}
                  active={props.writingView === "profile" || props.writingView === "submission"} />
                <ShellLink href="/writing/focus" label={vi ? "Trọng tâm" : "Focus"} icon={<Crosshair size={19} />}
                  active={props.writingView === "focus"} />
              </nav>
            )}
            <section className="shell-section shell-journey" aria-label={vi ? "Hành trình học tập" : "Learning journey"}>
              <h2 className="shell-section-label">{vi ? "Hành trình học tập" : "Learning journey"}</h2>
              <LucianStreak streak={streak?.ownerId === ownerId ? streak?.summary : undefined} vi={vi} />
              <ShellLink href="/practice" className="shell-resume" onClick={vocabulary ? () => follow("practice") : undefined}
                icon={<BookOpen size={19} />} label={vi ? "Đến trang luyện từ vựng" : "Go to vocabulary practice"}
                detail={journey?.dueCount ? (vi ? `${journey.dueCount} từ sẵn sàng luyện`
                  : `${journey.dueCount} ${journey.dueCount === 1 ? "word" : "words"} ready to practice`)
                  : undefined} />
            </section>
          </div>
          <footer className="shell-rail-footer">
            <div className="shell-drawer-language">
              <span aria-hidden="true">{vi ? "Ngôn ngữ" : "Language"}</span>
              <LanguageSwitch />
            </div>
            <details className="shell-account" ref={accountMenu}
              onBlur={(event) => {
                if (event.relatedTarget && !event.currentTarget.contains(event.relatedTarget)) event.currentTarget.open = false;
              }}
              onKeyDown={(event) => {
                if (event.key === "Escape" && event.currentTarget.open) {
                  event.preventDefault();
                  event.currentTarget.open = false;
                  event.currentTarget.querySelector("summary")?.focus();
                }
              }}>
              <summary aria-label={accountLabel} title={accountLabel}>
                <AccountAvatar name={name} locale={locale} src={account?.avatarUrl} />
                <span className="shell-account-copy">{name}</span>
                <ChevronDown size={16} className="shell-account-chevron" aria-hidden="true" />
              </summary>
              <div className="shell-account-panel">
                <div className="shell-account-profile">
                  <AccountAvatar name={name} locale={locale} src={account?.avatarUrl} />
                  <div className="shell-account-identity">
                    <strong>{name}</strong>
                    {account?.email && <small>{account.email}</small>}
                  </div>
                </div>
                <div className="shell-account-links">
                  <ShellLink href="/settings" icon={<Settings2 size={17} />} label={settingsLabel}
                    active={view === "settings"} onClick={vocabulary ? () => follow("settings") : undefined} />
                </div>
                <div className="shell-account-links">
                  <ShellLink href="/auth/signout?return_to=/" target="_top" icon={<LogOut size={17} />} label={vi ? "Đăng xuất" : "Sign out"} />
                </div>
              </div>
            </details>
          </footer>
          {!collapsed && <div className="shell-resize-handle" role="separator" tabIndex={0}
            aria-label={vi ? "Thay đổi độ rộng thanh bên" : "Resize sidebar"}
            aria-orientation="vertical" aria-valuemin={minSidebarWidth}
            aria-valuemax={maxSidebarWidth}
            aria-valuenow={Math.round(dragWidth ?? savedSidebarWidth ?? 280)}
            onPointerDown={startSidebarResize} onPointerMove={moveSidebarResize}
            onPointerUp={finishSidebarResize} onPointerCancel={finishSidebarResize}
            onLostPointerCapture={finishSidebarResize}
            onKeyDown={resizeSidebarWithKeyboard} />}
        </aside>
        <div className="shell-content">{children}</div>
      </div>
    </div>
  );
}

function ShellLink({ href, label, icon, onClick, active, current = "page", className = "", detail, target, prefetch = false }: {
  href: string; label: string; icon: ReactNode; onClick?: () => void; active?: boolean;
  current?: "page" | "location"; className?: string; detail?: string; target?: string; prefetch?: boolean;
}) {
  const props = {
    href, target, className: `shell-link ${className}`, title: label,
    "aria-label": label, "aria-current": active ? current : undefined,
    onClick: onClick ? (event: MouseEvent<HTMLAnchorElement>) => {
      if (!event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey && event.button === 0) {
        event.preventDefault();
        onClick();
      }
    } : undefined,
  };
  const content = (
    <>
      <span className="shell-link-icon" aria-hidden="true">{icon}</span>
      <span className="shell-link-copy">{label}{detail && <small>{detail}</small>}</span>
      {detail && <ArrowRight className="shell-link-arrow" size={17} aria-hidden="true" />}
    </>
  );
  return prefetch ? <Link {...props} prefetch>{content}</Link> : <a {...props}>{content}</a>;
}
