"use client";
import { useI18n } from "./language-provider";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import { Check, X } from "lucide-react";
import { motion } from "motion/react";
import { useMotionTokens, useShouldReduceMotion } from "@animate-ui/react/utils/motion";
import type { AppState, PracticeSetupOptions, UserWord } from "@/lib/domain/types";
import {
  api,
  ErrorMessage,
  Loading,
  recallOnlySessionKey,
  type Navigate,
  type Notify,
  type View,
} from "./shared";
import { Board, WordDetail } from "./wordboard";
import { Writing } from "./writing";
import { Discover } from "./discover";
import { IdeaDiscovery } from "./idea-discovery";
import { Practice } from "./practice";
import { Settings } from "./preferences";
import { Insights } from "./lucian-399-word-cloud";
import { AppShell } from "./app-navigation";
import { useRequestLimitNotice } from "./request-limit-notice";
export function Studio({
  initialView,
  signedIn,
  account,
  writingEnabled = false,
}: {
  initialView: View;
  signedIn: boolean;
  account?: { id: string; name: string; email: string; avatarUrl?: string } | null;
  writingEnabled?: boolean;
}) {
  const { t, locale } = useI18n();
  const { handle: showLimit } = useRequestLimitNotice();
  const { transition } = useMotionTokens();
  const reduceMotion = useShouldReduceMotion();
  const [view, setView] = useState<View>(initialView);
  const [state, setState] = useState<AppState | null>(null);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [selected, setSelected] = useState<UserWord | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [practiceBusy, setPracticeBusy] = useState(false);
  const completePractice = useCallback(() => setSessionId(null), []);
  const opener = useRef<HTMLElement | null>(null);
  const [hasNavigated, setHasNavigated] = useState(false);
  const navigate = useCallback<Navigate>((next) => {
    if (
      !window.dispatchEvent(
        new Event("ownword:before-navigate", { cancelable: true }),
      )
    )
      return;
    setHasNavigated(true);
    setView(next);
    window.history.pushState({}, "", next === "home" ? "/" : `/${next}`);
    window.scrollTo({ top: 0 });
    setError("");
  }, []);
  useEffect(() => {
    if (state?.profile.id)
      queueMicrotask(() =>
        setSessionId(
          sessionStorage.getItem(`ownword:session:${state.profile.id}`),
        ),
      );
  }, [state?.profile.id]);
  const loaded = !!state;
  useEffect(() => {
    const labels: Record<View, string> = {
      home: "Ownword",
      start: t("Find words for your draft"),
      board: t("WordBoard"),
      write: t("Find words for your draft"),
      discover: locale === "vi" ? "Khám phá" : "Discover",
      idea: t("Find a word for what you mean"),
      practice: t("Practice"),
      insights: "WordCloud",
      settings: t("Settings"),
    };
    document.title = `${labels[view]} | Ownword`;
  }, [view, t, locale]);
  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      const heading = document.querySelector<HTMLElement>(`#main-content [data-route-view="${view}"] h1`);
      if (heading) {
        heading.tabIndex = -1;
        heading.focus({ preventScroll: true });
      }
    });
    return () => cancelAnimationFrame(frame);
  }, [view, loaded]);
  const notify = useCallback<Notify>((text) => setToast(text), []);
  const refresh = useCallback(async () => {
    const next = await api<AppState>("state");
    setState(next);
    return next;
  }, []);
  useEffect(() => {
    if (!signedIn || !state?.words.some((word) => !word.definition.trim())) return;
    const timer = window.setInterval(() => {
      if (!document.hidden) void refresh().catch(() => {});
    }, 5000);
    return () => window.clearInterval(timer);
  }, [signedIn, state?.words, refresh]);
  useEffect(() => {
    if (!signedIn) return;
    Promise.resolve().then(refresh).catch((e) => setError(e.message));
  }, [signedIn, refresh]);
  useEffect(() => {
    const onPop = () => {
      if (
        !window.dispatchEvent(
          new Event("ownword:before-navigate", { cancelable: true }),
        )
      ) {
        window.history.forward();
        return;
      }
      setHasNavigated(true);
      const path = window.location.pathname.slice(1) || "home";
      if (signedIn && path === "home") {
        window.history.replaceState({}, "", "/discover");
        setView("discover");
        return;
      }
      if (
        [
          "home",
          "start",
          "board",
          "write",
          "discover",
          "idea",
          "practice",
          "insights",
          "settings",
        ].includes(path)
      )
        setView(path as View);
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [signedIn]);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 4500);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("word");
    if (view === "board" && id && state)
      queueMicrotask(() =>
        setSelected(state.words.find((word) => word.userWordId === id) ?? null),
      );
  }, [view, state]);
  async function practice(wordId?: string, quickSessionId?: string, fresh = false, setup?: PracticeSetupOptions) {
    const unfinished = sessionStorage.getItem(
      `ownword:session:${state?.profile.id}`,
    );
    if (!fresh && !wordId && !quickSessionId && unfinished) {
      setSessionId(unfinished);
      navigate("practice");
      return true;
    }
    const trigger = document.activeElement;
    setPracticeBusy(true);
    setError("");
    try {
      const result = await api<{ sessionId: string }>(
        "practice/start",
        quickSessionId ? { quickSessionId } : wordId ? { wordId } : setup ? { wordIds: setup.wordIds } : {},
      );
      if (setup && !setup.includeWriting)
        sessionStorage.setItem(recallOnlySessionKey(result.sessionId), "1");
      setSessionId(result.sessionId);
      sessionStorage.setItem(
        `ownword:session:${state?.profile.id}`,
        result.sessionId,
      );
      setSelected(null);
      navigate("practice");
      return true;
    } catch (e) {
      if (!showLimit(e, trigger)) notify((e as Error).message);
      return false;
    } finally {
      setPracticeBusy(false);
    }
  }
  async function demo() {
    if (!signedIn) {
      window.location.assign(
        "/auth/signin?return_to=%2Fboard%3Fdemo%3D1",
      );
      return;
    }
    try {
      await api("demo/seed", {});
      await refresh();
      navigate("board");
    } catch (e) {
      setError((e as Error).message);
    }
  }
  const seedOnce = useRef(false);
  async function removeWord(id: string) {
    await api("words/remove", { id });
    setState((current) =>
      current
        ? {
            ...current,
            words: current.words.filter((word) => word.userWordId !== id),
            dueCount: Math.max(
              0,
              current.dueCount -
                (current.words.find((word) => word.userWordId === id)
                  ?.introducedAt
                  ? 1
                  : 0),
            ),
            queuedCount: Math.max(
              0,
              current.queuedCount -
                (current.words.find((word) => word.userWordId === id)
                  ?.introducedAt
                  ? 0
                  : 1),
            ),
          }
        : current,
    );
    setSelected(null);
    if (state?.profile.id) {
      try {
        sessionStorage.removeItem(`ownword:session:${state.profile.id}`);
      } catch {}
      setSessionId(null);
    }
    notify(t("Word removed from WordBoard."));
    refresh().catch((error) => notify((error as Error).message));
  }
  useEffect(() => {
    if (
      signedIn &&
      state &&
      new URLSearchParams(window.location.search).get("demo") === "1" &&
      !seedOnce.current
    ) {
      seedOnce.current = true;
      demo();
    }
  });
  return (
    <AppShell activeModule="vocabulary" vocabularyView={view} navigate={navigate}
      journey={state ? { dueCount: state.dueCount, practicedToday: state.practicedToday ?? false } : undefined}
      writingEnabled={writingEnabled} account={{ ...account, name: state?.profile.name ?? account?.name }}>
      <div className="workspace">
        {toast && (
          <div className="toast" role="status">
            <Check size={17} />
            {t(toast)}
            <button
              aria-label={t("Dismiss notification")}
              onClick={() => setToast("")}
            >
              <X size={15} />
            </button>
          </div>
        )}
        <main id="main-content" className={`main-content view-${view}`}>
          <motion.div
            key={view}
            data-route-view={view}
            initial={hasNavigated ? { opacity: 0.7, y: reduceMotion ? 0 : 8 } : false}
            animate={{ opacity: 1, y: 0, transition: transition.reveal }}
          >
          {error ? (
            <ErrorMessage
              message={error}
              retry={() => {
                setError("");
                refresh().catch((e) => setError(e.message));
              }}
            />
          ) : !state ? (
            <Loading />
          ) : (
            <>
              {view === "board" && (
                <Board
                  state={state}
                  select={(word) => {
                    opener.current = document.activeElement as HTMLElement;
                    setSelected(word);
                  }}
                  addWord={() => navigate("discover")}
                />
              )}
              {view === "discover" && (
                <Discover refresh={refresh} navigate={navigate} />
              )}
              {view === "idea" && (
                <IdeaDiscovery state={state} refresh={refresh} navigate={navigate} />
              )}
              {(view === "write" || view === "start") && (
                <Writing
                  key={view}
                  onboarding={view === "start"}
                  mock={state.mockMode}
                  userId={state.profile.id}
                  refresh={refresh}
                  notify={notify}
                  navigate={navigate}
                  practice={practice}
                />
              )}
              {view === "practice" && (
                <Practice
                  sessionId={sessionId}
                  state={state}
                  begin={practice}
                  busy={practiceBusy}
                  navigate={navigate}
                  refresh={refresh}
                  onComplete={completePractice}
                />
              )}
              {view === "insights" && (
                <Insights
                  state={state}
                  navigate={navigate}
                />
              )}
              {view === "settings" && (
                <Settings state={state} refresh={refresh} notify={notify} />
              )}
            </>
          )}
          </motion.div>
        </main>
      </div>
      <WordDetail
        key={selected?.userWordId ?? "empty"}
        word={selected ? state?.words.find((word) => word.userWordId === selected.userWordId) ?? selected : null}
        origin={opener}
        close={() => setSelected(null)}
        practice={practice}
        busy={practiceBusy}
        restoreFocus={() => {
          if (opener.current?.isConnected) opener.current.focus();
          else document.querySelector<HTMLElement>("#main-content h1")?.focus();
        }}
        remove={removeWord}
      />
    </AppShell>
  );
}
