// Lucian UX/UI Prompt #267 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#267
"use client";

import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import type { Locale } from "@/lib/i18n/messages";
import { useI18n } from "./language-provider";

const languages: { locale: Locale; code: string; name: string }[] = [
  { locale: "vi", code: "VI", name: "Tiếng Việt" },
  { locale: "en", code: "EN", name: "English" },
];

function useSwappedValue<T>(value: T, order: number) {
  const [shown, setShown] = useState(value);
  const [phase, setPhase] = useState("");
  const previous = useRef(value);

  useEffect(() => {
    if (previous.current === value) return;
    previous.current = value;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      queueMicrotask(() => {
        setShown(value);
        setPhase("");
      });
      return;
    }
    const delay = order * 45;
    const leaving = window.setTimeout(() => setPhase("is-go"), delay);
    const entering = window.setTimeout(() => {
      setShown(value);
      setPhase("is-in");
    }, delay + 260);
    const finishing = window.setTimeout(() => setPhase(""), delay + 640);
    return () => {
      window.clearTimeout(leaving);
      window.clearTimeout(entering);
      window.clearTimeout(finishing);
    };
  }, [value, order]);

  return { shown, phase };
}

export function LucianLanguageText({ value, order = 0, block = false }: { value: string; order?: number; block?: boolean }) {
  const { shown, phase } = useSwappedValue(value, order);
  return <span className={`u267-sw${block ? " u267-sw-block" : ""} ${phase}`}><span>{shown}</span></span>;
}

export function LucianLanguageContent({ locale, render, order = 0 }: { locale: Locale; render: (locale: Locale) => ReactNode; order?: number }) {
  const { shown, phase } = useSwappedValue(locale, order);
  return <span className={`u267-sw u267-sw-block ${phase}`}><span>{render(shown)}</span></span>;
}

export function LucianLanguageSwitch() {
  const { locale, setLocale } = useI18n();
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const menuId = useId();
  const current = languages.find((language) => language.locale === locale) ?? languages[0];

  useEffect(() => {
    if (!open) return;
    const closeOutside = (event: PointerEvent) => {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", closeOutside);
    return () => document.removeEventListener("pointerdown", closeOutside);
  }, [open]);

  const focusOption = (index: number) => {
    root.current?.querySelectorAll<HTMLButtonElement>(".u267-op")[index]?.focus();
  };
  const choose = (next: Locale) => {
    setLocale(next);
    setOpen(false);
    trigger.current?.focus();
  };

  return (
    <div ref={root} className={`ux u267${open ? " is-open" : ""}`}>
      <button
        ref={trigger}
        type="button"
        className="u267-gb"
        aria-label={locale === "vi" ? `Ngôn ngữ giao diện: ${current.name}` : `Interface language: ${current.name}`}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={menuId}
        onClick={() => setOpen((value) => !value)}
        onKeyDown={(event) => {
          if (event.key === "ArrowDown" || event.key === "ArrowUp") {
            event.preventDefault();
            setOpen(true);
            requestAnimationFrame(() => focusOption(event.key === "ArrowDown" ? languages.findIndex((language) => language.locale === locale) : languages.length - 1));
          }
        }}
      >
        <svg viewBox="0 0 14 14" aria-hidden="true"><circle cx="7" cy="7" r="5.5" fill="none" stroke="currentColor" strokeWidth="1.3"/><path d="M1.5 7h11M7 1.5c1.8 1.6 1.8 9.4 0 11M7 1.5c-1.8 1.6-1.8 9.4 0 11" fill="none" stroke="currentColor" strokeWidth="1.3"/></svg>
        <LucianLanguageText value={current.code} />
      </button>
      <div id={menuId} className="u267-dd" role="listbox" aria-label={locale === "vi" ? "Chọn ngôn ngữ" : "Choose language"} aria-hidden={!open} inert={!open}>
        {languages.map((language, index) => (
          <button
            key={language.locale}
            type="button"
            className={`u267-op${language.locale === locale ? " is-on" : ""}`}
            role="option"
            aria-selected={language.locale === locale}
            lang={language.locale}
            onClick={() => choose(language.locale)}
            onKeyDown={(event) => {
              if (event.key === "Escape") {
                event.preventDefault();
                setOpen(false);
                trigger.current?.focus();
              } else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
                event.preventDefault();
                focusOption((index + (event.key === "ArrowDown" ? 1 : languages.length - 1)) % languages.length);
              } else if (event.key === "Home" || event.key === "End") {
                event.preventDefault();
                focusOption(event.key === "Home" ? 0 : languages.length - 1);
              } else if (event.key === "Tab") {
                setOpen(false);
              }
            }}
          >
            <span>{language.name}</span>
            <svg viewBox="0 0 14 14" aria-hidden="true"><path d="M2.5 7.5l3 3 6-6.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        ))}
      </div>
    </div>
  );
}
