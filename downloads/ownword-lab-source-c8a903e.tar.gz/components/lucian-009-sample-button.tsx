// Lucian UX/UI Prompt #009 · MIT License (c) 2026 Seokwoooo · https://lucianlabs.dev/uxui-prompt/#009

export function SampleToggle({ label }: { label: string }) {
  return (
    <summary className="ux writing-samples-toggle u009-btn">
      <span className="u009-fill" aria-hidden="true" />
      <span className="u009-word">{label}</span>
      <span className="u009-orb" aria-hidden="true">
        <svg viewBox="0 0 24 24"><path d="M5 5l14 14M11 19h8v-8" /></svg>
        <svg viewBox="0 0 24 24"><path d="M5 5l14 14M11 19h8v-8" /></svg>
      </span>
    </summary>
  );
}
