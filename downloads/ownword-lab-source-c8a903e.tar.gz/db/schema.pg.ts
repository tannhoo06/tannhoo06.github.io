import { sql } from "drizzle-orm";
import {
  pgTable,
  text,
  integer,
  boolean,
  jsonb,
  doublePrecision,
  uniqueIndex,
  unique,
  index,
  primaryKey,
  foreignKey,
  check,
} from "drizzle-orm/pg-core";
import type { ConceptDiscovery, SourceAnchor, WritingReview } from "../lib/domain/types";
import type { DiagnosticReport } from "../lib/writing/contracts";
import type { WritingRevisionCheck } from "../lib/writing/revision-check";
import type { WritingAssistance, WritingRunStatus, WritingTaskSnapshot } from "../lib/writing/persistence";

export const users = pgTable("app_user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: text("created_at").notNull(),
  dailyLimit: integer("daily_limit").notNull().default(6),
  onboarded: boolean("onboarded").notNull().default(false),
});
export const learningActivityDays = pgTable("learning_activity_day", {
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  day: text("day").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.day] })]);

export const manualWordChecks = pgTable("manual_word_check", {
  userId: text("user_id").notNull().references(() => users.id),
  word: text("word").notNull(),
  status: text("status", { enum: ["valid", "correction", "invalid", "uncertain"] }).notNull(),
  suggestion: text("suggestion"),
  checkedAt: text("checked_at").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.word] })]);
export const words = pgTable("word", {
  id: text("id").primaryKey(),
  word: text("word").notNull().unique(),
  partOfSpeech: text("part_of_speech").notNull(),
  definition: text("definition").notNull(),
  nuance: text("nuance").notNull(),
  collocations: jsonb("collocations")
    .$type<string[]>()
    .notNull(),
  examples: jsonb("examples").$type<string[]>().notNull(),
  enrichmentAttempts: integer("enrichment_attempts").notNull().default(0),
  enrichmentNextAt: text("enrichment_next_at"),
});
export const userWords = pgTable(
  "user_word",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id),
    wordId: text("word_id")
      .notNull()
      .references(() => words.id),
    stage: text("stage", { enum: ["new", "practicing", "active"] })
      .notNull()
      .default("new"),
    addedAt: text("added_at").notNull(),
    introducedAt: text("introduced_at"),
    nextReviewAt: text("next_review_at").notNull(),
    source: text("source").notNull(),
    sourceText: text("source_text").notNull(),
    lexemeOverride: jsonb("lexeme_override").$type<Pick<import("../lib/domain/types").Lexeme, "partOfSpeech" | "definition" | "nuance" | "collocations" | "examples"> | null>(),
    demo: boolean("demo").notNull().default(false),
    removedAt: text("removed_at"),
  },
  (t) => [
    uniqueIndex("user_word_owner_lexeme").on(t.userId, t.wordId),
    index("user_word_due").on(t.userId, t.nextReviewAt),
  ],
);
export const writingSamples = pgTable(
  "writing_sample",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id),
    text: text("text").notNull(),
    prompt: text("prompt").notNull(),
    createdAt: text("created_at").notNull(),
  },
  (t) => [index("writing_owner").on(t.userId)],
);
export const conceptDiscoveries = pgTable(
  "concept_discovery",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id),
    concept: text("concept").notNull(),
    candidates: jsonb("candidates").$type<ConceptDiscovery["candidates"]>().notNull(),
    createdAt: text("created_at").notNull(),
  },
  (t) => [index("concept_discovery_owner_created").on(t.userId, t.createdAt)],
);
export const suggestions = pgTable("vocabulary_suggestion", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id),
  sampleId: text("sample_id")
    .notNull()
    .references(() => writingSamples.id),
  word: text("word").notNull(),
  partOfSpeech: text("part_of_speech").notNull(),
  definition: text("definition").notNull(),
  nuance: text("nuance").notNull(),
  collocations: jsonb("collocations")
    .$type<string[]>()
    .notNull(),
  examples: jsonb("examples").$type<string[]>().notNull(),
  originalText: text("original_text").notNull(),
  reason: text("reason").notNull(),
  confidence: doublePrecision("confidence").notNull(),
  source: jsonb("source_anchor").$type<SourceAnchor>(),
  suggestedSentence: text("suggested_sentence"),
  savedWordId: text("saved_word_id"),
  queued: boolean("queued"),
  ownsSavedWord: boolean("owns_saved_word"),
  status: text("status", { enum: ["pending", "added", "dismissed", "already"] })
    .notNull()
    .default("pending"),
});
export const writingReviews = pgTable("writing_review", {
  sampleId: text("sample_id")
    .primaryKey()
    .references(() => writingSamples.id),
  userId: text("user_id")
    .notNull()
    .references(() => users.id),
  review: jsonb("review").$type<WritingReview>().notNull(),
});
export const sessions = pgTable("practice_session", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id),
  createdAt: text("created_at").notNull(),
});
export const exercises = pgTable("exercise", {
  id: text("id").primaryKey(),
  sessionId: text("session_id")
    .notNull()
    .references(() => sessions.id),
  userId: text("user_id")
    .notNull()
    .references(() => users.id),
  userWordId: text("user_word_id")
    .notNull()
    .references(() => userWords.id),
  kind: text("kind").notNull(),
  prompt: text("prompt").notNull(),
  context: text("context").notNull(),
  semanticHint: text("semantic_hint").notNull(),
  hint: text("hint").notNull().default("none"),
  sentencePending: boolean("sentence_pending")
    .notNull()
    .default(false),
  position: integer("position").notNull(),
  answeredAt: text("answered_at"),
});
export const attempts = pgTable(
  "practice_attempt",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id),
    userWordId: text("user_word_id")
      .notNull()
      .references(() => userWords.id),
    exerciseId: text("exercise_id").notNull().unique(),
    at: text("at").notNull(),
    kind: text("kind").notNull(),
    hint: text("hint").notNull(),
    answer: text("answer").notNull(),
    retrieved: boolean("retrieved").notNull(),
    precise: boolean("precise").notNull(),
    majorMisuse: boolean("major_misuse").notNull(),
    context: text("context").notNull(),
    feedback: text("feedback").notNull(),
    spellingCorrection: text("spelling_correction"),
  },
  (t) => [index("attempt_word_time").on(t.userWordId, t.at)],
);
export const insights = pgTable(
  "insight",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id),
    phrase: text("phrase").notNull(),
    count: integer("count").notNull(),
    alternatives: jsonb("alternatives")
      .$type<{ word: string; meaning: string }[]>()
      .notNull(),
    updatedAt: text("updated_at").notNull(),
  },
  (t) => [uniqueIndex("insight_owner_phrase").on(t.userId, t.phrase)],
);
export const rateLimits = pgTable("request_limit", {
  id: text("id").primaryKey(),
  count: integer("count").notNull(),
});
export const llmKeyRotation = pgTable("llm_key_rotation", {
  id: text("id").primaryKey(),
  position: integer("position").notNull(),
});

export const writingTasks = pgTable("writing_task", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  clientRequestId: text("client_request_id").notNull(),
  promptId: text("prompt_id").notNull(),
  promptVersion: text("prompt_version").notNull(),
  snapshot: jsonb("snapshot").$type<WritingTaskSnapshot>().notNull(),
  createdAt: text("created_at").notNull(),
}, (t) => [
  unique("writing_task_owner_id").on(t.userId, t.id),
  uniqueIndex("writing_task_owner_request").on(t.userId, t.clientRequestId),
]);

export const writingSubmissions = pgTable("writing_submission", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  taskId: text("task_id").notNull(),
  clientRequestId: text("client_request_id").notNull(),
  parentSubmissionId: text("parent_submission_id"),
  text: text("text").notNull(),
  wordCount: integer("word_count").notNull(),
  assistance: text("assistance").$type<WritingAssistance>().notNull(),
  createdAt: text("created_at").notNull(),
}, (t) => [
  unique("writing_submission_owner_task_id").on(t.userId, t.taskId, t.id),
  uniqueIndex("writing_submission_owner_request").on(t.userId, t.clientRequestId),
  uniqueIndex("writing_submission_one_original").on(t.userId, t.taskId)
    .where(sql`${t.parentSubmissionId} is null`),
  index("writing_submission_parent").on(t.userId, t.taskId, t.parentSubmissionId),
  foreignKey({
    name: "writing_submission_owned_task_fk",
    columns: [t.userId, t.taskId],
    foreignColumns: [writingTasks.userId, writingTasks.id],
  }).onDelete("cascade"),
  foreignKey({
    name: "writing_submission_owned_parent_fk",
    columns: [t.userId, t.taskId, t.parentSubmissionId],
    foreignColumns: [t.userId, t.taskId, t.id],
  }).onDelete("cascade"),
  check("writing_submission_assistance", sql`${t.assistance} in ('unassisted', 'external_help', 'ownword_hint', 'unknown')`),
  check("writing_submission_word_count", sql`${t.wordCount} >= 0`),
  check("writing_submission_parent_not_self", sql`${t.parentSubmissionId} <> ${t.id}`),
]);

export const writingRuns = pgTable("writing_run", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  taskId: text("task_id").notNull(),
  submissionId: text("submission_id").notNull(),
  idempotencyKey: text("idempotency_key").notNull(),
  purpose: text("purpose", { enum: ["diagnostic"] }).notNull().default("diagnostic"),
  status: text("status").$type<WritingRunStatus>().notNull(),
  quotaDay: text("quota_day").notNull(),
  leaseExpiresAt: text("lease_expires_at").notNull(),
  startedAt: text("started_at").notNull(),
  finishedAt: text("finished_at"),
  report: jsonb("report").$type<DiagnosticReport>(),
}, (t) => [
  uniqueIndex("writing_run_owner_request").on(t.userId, t.idempotencyKey),
  uniqueIndex("writing_run_one_active").on(t.userId, t.submissionId, t.purpose)
    .where(sql`${t.status} in ('pending', 'succeeded')`),
  index("writing_run_submission").on(t.userId, t.taskId, t.submissionId, t.startedAt),
  index("writing_run_quota").on(t.userId, t.purpose, t.quotaDay, t.status, t.leaseExpiresAt),
  foreignKey({
    name: "writing_run_owned_submission_fk",
    columns: [t.userId, t.taskId, t.submissionId],
    foreignColumns: [writingSubmissions.userId, writingSubmissions.taskId, writingSubmissions.id],
  }).onDelete("cascade"),
  check("writing_run_diagnostic", sql`${t.purpose} = 'diagnostic'`),
  check("writing_run_state", sql`
    (${t.status} = 'pending' and ${t.finishedAt} is null and ${t.report} is null)
    or (${t.status} in ('failed', 'expired') and ${t.finishedAt} is not null and ${t.report} is null)
    or (${t.status} = 'succeeded' and ${t.finishedAt} is not null and ${t.report} is not null)
  `),
]);

export const writingRevisionChecks = pgTable("writing_revision_check", {
  revisionId: text("revision_id").primaryKey().references(() => writingSubmissions.id, { onDelete: "cascade" }),
  leaseToken: text("lease_token"),
  leaseExpiresAt: text("lease_expires_at"),
  result: jsonb("result").$type<WritingRevisionCheck>(),
  checkedAt: text("checked_at"),
}, (t) => [
  check("writing_revision_check_state", sql`
    (${t.leaseToken} is not null and ${t.leaseExpiresAt} is not null and ${t.result} is null)
    or (${t.leaseToken} is null and ${t.leaseExpiresAt} is null and ${t.result} is not null)
  `),
]);

export const writingProfileAnalyses = pgTable("writing_profile_analysis", {
  userId: text("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  evidenceKey: text("evidence_key").notNull(),
  leaseToken: text("lease_token"),
  nextAttemptAt: text("next_attempt_at").notNull(),
  updatedAt: text("updated_at").notNull(),
  result: text("result"),
}, (t) => [check("writing_profile_analysis_result", sql`${t.leaseToken} is null or ${t.result} is null`)]);

export const writingFocusStates = pgTable("writing_focus_state", {
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  problemKey: text("problem_key").notNull(),
  status: text("status", { enum: ["active", "dismissed"] }).notNull(),
}, (t) => [
  primaryKey({ columns: [t.userId, t.problemKey] }),
  check("writing_focus_status", sql`${t.status} in ('active', 'dismissed')`),
]);
