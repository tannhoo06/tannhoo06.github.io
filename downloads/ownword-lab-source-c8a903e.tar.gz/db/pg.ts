import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import * as schema from "./schema.pg";

let pool: Pool | undefined;

export function getPgDb() {
  const connectionString = process.env.DATABASE_URL;
  const host = process.env.DB_HOST;
  if (!connectionString && !host) throw new Error("DATABASE_URL or DB_HOST is required for PostgreSQL.");
  pool ??= new Pool({
    ...(connectionString ? { connectionString } : {
      host, port: Number(process.env.DB_PORT ?? 5432), user: process.env.DB_USER,
      password: process.env.DB_PASSWORD, database: process.env.DB_NAME ?? "ownword",
    }),
    max: 5,
    ssl: process.env.PGSSLMODE === "disable" ? false : { rejectUnauthorized: true },
  });
  return drizzle(pool, { schema });
}

export async function closePgDb() {
  if (pool) {
    const closing = pool;
    pool = undefined;
    await closing.end();
  }
}
