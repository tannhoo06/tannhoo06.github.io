import { cookies } from "next/headers";
import { createRemoteJWKSet, jwtVerify } from "jose";
import type { ChatGPTUser } from "@/app/chatgpt-auth";
import { cognitoOwnerId } from "./cognito-owner";
import { googleAvatarUrl } from "./google-avatar";

export const SESSION_COOKIE = "ownword_session";
export const LOGIN_COOKIE = "ownword_login";

export function publicOrigin(requestUrl: string): URL {
  const configured = new URL(process.env.APP_ORIGIN ?? requestUrl);
  const origin = new URL(configured.origin);
  if (origin.protocol !== "https:" && origin.hostname !== "localhost")
    throw new Error("APP_ORIGIN must use HTTPS.");
  return origin;
}

export function cognitoConfig() {
  const issuer = process.env.COGNITO_ISSUER;
  const clientId = process.env.COGNITO_CLIENT_ID;
  const domain = process.env.COGNITO_DOMAIN;
  if (!issuer || !clientId || !domain) throw new Error("Cognito is not configured.");
  const issuerUrl = new URL(issuer);
  const domainUrl = new URL(domain);
  if (issuerUrl.protocol !== "https:" || domainUrl.protocol !== "https:")
    throw new Error("Cognito URLs must use HTTPS.");
  return { issuer: issuerUrl.toString().replace(/\/$/, ""), clientId, domain: domainUrl.toString().replace(/\/$/, "") };
}

export function safeReturnTo(value: string | null): string {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/";
  try {
    const url = new URL(value, "https://ownword.local");
    if (url.origin !== "https://ownword.local" || url.pathname.startsWith("/auth/")) return "/";
    return url.pathname + url.search + url.hash;
  } catch { return "/"; }
}

export async function verifyIdToken(token: string): Promise<ChatGPTUser | null> {
  const config = cognitoConfig();
  try {
    const jwks = createRemoteJWKSet(new URL(`${config.issuer}/.well-known/jwks.json`));
    const { payload } = await jwtVerify(token, jwks, { issuer: config.issuer, audience: config.clientId });
    if (payload.token_use !== "id" || typeof payload.sub !== "string" || typeof payload.email !== "string") return null;
    const fullName = typeof payload.name === "string" ? payload.name : null;
    return {
      userId: await cognitoOwnerId(payload.sub, config.issuer, payload.identities),
      email: payload.email,
      fullName,
      displayName: fullName ?? payload.email,
      avatarUrl: googleAvatarUrl(payload.picture, payload.identities),
    };
  } catch { return null; }
}

export async function currentCognitoUser(): Promise<ChatGPTUser | null> {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  return token ? verifyIdToken(token) : null;
}
