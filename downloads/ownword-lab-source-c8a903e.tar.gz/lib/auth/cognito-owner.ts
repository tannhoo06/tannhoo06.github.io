import { z } from "zod";

// Cognito subjects can have UUID-shaped values with nonstandard version or variant bits.
const subjectSchema = z.string().regex(/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i);
const migrationSchema = z.object({
  issuer: z.url(),
  subjects: z.record(subjectSchema, subjectSchema),
  google: z.record(z.string().regex(/^[a-f0-9]{64}$/), subjectSchema),
});

let migration: { raw: string; mapping: z.infer<typeof migrationSchema> } | undefined;

export async function cognitoOwnerId(
  subject: string,
  issuer: string,
  identities: unknown,
): Promise<string> {
  const raw = process.env.COGNITO_OWNER_MIGRATION;
  if (!raw) return subject;
  if (migration?.raw !== raw) {
    migration = { raw, mapping: migrationSchema.parse(JSON.parse(raw)) };
  }
  if (migration.mapping.issuer !== issuer) return subject;

  const { subjects, google } = migration.mapping;
  let owner = Object.hasOwn(subjects, subject) ? subjects[subject] : undefined;
  if (Array.isArray(identities)) {
    for (const identity of identities) {
      if (identity?.providerName !== "Google" || identity.providerType !== "Google" ||
          typeof identity.userId !== "string" || !/^\d{1,64}$/.test(identity.userId)) continue;
      // Only use identities from an ID token verified against the configured Cognito pool.
      const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(identity.userId));
      const key = Buffer.from(digest).toString("hex");
      const linkedOwner = google[key];
      if (!linkedOwner) continue;
      if (owner && owner !== linkedOwner) throw new Error("Conflicting migrated Cognito identities");
      owner = linkedOwner;
    }
  }
  return owner ?? subject;
}
