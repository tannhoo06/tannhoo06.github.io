export function googleAvatarUrl(picture: unknown, identities: unknown): string | undefined {
  if (typeof picture !== "string" || !Array.isArray(identities) ||
    !identities.some((identity) => identity?.providerName === "Google")) return;

  try {
    const url = new URL(picture);
    if (url.protocol === "https:" && /^lh[0-9]\.googleusercontent\.com$/.test(url.hostname) &&
      !url.username && !url.password && !url.port) return url.href;
  } catch {
    return;
  }
}
