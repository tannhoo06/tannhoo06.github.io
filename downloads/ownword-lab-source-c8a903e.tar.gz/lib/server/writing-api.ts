import { z } from "zod";
import { AppError } from "../services/app-error";
import type { WritingService } from "../services/writing";
import { jsonResponse as json, readApiJson } from "./api-request";
import { withLearningCredit } from "./streak-response";

type RouteContext = { params: Promise<{ id: string }> };
const emptyJson = z.strictObject({});
type AssessmentResult = Awaited<ReturnType<WritingService["submit"]>>;

async function assessmentResponse(service: WritingService, result: AssessmentResult) {
  if (result.quotaReached) {
    return json({ ...result.record, quota: await service.quotas(), error: "Your daily Writing limit is reached.", code: "daily_limit" }, 429);
  }
  const response = json(result.record, result.record.run?.status === "pending" ? 202 : 200);
  return withLearningCredit(response, result.completedActivity ? service.streak : undefined);
}

export function createWritingApi(getService: () => Promise<WritingService>) {
  function route<T extends unknown[]>(handler: (service: WritingService, ...args: T) => Response | Promise<Response>) {
    return async (...args: T) => {
      try {
        return await handler(await getService(), ...args);
      } catch (error) {
        if (error instanceof AppError) return json({ error: error.message }, error.status);
        if (error instanceof z.ZodError) return json({ error: "Please check the writing request." }, 400);
        // Do not put writing, request identifiers, or database error details in logs.
        console.error("Writing request failed.");
        return json({ error: "The Writing request could not be completed. Please try again." }, 503);
      }
    };
  }

  return {
    prompts: route((service, request: Request) => json(service.prompts(new URL(request.url).searchParams.getAll("interest")))),
    createTask: route(async (service, request: Request) => json(await service.createTask(await readApiJson(request, true)))),
    submit: route(async (service, request: Request) => assessmentResponse(service, await service.submit(await readApiJson(request, true)))),
    submission: route(async (service, _request: Request, context: RouteContext) => json(await service.submissionDetail((await context.params).id))),
    revisions: route(async (service, _request: Request, context: RouteContext) => json(await service.revisions((await context.params).id))),
    revisionCheck: route(async (service, _request: Request, context: RouteContext) =>
      json(await service.getRevisionCheck((await context.params).id))),
    checkRevision: route(async (service, request: Request, context: RouteContext) => {
      emptyJson.parse(await readApiJson(request, true));
      let completed = false;
      const result = await service.checkRevision((await context.params).id, () => { completed = true; });
      return withLearningCredit(json(result), completed ? service.streak : undefined);
    }),
    completePractice: route(async (service, request: Request, context: RouteContext) => {
      const result = await service.completePractice((await context.params).id, await readApiJson(request, true));
      return withLearningCredit(json(result), service.streak);
    }),
    profile: route(async (service) => json(await service.profile())),
    focus: route(async (service, request: Request) => {
      const key = new URL(request.url).searchParams.get("problem");
      return json(key === null ? await service.focusBoard() : await service.focusDetail(key));
    }),
    updateFocus: route(async (service, request: Request) => json(await service.updateFocus(await readApiJson(request, true)))),
    profileOverview: route(async (service) => json(await service.profileOverview())),
    refreshProfileTrends: route(async (service, request: Request) => {
      emptyJson.parse(await readApiJson(request, true));
      return json(await service.refreshProfileTrends());
    }),
    history: route(async (service) => json(await service.history())),
    retry: route(async (service, request: Request, context: RouteContext) =>
      assessmentResponse(service, await service.retry((await context.params).id, await readApiJson(request, true)))),
    deleteSubmission: route(async (service, request: Request, context: RouteContext) => {
      emptyJson.parse(await readApiJson(request, true));
      await service.deleteSubmission((await context.params).id);
      return json({ deleted: true });
    }),
    deleteAll: route(async (service, request: Request) => {
      emptyJson.parse(await readApiJson(request, true));
      await service.deleteAll();
      return json({ deleted: true });
    }),
    quotas: route(async (service) => json(await service.quotas())),
  };
}
