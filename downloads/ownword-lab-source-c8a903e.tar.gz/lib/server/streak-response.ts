import { streakAwardHeader } from "../domain/learning-streak";
import type { LearningStreakService } from "../services/learning-streak";

export async function withLearningCredit(response: Response, streak?: LearningStreakService) {
  if (!streak) return response;
  try {
    const award = await streak.complete();
    if (award) response.headers.set(streakAwardHeader, JSON.stringify(award));
  } catch {
    // A streak write failure must not replace a successful learning response.
    console.error("Learning streak could not be recorded.");
  }
  return response;
}
