import { nextUtcDay } from "../domain/request-limits";
import { LanguageBudgetExceeded } from "../llm/call-budget";
import { AppError } from "../services/app-error";

const unavailable: Partial<Record<string, string>> = {
  analyze: "We couldn’t find word suggestions right now. Your text is still in the editor. Please try again.",
  "words/manual": "We couldn’t confirm that the word was saved. Check WordBoard or try adding it again.",
  "discovery/concept": "Word search is temporarily unavailable. Your description is still here. Please try again.",
  "discovery/concept/translate": "We couldn’t load the translation. Please try again.",
  "discovery/concept/save": "We couldn’t confirm that the word was saved. Check WordBoard or try adding it again.",
  "practice/answer": "We couldn’t check your answer right now. You can retry or skip the sentence if you’re on that step.",
  "practice/hint": "We couldn’t load a hint. Please try again.",
  "practice/start": "We couldn’t start a practice session. Please try again.",
  "practice/skip": "We couldn’t skip this step. Please try again.",
};

export class DiscoveryLimitExceeded extends AppError {
  constructor(kind: "writing" | "concept", readonly resetAt: string) {
    super(kind === "writing" ? "Your writing discovery limit is reached for today." : "Your concept discovery limit is reached for today.", 429);
  }
}

export function vocabularyFailure(path: string, error: unknown, now = new Date()) {
  if (error instanceof DiscoveryLimitExceeded)
    return { status: 429, body: { error: error.message, code: "daily_limit", resetAt: error.resetAt } };
  if (error instanceof LanguageBudgetExceeded) {
    const account = error.scope === "account";
    return { status: 429, body: {
      error: account ? "You’ve reached your daily usage limit." : "Word and sentence tools have reached their daily capacity.",
      code: account ? "daily_limit" : "service_daily_limit",
      resetAt: error.resetAt ?? nextUtcDay(now),
    } };
  }
  if (error instanceof AppError && error.status < 500) return { status: error.status, body: { error: error.message } };
  const message = Object.hasOwn(unavailable, path) ? unavailable[path] : undefined;
  return { status: 503, body: { error: message ?? "Ownword couldn’t complete this request. Please try again." } };
}
