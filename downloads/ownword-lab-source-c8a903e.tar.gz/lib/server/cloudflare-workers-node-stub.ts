// The AWS Next.js bundle never uses the Sites branch in composition.ts.
// This alias lets webpack resolve the Cloudflare-only import while building for Node.
export const env: Record<string, never> = {};
