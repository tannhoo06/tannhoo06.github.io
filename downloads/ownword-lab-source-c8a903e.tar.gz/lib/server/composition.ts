import { env } from "cloudflare:workers";
import { getDb } from "@/db";
import { D1Repository } from "../adapters/d1-repository";
import { sitesAuth } from "../adapters/sites-auth";
import { readConfig } from "../config";
import { createLlmProvider } from "../llm/provider-factory";
import { D1KeyRotationStore } from "../adapters/d1-key-rotation";
import { D1DailyLlmBudget } from "../adapters/d1-llm-budget";
import { AppError, VocabularyService } from "../services/vocabulary";
import { D1WritingRepository } from "../adapters/d1-writing-repository";
import { isWritingEnabled, readHostedWritingRuntime, readWritingConfig, writingFocusTwoPassEnabled } from "../writing/config";
import { createMockWritingEvaluator } from "../writing/mock-evaluator";
import { WritingService } from "../services/writing";
import { createIssueFirstPilotEvaluator, issueFirstPilotEnabled, ISSUE_FIRST_PILOT_ROUTE } from "../writing/issue-first-pilot";
import { createWritingFocusEvaluator } from "../writing/focus-check";
import { createWritingRevisionEvaluator } from "../writing/revision-check";
import { createWritingTrendAnalyst } from "../writing/profile-trends";
import { createWritingSkillVerifier } from "../writing/skill-verification";
import { LearningStreakService } from "../services/learning-streak";

// Deployment composition root. Swap this file + infrastructure adapters for a Node/Lambda deployment.
export async function services() {
  if (process.env.AUTH_PROVIDER === "cognito") {
    const { awsServices } = await import("./composition-aws");
    return awsServices();
  }
  const identity = await sitesAuth.currentIdentity();
  if (!identity)
    throw new AppError(
      "Sign in to keep your words and practice history in your own space.",
      401,
    );
  const config = readConfig({ ...process.env, ...env });
  const ids = { next: () => crypto.randomUUID() };
  const clock = { now: () => new Date() };
  const db = getDb();
  const repository = new D1Repository(db, ids.next);
  const llm = createLlmProvider(config.llm, {
    rotationStore: new D1KeyRotationStore(db),
    budget: new D1DailyLlmBudget(db, config.llmDailyCallLimit),
  });
  return {
    vocabulary: new VocabularyService(
      repository,
      llm,
      identity,
      clock,
      ids,
      config.policy,
    ),
    repository,
    streak: new LearningStreakService(repository, identity.id, clock),
    identity,
    clock,
    discoveryLimits: config.discoveryLimits,
  };
}

export function writingModuleEnabled() {
  if (process.env.AUTH_PROVIDER === "cognito") return readHostedWritingRuntime(process.env).terra;
  return isWritingEnabled({ ...process.env, ...env });
}

export function writingLiveEvaluationEnabled() {
  if (process.env.AUTH_PROVIDER === "cognito") return readHostedWritingRuntime(process.env).terra;
  const environment: Record<string, unknown> = { ...process.env, ...env };
  return issueFirstPilotEnabled(environment) && !!String(environment.WRITING_PILOT_OPENROUTER_API_KEY ?? "").trim();
}

export async function writingServices(): Promise<WritingService> {
  if (process.env.AUTH_PROVIDER === "cognito") {
    const { writingServices: awsWritingServices } = await import("./composition-aws");
    return awsWritingServices();
  }
  const environment: Record<string, unknown> = { ...process.env, ...env };
  const limits = readWritingConfig(environment);
  if (!limits) throw new AppError("This endpoint does not exist.", 404);
  const identity = await sitesAuth.currentIdentity();
  if (!identity) throw new AppError("Sign in to access your writing.", 401);
  const db = getDb();
  const ids = { next: () => crypto.randomUUID() };
  const clock = { now: () => new Date() };
  const profiles = new D1Repository(db, ids.next);
  const pilotKey = String(environment.WRITING_PILOT_OPENROUTER_API_KEY ?? "").trim();
  const pilot = issueFirstPilotEnabled(environment) && !!pilotKey;
  const improvement = pilot && environment.WRITING_TREND_IMPROVEMENT_PILOT === "true";
  const evaluator = pilot ? createIssueFirstPilotEvaluator(pilotKey) : createMockWritingEvaluator();
  return new WritingService(new D1WritingRepository(db), identity.id,
    () => profiles.ensureUser(identity, clock.now().toISOString()), clock, ids, limits, evaluator,
    pilot ? createWritingRevisionEvaluator(pilotKey) : undefined,
    pilot ? createWritingTrendAnalyst(pilotKey) : undefined,
    improvement ? "improvement-pilot" : "release",
    improvement && environment.WRITING_SKILL_VERIFICATION_PILOT === "true" ? createWritingSkillVerifier(pilotKey) : undefined,
    new LearningStreakService(profiles, identity.id, clock),
    pilot && writingFocusTwoPassEnabled(environment) ? createWritingFocusEvaluator(pilotKey, fetch, ISSUE_FIRST_PILOT_ROUTE) : undefined);
}
