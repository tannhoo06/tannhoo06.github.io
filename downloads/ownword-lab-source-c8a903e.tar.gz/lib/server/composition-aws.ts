import { getPgDb } from "@/db/pg";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { PgRepository } from "../adapters/pg-repository";
import { PgKeyRotationStore } from "../adapters/pg-key-rotation";
import { PgDailyLlmBudget } from "../adapters/pg-llm-budget";
import { readConfig } from "../config";
import { createLlmProvider } from "../llm/provider-factory";
import { createBedrockConceptDiscovery, readBedrockConceptModel } from "../llm/bedrock-concept";
import { AppError, VocabularyService } from "../services/vocabulary";
import { PgWritingRepository } from "../adapters/pg-writing-repository";
import { readHostedWritingRuntime, readWritingConfig, writingFocusTwoPassEnabled } from "../writing/config";
import { createIssueFirstPilotEvaluator, HOSTED_WRITING_ROUTE } from "../writing/issue-first-pilot";
import { createWritingFocusEvaluator } from "../writing/focus-check";
import { createWritingRevisionEvaluator } from "../writing/revision-check";
import { createWritingTrendAnalyst } from "../writing/profile-trends";
import { WritingService } from "../services/writing";
import { LearningStreakService } from "../services/learning-streak";

export async function awsServices() {
  const user = await getChatGPTUser();
  if (!user) throw new AppError("Sign in to keep your words and practice history in your own space.", 401);
  const identity = { id: user.userId, name: user.fullName ?? "My space", email: user.email };
  const config = readConfig(process.env);
  const ids = { next: () => crypto.randomUUID() };
  const clock = { now: () => new Date() };
  const db = getPgDb();
  const repository = new PgRepository(db, ids.next);
  const conceptModel = readBedrockConceptModel(process.env.BEDROCK_CONCEPT_MODEL);
  const llm = createLlmProvider(config.llm, {
    rotationStore: new PgKeyRotationStore(db),
    budget: new PgDailyLlmBudget(db, config.llmDailyCallLimit, identity.id, config.llmPerUserDailyCallLimit),
    discoverConcept: conceptModel && createBedrockConceptDiscovery(conceptModel),
  });
  return {
    vocabulary: new VocabularyService(repository, llm, identity, clock, ids, config.policy),
    repository,
    streak: new LearningStreakService(repository, identity.id, clock),
    identity,
    clock,
    discoveryLimits: config.discoveryLimits,
  };
}

export const services = awsServices;
export const writingLiveEvaluationEnabled = () => readHostedWritingRuntime(process.env).terra;
export const writingModuleEnabled = writingLiveEvaluationEnabled;

export async function writingServices(): Promise<WritingService> {
  const limits = readWritingConfig(process.env);
  const { key, terra, trends } = readHostedWritingRuntime(process.env);
  if (!limits || !terra) throw new AppError("This endpoint does not exist.", 404);
  const user = await getChatGPTUser();
  if (!user) throw new AppError("Sign in to access your writing.", 401);
  const identity = { id: user.userId, name: user.fullName ?? "My space", email: user.email };
  const db = getPgDb();
  const ids = { next: () => crypto.randomUUID() };
  const clock = { now: () => new Date() };
  const profiles = new PgRepository(db, ids.next);
  return new WritingService(new PgWritingRepository(db), identity.id,
    () => profiles.ensureUser(identity, clock.now().toISOString()), clock, ids, limits,
    createIssueFirstPilotEvaluator(key, fetch, HOSTED_WRITING_ROUTE),
    createWritingRevisionEvaluator(key, fetch, HOSTED_WRITING_ROUTE),
    trends ? createWritingTrendAnalyst(key) : undefined, trends ? "release" : "disabled",
    undefined, new LearningStreakService(profiles, identity.id, clock),
    writingFocusTwoPassEnabled(process.env) ? createWritingFocusEvaluator(key, fetch, HOSTED_WRITING_ROUTE) : undefined);
}
