import { AppError } from "../services/app-error";

export function jsonResponse(body: unknown, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" },
  });
}

async function boundedBody(request: Request, limit: number) {
  if (!request.body) return "";
  const reader = request.body.getReader();
  const decoder = new TextDecoder();
  let size = 0;
  let raw = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) return raw + decoder.decode();
      size += value.byteLength;
      if (size > limit) {
        void reader.cancel().catch(() => {});
        throw new AppError("This request is too large.", 413);
      }
      raw += decoder.decode(value, { stream: true });
    }
  } finally {
    reader.releaseLock();
  }
}

export async function readApiJson(request: Request, streamBytes = false): Promise<unknown> {
  // Behind Caddy, request.url can use the container's HTTP origin.
  const expectedOrigin = new URL(process.env.APP_ORIGIN || request.url).origin;
  if (request.headers.get("origin") !== expectedOrigin)
    throw new AppError("This request did not originate from your app.", 403);
  const contentType = request.headers.get("content-type") ?? "";
  const isJson = streamBytes ? contentType.split(";")[0].trim().toLowerCase() === "application/json" :
    contentType.includes("application/json");
  if (!isJson) throw new AppError("Send JSON data.", 415);
  const limit = 32_000;
  if (Number(request.headers.get("content-length") ?? 0) > limit)
    throw new AppError("This request is too large.", 413);
  const raw = streamBytes ? await boundedBody(request, limit) : await request.text();
  if (raw.length > limit) throw new AppError("This request is too large.", 413);
  try {
    return JSON.parse(raw);
  } catch {
    throw new AppError("The request could not be read.");
  }
}
