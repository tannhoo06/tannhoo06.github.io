import { and, asc, eq, isNull, lte, or, sql } from "drizzle-orm";
import { getPgDb } from "@/db/pg";
import * as s from "@/db/schema.pg";
import { PgDailyLlmBudget } from "../adapters/pg-llm-budget";
import { PgKeyRotationStore } from "../adapters/pg-key-rotation";
import { readConfig } from "../config";
import { createLlmProvider } from "../llm/provider-factory";

/** Empty manual lexemes are durable work items, including words saved before this worker existed. */
export async function enrichManualWord(userWordId?: string): Promise<boolean | null> {
  const db = getPgDb();
  const now = new Date();
  const due = or(isNull(s.words.enrichmentNextAt), lte(s.words.enrichmentNextAt, now.toISOString()));
  const [candidate] = await db.select({ id: s.words.id, word: s.words.word, userId: s.userWords.userId })
    .from(s.words)
    .innerJoin(s.userWords, eq(s.userWords.wordId, s.words.id))
    .where(and(
      eq(s.words.definition, ""),
      isNull(s.userWords.removedAt),
      due,
      userWordId ? eq(s.userWords.id, userWordId) : undefined,
    ))
    .orderBy(asc(s.userWords.addedAt))
    .limit(1);
  if (!candidate) return null;

  // Claim before the model call. A crashed worker becomes eligible again after the lease.
  const leaseUntil = new Date(now.getTime() + 2 * 60_000).toISOString();
  const [claimed] = await db.update(s.words).set({
    enrichmentAttempts: sql`${s.words.enrichmentAttempts} + 1`,
    enrichmentNextAt: leaseUntil,
  }).where(and(eq(s.words.id, candidate.id), eq(s.words.definition, ""), due))
    .returning({ attempts: s.words.enrichmentAttempts });
  if (!claimed) return null;

  try {
    const config = readConfig(process.env);
    const llm = createLlmProvider(config.llm, {
      rotationStore: new PgKeyRotationStore(db),
      budget: new PgDailyLlmBudget(db, config.llmDailyCallLimit, candidate.userId, config.llmPerUserDailyCallLimit),
    });
    const entry = await llm.defineWord(candidate.word);
    await db.update(s.words).set(entry)
      .where(and(eq(s.words.id, candidate.id), eq(s.words.definition, "")));
    return true;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const quotaReached = message.includes("daily language-service request limit");
    const tomorrow = new Date(now);
    tomorrow.setUTCHours(24, 1, 0, 0);
    const backoff = Math.min(6 * 60 * 60_000, 5 * 60_000 * 2 ** Math.min(claimed.attempts - 1, 7));
    const retryAt = quotaReached ? tomorrow : new Date(now.getTime() + backoff);
    await db.update(s.words).set({ enrichmentNextAt: retryAt.toISOString() })
      .where(and(eq(s.words.id, candidate.id), eq(s.words.definition, "")));
    console.error(`Manual word enrichment failed for lexeme ${candidate.id}; retry at ${retryAt.toISOString()}: ${message}`);
    return false;
  }
}

export async function enrichPendingManualWords(limit = 5) {
  let attempted = 0;
  let enriched = 0;
  for (; attempted < limit; attempted++) {
    const result = await enrichManualWord();
    if (result === null) break;
    if (result) enriched++;
  }
  return { attempted, enriched };
}
