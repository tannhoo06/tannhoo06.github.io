import { streakAwardHeader, type LearningStreak } from "../domain/learning-streak";

const eventName = "ownword:streak-earned";
const detailsEventName = "ownword:streak-details";

export function announceStreakAward(response: Response) {
  const header = response.headers.get(streakAwardHeader);
  if (!response.ok || !header) return;
  try {
    const award = JSON.parse(header) as LearningStreak;
    if (Number.isSafeInteger(award.count) && award.count > 0 && award.week?.length === 7)
      window.dispatchEvent(new CustomEvent(eventName, { detail: award }));
  } catch {
    // A malformed optional header does not affect the completed activity.
  }
}

export function onStreakAward(receive: (award: LearningStreak) => void) {
  const listener = (event: Event) => receive((event as CustomEvent<LearningStreak>).detail);
  window.addEventListener(eventName, listener);
  return () => window.removeEventListener(eventName, listener);
}

export function openStreakDetails(streak?: LearningStreak) {
  window.dispatchEvent(new CustomEvent(detailsEventName, { detail: streak }));
}

export function onStreakDetails(receive: (streak?: LearningStreak) => void) {
  const listener = (event: Event) => receive((event as CustomEvent<LearningStreak | undefined>).detail);
  window.addEventListener(detailsEventName, listener);
  return () => window.removeEventListener(detailsEventName, listener);
}
