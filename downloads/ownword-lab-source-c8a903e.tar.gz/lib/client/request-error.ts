import { isRequestLimitCode, type RequestLimitCode } from "../domain/request-limits";

export class RequestError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly limit?: RequestLimitCode,
    readonly resetAt?: string,
  ) { super(message); }
}

export function requestError(status: number, data: unknown) {
  const body = data && typeof data === "object" ? data as Record<string, unknown> : {};
  const message = status === 401 ? "Your session has ended. Sign in and try again."
    : typeof body.error === "string" && body.error ? body.error
      : status === 429 ? "Too many requests. Wait a little and try again."
        : "Ownword couldn’t complete this request. Please try again.";
  const limit = status === 429 && isRequestLimitCode(body.code) ? body.code : undefined;
  const resetAt = limit && typeof body.resetAt === "string" && Number.isFinite(Date.parse(body.resetAt)) ? body.resetAt : undefined;
  return new RequestError(message, status, limit, resetAt);
}
