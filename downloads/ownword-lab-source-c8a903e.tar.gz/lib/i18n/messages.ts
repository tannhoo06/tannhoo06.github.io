import { v2vi } from "./mvp-v2";
/** Interface copy only. Learner text, vocabulary and generated English stay untouched. */
export const vi: Record<string, string> = {
  Close: "Đóng",
  "Daily limit reached": "Đã hết lượt hôm nay",
  "Daily capacity reached": "Các công cụ đã hết lượt phục vụ hôm nay",
  "Assessments in progress": "Đang xử lý các bài viết khác",
  "You can try again after {time}.": "Bạn có thể thử lại sau {time}.",
  "You’ve reached your daily usage limit.": "Bạn đã dùng hết lượt sử dụng các công cụ hỗ trợ tiếng Anh hôm nay.",
  "Word and sentence tools have reached their daily capacity.": "Các công cụ hỗ trợ từ vựng và đặt câu đã hết lượt phục vụ hôm nay.",
  "Your essay is saved. You’ve reached today’s writing assessment limit.": "Bài viết đã được lưu. Bạn đã dùng hết lượt nhận xét bài viết hôm nay.",
  "Your essay is saved. All assessment slots are in use. Check again when the current assessments finish.": "Bài viết đã được lưu. Các lượt nhận xét đang được xử lý. Hãy kiểm tra lại khi các bài đang chờ đã được nhận xét.",
  "We couldn’t generate feedback for this essay. You can retry using the saved version.": "Ownword chưa tạo được nhận xét cho bài này. Bạn có thể yêu cầu nhận xét lại bài đã lưu.",
  "The assessment took too long. You can retry using the saved essay.": "Việc nhận xét mất quá nhiều thời gian. Bạn có thể yêu cầu nhận xét lại bài đã lưu.",
  "You can request feedback for this saved essay.": "Bạn có thể yêu cầu nhận xét cho bài đã lưu.",
  "Couldn’t connect to Ownword. Your essay is saved. Check your connection and retry.": "Không thể kết nối với Ownword. Bài viết đã được lưu. Hãy kiểm tra mạng rồi thử lại.",
  "Couldn’t connect to Ownword. Your draft is still here. Check your connection and retry.": "Không thể kết nối với Ownword. Phần bạn đang viết vẫn còn ở đây. Hãy kiểm tra mạng rồi thử lại.",
  "We couldn’t confirm the assessment request. Your essay is saved. Please try again.": "Chưa xác nhận được yêu cầu nhận xét. Bài viết đã được lưu. Hãy thử lại.",
  "Your session has ended. Sign in and try again.": "Phiên đăng nhập đã hết hạn. Hãy đăng nhập lại rồi thử lại.",
  "We couldn’t find word suggestions right now. Your text is still in the editor. Please try again.": "Ownword chưa thể tìm từ gợi ý lúc này. Đoạn bạn viết vẫn còn trong ô nhập. Hãy thử lại.",
  "We couldn’t confirm that the word was saved. Check WordBoard or try adding it again.": "Chưa xác nhận được từ đã được lưu. Hãy kiểm tra WordBoard hoặc thử thêm lại từ.",
  "Word search is temporarily unavailable. Your description is still here. Please try again.": "Tạm thời chưa tìm được từ. Phần bạn mô tả vẫn còn ở đây. Hãy thử lại.",
  "We couldn’t load the translation. Please try again.": "Chưa tải được bản dịch. Hãy thử lại.",
  "We couldn’t check your answer right now. You can retry or skip the sentence if you’re on that step.": "Chưa kiểm tra được câu trả lời lúc này. Bạn có thể thử lại hoặc bỏ qua bước đặt câu nếu đang ở bước đó.",
  "We couldn’t load a hint. Please try again.": "Chưa tải được gợi ý. Hãy thử lại.",
  "We couldn’t start a practice session. Please try again.": "Chưa bắt đầu được buổi luyện tập. Hãy thử lại.",
  "We couldn’t skip this step. Please try again.": "Chưa bỏ qua được bước này. Hãy thử lại.",
  "Ownword couldn’t complete this request. Please try again.": "Ownword chưa xử lý được yêu cầu này. Hãy thử lại.",
  "Too many requests. Wait a little and try again.": "Bạn đã gửi quá nhiều yêu cầu. Hãy chờ một lúc rồi thử lại.",
  "You’ve made quite a few requests. Please take a break and try again next hour.": "Bạn đã gửi quá nhiều yêu cầu trong giờ này. Hãy thử lại vào giờ sau.",
  "Write a little more so there is enough context.": "Hãy viết thêm một chút để Ownword có đủ ngữ cảnh.",
  "Failed to fetch": "Không thể kết nối. Kiểm tra mạng rồi thử lại nhé.",
  "Your writing discovery limit is reached for today.": "Bạn đã dùng hết lượt tìm từ qua bài viết hôm nay.",
  "Your concept discovery limit is reached for today.": "Bạn đã dùng hết lượt tìm từ cho ý này hôm nay.",
  "Enter an English word or short phrase using letters.": "Nhập một từ hoặc cụm từ tiếng Anh ngắn bằng chữ cái.",
  "NetworkError when attempting to fetch resource.":
    "Không thể kết nối. Kiểm tra mạng rồi thử lại nhé.",
  "That word was not found on your board.":
    "Không tìm thấy từ này trong bộ từ của bạn.",
  "Remove from My words": "Xóa khỏi Từ của bạn",
  "Removing…": "Đang xóa…",
  "Remove “{word}” from My words? Your writing and practice history will stay saved.":
    "Xóa “{word}” khỏi Từ của bạn? Bài viết và lịch sử luyện tập vẫn được lưu.",
  "Word removed from My words.": "Đã xóa từ khỏi Từ của bạn.",
  "Start a new draft": "Bắt đầu viết đoạn mới",
  "Try another demo example": "Thử bài mẫu khác",
  "The demo recognizes only a few example patterns. Words already in My words are not suggested again. Try a new example or write about a different idea.":
    "Bản dùng thử chỉ nhận diện một số mẫu câu. Từ đã có trong Từ của bạn sẽ không được gợi ý lại. Hãy thử bài mẫu khác hoặc viết về ý tưởng mới.",
  "This writing review could not be found.":
    "Không tìm thấy kết quả phân tích bài viết này.",
  "This suggestion could not be found.": "Không tìm thấy gợi ý này.",
  "This word has entered practice. Its saved word and learning history are preserved; this save can no longer be undone.":
    "Từ này đã được đưa vào luyện tập. Từ và lịch sử học vẫn được giữ lại; bạn không thể hoàn tác lần lưu này nữa.",
  "Try exploring this word in a piece of writing first.":
    "Hãy thử dùng từ này trong một đoạn viết trước nhé.",
  "This word is waiting in your introduction queue. We’ll introduce a few new words each day.":
    "Từ này đang chờ học. Mỗi ngày bạn sẽ được giới thiệu một số từ mới.",
  "You’re up to date. Your words will be ready when a little time has passed.":
    "Bạn đã ôn hết từ đến hạn. Hãy quay lại sau một khoảng thời gian nhé.",
  "That practice session could not be found.":
    "Không tìm thấy buổi luyện tập này.",
  "This exercise is no longer open.": "Bài tập này đã kết thúc.",
  "Finish the sentence step before requesting another hint.":
    "Hãy hoàn thành bước đặt câu trước khi xem thêm gợi ý.",
  "You can skip the sentence after recalling or being shown the word.":
    "Bạn có thể bỏ qua bước đặt câu sau khi nhớ được từ hoặc xem đáp án.",
  "This exercise could not be found.": "Không tìm thấy bài tập này.",
  "That response has already been saved. Continue to the next word.":
    "Câu trả lời đã được lưu. Hãy chuyển sang từ tiếp theo.",
  "That response has already been saved.": "Câu trả lời này đã được lưu.",
  "Please check your input.": "Bạn hãy kiểm tra lại nội dung đã nhập.",
  "Sign in to keep your words and practice history in your own space.":
    "Đăng nhập để lưu từ vựng và lịch sử luyện tập của riêng bạn.",
  "{stage} words": "Từ {stage}",
  "A recent trip": "Một chuyến đi gần đây",
  "A favorite animal": "Một con vật yêu thích",
  "Show Vietnamese meaning": "Hiện nghĩa tiếng Việt",
  "A book or movie": "Một cuốn sách hoặc bộ phim",
  "A personal goal": "Một mục tiêu cá nhân",
  "Quick review": "Ôn nhanh",
  "Full practice": "Luyện tập đầy đủ",
  "Quick review complete": "Đã hoàn thành ôn nhanh",
  "Start quick review": "Bắt đầu ôn nhanh",
  "Choose a valid set of words to practice.": "Hãy chọn danh sách từ hợp lệ để luyện tập.",
  "Some selected words are no longer available. Refresh your WordBoard and try again.":
    "Một số từ đã chọn không còn sẵn sàng. Hãy tải lại WordBoard và thử lại.",
  "Flip through a few WordBoard words and check whether you can recall them.":
    "Ôn vài từ trong WordBoard và tự kiểm tra xem bạn có nhớ được không.",
  "Did you remember this word?": "Bạn có nhớ từ này không?",
  Forgot: "Chưa nhớ",
  "Got it": "Đã nhớ",
  Skipped: "Đã bỏ qua",
  "Needs another look": "Cần ôn thêm",
  "Continue to Full Practice": "Tiếp tục luyện tập đầy đủ",
  "Review again": "Ôn lại",
  "Back to Practice": "Về Luyện tập",
  "Practice again": "Luyện tập tiếp",
  "Choose how you want to practice.": "Chọn cách bạn muốn luyện tập.",
  "You’re caught up for now. You can still practice your WordBoard words.":
    "Bạn đã ôn hết từ đến hạn. Bạn vẫn có thể luyện các từ trong WordBoard bất cứ lúc nào.",
  "About 1–2 minutes": "Khoảng 1–2 phút",
  "Choose your practice mode": "Chọn cách luyện tập",
  "1–2 min": "1–2 phút",
  "5–10 min": "5–10 phút",
  "Quick flashcard review": "Ôn nhanh bằng thẻ từ",
  "From your WordBoard": "Từ WordBoard của bạn",
  "Scheduled words come first. You can practice any time.":
    "Ưu tiên các từ đến hạn. Bạn có thể luyện tập bất cứ lúc nào.",
  "Fast recall": "Nhớ lại nhanh",
  "Just flip and rate": "Lật thẻ và tự đánh giá",
  "No typing required": "Không cần gõ đáp án",
  "Recall at your own pace": "Ôn theo nhịp của bạn",
  "Great for short breaks": "Phù hợp lúc nghỉ ngắn",
  "Card {position} of {total}": "Từ {position} / {total}",
  "Pause review": "Về Luyện tập",
  "Flip card": "Lật thẻ",
  "Flashcard navigation": "Chuyển thẻ từ",
  "Previous card": "Thẻ trước",
  "Next card": "Thẻ tiếp theo",
  Next: "Tiếp",
  Shortcuts: "Phím tắt",
  "Click or tap the card to flip": "Nhấn hoặc chạm vào thẻ để lật",
  Space: "Phím cách",
  "to flip": "để lật thẻ",
  "to browse": "để chuyển thẻ",
  "Tap the card to flip": "Chạm vào thẻ để lật",
  "Saved rating:": "Đã lưu đánh giá:",
  "Forgotten words can return in Full Practice later.":
    "Bạn có thể ôn lại các từ chưa nhớ trong phần Luyện tập đầy đủ.",
  "{count} words to revisit": "{count} từ cần ôn thêm",
  "{count} word to revisit": "{count} từ cần ôn thêm",
  "Practice them in Full Practice to use them in sentences.":
    "Luyện các từ này trong phần Luyện tập đầy đủ để dùng từ trong câu.",
  Write: "Viết",
  Practice: "Luyện tập",
  "My words": "Từ của bạn",
  More: "Thêm",
  "Writing insights": "Phân tích",
  Settings: "Cài đặt",
  Name: "Tên",
  "Main navigation": "Điều hướng chính",
  "Skip to content": "Chuyển đến nội dung",
  "Ownword home": "Trang chủ Ownword",
  "Dismiss notification": "Đóng thông báo",
  "Demo mode": "Chế độ dùng thử",
  New: "Mới học",
  Practicing: "Đang luyện",
  Active: "Đã vận dụng",
  "Start writing": "Bắt đầu viết",
  "A personal vocabulary practice.": "Không gian luyện từ vựng của bạn.",
  "Find words you can use.": "Học từ để dùng thật tự nhiên.",
  "Write a few sentences. Find useful words. Practice using them.":
    "Viết vài câu. Khám phá từ hữu ích. Luyện cách sử dụng.",
  "A few sentences. That’s all.": "Chỉ cần vài câu là đủ.",
  "Add a labelled sample collection": "Thử bộ từ vựng mẫu có ghi chú",
  "Example of feedback on writing": "Ví dụ về góp ý cho bài viết",
  "Example: your meaning, a new word": "Ví dụ: ý của bạn, cách diễn đạt mới",
  "Try “negligible”": "Thử dùng “negligible”",
  "Too small to make a practical difference.":
    "Nhỏ đến mức không tạo ra khác biệt đáng kể.",
  "Choose whether to revise your sentence, save the word for practice, or keep your original.":
    "Bạn có thể sửa câu, lưu từ để luyện tập hoặc giữ nguyên cách viết.",
  "1. Write": "1. Viết",
  "2. Choose words": "2. Chọn từ",
  "3. Practice": "3. Luyện tập",
  "3. Try one": "3. Thử một từ",
  "Start with your own words.": "Bắt đầu từ cách viết của bạn.",
  "A few sentences about something on your mind.":
    "Viết vài câu về điều bạn đang nghĩ đến.",
  "Choose a useful alternative.": "Chọn cách diễn đạt hữu ích.",
  "Choose useful words that fit what you mean.":
    "Chọn những từ phù hợp với ý bạn muốn nói.",
  "Recall it in your own sentences.": "Nhớ lại và đặt câu của riêng bạn.",
  "Short, spaced practice that turns knowing into using.":
    "Luyện tập ngắn, ôn lại đúng lúc để biến từ đã biết thành từ dùng được.",
  "Thoughtful practice. More precise expression.":
    "Luyện tập có chủ đích. Diễn đạt chính xác hơn.",
  "No streaks to protect. Just words to own.":
    "Không áp lực duy trì chuỗi ngày. Chỉ cần từng bước làm chủ từ vựng.",
  "Getting your space ready…": "Đang chuẩn bị không gian học…",
  "That didn’t work. Please try again.":
    "Thao tác chưa thành công. Bạn hãy thử lại nhé.",
  "Try again": "Thử lại",
  "Ready to practice": "Sẵn sàng ôn tập",
  Tomorrow: "Ngày mai",
  "In {days} days": "Sau {days} ngày",
  "Write a few sentences": "Viết vài câu",
  "Word suggestions": "Gợi ý từ vựng",
  "Getting started": "Các bước bắt đầu",
  "Write about an idea or experience. Choose words you want to use more naturally.":
    "Viết về một ý tưởng hoặc trải nghiệm. Chọn những từ bạn muốn sử dụng tự nhiên hơn.",
  "These are optional alternatives. Saving a word does not edit your writing.":
    "Đây là các gợi ý để bạn cân nhắc. Lưu từ không làm thay đổi bài viết.",
  "Browser storage is unavailable. Keep this page open to retain your draft and review position.":
    "Không thể lưu trong trình duyệt. Hãy giữ trang này mở để giữ đoạn đang viết và vị trí đang xem.",
  "From your writing insights": "Từ góc nhìn bài viết của bạn",
  "Try “{word}” in your writing": "Thử dùng “{word}” trong bài viết",
  "Use a context that makes the meaning clear.":
    "Chọn ngữ cảnh giúp thể hiện rõ nghĩa của từ.",
  "Replace the current draft with this source passage? Your analyzed original will be kept.":
    "Thay đoạn đang viết bằng đoạn văn này? Bản gốc đã phân tích vẫn được giữ lại.",
  "Use this passage": "Dùng đoạn văn này",
  "Dismiss context": "Đóng ngữ cảnh",
  "Demo analysis matches a limited set of examples. It is not a full vocabulary, grammar, or essay assessment.":
    "Bản dùng thử chỉ nhận diện một số mẫu có sẵn, chưa đánh giá đầy đủ từ vựng, ngữ pháp hay chất lượng bài viết.",
  "Your previous analysis and decisions are saved.":
    "Kết quả phân tích và các lựa chọn trước đó đã được lưu.",
  "Continue reviewing": "Tiếp tục xem gợi ý",
  "Need a starting prompt?": "Bạn cần gợi ý để bắt đầu?",
  "Another prompt": "Đổi gợi ý",
  "Your writing": "Bài viết của bạn",
  "Use an example": "Dùng bài mẫu",
  "Replace your draft with the example?": "Thay đoạn đang viết bằng bài mẫu?",
  "Lately, I’ve been thinking about…":
    "Viết bằng tiếng Anh, chẳng hạn: Lately, I’ve been thinking about…",
  "Write 2–3 sentences. At least 10 characters; up to 5,000.":
    "Viết 2–3 câu bằng tiếng Anh, từ 10 đến 5.000 ký tự.",
  "{count} more characters needed.": "Cần thêm {count} ký tự.",
  "Draft not saved": "Bản nháp chưa được lưu",
  "Draft saved in this tab": "Đã lưu đoạn đang viết trong thẻ này",
  "Analyzing your writing…": "Đang phân tích bài viết…",
  "Retry analysis": "Phân tích lại",
  "Analyze this draft": "Xem gợi ý cho đoạn đang viết",
  "Review word suggestions": "Xem gợi ý từ vựng",
  "Skip for now": "Bỏ qua lúc này",
  "Edit writing": "Sửa bài viết",
  "{count} suggestions left to decide": "Còn {count} gợi ý cần lựa chọn",
  "Review decisions saved": "Đã lưu các lựa chọn",
  "Reviewing the original version. Your draft has changed; analyze it again for fresh locations.":
    "Bạn đang xem góp ý cho bản gốc. Bản nháp đã thay đổi; hãy phân tích lại để cập nhật vị trí gợi ý.",
  "View current draft": "Xem đoạn đang viết",
  "Undo revision": "Hoàn tác sửa câu",
  "Revision undone.": "Đã hoàn tác sửa câu.",
  "Your original writing": "Bài viết gốc của bạn",
  "Review suggestions": "Xem các gợi ý",
  Recall: "Nhớ lại",
  "Suggestion {number}": "Gợi ý {number}",
  "Suggestion {number}: {phrase}": "Gợi ý {number}: {phrase}",
  "Suggestion {number} of {total}": "Gợi ý {number} / {total}",
  "Original sentence": "Câu gốc",
  "Try “{word}”": "Thử dùng “{word}”",
  "Location unavailable: we could not identify one exact occurrence. No text will be changed.":
    "Chưa xác định được vị trí chính xác trong bài viết. Nội dung sẽ không bị thay đổi.",
  "Suggested sentence": "Câu gợi ý",
  "A reliable sentence rewrite is unavailable. You can save the word and write your own version.":
    "Chưa có cách viết lại đủ tin cậy. Bạn có thể lưu từ và tự viết câu của mình.",
  "Saving…": "Đang lưu…",
  "Saved for later": "Đã lưu để học sau",
  "Word saved": "Đã lưu từ",
  "Save word": "Lưu từ",
  "Cancel preview": "Đóng bản xem trước",
  "Try this wording": "Thử cách viết này",
  "Preview draft revision": "Xem trước câu sửa",
  "This changes only this sentence in your draft. Your original is kept.":
    "Chỉ câu này trong đoạn đang viết sẽ được thay đổi. Bản gốc vẫn được giữ lại.",
  "Apply to draft": "Dùng câu đã sửa",
  "Keep original": "Giữ nguyên",
  "I already use this word": "Tôi đã dùng được từ này",
  "Undo decision": "Hoàn tác lựa chọn",
  "Meaning and more examples": "Nghĩa và ví dụ khác",
  "Recall a word you know": "Nhớ lại một từ bạn đã học",
  "Try retrieving it": "Thử nhớ lại",
  Previous: "Trước",
  "Next suggestion": "Gợi ý tiếp",
  "Review summary": "Tổng kết lựa chọn",
  "Words saved for later practice": "Đã lưu từ để luyện tập sau",
  "Your words are saved": "Đã lưu các từ bạn chọn",
  "Review complete": "Đã xem xong gợi ý",
  "No matching demo suggestions": "Chưa có gợi ý phù hợp trong bản dùng thử",
  "No new word suggestions": "Chưa có gợi ý từ mới",
  "{saved} saved: {ready} ready to practice, {queued} queued. {kept} kept original. {known} already in use.":
    "Đã lưu {saved} từ: {ready} từ có thể luyện tập, {queued} từ chờ học. Giữ nguyên {kept} gợi ý; đã dùng được {known} từ.",
  "The demo recognizes only a few example patterns. This is not a judgment of your writing. Try the example or keep writing.":
    "Bản dùng thử chỉ nhận diện một số mẫu nhất định. Đây không phải đánh giá chất lượng bài viết. Bạn có thể thử bài mẫu hoặc tiếp tục viết.",
  "Queued words stay in My words and are introduced gradually under your daily learning limit.":
    "Các từ chờ học vẫn nằm trong Từ của bạn và sẽ được giới thiệu dần theo giới hạn học mỗi ngày.",
  "Practice all ready words": "Luyện tất cả từ đã sẵn sàng",
  "Return to writing": "Quay lại viết",
  "Practice all ready words; review stays saved":
    "Luyện tất cả từ đã sẵn sàng; gợi ý vẫn được lưu",
  "Words you used from your collection": "Những từ đã học bạn dùng trong bài",
  Saved: "Đã lưu",
  "Kept original": "Đã giữ nguyên",
  "Already use it": "Đã dùng được",
  "Not decided": "Chưa chọn",
  "Could not refresh this review. Your saved view is here; reconnect before changing decisions.":
    "Chưa tải lại được gợi ý. Bản đã lưu vẫn ở đây; hãy kết nối lại trước khi thay đổi lựa chọn.",
  "{count} word suggestions. Your original writing is preserved.":
    "Có {count} gợi ý từ vựng. Bài viết gốc vẫn được giữ nguyên.",
  "Decision undone.": "Đã hoàn tác lựa chọn.",
  "Word saved for later practice.": "Đã lưu từ để luyện tập sau.",
  "Word saved for practice.": "Đã lưu từ để luyện tập.",
  "Decision saved. Your writing is unchanged.":
    "Đã lưu lựa chọn. Bài viết không thay đổi.",
  "Revision applied to your draft. The analyzed original is preserved.":
    "Đã áp dụng câu sửa vào đoạn đang viết. Bản gốc đã phân tích vẫn được giữ lại.",
  "Write something new": "Viết bài mới",
  "{count} words ready to practice": "Có {count} từ sẵn sàng ôn tập",
  "Your reviews are up to date": "Bạn đã ôn tập đầy đủ",
  "Start your collection": "Bắt đầu bộ từ vựng của bạn",
  "Recall a word, then use it in a sentence.":
    "Nhớ lại một từ, rồi dùng từ đó để đặt câu.",
  "Next review: {date}.": "Lần ôn tiếp theo: {date}.",
  "words will be introduced gradually": "các từ sẽ được giới thiệu dần",
  "Start with a few sentences. Find a word that says exactly what you mean.":
    "Bắt đầu bằng vài câu. Tìm từ diễn đạt đúng ý bạn muốn nói.",
  "Practice {count} words": "Luyện {count} từ",
  "{visible} of {total} words": "Hiển thị {visible} / {total} từ",
  "Find a word": "Tìm từ",
  "Find a word…": "Tìm từ…",
  "Show only words due for practice": "Chỉ hiển thị từ đến hạn ôn",
  "Only due words": "Từ đến hạn ôn",
  "Sort words": "Sắp xếp từ",
  "Newest first": "Mới nhất trước",
  Alphabetical: "Theo bảng chữ cái",
  "Filter by learning stage": "Lọc theo giai đoạn học",
  All: "Tất cả",
  "Clear filters": "Xóa bộ lọc",
  "No matching words": "Không tìm thấy từ phù hợp",
  "Try another search or clear your filters.":
    "Thử tìm từ khác hoặc xóa bộ lọc.",
  "No words saved yet": "Bạn chưa lưu từ nào",
  "Write a few sentences and choose a useful word to practice.":
    "Viết vài câu rồi chọn một từ hữu ích để luyện tập.",
  "Newly introduced": "Những từ vừa bắt đầu học",
  "Building recall through practice": "Luyện tập để nhớ và dùng từ",
  "Independent use; reviews continue": "Đã tự dùng được; vẫn cần ôn lại",
  Sample: "Từ mẫu",
  "In your queue": "Đang chờ học",
  "No matching words here.": "Chưa có từ phù hợp ở đây.",
  "Your next useful word starts with a little writing.":
    "Viết một chút để khám phá từ hữu ích tiếp theo.",
  "Words arrive here with successful practice on separate days.":
    "Từ chuyển đến đây sau khi bạn nhớ lại được qua nhiều ngày luyện tập.",
  "With time and independent use, your words will settle here.":
    "Khi bạn tự dùng được từ qua thời gian, từ sẽ chuyển đến đây.",
  "Find your first word": "Khám phá từ đầu tiên",
  "How words progress": "Các giai đoạn học từ",
  "New words become Practicing through successful recalls on separate days. Active requires independent use across contexts and time. All stages continue to receive spaced reviews.":
    "Từ mới chuyển sang Đang luyện khi bạn nhớ lại được qua nhiều ngày. Đã vận dụng cần khả năng tự dùng từ trong nhiều ngữ cảnh và qua thời gian. Từ ở mọi giai đoạn vẫn được ôn tập ngắt quãng.",
  "{count} words are waiting. We’ll introduce them gradually so practice stays manageable.":
    "Có {count} từ đang chờ học. Từ sẽ được giới thiệu dần để bạn không bị quá tải.",
  "Manage sample words": "Quản lý từ mẫu",
  "Explore a sample collection": "Khám phá bộ từ mẫu",
  "Close word details": "Đóng chi tiết từ",
  "Review status": "Trạng thái ôn tập",
  "Queued: introduced gradually within your daily limit.":
    "Đang chờ: từ sẽ được giới thiệu dần trong giới hạn học mỗi ngày.",
  "Examples and usage": "Ví dụ và cách dùng",
  "Meaning and nuance": "Nghĩa và sắc thái",
  "Common combinations": "Cụm từ thường gặp",
  "Practice history": "Lịch sử luyện tập",
  "Practice evidence": "Tiến trình luyện tập",
  Retrieval: "Nhớ lại",
  Precision: "Độ chính xác",
  Flexibility: "Khả năng vận dụng",
  Retention: "Khả năng ghi nhớ",
  "{count} spaced recalls": "Nhớ lại {count} lần qua các buổi",
  "Just beginning": "Vừa bắt đầu",
  "{count} natural uses": "Dùng tự nhiên {count} lần",
  "Ready to explore": "Sẵn sàng luyện cách dùng",
  "{count} different contexts": "{count} ngữ cảnh khác nhau",
  "Across {days} days": "Trong {days} ngày",
  "Time will tell": "Cần thêm thời gian",
  "Recent attempts": "Các lần luyện gần đây",
  "This is illustrative history from the sample collection.":
    "Đây là lịch sử minh họa của bộ từ mẫu.",
  "Your own writing": "Bài viết của bạn",
  "Practiced with the word revealed": "Đã luyện sau khi xem đáp án",
  "Brought it to mind": "Đã nhớ lại được",
  "A word to revisit": "Cần ôn lại",
  "Your first retrieval is the beginning.":
    "Lần nhớ lại đầu tiên là bước khởi đầu.",
  "Waiting in your introduction queue": "Đang chờ đến lượt học",
  "Practice this word": "Luyện từ này",
  "Loading your practice…": "Đang tải bài luyện tập…",
  "Session complete": "Hoàn thành buổi luyện tập",
  "You practiced {count} words. Coming back after a little time is what helps them stay.":
    "Bạn đã luyện {count} từ. Ôn lại sau một khoảng thời gian sẽ giúp bạn nhớ lâu hơn.",
  "Back to my words": "Về Từ của bạn",
  "Practice {count} remaining words": "Luyện tiếp {count} từ còn lại",
  "Continue writing": "Tiếp tục viết",
  "Your words are up to date": "Bạn đã ôn hết từ đến hạn",
  "Recall words and use them in your own sentences.":
    "Nhớ lại từ và đặt câu của riêng bạn.",
  "Write something new, or return when your next review is due.":
    "Viết bài mới hoặc quay lại khi đến lần ôn tiếp theo.",
  "Next review:": "Lần ôn tiếp theo:",
  "Start practice": "Bắt đầu luyện tập",
  "Recall the word": "Nhớ lại từ",
  "Complete the sentence": "Hoàn thành câu",
  "Rewrite the sentence": "Viết lại câu",
  "Write your own sentence": "Đặt câu của bạn",
  "Write about the idea": "Viết về ý tưởng",
  "Choose the precise meaning": "Chọn cách diễn đạt chính xác",
  "Save and exit practice": "Lưu và thoát luyện tập",
  "Question {position} of {total}": "Câu {position} / {total}",
  "Practice progress": "Tiến độ luyện tập",
  "Practice using the word": "Luyện cách dùng từ",
  Use: "Dùng từ",
  "in a sentence of your own.": "để đặt một câu của riêng bạn.",
  "Seeing the answer is part of learning. This builds usage, without counting as independent recall.":
    "Xem đáp án cũng là một phần của việc học. Bước này giúp luyện cách dùng, không tính là tự nhớ lại.",
  "You found the word. Write a complete sentence to show how you would use it.":
    "Bạn đã nhớ được từ. Hãy viết một câu hoàn chỉnh để thể hiện cách dùng.",
  "You found the word. Now use it in a complete sentence to finish this step.":
    "Bạn đã nhớ được từ. Hãy dùng từ trong một câu hoàn chỉnh để kết thúc bước này.",
  "The word is right, but this step needs a complete sentence that shows its meaning.":
    "Bạn đã viết đúng từ, nhưng bước này cần một câu hoàn chỉnh thể hiện nghĩa của từ.",
  "Use the shown word in a complete, natural sentence that shows its meaning.":
    "Hãy dùng từ đã xem trong một câu hoàn chỉnh, tự nhiên và thể hiện nghĩa của từ.",
  "You can practice this word again when it is due.":
    "Bạn có thể luyện lại từ này khi đến lượt ôn tiếp theo.",
  "It hasn’t come to mind yet. Take a hint, or reveal the word and try using it in a sentence.":
    "Bạn chưa nhớ ra từ này. Hãy thử lại, xem gợi ý, hoặc xem đáp án rồi đặt câu với từ đó.",
  "You know the idea. Which word comes to mind?":
    "Bạn đã hiểu ý nghĩa. Bạn nhớ đến từ nào?",
  "Keep the meaning natural. There may be more than one good answer.":
    "Diễn đạt tự nhiên, đúng nghĩa. Có thể có nhiều đáp án phù hợp.",
  "Your previous attempt": "Câu trả lời trước",
  "Your answer": "Câu trả lời của bạn",
  "The word that comes to mind…": "Nhập từ tiếng Anh bạn nhớ đến…",
  "Your words go here…": "Viết câu trả lời bằng tiếng Anh…",
  "Another word also works": "Một từ khác cũng phù hợp",
  "Try using the revealed word": "Thử dùng từ vừa được gợi ý",
  "Correct use after reveal": "Đã dùng đúng sau khi xem đáp án",
  "Right word; check the spelling": "Đúng từ rồi; hãy kiểm tra chính tả",
  "Correct use": "Bạn đã dùng đúng",
  "Word recalled; add context": "Đã nhớ đúng từ; hãy thêm ngữ cảnh",
  "Word recalled; write a sentence": "Đã nhớ đúng từ; hãy đặt câu",
  "Sentence skipped for now": "Tạm bỏ qua bước đặt câu",
  "Let’s try it in a sentence": "Cùng thử đặt câu với từ này",
  "{word} has moved to {stage}.": "Từ {word} đã chuyển sang {stage}.",
  "The word was": "Đáp án là",
  ". Try it in a new sentence next time.":
    ". Lần sau, hãy thử dùng từ này trong một câu mới.",
  "One moment…": "Chờ một chút nhé…",
  "Reveal the word": "Xem đáp án",
  "Show a hint": "Xem gợi ý",
  "Another hint": "Gợi ý tiếp",
  "Considering your answer…": "Đang xem câu trả lời…",
  "Check my answer": "Kiểm tra câu trả lời",
  "Skip the sentence for now": "Tạm bỏ qua bước đặt câu",
  "Finish this session": "Kết thúc buổi luyện",
  "Next word": "Từ tiếp theo",
  "Demo feedback uses curated examples; it is not a comprehensive language assessment.":
    "Góp ý dùng thử dựa trên các ví dụ có sẵn, chưa phải đánh giá ngôn ngữ toàn diện.",
  "Your progress is saved in this tab.":
    "Tiến trình đã được lưu trong thẻ này.",
  "Review recurring phrases in their original context.":
    "Xem những cách diễn đạt bạn hay dùng trong ngữ cảnh gốc.",
  "Repeating a word isn’t a problem. If it says exactly what you mean, keep it. These alternatives offer different shades of meaning.":
    "Lặp lại một từ không phải là lỗi. Nếu từ diễn đạt đúng ý bạn, hãy giữ nguyên. Các gợi ý khác giúp bạn khám phá thêm sắc thái nghĩa.",
  "Potential patterns": "Những xu hướng ban đầu",
  "Frequent choices": "Cách diễn đạt thường dùng",
  "From {count} pieces of writing": "Từ {count} bài viết",
  "No writing to explore yet.": "Chưa có bài viết để xem lại.",
  "Write a few sentences to see recurring choices in context.":
    "Viết vài câu để khám phá những cách diễn đạt bạn thường dùng.",
  "Start with a few sentences": "Bắt đầu bằng vài câu",
  "You’ve used": "Bạn đã dùng",
  "{count} times": "{count} lần",
  "Examples from your writing": "Ví dụ từ bài viết của bạn",
  "View in writing": "Xem trong bài viết",
  "Sometimes this is just right. In other contexts, consider:":
    "Đôi khi cách viết này đã phù hợp. Trong ngữ cảnh khác, bạn có thể cân nhắc:",
  "View word": "Xem từ",
  "Save {word} for practice": "Lưu từ {word} để luyện tập",
  "Try in writing": "Thử viết với từ này",
  "“{word}” is saved for later practice.": "Đã lưu “{word}” để luyện tập sau.",
  "“{word}” is ready to practice.": "Từ “{word}” đã sẵn sàng để luyện tập.",
  "It’s early. These are observations from a small writing sample, not conclusions about your vocabulary.":
    "Đây mới là nhận xét từ một số ít bài viết, chưa phải kết luận về vốn từ của bạn.",
  "Frequency shows what you reach for, not what you should avoid.":
    "Tần suất cho biết bạn hay dùng từ nào, không có nghĩa là bạn nên tránh từ đó.",
  "Leave Settings without saving your changes?":
    "Rời Cài đặt mà chưa lưu thay đổi?",
  "Your preferences are saved.": "Đã lưu cài đặt của bạn.",
  "Sample words and their illustrative history have been removed.":
    "Đã xóa từ mẫu và lịch sử minh họa.",
  "Shown in your workspace.": "Tên hiển thị trong không gian học.",
  "Words per session": "Số từ mỗi buổi",
  "A small, manageable amount of practice.":
    "Lượng bài tập vừa sức cho mỗi buổi.",
  "{count} words": "{count} từ",
  "Saving changes…": "Đang lưu thay đổi…",
  "Unsaved changes": "Có thay đổi chưa lưu",
  "All changes saved": "Đã lưu mọi thay đổi",
  "Save changes": "Lưu thay đổi",
  "Sign out": "Đăng xuất",
  "How practice works": "Cách luyện tập hoạt động",
  "Words become active through spaced recall, natural usage, varied contexts, and independence. Active words receive occasional check-ins. One difficult day won’t undo your progress.":
    "Bạn làm chủ từ qua việc ôn tập ngắt quãng và tự dùng từ một cách tự nhiên trong nhiều ngữ cảnh. Những từ đã vận dụng vẫn được ôn lại định kỳ. Một ngày khó khăn không xóa đi tiến bộ của bạn.",
  "Writing suggestions and feedback currently come from curated examples. They do not assess all of your language or writing quality.":
    "Gợi ý từ và góp ý hiện dựa trên các ví dụ có sẵn, chưa đánh giá toàn bộ năng lực ngôn ngữ hoặc chất lượng bài viết.",
  "Sample collection": "Bộ từ mẫu",
  "The sample words have illustrative practice history. Removing the collection keeps words you added yourself.":
    "Các từ mẫu có lịch sử luyện tập minh họa. Xóa bộ mẫu không ảnh hưởng đến những từ bạn tự thêm.",
  "Remove sample words and their practice history?":
    "Xóa các từ mẫu cùng lịch sử luyện tập của chúng?",
  "Keep them": "Giữ lại",
  "Remove sample collection": "Xóa bộ từ mẫu",
  ...v2vi,
};

export type Locale = "vi" | "en";
export const LOCALE_COOKIE = "ownword-language";
export const resolveLocale = (value?: string | null): Locale =>
  value === "en" ? "en" : "vi";
export type TranslationValues = Record<string, string | number>;
export function translate(
  locale: Locale,
  key: string,
  values: TranslationValues = {},
): string {
  const singular: Record<string, string> = {
    "You practiced {count} words today.": "You practiced {count} word today.",
    "{count} words practiced": "{count} word practiced",
    "{count} words added to your WordBoard.":
      "{count} word added to your WordBoard.",
    "used {count} times": "used {count} time",
    "{count} insights": "{count} insight",
    "{count} suggestions found": "{count} suggestion found",
    "{count} words": "{count} word",
    "Practice {count} words": "Practice {count} word",
    "Practice {count} remaining words": "Practice {count} remaining word",
    "{count} words ready to practice": "{count} word ready to practice",
    "{count} suggestions left to decide": "{count} suggestion left to decide",
    "{count} times": "{count} time",
    "From {count} pieces of writing": "From {count} piece of writing",
    "You practiced {count} words. Coming back after a little time is what helps them stay.":
      "You practiced {count} word. Coming back after a little time is what helps them stay.",
    "{count} word suggestions. Your original writing is preserved.":
      "{count} word suggestion. Your original writing is preserved.",
  };
  const message =
    locale === "vi"
      ? Object.prototype.hasOwnProperty.call(vi, key)
        ? vi[key]
        : key
      : values.count === 1 &&
          Object.prototype.hasOwnProperty.call(singular, key)
        ? singular[key]
        : key;
  return message.replace(/\{(\w+)\}/g, (placeholder, name: string) =>
    Object.prototype.hasOwnProperty.call(values, name)
      ? String(values[name])
      : placeholder,
  );
}
