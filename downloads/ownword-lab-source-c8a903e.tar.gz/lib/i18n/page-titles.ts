import type { Locale } from "./messages";

const pageTitles = {
  home: { en: "Practice writing in English", vi: "Luyện viết tiếng Anh" },
  diagnostic: { en: "Choose a writing prompt", vi: "Chọn đề viết" },
  profile: { en: "Writing Profile", vi: "Hồ sơ viết" },
  focus: { en: "Writing Focus", vi: "Trọng tâm" },
  submission: { en: "Essay feedback", vi: "Góp ý bài viết" },
  revision: { en: "Revise your essay", vi: "Chỉnh sửa bài viết" },
  practice: { en: "Writing practice", vi: "Luyện viết" },
  privacy: { en: "Privacy Policy", vi: "Chính sách quyền riêng tư" },
  terms: { en: "Terms of Use", vi: "Điều khoản sử dụng" },
  account: { en: "Sign in", vi: "Đăng nhập" },
  notFound: { en: "Page not found", vi: "Không tìm thấy trang" },
} as const;

export type PageTitleName = keyof typeof pageTitles;

export function pageTitle(name: PageTitleName, locale: Locale) {
  return `${pageTitles[name][locale]} | Ownword`;
}
