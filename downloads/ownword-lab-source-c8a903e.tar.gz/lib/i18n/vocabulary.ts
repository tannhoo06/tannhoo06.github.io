/** Vietnamese meanings for the built-in, fixed demo definitions. */
export const vietnameseDemoMeanings: Record<string, string> = {
  "So small that it makes little practical difference.": "Nhỏ đến mức gần như không tạo ra khác biệt trong thực tế.",
  "Sensitive to small but meaningful differences.": "Tinh tế, chú ý đến những khác biệt nhỏ nhưng có ý nghĩa.",
  "Convincing enough to hold your attention or persuade you.": "Có sức thuyết phục hoặc thu hút sự chú ý.",
  "Done consciously and with careful intention.": "Được thực hiện có ý thức và chủ đích.",
  "Not yet certain or final; open to change.": "Chưa chắc chắn hoặc chưa được quyết định cuối cùng; có thể thay đổi.",
  "Large enough in amount or importance to make a difference.": "Đủ lớn về số lượng hoặc tầm quan trọng để tạo ra khác biệt.",
  "To put an idea or feeling into clear words.": "Diễn đạt rõ ràng một ý tưởng hoặc cảm xúc bằng lời.",
  "Able to recover and adapt after difficulties.": "Có khả năng phục hồi và thích nghi sau khó khăn.",
  "Important because it changes what happens next.": "Quan trọng vì tạo ra bước ngoặt cho những gì xảy ra sau đó.",
  "Necessary for a particular outcome or success.": "Cần thiết để đạt được một kết quả hoặc thành công cụ thể.",
  "Meaningful or large enough to deserve attention.": "Có ý nghĩa hoặc đủ lớn để đáng được chú ý.",
  "More important than every other consideration.": "Quan trọng hơn mọi yếu tố khác cần cân nhắc.",
};
