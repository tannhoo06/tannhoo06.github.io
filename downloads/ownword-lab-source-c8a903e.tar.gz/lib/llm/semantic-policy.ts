import { lexicalTokens } from "./lexical-units";

// Profiles describe entailment jumps, rather than synonym-pair exceptions.
const strengthProfiles = [
  {
    name: "fundamental-change",
    source:
      /\b(?:big|large|major|significant|noticeable)\b.{0,30}\b(?:effect|impact|change)|\b(?:effect|impact) on\b|\bchang(?:e[sd]?|ing)\b/i,
    strong:
      /\b(?:transform\w*|revolutioniz\w*|fundamental(?:ly)?|complete(?:ly)?|radical(?:ly)?)\b/i,
    licensed:
      /\b(?:transform\w*|fundamental(?:ly)?|complete(?:ly)?|radical(?:ly)?)\b|\binto (?:a |an )?(?:different|new)\b/i,
  },
  {
    name: "proof-certainty",
    source:
      /\b(?:support\w*|suggest\w*|consistent with|possible|possibly|likely|likelihood|may|might|could)\b/i,
    strong:
      /\b(?:prov(?:e[sd]?|ing)|proof|guarantee\w*|ensur\w*|conclusive(?:ly)?|certain(?:ly|ty)?|definit(?:e|ely))\b/i,
    licensed:
      /\b(?:prov(?:e[sd]?|ing)|proof|guarantee\w*|conclusive(?:ly)?|certain(?:ly|ty)?)\b/i,
  },
  {
    name: "complete-resolution",
    source: /\b(?:reduc\w*|less(?: severe)?|partial\w*|help\w*|improv\w*)\b/i,
    strong: /\b(?:eliminat\w*|eradicat\w*|solv\w*|fix(?:e[sd])?|prevent\w*)\b/i,
    licensed: /\b(?:eliminat\w*|eradicat\w*|solv\w*|fix(?:e[sd])?)\b/i,
  },
  {
    name: "impossibility",
    source: /\b(?:difficult|hard|challenging)\b/i,
    strong: /\b(?:impossible|unachievable|insurmountable)\b/i,
    licensed: /\b(?:impossible|unachievable|insurmountable)\b/i,
  },
  {
    name: "intensity",
    source: /\b(?:noticeable|visible|perceptible)\b/i,
    strong: /\b(?:dramatic(?:ally)?|spectacular(?:ly)?|extreme(?:ly)?)\b/i,
    licensed: /\b(?:dramatic(?:ally)?|spectacular(?:ly)?|extreme(?:ly)?)\b/i,
  },
  {
    name: "causal-necessity",
    source: /\b(?:influenc\w*|help\w*|contribut\w*)\b/i,
    strong: /\b(?:determin(?:e[sd]?|ing)|caus(?:e[sd]?|ing)|necessitat\w*)\b/i,
    licensed:
      /\b(?:determin(?:e[sd]?|ing)|caus(?:e[sd]?|ing)|necessitat\w*)\b/i,
  },
  {
    name: "absolute-mental-effect",
    source:
      /\b(?:interest\w*|intresting|attention|persuad\w*|convinc\w*|evidence|argument|strong)\b/i,
    strong:
      /\b(?:compel|force|demand|command|guarantee|ensure|cause)\w*\b.{0,30}\b(?:agree\w*|belief|acceptance|conviction|persuasion)\b|\bmakes?\b.{0,30}\b(?:agree|believe|accept)\b|\b(?:automatically|inevitably)\b.{0,25}\b(?:convinc\w*|persuad\w*|agree\w*|belie\w*)\b|\bno\b.{0,30}\b(?:possibility|possib\w*)\b.{0,20}\bdisagree\w*\b|\b(?:completely|entirely|fully|totally)\b.{0,25}\b(?:attention|agreement)\b|\battention\b.{0,25}\b(?:completely|entirely|fully|totally)\b|\bwithout\b.{0,24}\b(?:persuasion|doubt|question)\b/i,
    licensed:
      /\b(?:forced|compelled|demanded)\b.{0,30}\b(?:agree\w*|belief)\b|\b(?:complete|entire|full|total) attention\b/i,
  },
];

/** Generic teaching about a persuasive quality must not assert the audience's
 * mental or behavioral response. Outcome verbs are outside this profile: their
 * meanings may themselves encode a response. This remains a bounded cue check. */
export function instructionalResponseOverclaims(
  candidate: string,
  partOfSpeech: string,
  fields: Record<string, string>,
) {
  if (!/^adjective$/i.test(partOfSpeech) ||
      !/^(?:compelling|persuasive|convincing|forceful|cogent|powerful)$/i.test(candidate)) return [];
  const families: Array<[string, RegExp]> = [
    ["persuasion-success", /\b(?:persuades|convinces|(?:persuade|convince)\s+(?:people|others|listeners|readers|the\s+audience)|wins\s+(?:(?:people|others|listeners|readers|the\s+audience)\s+over|over\s+(?:people|others|listeners|readers|the\s+audience))|secures\s+(?:agreement|acceptance)|gets\s+(?:people|others|listeners|readers|the\s+audience)\s+to\s+(?:agree|accept|believe)|results\s+in\s+(?:agreement|acceptance))\b/gi],
    ["belief-or-agreement", /\b(?:driv\w*|caus\w*|produc\w*|generat\w*|bring\w* about|ensur\w*|guarantee\w*|forc\w*|command\w*|demand\w*)\b[^.!?;]{0,65}\b(?:conviction|agreement|belief|acceptance|persuasion)\b/gi],
    ["belief-or-agreement", /\b(?:lead\w*|mov\w*|push\w*)\b[^.!?;]{0,55}\b(?:toward|towards|to|into)\b[^.!?;]{0,25}\b(?:agreement|belief|acceptance|conviction)\b/gi],
    ["belief-or-agreement", /\b(?:mak\w*|forc\w*|caus\w*)\b[^.!?;]{0,60}\b(?:agree\w*|believ\w*|accept\w*)\b/gi],
    ["changed-opinion", /\b(?:chang\w*|alter\w*)\b[^.!?;]{0,55}\b(?:minds?|opinions?|beliefs?|views?)\b/gi],
    ["automatic-persuasion", /\b(?:automatically|inevitably|necessarily)\s+(?:convinc\w*|persuad\w*|sway\w*)\b[^.!?;]*/gi],
    ["emotional-or-behavioral-response", /\b(?:caus\w*|mak\w*|forc\w*|produc\w*|guarantee\w*|ensur\w*)\b[^.!?;]{0,55}\b(?:fear|panic|anger|joy|sadness|obey\w*|purchas\w*|buy\w*|vote\w*|act\w*)\b/gi],
  ];
  const findings: {candidate:string;field:string;phrase:string;dimension:string;lexicallyEntailed:false}[] = [];
  for (const [field,text] of Object.entries(fields)) {
    // A normal example describes one event; inspect examples only when they
    // explicitly present a general rule about the lexical item.
    if (field.startsWith("example") && !/\b(?:always|typically|generally|inevitably|necessarily|automatically)\b/i.test(text)) continue;
    for (const [dimension, pattern] of families) for (const m of text.matchAll(pattern)) {
      const before = text.slice(Math.max(0,m.index! - 45),m.index!);
      if (/\b(?:not|never|without)\s+(?:necessarily\s+)?$/i.test(before)) continue;
      if (dimension === "persuasion-success" && /\b(?:can|could|may|might|help(?:s)?(?:\s+to)?|designed\s+to)\s+$/i.test(before)) continue;
      findings.push({candidate,field,phrase:m[0],dimension,lexicallyEntailed:false});
    }
  }
  return findings;
}

/** Intensity and importance do not by themselves entail duration. Temporal
 * vocabulary itself is outside this bounded lexical profile. */
export function instructionalTemporalOverclaims(
  candidate: string,
  partOfSpeech: string,
  fields: Record<string, string>,
) {
  if (!/^(?:adjective|noun)$/i.test(partOfSpeech) ||
      !/^(?:profound|significant|substantial|dramatic|transformative|transformation|major|powerful|considerable|severe|meaningful|consequential)$/i.test(candidate)) return [];
  const temporal = /\b(?:long[- ]lasting|long[- ]term|long[- ]standing|lasting|enduring|persistent|permanent(?:ly)?|sustained|continuing|ongoing|durable|prolonged|persist(?:s|ed|ing)?|remains? over time|continues? indefinitely|does not fade)\b/gi;
  const findings: {candidate:string;field:string;phrase:string;dimension:string;lexicallyEntailed:false}[] = [];
  for (const [field,text] of Object.entries(fields)) {
    if (field.startsWith("example") && !/\b(?:always|typically|generally|inevitably|necessarily|automatically)\b/i.test(text)) continue;
    for (const m of text.matchAll(temporal)) {
      const before = text.slice(Math.max(0,m.index! - 45),m.index!);
      if (/\b(?:not|never|without)\s+(?:necessarily\s+)?$/i.test(before) ||
          /\b(?:may|might|can|could)\s+be\s+$/i.test(before)) continue;
      findings.push({candidate,field,phrase:m[0],dimension:"duration-or-persistence",lexicallyEntailed:false});
    }
  }
  return findings;
}
export function semanticStrength(
  source: string,
  replacement: string,
  explanation: string,
  localContext = source,
) {
  const rewrite: string[] = [],
    teaching: string[] = [];
  const matches = (text: string, pattern: RegExp) => [
    ...text.matchAll(new RegExp(pattern.source, "gi")),
  ];
  const scoped = (text: string, at: number) => {
    const before =
      text
        .slice(Math.max(0, at - 90), at)
        .split(/[.;,:!?]|\b(?:but|however|although|and|or)\b/i)
        .at(-1) ?? "";
    if (
      /\b(?:not|never|without|no|neither|nor)(?:\s+necessarily)?(?:\s+(?:fully|completely|entirely))?\s*$/i.test(
        before,
      ) &&
      !/\bnot\s+not\s*$/i.test(before)
    )
      return "negated";
    if (
      /\b(?:helps?|helping)(?:\s+to)?\s*$|\bcontributes?\s+to\s*$|\bsupports?\s*$|\b(?:may|might|could|partially|partly)\s*$/i.test(
        before,
      )
    )
      return "qualified";
    return "affirmative";
  };
  for (const p of strengthProfiles)
    if (
      p.source.test(source) &&
      !matches(localContext, p.licensed).some(
        (m) => scoped(localContext, m.index!) === "affirmative",
      )
    ) {
      const risky = matches(replacement, p.strong).filter(
        (m) => scoped(replacement, m.index!) !== "negated",
      );
      // A hedge is not a conclusive claim, but adding a new possible outcome
      // to an actual source event still needs evidence. Teaching definitions
      // may describe contribution/potential without asserting that outcome.
      if (risky.length)
        rewrite.push(
          risky.every((m) => scoped(replacement, m.index!) === "qualified")
            ? "qualified-" + p.name
            : p.name,
        );
      if (
        matches(explanation, p.strong).some(
          (m) => scoped(explanation, m.index!) === "affirmative",
        )
      )
        teaching.push(p.name);
    }
  // An achieved source outcome does not license a generic lexical guarantee.
  const mental = strengthProfiles.find((p) => p.name === "absolute-mental-effect")!;
  if (mental.source.test(source) && !teaching.includes(mental.name) &&
      matches(explanation, mental.strong).some((m) => scoped(explanation, m.index!) === "affirmative"))
    teaching.push(mental.name);
  return { rewrite, teaching };
}

export function lexicalBenefit(
  old: string,
  local: string,
  canonical: string,
  context: {
    sentence?: string;
    definition?: string;
    partOfSpeech?: string;
  } = {},
) {
  const a = lexicalTokens(old),
    b = lexicalTokens(local);
  let left = 0,
    right = 0;
  while (left < a.length && left < b.length && a[left] === b[left]) left++;
  while (
    right < a.length - left &&
    right < b.length - left &&
    a.at(-1 - right) === b.at(-1 - right)
  )
    right++;
  const removed = a.slice(left, right ? -right : undefined),
    added = b.slice(left, right ? -right : undefined);
  const sentence = context.sentence ?? old,
    definition = context.definition ?? "";
  const sourceBasic =
    removed.length === 1 &&
    /^(?:small|little|slight|big|large|clear|evident|obvious|important|fast|quick|increase|rise|decrease|fall|use|used|using|uses)$/.test(
      removed[0],
    );
  // Evidence profiles compare the source concept with a definitional meaning;
  // no candidate spelling or model rationale grants a benefit pass.
  const precision =
    (/\b(?:too small to affect|one cent|small to matter|little practical|not affect|not final)\b/i.test(
      sentence,
    ) &&
      /\b(?:unimportant|insignificant|not worth|subject to change|changed later|not final|provisional)\b/i.test(
        definition,
      )) ||
    (/\b(?:persuad\w*|convinc\w*)\b/i.test(sentence) &&
      /\b(?:attention|persuad\w*|convinc\w*|belief)\b/i.test(definition)) ||
    (/\b(?:effect|impact)\b/i.test(sentence) &&
      /\b(?:changing|change|important|planning)\b/i.test(sentence) &&
      /\b(?:deep|serious|significan\w*|importance)\b/i.test(definition)) ||
    (/\b(?:small|fine|meaningful|subtle)\b.{0,40}\b(?:differences|distinctions)\b/i.test(
      sentence,
    ) &&
      /\b(?:difference|distinction|detail)\w*\b/i.test(definition));
  const process =
    /\b(?:steps|process|paperwork|workflow)\b/i.test(sentence) &&
    /\b(?:simpler|fewer|simplif\w*)\b/i.test(sentence);
  const partial =
    /\b(?:less severe|reduce\w*|partial\w*)\b/i.test(old) &&
    /\b(?:severity|severe|reduce|less|harmful)\b/i.test(definition);
  const support =
    /\b(?:more support|earlier findings|additional evidence)\b/i.test(
      sentence,
    ) && /\b(?:support|evidence|confirm|backing)\w*\b/i.test(definition);
  const provisional =
    /\bnot final\b/i.test(old) &&
    /\b(?:change|revise|confirmation|present|final)\w*\b/i.test(definition);
  const recovery =
    /\b(?:recover\w*|setbacks)\b/i.test(sentence) &&
    /\b(?:recover\w*|return|bounce)\b/i.test(definition);
  const compressed =
    removed.length - added.length >= 2 &&
    /\b(?:make|made|provide|provided|give|gave|not|very|enough)\b/i.test(old);
  const wrapper =
    /^(?:a |an |the )?(?:degree|level|amount|sense|state|quality) of\b/.test(
      local.toLowerCase(),
    );
  // A single already precise persuasion verb is not itself evidence of gain.
  const equivalentPersuasionSwap =
    removed.length === 1 && added.length === 1 &&
    /^(?:convinc(?:e|es|ed|ing)|persuad(?:e|es|ed|ing)|sway(?:s|ed|ing)?)$/.test(removed[0]) &&
    /^(?:convinc(?:e|es|ed|ing)|persuad(?:e|es|ed|ing)|sway(?:s|ed|ing)?)$/.test(added[0]);
  const scores = {
    conceptNaming: process || partial || support || provisional || recovery,
    semanticPrecision: precision,
    meaningfulCompression: compressed,
    conventionalPackaging: canonical.includes(" "),
    reusableCollocationalValue:
      (!sourceBasic && removed.length > 0 && added.length > 0 && !wrapper) ||
      (/^adverb$/i.test(context.partOfSpeech ?? "") &&
        removed.length === 0 &&
        added.length === 1 &&
        /\b(?:every|tiny|decimal|footnote|reference)\b/i.test(sentence) &&
        /\b(?:checked|checking|reviewed|inspected)\b/i.test(sentence)),
  };
  const sufficient = !wrapper && !equivalentPersuasionSwap && Object.values(scores).some(Boolean);
  return {
    sufficient,
    evidence: sufficient
      ? Object.entries(scores)
          .filter(([, v]) => v)
          .map(([k]) => k)
          .join(",")
      : wrapper
        ? "abstract-wrapper"
        : "same-level-no-source-gain",
    scores,
    sourceEvidence: {
      sourceBasic,
      process,
      partial,
      support,
      provisional,
      recovery,
    },
  };
}
