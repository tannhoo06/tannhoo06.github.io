import type { Evaluation, HintLevel, Lexeme } from "../domain/types";
import { isEnglishInstruction } from "./output-language";
import { unitEvidence } from "./lexical-units";

function oneEditApart(a: string, b: string): boolean {
  if (Math.abs(a.length - b.length) > 1) return false;
  if (a.length === b.length) {
    const different = [...a].flatMap((letter, index) =>
      letter === b[index] ? [] : [index],
    );
    return (
      different.length <= 1 ||
      (different.length === 2 &&
        different[1] === different[0] + 1 &&
        a[different[0]] === b[different[1]] &&
        a[different[1]] === b[different[0]])
    );
  }
  const longer = a.length > b.length ? a : b;
  const shorter = a.length > b.length ? b : a;
  let i = 0;
  while (i < shorter.length && longer[i] === shorter[i]) i++;
  return longer.slice(i + 1) === shorter.slice(i);
}

/** Necessary lexical evidence, not proof that a sentence is semantically correct. */
export function adjectiveAdverbForm(word: string): string {
  const target = word.normalize("NFKC").toLowerCase();
  if (target.endsWith("ble")) return `${target.slice(0, -1)}y`;
  if (/[^aeiou]y$/.test(target)) return `${target.slice(0, -1)}ily`;
  if (target.endsWith("ic")) return `${target}ally`;
  return `${target}ly`;
}

export function hasWordEvidence(word: string, text: string, adjective = false): boolean {
  if (word.trim().includes(" "))
    return unitEvidence(word.trim().toLowerCase(), text, hasWordEvidence);
  const target = word.normalize("NFKC").toLowerCase();
  const forms = new Set([
    target,
    target + "s",
    target + "es",
    target + "ed",
    target + "ing",
  ]);
  if (target.endsWith("e")) {
    forms.add(target + "d");
    forms.add(target.slice(0, -1) + "ing");
  }
  if (/[^aeiou]y$/.test(target)) {
    forms.add(target.slice(0, -1) + "ies");
    forms.add(target.slice(0, -1) + "ied");
  }
  if (/[aeiou][bcdfghjklmnpqrstvwxyz]$/.test(target)) {
    forms.add(target + target.at(-1) + "ed");
    forms.add(target + target.at(-1) + "ing");
  }
  if (adjective) forms.add(adjectiveAdverbForm(target));
  const tokens =
    text
      .normalize("NFKC")
      .toLowerCase()
      .match(/[a-z]+(?:-[a-z]+)*/g) ?? [];
  return tokens.some(
    (token) =>
      forms.has(token) || (target.length >= 5 && oneEditApart(target, token)),
  );
}

/** Enforce facts the server can check, even if the model obeys an injected grading request. */
export function guardEvaluation(
  word: Lexeme,
  text: string,
  result: Evaluation,
  options: {
    definitionRecall?: boolean;
    revealed?: boolean;
    hideUnrecalledTarget?: boolean;
    hint?: HintLevel;
  } = {},
): Evaluation {
  const evidence = hasWordEvidence(word.word, text, word.partOfSpeech === "adjective");
  const supportedCorrection =
    evidence &&
    result.spellingCorrection?.toLowerCase() === word.word.toLowerCase()
      ? result.spellingCorrection
      : null;
  // A strong-cue single-word answer with a checked typo and an acknowledged
  // canonical correction demonstrates recall even if the model demands perfect
  // spelling. It never establishes sentence precision, or overrides misuse,
  // synonyms, revealed answers, or missing lexical evidence.
  const acknowledgedTypo =
    options.definitionRecall &&
    (/^[a-z]+(?:-[a-z]+)*[.!?]?$/i.test(text.trim()) ||
      (word.word.includes(" ") &&
        unitEvidence(word.word, text, hasWordEvidence, true))) &&
    !!supportedCorrection &&
    !result.majorMisuse &&
    !result.validAlternative;
  const retrieved =
    evidence && !options.revealed && (result.retrieved || !!acknowledgedTypo);
  const guarded = {
    ...result,
    retrieved,
    precise:
      result.precise &&
      evidence &&
      !result.majorMisuse &&
      !(
        options.definitionRecall &&
        (text.trim().split(/\s+/).length === 1 ||
          (word.word.includes(" ") &&
            unitEvidence(word.word, text, hasWordEvidence, true)))
      ),
    spellingCorrection: retrieved ? supportedCorrection : null,
  };
  // Model prose is not authoritative, even if the model's booleans were already
  // false. Rebuilding it closes praise, obfuscated spelling and letter-hint leaks
  // without attempting to enumerate all ways an attacker can phrase them.
  guarded.feedback = guarded.retrieved
    ? guarded.majorMisuse
      ? "You recalled the word, but this use does not fit its intended meaning. Try another context."
      : guarded.precise
        ? "You recalled the word and used it appropriately in this context."
        : "You recalled the word. Contextual precision is not established yet; try using it in a fitting sentence."
    : options.revealed
      ? guarded.precise
        ? "This use fits the meaning. The answer was revealed, so it does not count as independent recall."
        : "The answer was revealed. Try using it in a sentence that fits its meaning; this does not count as independent recall."
      : guarded.validAlternative
        ? "That wording may express a related meaning, but recall of the word being practiced is not established. Try again."
        : "This response does not establish recall of the word being practiced. Try again from its meaning.";
  guarded.nuance = "";
  // Hints come only from the configured mode, never model feedback. Full reveal
  // is the only mode allowed to give the answer to an unsuccessful recall.
  const hint = options.hint ?? (options.revealed ? "revealed" : "none");
  if (!guarded.retrieved && options.hideUnrecalledTarget) {
    if (
      hint === "semantic" &&
      isEnglishInstruction(word.definition) &&
      !hasWordEvidence(word.word, word.definition)
    )
      guarded.nuance = `Meaning hint: ${word.definition}`;
    if (hint === "letter")
      guarded.nuance = `Letter hint: ${word.word.slice(0, 1)}.`;
    if (hint === "partial")
      guarded.nuance = `Spelling hint: ${word.word.slice(0, Math.min(3, Math.max(1, word.word.length - 1)))}${"_".repeat(Math.max(1, word.word.length - 3))}`;
    if (hint === "revealed" && options.revealed)
      guarded.nuance = `The word is ${word.word}.`;
  }
  return guarded;
}
