/** Infrastructure port: implementations must atomically reserve a slot across callers. */
export interface KeyRotationStore {
  reserve(poolId: string, size: number): Promise<number>;
}

/** Cycles only credentials for one provider; it never retries or switches providers. */
export class RoundRobinKeys {
  private readonly keys: readonly string[];
  private readonly poolId: Promise<string>;

  constructor(
    keys: readonly string[],
    private readonly store: KeyRotationStore,
  ) {
    if (
      keys.length < 2 ||
      new Set(keys).size !== keys.length ||
      keys.some((key) => !key.trim())
    )
      throw new Error(
        "A rotating key pool needs at least two distinct, non-empty keys.",
      );
    this.keys = [...keys];
    // Persist only a digest of the ordered pool, never API keys or individual key hashes.
    this.poolId = crypto.subtle
      .digest("SHA-256", new TextEncoder().encode(JSON.stringify(this.keys)))
      .then(
        (digest) =>
          "gemini:" +
          Array.from(new Uint8Array(digest), (byte) =>
            byte.toString(16).padStart(2, "0"),
          ).join(""),
      );
  }

  async nextKey(): Promise<string> {
    const index = await this.store.reserve(await this.poolId, this.keys.length);
    if (!Number.isInteger(index) || index < 0 || index >= this.keys.length)
      throw new Error("The language service key selector is unavailable.");
    return this.keys[index];
  }
}
