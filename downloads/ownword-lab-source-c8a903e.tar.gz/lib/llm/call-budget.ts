import type { LlmProvider } from "../domain/ports";

export class LanguageBudgetExceeded extends Error {
  constructor(readonly scope: "account" | "service", readonly resetAt?: string) {
    super("The daily language-service request limit has been reached.");
  }
}

export interface LlmCallBudget {
  take(): Promise<boolean>;
}

/** Provider-independent cost ceiling. Rejected calls never reach the provider. */
export function withCallBudget(
  provider: LlmProvider,
  budget?: LlmCallBudget,
  conceptOverride?: LlmProvider["discoverConcept"],
): LlmProvider {
  if (!budget && !conceptOverride) return provider;
  const allow = async () => {
    if (budget && !(await budget.take()))
      throw new LanguageBudgetExceeded("service");
  };
  if (provider.mode === "mock") {
    if (conceptOverride) {
      provider.discoverConcept = async (concept) => {
        await allow();
        return conceptOverride(concept);
      };
    }
    return provider;
  }
  return {
    mode: provider.mode,
    async checkWord(...args) {
      await allow();
      return provider.checkWord(...args);
    },
    async defineWord(...args) {
      await allow();
      return provider.defineWord(...args);
    },
    async translateLexeme(...args) {
      await allow();
      return provider.translateLexeme(...args);
    },
    async discoverConcept(...args) {
      await allow();
      return conceptOverride ? conceptOverride(...args) : provider.discoverConcept(...args);
    },
    async analyzeWriting(...args) {
      await allow();
      return provider.analyzeWriting(...args);
    },
    async suggestVocabulary(...args) {
      await allow();
      return provider.suggestVocabulary(...args);
    },
    async generateExercise(...args) {
      await allow();
      return provider.generateExercise(...args);
    },
    async evaluateUsage(...args) {
      await allow();
      return provider.evaluateUsage(...args);
    },
    async evaluateRecall(...args) {
      await allow();
      return provider.evaluateRecall(...args);
    },
  };
}
