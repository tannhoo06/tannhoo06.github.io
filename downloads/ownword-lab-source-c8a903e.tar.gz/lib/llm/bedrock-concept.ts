import { BedrockRuntimeClient, ConverseCommand } from "@aws-sdk/client-bedrock-runtime";
import type { z } from "zod";
import { GeminiLlm, SYSTEM } from "./gemini";
import { toJsonSchema } from "./openrouter";

export const bedrockConceptModels = ["deepseek.v3.2", "us.moonshotai.kimi-k3.1"] as const;
export type BedrockConceptModel = (typeof bedrockConceptModels)[number];

const unsupportedKeywords = new Set(["minLength", "maxLength", "minimum", "maximum", "minItems", "maxItems"]);
let runtimeClient: BedrockRuntimeClient | undefined;

class BedrockConceptLlm extends GeminiLlm {
  constructor(private readonly client: Pick<BedrockRuntimeClient, "send">, private readonly modelId: BedrockConceptModel) {
    super("unused");
  }

  protected override async generate<T>(task: string, input: unknown, schema: unknown,
    validator: z.ZodType<T>, system: string = SYSTEM): Promise<T> {
    const kimi = this.modelId === "us.moonshotai.kimi-k3.1";
    const response = await this.client.send(new ConverseCommand({
      modelId: this.modelId,
      system: [{ text: [system, task].filter(Boolean).join("\n\n") }],
      messages: [{ role: "user", content: [{ text: JSON.stringify({ input }) }] }],
      inferenceConfig: { maxTokens: 1500, ...(kimi ? {} : { temperature: 0.3 }) },
      ...(kimi && { additionalModelRequestFields: { reasoning_effort: "low" } }),
      outputConfig: { textFormat: { type: "json_schema", structure: { jsonSchema: {
        name: "ownword_concept_search",
        schema: JSON.stringify(toJsonSchema(schema), (key, value) => unsupportedKeywords.has(key) ? undefined : value),
      } } } },
    }), { abortSignal: AbortSignal.timeout(30_000) });
    const text = response.output?.message?.content?.map((block) => block.text ?? "").join("");
    if (response.stopReason !== "end_turn" || !text) throw new Error("Bedrock did not return a complete concept search.");
    try {
      return validator.parse(JSON.parse(text));
    } catch {
      throw new Error("Bedrock returned an invalid concept search result.");
    }
  }
}

export function createBedrockConceptDiscovery(modelId: BedrockConceptModel,
  client: Pick<BedrockRuntimeClient, "send"> =
    runtimeClient ??= new BedrockRuntimeClient({ region: "us-east-1", maxAttempts: 1 })) {
  const llm = new BedrockConceptLlm(client, modelId);
  return llm.discoverConcept.bind(llm);
}

export function readBedrockConceptModel(value: string | undefined): BedrockConceptModel | undefined {
  const model = value?.trim();
  if (!model) return undefined;
  const supported = bedrockConceptModels.find((candidate) => candidate === model);
  if (!supported) throw new Error("Unsupported BEDROCK_CONCEPT_MODEL.");
  return supported;
}
