import type { Lexeme } from "../domain/types";
export interface CatalogWord extends Lexeme {
  alternatives: string[];
  trigger: string;
  contexts: {
    domain: string;
    scenario: string;
    sentence: string;
    simple: string;
  }[];
}
export const CATALOG: CatalogWord[] = [
  {
    id: "negligible",
    word: "negligible",
    partOfSpeech: "adjective",
    definition: "So small that it makes little practical difference.",
    nuance:
      "Small is about size. Negligible says the size is too small to matter in this particular situation.",
    collocations: [
      "negligible difference",
      "negligible impact",
      "negligible cost",
    ],
    examples: [
      "The difference in battery life was negligible.",
      "The change had a negligible effect on the final cost.",
    ],
    alternatives: ["insignificant", "minimal", "tiny"],
    trigger: "(?:very small|tiny|small) (?:difference|impact|effect|cost)",
    contexts: [
      {
        domain: "technology",
        scenario:
          "One laptop lasts 10 hours; another lasts 10 hours and 2 minutes. You need either for a 6-hour day. Compare their battery life.",
        sentence: "For my working day, the difference in battery life is ____.",
        simple: "The difference in battery life is too small to matter.",
      },
      {
        domain: "finance",
        scenario:
          "A delivery fee rises by one cent on an order worth $500. Describe the effect on the total cost.",
        sentence: "The extra fee has a ____ effect on the total cost.",
        simple: "The extra delivery fee barely affects the total cost.",
      },
      {
        domain: "environment",
        scenario:
          "A change in packaging reduces a factory's annual waste by only a few grams. Describe its environmental effect.",
        sentence: "The packaging change has a ____ effect on annual waste.",
        simple:
          "The change reduces waste by too little to make a practical difference.",
      },
    ],
  },
  {
    id: "nuanced",
    word: "nuanced",
    partOfSpeech: "adjective",
    definition: "Sensitive to small but meaningful differences.",
    nuance:
      "A nuanced view notices qualifications and competing considerations, rather than treating a subject as simply good or bad.",
    collocations: [
      "nuanced perspective",
      "nuanced understanding",
      "nuanced argument",
      "nuanced explanation",
    ],
    examples: [
      "The essay offers a nuanced view of remote work.",
      "Experience gave her a more nuanced understanding of the debate.",
    ],
    alternatives: ["subtle", "balanced", "thoughtful"],
    trigger:
      "(?:more detailed|balanced|complex) (?:view|understanding|perspective)",
    contexts: [
      {
        domain: "work",
        scenario:
          "Working from home helps some colleagues concentrate but leaves others isolated. Describe a view that takes both experiences into account.",
        sentence: "We need a more ____ view of remote work.",
        simple:
          "We need a view of remote work that considers its subtle differences.",
      },
      {
        domain: "culture",
        scenario:
          "A film critic explores a character's kindness as well as their selfish choices. Describe the critic's interpretation.",
        sentence: "The review offers a ____ interpretation of the character.",
        simple:
          "The review notices subtle and sometimes conflicting aspects of the character.",
      },
      {
        domain: "education",
        scenario:
          "A teacher considers motivation, circumstances, and prior knowledge when discussing test results. Describe that understanding.",
        sentence: "The teacher has a ____ understanding of the results.",
        simple:
          "The teacher understands the subtle distinctions behind the test results.",
      },
    ],
  },
  {
    id: "compelling",
    word: "compelling",
    partOfSpeech: "adjective",
    definition: "Convincing enough to hold your attention or persuade you.",
    nuance:
      "Compelling reasons persuade; compelling stories hold attention. It is stronger and more specific than simply interesting.",
    collocations: [
      "compelling evidence",
      "compelling argument",
      "compelling story",
    ],
    examples: ["She made a compelling case for changing the policy."],
    alternatives: ["convincing", "persuasive", "gripping"],
    trigger:
      "(?:very interesting|really interesting|very convincing|convincing) (?:story|argument|case|evidence)",
    contexts: [
      {
        domain: "work",
        scenario:
          "A proposal includes clear savings, strong research, and a workable plan. Describe the case it makes for change.",
        sentence: "The proposal makes a ____ case for change.",
        simple: "The proposal makes a very convincing case for change.",
      },
      {
        domain: "culture",
        scenario:
          "A novel keeps you reading late into the night because you want to know what happens. Describe its story.",
        sentence: "The novel tells a ____ story.",
        simple: "The novel's story strongly holds your attention.",
      },
      {
        domain: "science",
        scenario:
          "Several independent studies reach the same result. Describe the evidence supporting the conclusion.",
        sentence: "The studies provide ____ evidence.",
        simple: "The studies provide very convincing evidence.",
      },
    ],
  },
  {
    id: "deliberate",
    word: "deliberate",
    partOfSpeech: "adjective",
    definition: "Done consciously and with careful intention.",
    nuance:
      "Deliberate distinguishes a chosen action from an accidental one. It can also describe a careful, unhurried pace.",
    collocations: [
      "deliberate choice",
      "deliberate effort",
      "deliberate approach",
      "deliberate purchase",
    ],
    examples: ["Leaving my phone at home was a deliberate choice."],
    alternatives: ["intentional", "conscious", "purposeful"],
    trigger:
      "(?:intentional|carefully planned|conscious) (?:choice|decision|effort)",
    contexts: [
      {
        domain: "habits",
        scenario:
          "You choose to leave your phone outside your bedroom every night. Describe this choice.",
        sentence: "Leaving my phone outside was a ____ choice.",
        simple: "I made a conscious choice to leave my phone outside.",
      },
      {
        domain: "work",
        scenario:
          "A team sets aside time each week to hear quieter colleagues. Describe the effort.",
        sentence: "The team makes a ____ effort to hear every voice.",
        simple: "The team makes an intentional effort to hear every voice.",
      },
      {
        domain: "design",
        scenario:
          "A designer uses only two colors to keep a poster readable. Describe the decision.",
        sentence: "The limited palette was a ____ decision.",
        simple: "The designer chose the limited palette on purpose.",
      },
    ],
  },
  {
    id: "tentative",
    word: "tentative",
    partOfSpeech: "adjective",
    definition: "Not yet certain or final; open to change.",
    nuance:
      "Tentative plans are provisional. Tentative conclusions need more evidence before you commit to them.",
    collocations: [
      "tentative plan",
      "tentative agreement",
      "tentative conclusion",
    ],
    examples: ["We made tentative plans to meet on Friday."],
    alternatives: ["provisional", "uncertain", "preliminary"],
    trigger:
      "(?:not final|uncertain|provisional|possible) (?:plan|agreement|conclusion)",
    contexts: [
      {
        domain: "travel",
        scenario:
          "You might travel in June, but have not confirmed leave or booked tickets. Describe your plans.",
        sentence: "Our travel plans are still ____.",
        simple: "Our travel plans are not yet final.",
      },
      {
        domain: "science",
        scenario:
          "An early study suggests a benefit, but the sample is very small. Describe its conclusion.",
        sentence: "The researchers reached a ____ conclusion.",
        simple: "The researchers' conclusion is preliminary and may change.",
      },
      {
        domain: "work",
        scenario:
          "Two teams agree on a delivery date, pending approval from their managers. Describe the agreement.",
        sentence: "The teams have a ____ agreement.",
        simple: "The teams have an agreement that is not yet final.",
      },
    ],
  },
  {
    id: "substantial",
    word: "substantial",
    partOfSpeech: "adjective",
    definition: "Large enough in amount or importance to make a difference.",
    nuance:
      "Natural with costs, improvements, evidence, or amounts. It is not a universal replacement for big: a big dog is usually just a big dog.",
    collocations: [
      "substantial improvement",
      "substantial investment",
      "substantial impact",
    ],
    examples: ["The new route brought a substantial reduction in travel time."],
    alternatives: ["significant", "considerable", "large"],
    trigger:
      "(?:very big|large|big|very large) (?:impact|improvement|investment|reduction|cost)",
    contexts: [
      {
        domain: "transport",
        scenario:
          "A new train route cuts a commute from 90 minutes to 40. Describe the improvement.",
        sentence: "The new route brought a ____ improvement.",
        simple:
          "The new route brought a very large improvement in travel time.",
      },
      {
        domain: "finance",
        scenario:
          "A company spends half its annual budget on a new research facility. Describe the investment.",
        sentence: "The company made a ____ investment in research.",
        simple: "The company made a very large investment in research.",
      },
      {
        domain: "environment",
        scenario:
          "A recycling program cuts a town's landfill waste by 40%. Describe the reduction.",
        sentence: "The program achieved a ____ reduction in waste.",
        simple: "The program achieved a very big reduction in waste.",
      },
    ],
  },
  {
    id: "articulate",
    word: "articulate",
    partOfSpeech: "verb",
    definition: "To put an idea or feeling into clear words.",
    nuance:
      "To articulate is to express something clearly, especially when it is complex or initially hard to put into words.",
    collocations: [
      "articulate an idea",
      "articulate concerns",
      "articulate a vision",
    ],
    examples: ["She helped me articulate what was bothering me."],
    alternatives: ["express", "explain", "communicate"],
    trigger: "(?:explain clearly|clearly express|put into words)",
    contexts: [
      {
        domain: "work",
        scenario:
          "You know why a proposal worries you, but need to explain your concerns clearly to the team. Describe what you need to do.",
        sentence: "I need to ____ my concerns to the team.",
        simple: "I need to put my concerns into clear words.",
      },
      {
        domain: "relationships",
        scenario:
          "A friend helps you find words for a difficult feeling. Describe how they helped.",
        sentence: "My friend helped me ____ my feelings.",
        simple: "My friend helped me explain my feelings clearly.",
      },
      {
        domain: "design",
        scenario:
          "A founder explains the purpose of a new product in one clear sentence. Describe what they can do.",
        sentence: "The founder can ____ the product's purpose clearly.",
        simple: "The founder can put the product's purpose into clear words.",
      },
    ],
  },
  {
    id: "resilient",
    word: "resilient",
    partOfSpeech: "adjective",
    definition: "Able to recover and adapt after difficulties.",
    nuance:
      "Resilience is the capacity to recover, rather than never experiencing difficulty.",
    collocations: [
      "resilient community",
      "resilient system",
      "resilient attitude",
    ],
    examples: ["The community proved remarkably resilient after the flood."],
    alternatives: ["adaptable", "tough", "robust"],
    trigger: "(?:able to recover|recover quickly|bounce back)",
    contexts: [
      {
        domain: "community",
        scenario:
          "After a flood, neighbors help each other rebuild and reopen local businesses. Describe the community.",
        sentence: "The community proved ____ after the flood.",
        simple: "The community recovered quickly after the flood.",
      },
      {
        domain: "technology",
        scenario:
          "A service keeps working when one of its servers fails. Describe the system.",
        sentence: "The service runs on a ____ system.",
        simple: "The system can recover from failures and keep working.",
      },
      {
        domain: "work",
        scenario:
          "A team learns from a failed launch and successfully tries again. Describe their approach.",
        sentence: "The team remained ____ after the setback.",
        simple: "The team could bounce back after the setback.",
      },
    ],
  },
  {
    id: "pivotal",
    word: "pivotal",
    partOfSpeech: "adjective",
    definition: "Important because it changes what happens next.",
    nuance:
      "Pivotal points to a turning point or central role in an outcome; not everything important is pivotal.",
    collocations: ["pivotal moment", "pivotal role", "pivotal decision"],
    examples: ["That conversation was a pivotal moment in my career."],
    alternatives: ["crucial", "decisive", "significant"],
    trigger: "(?:very important|important) (?:turning point|moment|decision)",
    contexts: [
      {
        domain: "career",
        scenario:
          "A conversation persuades someone to change career, shaping the next decade. Describe that moment.",
        sentence: "That conversation was a ____ moment in her career.",
        simple:
          "That conversation was an important turning point in her career.",
      },
      {
        domain: "sport",
        scenario:
          "One late goal completely changes the direction of a match. Describe its role.",
        sentence: "The goal played a ____ role in the match.",
        simple: "The goal changed what happened next in the match.",
      },
      {
        domain: "science",
        scenario:
          "A discovery opens an entirely new direction for medical research. Describe the discovery.",
        sentence: "It was a ____ discovery for medical research.",
        simple:
          "The discovery was an important turning point for medical research.",
      },
    ],
  },
];
export const CONTEXT_DOMAINS = [
  "work",
  "technology",
  "relationships",
  "education",
  "environment",
  "culture",
  "finance",
  "travel",
  "habits",
  "community",
  "design",
  "science",
  "sport",
  "career",
  "transport",
];
CATALOG.push(
  {
    id: "crucial",
    word: "crucial",
    partOfSpeech: "adjective",
    definition: "Necessary for a particular outcome or success.",
    nuance:
      "Crucial stresses that an outcome depends on something; it is more specific than generally important.",
    collocations: ["crucial step", "crucial information", "crucial role"],
    examples: ["Accurate measurements are crucial to the experiment."],
    alternatives: ["essential", "vital", "necessary"],
    trigger: "(?:essential|necessary) (?:step|information)",
    contexts: [
      {
        domain: "science",
        scenario:
          "An experiment cannot produce reliable results without accurate measurements. Describe the role of those measurements.",
        sentence: "Accurate measurements are ____ to reliable results.",
        simple: "Accurate measurements are necessary for reliable results.",
      },
      {
        domain: "travel",
        scenario:
          "Without a valid passport, you cannot board an international flight. Describe the importance of checking it before you leave.",
        sentence: "Checking your passport is a ____ step.",
        simple: "Checking your passport is a necessary step before travel.",
      },
      {
        domain: "work",
        scenario:
          "A project cannot meet its deadline unless two teams share information. Describe the role of communication.",
        sentence: "Communication is ____ to meeting the deadline.",
        simple: "Communication is necessary for meeting the deadline.",
      },
    ],
  },
  {
    id: "significant",
    word: "significant",
    partOfSpeech: "adjective",
    definition: "Meaningful or large enough to deserve attention.",
    nuance:
      "Significant can mean consequential or appreciable. In statistics it has a technical meaning; everyday significance does not automatically establish statistical significance.",
    collocations: [
      "significant change",
      "significant progress",
      "significant difference",
    ],
    examples: ["The new policy marks a significant change in direction."],
    alternatives: ["meaningful", "notable", "considerable"],
    trigger: "(?:meaningful|notable) (?:change|progress|difference)",
    contexts: [
      {
        domain: "work",
        scenario:
          "A company changes from entirely office-based work to a permanent hybrid model. Describe the change.",
        sentence: "This represents a ____ change in working arrangements.",
        simple:
          "This represents an important and meaningful change in working arrangements.",
      },
      {
        domain: "education",
        scenario:
          "A learner can now write clear paragraphs after struggling to form sentences. Describe their progress.",
        sentence: "The learner has made ____ progress.",
        simple: "The learner has made noticeable and meaningful progress.",
      },
      {
        domain: "environment",
        scenario:
          "A city reduces its water consumption by a quarter. Describe the reduction.",
        sentence: "The city achieved a ____ reduction in water consumption.",
        simple:
          "The city achieved a large enough reduction in water consumption to matter.",
      },
    ],
  },
  {
    id: "paramount",
    word: "paramount",
    partOfSpeech: "adjective",
    definition: "More important than every other consideration.",
    nuance:
      "Paramount expresses the highest priority. It is strong and somewhat formal; use it when other considerations really are secondary.",
    collocations: [
      "paramount importance",
      "paramount concern",
      "safety is paramount",
    ],
    examples: ["The safety of the passengers is paramount."],
    alternatives: ["supreme", "foremost", "primary"],
    trigger: "(?:highest|top) priority",
    contexts: [
      {
        domain: "transport",
        scenario:
          "An airline will delay a flight whenever necessary to protect passengers, regardless of cost. Describe its view of safety.",
        sentence: "Passenger safety is ____.",
        simple:
          "Passenger safety is more important than every other consideration.",
      },
      {
        domain: "research",
        scenario:
          "A research team puts participants' wellbeing ahead of speed, budget, and publication. Describe its main concern.",
        sentence: "Participants' wellbeing is of ____ importance.",
        simple:
          "Participants' wellbeing matters more than all other considerations.",
      },
      {
        domain: "work",
        scenario:
          "A team handles sensitive client records and prioritizes confidentiality over convenience. Describe that priority.",
        sentence: "Client confidentiality is ____.",
        simple:
          "Client confidentiality is more important than convenience or any other consideration.",
      },
    ],
  },
);
