import type { LlmProvider } from "../domain/ports";
import type {
  Evaluation,
  Exercise,
  ExerciseKind,
  Lexeme,
  UserWord,
  WritingAnalysis,
} from "../domain/types";
import { CATALOG } from "./catalog";
import { resolveSource } from "../domain/anchors";
import { adjectiveAdverbForm, hasWordEvidence } from "./evaluation-guards";

function distance(a: string, b: string): number {
  const row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let diagonal = row[0];
    row[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const old = row[j];
      row[j] = Math.min(
        row[j] + 1,
        row[j - 1] + 1,
        diagonal + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
      diagonal = old;
    }
  }
  return row[b.length];
}
export class MockLlm implements LlmProvider {
  readonly mode = "mock" as const;
  async checkWord(word: string) {
    const normalized = word.toLowerCase();
    if (normalized === "hihi" || /^(.)\1{3,}$/.test(normalized))
      return { status: "invalid" as const, suggestion: null };
    if (normalized === "neglibile")
      return { status: "correction" as const, suggestion: "negligible" };
    return { status: "valid" as const, suggestion: null };
  }
  async defineWord(word: string) {
    const known = CATALOG.find((entry) => entry.word === word.toLowerCase());
    if (!known) throw new Error("The mock provider has no definition for this word.");
    return {
      partOfSpeech: known.partOfSpeech,
      definition: known.definition,
      nuance: known.nuance,
      collocations: known.collocations,
      examples: known.examples,
    };
  }
  async translateLexeme(word: Lexeme) {
    const examples: Record<string, string> = {
      negligible: "Không đáng kể; nhỏ đến mức gần như không ảnh hưởng.",
      nuanced: "Tinh tế, có sắc thái; thể hiện những khác biệt nhỏ nhưng quan trọng.",
      compelling: "Thuyết phục hoặc cuốn hút mạnh mẽ.",
    };
    return examples[word.word.toLowerCase()] ?? "Bản demo chưa có nghĩa tiếng Việt cho từ này.";
  }
  async discoverConcept(concept: string): Promise<Lexeme[]> {
    const query = concept.toLowerCase();
    return Promise.all(CATALOG.filter((entry) => query.includes(entry.word) || (entry.trigger && new RegExp(entry.trigger, "i").test(concept)))
      .slice(0, 3)
      .map(async (entry) => ({ ...entry, vietnameseMeaning: await this.translateLexeme(entry) })));
  }
  async suggestVocabulary(text: string) {
    return CATALOG.flatMap((w) => {
      const match = text.match(new RegExp(w.trigger, "i"));
      const source = match
        ? resolveSource(text, match[0], "", {
            start: match.index!,
            end: match.index! + match[0].length,
          })
        : null;
      // Curated adjective+noun frames retain the noun. Verb phrases require
      // clause-level reasoning and deliberately have no demo rewrite.
      const noun = match?.[0].split(" ").at(-1);
      const adjective = [
        "negligible",
        "nuanced",
        "compelling",
        "deliberate",
        "tentative",
        "substantial",
        "pivotal",
        "crucial",
        "significant",
        "paramount",
      ].includes(w.word);
      let replacement = adjective && noun ? `${w.word} ${noun}` : null;
      if (
        replacement &&
        source &&
        source.start === source.sentenceStart &&
        /^[A-Z]/.test(source.exact)
      )
        replacement = replacement[0].toUpperCase() + replacement.slice(1);
      let suggestedSentence =
        source && replacement
          ? source.sentence.slice(0, source.start - source.sentenceStart) +
            replacement +
            source.sentence.slice(source.end - source.sentenceStart)
          : null;
      if (suggestedSentence && source && replacement) {
        // All curated target adjectives start with a consonant sound.
        const prefix = source.sentence.slice(
          0,
          source.start - source.sentenceStart,
        );
        if (/\ban\s$/i.test(prefix))
          suggestedSentence =
            prefix.replace(
              /\ban(\s)$/i,
              (article, space) => `${article[0] === "A" ? "A" : "a"}${space}`,
            ) +
            replacement +
            source.sentence.slice(source.end - source.sentenceStart);
      }
      return match
        ? [
            {
              word: w.word,
              partOfSpeech: w.partOfSpeech,
              definition: w.definition,
              nuance: w.nuance,
              collocations: w.collocations,
              examples: w.examples,
              originalText: match[0],
              source,
              suggestedSentence,
              reason: w.nuance,
              confidence: 0.9,
            },
          ]
        : [];
    });
  }
  async analyzeWriting(
    text: string,
    words: UserWord[],
  ): Promise<WritingAnalysis> {
    const found = await this.suggestVocabulary(text);
    const suggestions = found
      .filter((s) => !words.some((w) => w.word === s.word))
      .slice(0, 5);
    const opportunities = found.flatMap((s) => {
      const w = words.find((w) => w.word === s.word);
      return w
        ? [
            {
              userWordId: w.userWordId,
              originalText: s.originalText,
              source: s.source,
              prompt: `You have a word on your board that may express “${s.originalText}” more precisely. Can you bring it to mind?`,
            },
          ]
        : [];
    });
    const usages = [];
    for (const word of words)
      if (new RegExp(`\\b${word.word}\\b`, "i").test(text))
        usages.push({
          userWordId: word.userWordId,
          evaluation: await this.evaluateUsage(word, text, "writing"),
        });
    return {
      suggestions,
      opportunities,
      usages,
      summary: found.length
        ? "A few possibilities worth making your own. Choose only the words that feel useful to you."
        : "No matching demo examples were found. Demo analysis checks a limited set of phrases; this is not an assessment of your writing.",
    };
  }
  async generateExercise(word: UserWord, _kind: ExerciseKind, _context: string) {
    return {
      prompt: `Bring to mind a word meaning: ${word.definition}`,
      semanticHint: word.definition,
    };
  }
  async evaluateUsage(word: Lexeme, text: string, context: string) {
    return this.evaluateRecall(
      word,
      { kind: "open", context } as Exercise,
      text,
    );
  }
  async evaluateRecall(
    word: Lexeme,
    exercise: Exercise,
    answer: string,
  ): Promise<Evaluation> {
    const tokens: string[] = answer.toLowerCase().match(/[a-z]+/g) ?? [];
    const exact = word.word.includes(" ")
      ? hasWordEvidence(word.word, answer)
      : tokens.includes(word.word) ||
        (word.partOfSpeech === "adjective" && tokens.includes(adjectiveAdverbForm(word.word)));
    const misspelling =
      !exact && word.word.length >= 6
        ? tokens.find((t) => t.length >= 5 && distance(t, word.word) === 1)
        : undefined;
    const retrieved = exact || !!misspelling;
    const known = CATALOG.find((w) => w.word === word.word);
    const validAlternative =
      !retrieved && !!known?.alternatives.some((w) => tokens.includes(w));
    const majorMisuse =
      retrieved &&
      /(?:negligible|substantial)\s+(?:dog|cat|person)|nuanced\s+(?:dog|table)|pivotal\s+(?:sandwich|banana)/i.test(
        answer,
      );
    const hasContext = tokens.length >= 5 || exercise.kind === "completion";
    // The demo can only check obvious misuse; it must not impose a preset topic.
    const precise = retrieved && !majorMisuse && hasContext;
    const feedback = majorMisuse
      ? "You brought the word to mind, but this combination changes the meaning unnaturally. Let’s connect it to a more fitting context."
      : validAlternative
        ? `“${known?.alternatives.find((w) => tokens.includes(w))}” can work here. That is a valid choice. Now see if you can retrieve the word currently being practiced.`
        : retrieved
          ? misspelling
            ? `You recalled the word. One spelling adjustment: ${word.word}.`
            : precise
              ? "That works naturally in this context. You brought the word into your own sentence."
              : "You brought it to mind. A sentence in your own words will help make the meaning stick."
          : "It hasn’t come to mind yet. Take a hint, or reveal the word and try using it in a sentence.";
    return {
      retrieved,
      precise,
      majorMisuse,
      validAlternative,
      spellingCorrection: misspelling ? word.word : null,
      feedback,
      nuance: retrieved || majorMisuse ? word.nuance : "",
    };
  }
}
