import { z } from "zod";
import { GeminiLlm, SYSTEM } from "./gemini";

/** Convert the existing Gemini response schema to standard JSON Schema. */
export function toJsonSchema(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(toJsonSchema);
  if (!value || typeof value !== "object") return value;
  const input = value as Record<string, unknown>;
  const output: Record<string, unknown> = {};
  for (const [key, entry] of Object.entries(input)) {
    if (key === "nullable") continue;
    if (key === "type" && typeof entry === "string") {
      const type = entry.toLowerCase();
      output.type = input.nullable === true ? [type, "null"] : type;
    } else output[key] = toJsonSchema(entry);
  }
  if (output.type === "object") output.additionalProperties = false;
  return output;
}

export function requestOpenRouterStructured(request: typeof fetch, options: {
  key: string;
  model: string;
  instructions: string;
  input: unknown;
  schema: unknown;
  schemaName: string;
  maxTokens: number;
  completionTokenField?: "max_completion_tokens";
  provider: {
    require_parameters: true;
    allow_fallbacks: boolean;
    only?: string[];
    data_collection?: "deny";
    zdr?: true;
    max_price?: { prompt: number; completion: number };
  };
  temperature?: number;
  reasoning?: { effort: "minimal" | "none" | "low"; exclude: true };
  rejectRedirects?: true;
  signal?: AbortSignal;
}) {
  return request("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${options.key}`, "X-OpenRouter-Metadata": "enabled" },
    signal: options.signal ?? AbortSignal.timeout(30_000),
    ...(options.rejectRedirects && { redirect: "error" }),
    body: JSON.stringify({
      model: options.model,
      messages: [{ role: "system", content: options.instructions },
        { role: "user", content: JSON.stringify({ input: options.input }) }],
      temperature: options.temperature,
      reasoning: options.reasoning,
      [options.completionTokenField ?? "max_tokens"]: options.maxTokens,
      response_format: { type: "json_schema", json_schema: { name: options.schemaName, strict: true, schema: toJsonSchema(options.schema) } },
      provider: options.provider,
    }),
  });
}

/** Reuses the exact task methods, postprocessing and guards in GeminiLlm. */
export class OpenRouterLlm extends GeminiLlm {
  readonly mode: string = "openrouter";
  constructor(private readonly routerKey: string, private readonly routerModel: string,
    private readonly routerRequest: typeof fetch = fetch) { super("unused"); }

  protected async generate<T>(task: string, input: unknown, schema: unknown,
    validator: z.ZodType<T>, system: string = SYSTEM): Promise<T> {
    const response = await requestOpenRouterStructured(this.routerRequest, {
      key: this.routerKey, model: this.routerModel,
      instructions: [system, task].filter(Boolean).join("\n\n"), input, schema,
      schemaName: "ownword_response", temperature: 0.3, maxTokens: 4096,
      provider: { require_parameters: true, allow_fallbacks: true },
    });
    if (!response.ok) throw new Error(response.status === 429
      ? "The language service is busy. Please try again shortly."
      : "The language service is unavailable. Your writing is still here; please try again.");
    const result = await response.json() as {model?: string; choices?: {finish_reason?: string; message?: {content?: unknown}}[]};
    if (result.model !== this.routerModel) throw new Error("The language service returned an unexpected model. Please try again.");
    const choice = result.choices?.[0];
    const text = choice?.message?.content;
    if (typeof text !== "string" || !text || (choice?.finish_reason && choice.finish_reason !== "stop"))
      throw new Error("No complete analysis was returned. Please try a different short passage.");
    let data: unknown;
    try { data = JSON.parse(text); } catch { throw new Error("The analysis could not be read. Please try again."); }
    const parsed = validator.safeParse(data);
    if (!parsed.success) throw new Error("The analysis did not meet the expected format. Please try again.");
    return parsed.data;
  }
}
