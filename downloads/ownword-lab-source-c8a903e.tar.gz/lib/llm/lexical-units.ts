export type LexicalType = "word" | "phrasalVerb" | "multiword";
// A validation lexicon, not a candidate-generation list. Unknown compounds fail
// closed; adding one requires a meaning/frame test, not arbitrary model text.
export const phrasalUnits: Record<string, { separable: boolean }> =
  Object.fromEntries(
    [
      ["bounce back", false],
      ["phase out", true],
      ["rule out", true],
      ["account for", false],
      ["carry out", true],
      ["bring up", true],
      ["break down", true],
      ["follow up", true],
      ["figure out", true],
      ["point out", true],
      ["take over", true],
      ["set aside", true],
      ["come across", false],
      ["turn out", false],
      ["work out", true],
      ["put off", true],
      ["give up", true],
      ["look into", false],
      ["rely on", false],
      ["build on", false],
    ].map(([unit, separable]) => [unit, { separable }]),
  );
export const fixedUnits = new Set([
  "turning point",
  "common ground",
  "root cause",
  "point of view",
  "in light of",
  "in spite of",
  "by contrast",
  "in particular",
  "at stake",
  "on balance",
  "in essence",
  "due to",
]);
const irregular: Record<string, string[]> = {
  be: ["am", "is", "are", "was", "were", "been", "being"],
  have: ["has", "had"],
  do: ["does", "did", "done"],
  go: ["goes", "went", "gone"],
  make: ["made"],
  take: ["took", "taken"],
  give: ["gave", "given"],
  bring: ["brought"],
  break: ["broke", "broken"],
  come: ["came"],
  put: ["put"],
  set: ["set"],
  build: ["built"],
  write: ["wrote", "written"],
};
export function wordForms(base: string): Set<string> {
  const forms = new Set([base, base + "s", ...(irregular[base] ?? [])]);
  if (base.endsWith("e")) {
    forms.add(base + "d");
    forms.add(base.slice(0, -1) + "ing");
  } else {
    forms.add(base + "ed");
    forms.add(base + "ing");
  }
  if (/[^aeiou]y$/.test(base)) {
    forms.add(base.slice(0, -1) + "ies");
    forms.add(base.slice(0, -1) + "ied");
  }
  if (/(?:s|sh|ch|x|z|o)$/.test(base)) forms.add(base + "es");
  if (/[aeiou][bcdfghjklmnpqrstvwxyz]$/.test(base)) {
    forms.add(base + base.at(-1) + "ed");
    forms.add(base + base.at(-1) + "ing");
  }
  return forms;
}
export const lexicalTokens = (text: string): string[] =>
  text
    .normalize("NFKC")
    .toLowerCase()
    .match(/[a-z]+(?:-[a-z]+)*/g) ?? [];
type WordEvidence = (word: string, text: string) => boolean;
export function unitEvidence(
  unit: string,
  text: string,
  evidence: WordEvidence,
  bare = false,
): boolean {
  const normalized = text.normalize("NFKC").toLowerCase();
  const matches = [...normalized.matchAll(/[a-z]+(?:-[a-z]+)*/g)];
  const parts = unit.toLowerCase().split(" "),
    tokens = matches.map((m) => m[0]);
  const uninterrupted = (i: number, j: number) =>
    !/[.!?;:,\r\n]/.test(
      normalized.slice(
        matches[i].index! + matches[i][0].length,
        matches[j].index!,
      ),
    );
  if (fixedUnits.has(unit))
    return tokens.some(
      (_, i) =>
        parts.every(
          (p, j) =>
            tokens[i + j] === p && (j === 0 || uninterrupted(i + j - 1, i + j)),
        ) &&
        (!bare || (i === 0 && tokens.length === parts.length)),
    );
  const frame = phrasalUnits[unit];
  if (!frame || parts.length !== 2) return false;
  return tokens.some((token, i) => {
    if (!evidence(parts[0], token) && !wordForms(parts[0]).has(token))
      return false;
    if (tokens[i + 1] === parts[1] && uninterrupted(i, i + 1))
      return !bare || (i === 0 && tokens.length === 2);
    if (bare || !frame.separable) return false;
    for (let j = i + 2; j <= i + 5 && j < tokens.length; j++) {
      if (tokens[j] !== parts[1] || !uninterrupted(i, j)) continue;
      const between = tokens.slice(i + 1, j);
      if (
        !between.some((t) =>
          /^(?:not|never|no|without|and|or|but|because|if|then|is|was|are|were|will|would|can|could|must)$/.test(
            t,
          ),
        )
      )
        return true;
    }
    return false;
  });
}
const verbBases = new Set(
  "heed hinge depend rely account bounce phase rule streamline mitigate alleviate reduce lessen abate corroborate reinforce support demystify convince sway clarify delineate specify articulate elucidate simplify consolidate verify check inspect review explain consider retain improve remove solve eliminate eradicate prevent guarantee prove ensure need feed bleed breed speed shed wed seed shred succeed proceed exceed embed bed bring sing spring cling fling ring sling sting wring assess address possess progress discuss focus witness process access cross dismiss pass press stress dress express guess bias gas".split(
    " ",
  ),
);
export function canonicalLexicalItem(input: {
  word: string;
  canonicalForm?: string;
  surfaceForm?: string;
  lexicalType?: LexicalType;
  partOfSpeech: string;
  replacementText?: string | null;
}) {
  const raw = input.word.trim().toLowerCase().replace(/\s+/g, " ");
  let canonical = (input.canonicalForm ?? raw)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
  const verb =
    /verb/i.test(input.partOfSpeech) && !/adverb/i.test(input.partOfSpeech);
  const noun = /noun/i.test(input.partOfSpeech);
  if (!input.canonicalForm && noun) {
    const known = [
      "nuance",
      "prerequisite",
      "discrepancy",
      "dependency",
      "condition",
      "requirement",
    ];
    const base = known.find(
      (b) =>
        canonical === b + "s" ||
        (/y$/.test(b) && canonical === b.slice(0, -1) + "ies"),
    );
    if (base) canonical = base;
  }
  if (!input.canonicalForm && verb && !canonical.includes(" ")) {
    const base = [...verbBases].find(
      (b) => b !== canonical && wordForms(b).has(canonical),
    );
    if (base) canonical = base;
  }
  let type =
    input.lexicalType ??
    (phrasalUnits[canonical]
      ? "phrasalVerb"
      : fixedUnits.has(canonical)
        ? "multiword"
        : "word");
  const strict = (base: string, token: string) => wordForms(base).has(token);
  if (
    !input.canonicalForm &&
    !input.lexicalType &&
    verb &&
    input.replacementText
  ) {
    const unit = Object.keys(phrasalUnits).find(
      (unit) =>
        unit.split(" ")[0] === canonical &&
        unitEvidence(unit, input.replacementText!, strict),
    );
    if (unit) {
      canonical = unit;
      type = "phrasalVerb";
    }
  }
  const fail = (reason: string) => ({
    valid: false as const,
    reason,
    canonical,
    surface: input.surfaceForm ?? null,
    type,
  });
  if (
    canonical.length < 2 ||
    canonical.length > 50 ||
    !/^(?:[a-z]+(?:-[a-z]+)*)(?: [a-z]+(?:-[a-z]+)*){0,2}$/.test(canonical)
  )
    return fail("noncanonical-headword");
  if (
    (type === "word" && canonical.includes(" ")) ||
    (type === "phrasalVerb" && !phrasalUnits[canonical]) ||
    (type === "multiword" && !fixedUnits.has(canonical))
  )
    return fail("unsupported-lexical-unit");
  if (type === "phrasalVerb" && !verb) return fail("invalid-lexical-type");
  const head = canonical.split(" ")[0];
  if (
    verb &&
    !verbBases.has(head) &&
    (/(?:ed|ing)$/.test(head) || /[^s]s$/.test(head))
  )
    return fail("noncanonical-headword");
  const nounForms = new Set([
    canonical,
    canonical + "s",
    canonical + "es",
    ...(/[^aeiou]y$/.test(canonical) ? [canonical.slice(0, -1) + "ies"] : []),
  ]);
  const family = (value: string) =>
    type === "word"
      ? verb
        ? strict(canonical, value)
        : noun
          ? nounForms.has(value)
          : value === canonical
      : unitEvidence(canonical, value, strict, true);
  if (
    raw !== canonical &&
    !family(raw) &&
    !(
      type === "phrasalVerb" &&
      strict(head, raw) &&
      input.replacementText &&
      unitEvidence(canonical, input.replacementText, strict)
    )
  )
    return fail("noncanonical-headword");
  const surface = input.surfaceForm?.trim().toLowerCase().replace(/\s+/g, " ");
  if (surface && !family(surface)) return fail("surface-form-mismatch");
  if (type === "word" && verb && input.replacementText) {
    const incomplete = Object.keys(phrasalUnits).find(
      (unit) =>
        unit.split(" ")[0] === canonical &&
        unitEvidence(unit, input.replacementText!, strict),
    );
    if (incomplete) return fail("missing-required-particle");
  }
  return {
    valid: true as const,
    reason: raw === canonical ? "canonical" : "canonicalized",
    canonical,
    surface: surface ?? null,
    type,
  };
}
