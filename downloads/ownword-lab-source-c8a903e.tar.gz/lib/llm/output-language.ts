// Bounded, high-confidence rejection of obvious foreign instructional prose.
// This is not a general language classifier: short/mixed Latin-script text can
// remain ambiguous. Fixed English instructions and human review still matter.
const profiles = [
  "el la los las una unas unos del que para como pero por muy suficientemente demasiado tener cuenta significa pequeño pequeña sin algo",
  "le les une des du est et pour dans avec très signifie quelque chose petit petite être",
  "der die das ein eine und ist für mit nicht sehr bedeutet etwas klein kann werden",
  "uma um os as não muito para que significa pequeno pequena sem são pelo pela",
  "là của và một những được trong không rất nghĩa nhỏ để có thể này với",
].map((words) => new Set(words.split(" ")));
const englishMarkers = new Set(
  "the an is are was were be being been to of or that which it its this something someone so too enough without with not worth small important great showing having used describes means meaning than can may by as".split(
    " ",
  ),
);

export function isEnglishInstruction(text: string): boolean {
  if (text.length > 6000) return false;
  const words =
    text
      .normalize("NFKC")
      .toLowerCase()
      .match(/\p{L}+/gu) ?? [];
  if (!words.length) return true;
  const nonLatin = words.filter((w) =>
    /[^\p{Script=Latin}\p{M}]/u.test(w),
  ).length;
  if (nonLatin >= 2 || nonLatin / words.length > 0.25) return false;
  const english = words.filter((w) => englishMarkers.has(w)).length;
  return !profiles.some((profile) => {
    const foreign = words.filter((w) => profile.has(w)).length;
    return foreign >= 3 && foreign / words.length >= 0.28 && foreign > english;
  });
}

export function requireEnglishInstruction(...texts: string[]): void {
  if (texts.some((text) => !isEnglishInstruction(text)))
    throw new Error(
      "The analysis did not meet the expected format: English instructional text is required. Please try again.",
    );
}
