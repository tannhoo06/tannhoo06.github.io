import type { LlmConfig } from "../config";
import type { LlmProvider } from "../domain/ports";
import { GeminiLlm } from "./gemini";
import { OpenRouterLlm } from "./openrouter";
import { MockLlm } from "./mock";
import { RoundRobinKeys, type KeyRotationStore } from "./key-pool";
import { withCallBudget, type LlmCallBudget } from "./call-budget";

/** Selects the provider and applies the shared call budget to optional task overrides. */
export function createLlmProvider(
  config: LlmConfig,
  dependencies: {
    rotationStore: KeyRotationStore;
    request?: typeof fetch;
    budget?: LlmCallBudget;
    discoverConcept?: LlmProvider["discoverConcept"];
  },
): LlmProvider {
  const configure = (provider: LlmProvider) =>
    withCallBudget(provider, dependencies.budget, dependencies.discoverConcept);
  switch (config.provider) {
    case "mock":
      return configure(new MockLlm());
    case "openrouter":
      return configure(new OpenRouterLlm(config.key, config.model, dependencies.request));
    case "gemini": {
      const apiKey =
        config.keyStrategy === "single" || config.keys.length === 1
          ? config.keys[0]
          : (() => {
              const pool = new RoundRobinKeys(
                config.keys,
                dependencies.rotationStore,
              );
              return () => pool.nextKey();
            })();
      return configure(new GeminiLlm(apiKey, config.model, dependencies.request));
    }
  }
}
