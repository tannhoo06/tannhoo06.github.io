/** Only simple sentence-initial subjects and a small unambiguous noun/verb
 * vocabulary are eligible, regardless of the replacement's position. */
export function repairLocalAgreement(sentence: string, focusStart: number) {
  void focusStart; // Kept for callers; the replacement's location no longer limits repair.
  const match = /^(?:(the|a|an|this|that|these|those)\s+(change|changes|result|results|policy|policies|approach|approaches)|\b(he|she|it|they|we|i|you))\s+(have|has|is|are|show|shows|make|makes|improve|improves|explain|explains)\b/i.exec(sentence);
  if (!match) return null;
  const determiner = match[1]?.toLowerCase();
  const noun = match[2]?.toLowerCase();
  const pronoun = match[3]?.toLowerCase();
  const pluralNoun = noun && /^(?:changes|results|policies|approaches)$/.test(noun);
  if (noun && ((pluralNoun && !['the','these','those'].includes(determiner)) || (!pluralNoun && !['the','a','an','this','that'].includes(determiner)))) return null;
  const thirdSingular = pronoun ? /^(?:he|she|it)$/.test(pronoun) : !pluralNoun;
  const subjectNumber = thirdSingular ? 'singular' : 'plural-or-first-second-person';
  const originalVerb = match[4];
  const lower = originalVerb.toLowerCase();
  const pairs: Record<string, [string,string]> = {have:['has','have'],has:['has','have'],is:['is','are'],are:['is','are'],show:['shows','show'],shows:['shows','show'],make:['makes','make'],makes:['makes','make'],improve:['improves','improve'],improves:['improves','improve'],explain:['explains','explain'],explains:['explains','explain']};
  const next = pronoun === 'i' && (lower === 'is' || lower === 'are')
    ? 'am'
    : pairs[lower][thirdSingular ? 0 : 1];
  if (next === lower) return null;
  const repairedVerb = originalVerb === originalVerb.toUpperCase() ? next.toUpperCase() : /^[A-Z]/.test(originalVerb) ? next[0].toUpperCase()+next.slice(1) : next;
  const verbStart = match[0].length - originalVerb.length;
  const repairedSentence = sentence.slice(0,verbStart)+repairedVerb+sentence.slice(match[0].length);
  return {diagnostic:'learner-facing-local-agreement-repair',originalSentence:sentence,repairedSentence,subjectSpan:{start:0,end:verbStart-1,text:sentence.slice(0,verbStart).trim()},subjectNumber,verbSpan:{start:verbStart,end:match[0].length},originalVerb,repairedVerb,rule:'simple-initial-subject-present-agreement',highConfidence:true};
}
