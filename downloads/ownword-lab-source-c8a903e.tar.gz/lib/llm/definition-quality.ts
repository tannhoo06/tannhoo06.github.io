import { hasWordEvidence } from "./evaluation-guards";
import { phrasalUnits } from "./lexical-units";

/** Bounded surface checks, not a claim to verify every dictionary meaning. */
export function learnerFriendlyDefinition(
  word: string,
  definition: string,
): boolean {
  const tokens = definition.trim().match(/[a-z]+(?:-[a-z]+)*/gi) ?? [];
  return (
    tokens.length >= 2 &&
    tokens.length <= 32 &&
    !hasWordEvidence(word, definition) &&
    !(phrasalUnits[word] && hasWordEvidence(word.split(" ")[0], definition)) &&
    !/\b(?:something|a thing|someone) that makes? it (?:seem|appear)\b/i.test(
      definition,
    ) &&
    !/\b(?:the word|this term) (?:means|refers to)\b/i.test(definition)
  );
}
