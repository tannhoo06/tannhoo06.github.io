import { resolveSource, validSource } from "../domain/anchors";
import type { WritingAnalysis } from "../domain/types";
import { inspectUnknownShape, type FrameConfidence } from "./frame-confidence";
import { instructionalResponseOverclaims, instructionalTemporalOverclaims, lexicalBenefit, semanticStrength } from "./semantic-policy";
import { danglingExampleModifiers } from "./example-quality";
import { semanticSpecificity, supportedSpecificityCompression } from "./semantic-specificity";
import { proveEventNominalization } from "./source-mapping";
import {
  lexicalTokens,
  unitEvidence,
  wordForms,
  type LexicalType,
} from "./lexical-units";
type Suggestion = WritingAnalysis["suggestions"][number];
export type LexicalMetadata = {
  canonical: string;
  surface: string | null;
  type: LexicalType;
};
const prepositions = new Set(
  "to on upon in at about of for from into onto with without over under by through".split(
    " ",
  ),
);
const transitive = new Set(
  "heed obey discuss streamline mitigate alleviate reduce lessen corroborate reinforce support demystify convince sway clarify delineate specify articulate elucidate simplify consolidate verify inspect examine remove solve eliminate eradicate prevent guarantee prove ensure".split(
    " ",
  ),
);
const prepFrames: Record<string, string[]> = {
  hinge: ["on", "upon"],
  depend: ["on", "upon"],
  rely: ["on", "upon"],
  contingent: ["on", "upon"],
  dependent: ["on", "upon"],
  consistent: ["with"],
  meticulous: ["in", "about", "with"],
  capable: ["of"],
  averse: ["to"],
};
const participants = new Set(
  "i we you he she they them us him her me everyone everybody nobody anybody someone somebody each every both all our your my his their its".split(
    " ",
  ),
);
const qualifierGroups: Record<string, Set<string>> = {
  negation: new Set("not no never none nothing neither nor without".split(" ")),
  modality: new Set(
    "can could may might must should will would shall".split(" "),
  ),
  frequency: new Set(
    "once twice always usually often sometimes rarely occasionally repeatedly repeated again quickly slowly gradually immediately briefly".split(
      " ",
    ),
  ),
  degree: new Set(
    "only even exactly nearly almost partly partially completely entirely totally fully barely merely at-least at-most".split(
      " ",
    ),
  ),
  quantity: new Set(
    "one two three four five six seven eight nine ten several many few".split(
      " ",
    ),
  ),
  temporal: new Set(
    "before after still already yet currently initial initially previous previously earlier later until temporary temporarily".split(
      " ",
    ),
  ),
  conditional: new Set(
    "if unless whether although because despite except when".split(" "),
  ),
  comparison: new Set("less more fewer simpler higher lower".split(" ")),
};
const count = (tokens: string[], term: string) =>
  tokens.filter((t) => t === term).length;
const escaped = (text: string) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const frameWords = (text: string) =>
  [...text.toLowerCase().matchAll(/[a-z]+(?:-[a-z]+)*|[^\s\w]/g)].map((m) => ({
    text: m[0],
    at: m.index!,
  }));
const strict = (base: string, token: string) => wordForms(base).has(token);

export function protectedSemanticSlots(text: string) {
  const tokens = lexicalTokens(text);
  const select = (sets: Set<string>[]) =>
    tokens.filter((t) => sets.some((s) => s.has(t)));
  return {
    preservedQualifiers: select(
      Object.entries(qualifierGroups)
        .filter(([k]) => !["quantity", "modality", "conditional"].includes(k))
        .map(([, v]) => v),
    ),
    preservedParticipants: select([participants]),
    preservedConditions: select([qualifierGroups.conditional]),
    preservedCounts: [
      ...select([qualifierGroups.quantity, new Set(["once", "twice"])]),
      ...(text.match(/\b\d+(?:[.,]\d+)*\b/g) ?? []),
    ],
    preservedModality: select([qualifierGroups.modality]),
  };
}

/** Small lexical entailments allow a concept name to encode its own qualifier.
 * They never authorize deleting an independent audience, count or limitation. */
function encodedQualifier(
  word: string,
  term: string,
  oldSpan: string,
): boolean {
  if (
    ["tentative", "provisional", "preliminary"].includes(word) &&
    term === "not" &&
    /\bnot final\b/i.test(oldSpan)
  )
    return true;
  if (
    ["mitigate", "alleviate", "lessen", "abate"].includes(word) &&
    term === "less" &&
    /\bless (?:severe|harmful|painful)\b/i.test(oldSpan)
  )
    return true;
  if (
    word === "streamline" &&
    ["fewer", "simpler"].includes(term) &&
    /\bfewer and simpler\b/i.test(oldSpan)
  )
    return true;
  if (
    word === "streamline" &&
    term === "simpler" &&
    /\b(?:steps|process|work|workflow|operations|paperwork)\b.*\bsimpler\b/i.test(
      oldSpan,
    )
  )
    return true;
  if (
    ["corroborate", "reinforce"].includes(word) &&
    term === "more" &&
    /\bmore support\b/i.test(oldSpan)
  )
    return true;
  return false;
}
export function validateLexicalRewrite(
  text: string,
  suggestion: Suggestion,
  metadata: LexicalMetadata,
) {
  const stages = {
    structurallyValid: false,
    grammaticallyValid: false,
    semanticallyFaithful: false,
    qualifierPreserving: false,
    canonicalCorrect: true,
    learningBenefitSufficient: false,
  };
  let frameConfidence: FrameConfidence = "unknown-frame";
  let frameEvidence: object | null = null;
  let benefitEvidence: string | null = null;
  let benefitComparison: ReturnType<typeof lexicalBenefit> | null = null;
  let instructionalResponseFindings: ReturnType<typeof instructionalResponseOverclaims> = [];
  let instructionalTemporalFindings: ReturnType<typeof instructionalTemporalOverclaims> = [];
  let exampleQualityFindings: ReturnType<typeof danglingExampleModifiers> = [];
  const protectedSlots = protectedSemanticSlots(
    suggestion.source?.sentence ?? text,
  );
  const failed = (reason: string, issues = [reason]) => ({
    suggestion: null as Suggestion | null,
    reason,
    issues,
    stages,
    repaired: false,
    frameConfidence,
    frameEvidence,
    benefitEvidence,
    benefitComparison,
    instructionalResponseFindings,
    instructionalTemporalFindings,
    exampleQualityFindings,
    protectedSlots,
  });
  if (
    !validSource(text, "", suggestion.source) ||
    !suggestion.suggestedSentence
  )
    return failed("unsafe-reconstruction");
  let source = suggestion.source,
    sentence = suggestion.suggestedSentence;
  const original = source.sentence;
  let start = source.start - source.sentenceStart,
    end = source.end - source.sentenceStart;
  let prefix = original.slice(0, start),
    suffix = original.slice(end);
  if (!sentence.startsWith(prefix) || !sentence.endsWith(suffix))
    return failed("unsafe-reconstruction");
  let local = sentence.slice(
    prefix.length,
    suffix.length ? -suffix.length : undefined,
  );
  let repaired = false;
  // Recover a colon's unchanged antecedent object, never invent an object or
  // delete punctuation blindly. Otherwise the dangling preposition is rejected.
  if (/^\s*:/.test(suffix) && /\b(?:on|upon)\s*$/i.test(local)) {
    const tail = source.exact.match(
      /\b(?:on|upon)\s+((?:one|a|the|this|that)\s+(?:thing|condition|factor))$/i,
    )?.[1];
    if (tail) {
      local += " " + tail;
      sentence = prefix + local + suffix;
      repaired = true;
    }
  }
  const head = metadata.canonical.split(" ")[0];
  const items = frameWords(sentence),
    oldTokens = lexicalTokens(original),
    newTokens = lexicalTokens(sentence);
  const indices = items.flatMap((t, i) =>
    strict(head, t.text) &&
    t.at >= prefix.length &&
    t.at < prefix.length + local.length
      ? [i]
      : [],
  );
  const compoundPresent =
    metadata.type === "word" ||
    unitEvidence(metadata.canonical, sentence, strict);
  if (!compoundPresent || !indices.length)
    return failed(
      metadata.type === "phrasalVerb"
        ? "missing-required-particle"
        : "missing-candidate-evidence",
    );
  if (metadata.surface) {
    const surfaceHead = metadata.surface.split(" ")[0];
    if (!indices.some((i) => items[i].text === surfaceHead))
      return failed("surface-form-mismatch");
  }
  stages.structurallyValid = true;
  const issues: string[] = [];
  const add = (reason: string) => {
    if (!issues.includes(reason)) issues.push(reason);
  };
  const compoundSenses: Record<string, { particle: string; meaning: RegExp }> =
    {
      bounce: { particle: "back", meaning: /\brecover|\brecovery|\bsetback/i },
      phase: {
        particle: "out",
        meaning: /\bremove|\bdiscontinue|\beliminate/i,
      },
      rule: {
        particle: "out",
        meaning: /\bexclude|\beliminate|\breject.*possib/i,
      },
      account: { particle: "for", meaning: /\bexplain|\bconstitute/i },
    };
  const incomplete =
    metadata.type === "word" && compoundSenses[metadata.canonical];
  if (
    incomplete &&
    incomplete.meaning.test(source.exact + " " + suggestion.definition)
  ) {
    add("missing-required-particle");
    stages.canonicalCorrect = false;
  }
  for (const i of indices) {
    let j = i + 1;
    while (
      items[j] &&
      /^(?:fully|entirely|solely|directly|carefully|successfully)$/.test(
        items[j].text,
      )
    )
      j++;
    const next = items[j]?.text ?? "",
      after = items[j + 1]?.text ?? "";
    if (
      prepFrames[metadata.canonical] &&
      ((/verb/i.test(suggestion.partOfSpeech) &&
        !/adverb/i.test(suggestion.partOfSpeech)) ||
        prepositions.has(next))
    ) {
      if (!prepFrames[metadata.canonical].includes(next))
        add("invalid-valency");
      else if (!after || /^[,:;.!?]$/.test(after))
        add("invalid-grammatical-frame");
    }
    if (metadata.type === "word" && transitive.has(metadata.canonical)) {
      if (!next || /^[,:;.!?]$/.test(next)) add("participant-loss");
      else if (prepositions.has(next)) add("invalid-valency");
    }
    if (
      metadata.type === "phrasalVerb" &&
      /^(?:phase out|rule out|account for|carry out|bring up|figure out|point out|take over|set aside|put off|look into|build on)$/.test(
        metadata.canonical,
      )
    ) {
      const particle = metadata.canonical.split(" ")[1];
      const p = items.findIndex(
        (t, index) => index > i && index <= i + 5 && t.text === particle,
      );
      const passive = /^(?:is|are|was|were|be|been|being)$/.test(
        items[i - 1]?.text ?? "",
      );
      if (p < 0) add("missing-required-particle");
      else if (
        p === i + 1 &&
        (!items[p + 1] || /^[,:;.!?]$/.test(items[p + 1].text)) &&
        !passive
      )
        add("participant-loss");
    }
    if (prepositions.has(next) && (/^[,:;.!?]$/.test(after) || next === after))
      add("invalid-grammatical-frame");
    if (/adverb/i.test(suggestion.partOfSpeech)) {
      if (items[i - 1]?.text === "," && (!next || /^[.!?;]$/.test(next)))
        add("awkward-local-attachment");
      const oldEvent = source.exact.match(
        /\b(checked|verified|reviewed|tested|counted|measured|examined|inspected)\b/i,
      )?.[1];
      if (oldEvent && !newTokens.includes(oldEvent.toLowerCase()))
        add("event-structure-loss");
      if (
        oldEvent &&
        !items
          .slice(Math.max(0, i - 4), i + 5)
          .some((t) => t.text === oldEvent.toLowerCase())
      )
        add("awkward-local-attachment");
    }
    if (
      /\bnoun\b/i.test(suggestion.partOfSpeech) &&
      [
        "prerequisite",
        "discrepancy",
        "nuance",
        "condition",
        "requirement",
        "dependency",
      ].includes(metadata.canonical) &&
      items[i].text === metadata.canonical &&
      /^(?:is|was|are|were)$/.test(items[i - 1]?.text ?? "")
    )
      add("invalid-determiner");
  }
  if (
    /\b(?:to|on|upon|of|for|with|about|into)\s*[:;,]/i.test(sentence) ||
    /\b(to|on|upon|in|of|for|with|about)\s+\1\b/i.test(sentence) ||
    /[,;:]\s*[,;:]/.test(sentence)
  ) {
    // Do not blame inherited source grammar. Only newly introduced sequences
    // are blocked here; the task remains lexical, not general proofreading.
    const bad = sentence.match(
      /\b(?:to|on|upon|of|for|with|about|into)\s*[:;,]|\b(to|on|upon|in|of|for|with|about)\s+\1\b|[,;:]\s*[,;:]/i,
    )?.[0];
    if (bad && !original.toLowerCase().includes(bad.toLowerCase()))
      add("invalid-grammatical-frame");
  }
  const eventProof = proveEventNominalization(
    source.exact,
    local,
    metadata.canonical,
    suggestion.partOfSpeech,
    { prefix, suffix, definition: suggestion.definition },
  );
  const boundedFrame =
    !!eventProof ||
    (/^(?:verb|phrasal verb)$/i.test(suggestion.partOfSpeech) &&
      (transitive.has(metadata.canonical) ||
        !!prepFrames[metadata.canonical] ||
        metadata.canonical === "bounce back")) ||
    (/^adjective$/i.test(suggestion.partOfSpeech) &&
      !!prepFrames[metadata.canonical]);
  const generic = inspectUnknownShape(
    original,
    sentence,
    start,
    end,
    suggestion.partOfSpeech,
  );
  const teaching = [suggestion.definition, suggestion.nuance, suggestion.reason].join(" ");
  const specificityProof = supportedSpecificityCompression(original, source.exact, local, suggestion.definition, teaching);
  // Exact validated anchor, unchanged determiner and unchanged simple singular
  // of-complement; the original/rewritten prefix and suffix were checked above.
  // Other noun shapes and uncertain source evidence remain unknown.
  const compressionProof = specificityProof && !generic.safe &&
    generic.detail === "noun-wrapper-or-category-change" &&
    metadata.type === "word" && /^noun$/i.test(suggestion.partOfSpeech) &&
    /\bthe\s+$/i.test(prefix) &&
    /^\s+of\s+the\s+[a-z]+\s*[.!?]?\s*$/i.test(suffix) &&
    !/s\s*[.!?]?\s*$/i.test(suffix) &&
    !issues.some((x) => ["participant-loss", "qualifier-loss", "invalid-determiner", "invalid-grammatical-frame"].includes(x))
      ? {reason: "source-supported-semantic-compression", specificityProof,
        structuralEvidence: {determiner: "the", unchangedComplement: suffix.trim(), sourceSpan: source.exact},
        finalSentence: sentence}
      : null;
  frameEvidence = compressionProof
    ? { ...generic, semanticCompressionProof: compressionProof }
    : eventProof
    ? { ...generic, validatedSourceEvent: eventProof }
    : generic;
  const syntaxIssues = [
    "invalid-valency",
    "invalid-grammatical-frame",
    "invalid-determiner",
    "awkward-local-attachment",
    "event-structure-loss",
    "missing-required-particle",
    "participant-loss",
  ];
  if (issues.some((x) => syntaxIssues.includes(x)))
    frameConfidence = "known-unsafe";
  else if (boundedFrame) frameConfidence = "known-safe";
  else if (!generic.safe && !compressionProof) add("unknown-frame-risk");
  stages.grammaticallyValid = !issues.some((x) =>
    [
      "invalid-valency",
      "invalid-grammatical-frame",
      "invalid-determiner",
      "awkward-local-attachment",
      "event-structure-loss",
      "missing-required-particle",
      "participant-loss",
      "unknown-frame-risk",
    ].includes(x),
  );
  for (const term of participants)
    if (count(newTokens, term) < count(oldTokens, term)) {
      const encoded =
        ["convince", "sway", "persuade"].includes(metadata.canonical) &&
        /^(?:its|their|his|her|your|my|our)$/.test(term) &&
        new RegExp("\\bchange " + term + " mind\\b", "i").test(source.exact);
      if (!encoded) add("participant-loss");
    }
  // Preserve explicit named participants, without attempting a full parser.
  for (const m of original.matchAll(/\b[A-Z][a-z]+\b/g))
    if (
      ![
        "The",
        "A",
        "An",
        "She",
        "He",
        "They",
        "We",
        "It",
        "This",
        "That",
        "Our",
        "After",
        "Before",
      ].includes(m[0]) &&
      !new RegExp("\\b" + escaped(m[0]) + "\\b").test(sentence)
    )
      add("participant-loss");
  for (const group of Object.values(qualifierGroups))
    for (const term of group)
      if (
        count(newTokens, term) < count(oldTokens, term) &&
        !encodedQualifier(metadata.canonical, term, source.exact)
      )
        add("qualifier-loss");
  for (const number of original.match(/\b\d+(?:[.,]\d+)*\b/g) ?? [])
    if (!new RegExp("\\b" + escaped(number) + "\\b").test(sentence))
      add("qualifier-loss");
  // Explicit causative objects must survive. This bounded source pattern is
  // intentionally narrower than a general noun/semantic parser.
  for (const match of original.matchAll(
    /\b(?:make|made|makes|making)\s+((?:the|a|an|our|their|its)\s+[^,;:.]{1,65}?)\s+(?:less|more|fewer|simpler|easier|clear|change)\b/gi,
  )) {
    for (const token of lexicalTokens(match[1]).filter(
      (t) => !/^(?:the|a|an)$/.test(t),
    ))
      if (!newTokens.includes(token)) add("participant-loss");
  }
  if (
    metadata.canonical === "heed" &&
    /\b(?:paid|pay|paying) (?:close )?attention\b/i.test(original) &&
    !/\b(?:followed|obeyed|acted on|complied)\b/i.test(original)
  )
    add("formality-only");
  if (
    (metadata.canonical === "increment" &&
      /\bsmall increase\b/i.test(source.exact)) ||
    (metadata.canonical === "slim" && /\bsmall\b/i.test(source.exact))
  )
    add("formality-only");
  if (
    ["solve", "eliminate", "eradicate", "prevent"].includes(
      metadata.canonical,
    ) &&
    /\bless severe|\b(?:helped |partly |partially )?(?:reduce|reduced)|\bdid not solve\b/i.test(
      original,
    )
  )
    add("semantic-expansion");
  if (
    ["prove", "guarantee", "ensure"].includes(metadata.canonical) &&
    /\b(?:support|consistent with|suggest|suggests|might|may|could)\b/i.test(
      original,
    ) &&
    !/\b(?:proved|guaranteed|ensured)\b/i.test(original)
  )
    add("semantic-expansion");
  if (
    metadata.canonical === "negligible" &&
    /\bdangerous|\benough to change|\bnot insignificant\b/i.test(original)
  )
    add("semantic-expansion");
  if (
    (metadata.canonical === "ubiquitous" &&
      /\babsent|\bonly one\b/i.test(original)) ||
    (metadata.canonical === "pivotal" &&
      /\bnot the turning point\b/i.test(original))
  )
    add("semantic-drift");
  const strength = semanticStrength(
    source.exact,
    local,
    teaching,
    source.exact + suffix.split(/[,;.!?]/)[0].slice(0, 160),
  );
  instructionalResponseFindings = instructionalResponseOverclaims(metadata.canonical, suggestion.partOfSpeech, {
    definition: suggestion.definition, nuance: suggestion.nuance, reason: suggestion.reason,
    ...Object.fromEntries(suggestion.examples.map((example, index) => [`example-${index}`, example])),
  });
  if (instructionalResponseFindings.length) add("instructional-response-entailment-overclaim");
  instructionalTemporalFindings = instructionalTemporalOverclaims(metadata.canonical, suggestion.partOfSpeech, {
    definition: suggestion.definition, nuance: suggestion.nuance, reason: suggestion.reason,
    ...Object.fromEntries(suggestion.examples.map((example, index) => [`example-${index}`, example])),
  });
  if (instructionalTemporalFindings.length) add("instructional-temporal-entailment-overclaim");
  exampleQualityFindings = danglingExampleModifiers(suggestion.examples);
  if (exampleQualityFindings.length) add("instructional-example-dangling-modifier");
  if (strength.rewrite.length) add("semantic-expansion");
  if (strength.teaching.length) add("instructional-semantic-overreach");
  const specificity = semanticSpecificity(
    original,
    local,
    teaching,
  );
  if (specificity.length) add("unsupported-semantic-specificity");
  const benefit = lexicalBenefit(source.exact, local, metadata.canonical, {
    sentence: original,
    definition: suggestion.definition,
    partOfSpeech: suggestion.partOfSpeech,
  });
  benefitComparison = benefit;
  benefitEvidence = benefit.evidence;
  stages.learningBenefitSufficient =
    benefit.sufficient && !issues.includes("formality-only");
  if (!stages.learningBenefitSufficient && !issues.includes("formality-only"))
    add("insufficient-learning-benefit");
  stages.qualifierPreserving = !issues.some((x) =>
    ["participant-loss", "qualifier-loss", "event-structure-loss"].includes(x),
  );
  stages.semanticallyFaithful =
    stages.qualifierPreserving &&
    !issues.some((x) =>
      [
        "semantic-expansion",
        "semantic-drift",
        "unsupported-semantic-specificity",
        "instructional-semantic-overreach",
        "instructional-response-entailment-overclaim",
        "instructional-temporal-entailment-overclaim",
        "missing-required-particle",
      ].includes(x),
    );
  if (issues.length) return failed(issues[0], issues);
  if (repaired) {
    // Keep offsets tied to the exact original phrase after bounded repair.
    source = resolveSource(text, source.exact, "", {
      start: source.start,
      end: source.end,
    })!;
    start = source.start - source.sentenceStart;
    end = source.end - source.sentenceStart;
    prefix = source.sentence.slice(0, start);
    suffix = source.sentence.slice(end);
    if (prefix + local + suffix !== sentence)
      return failed("unsafe-reconstruction");
  }
  return {
    suggestion: { ...suggestion, source, suggestedSentence: sentence },
    reason: compressionProof ? "source-supported-semantic-compression" : repaired ? "grammatical-frame-repaired" : "quality-checked",
    issues,
    stages,
    repaired,
    frameConfidence,
    frameEvidence,
    benefitEvidence,
    benefitComparison,
    instructionalResponseFindings,
    instructionalTemporalFindings,
    exampleQualityFindings,
    protectedSlots,
  };
}
