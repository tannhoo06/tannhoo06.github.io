/** Bounded checks for common semantic subtypes. This is not a dictionary or
 * an exhaustive semantic entailment model. Evidence comes only from the source. */
const dimensions = [
  {
    name: "origin-or-ownership-history",
    generic: /\b(?:histor\w*|past|background|record)\b/i,
    candidate: /\b(?:provenance|pedigree|chain of custody)\b/i,
    teaching: /\b(?:origin\w*|ownership|owned|owners?|custody|where .{0,25}(?:came|originated)|source history)\b/i,
    evidence: /\b(?:origin\w*|ownership|owned|owners?|custody|provenance|pedigree|came from|source of|where .{0,25}(?:came|originated))\b/i,
  },
  {
    name: "worsening",
    generic: /\b(?:chang\w*|develop\w*|condition|state)\b/i,
    candidate: /\b(?:deteriorat\w*|worsen\w*|degrad\w*|declin\w*)\b/i,
    teaching: /\b(?:wors\w*|declin\w*|degrad\w*|deteriorat\w*)\b/i,
    evidence: /\b(?:wors\w*|declin\w*|degrad\w*|deteriorat\w*|became (?:less|poorer)|got worse)\b/i,
  },
  {
    name: "mismatch-or-inconsistency",
    generic: /\b(?:difference\w*|differ\w*|variation\w*)\b/i,
    candidate: /\b(?:discrepanc\w*|mismatch\w*|inconsisten\w*)\b/i,
    teaching: /\b(?:mismatch\w*|inconsisten\w*|disagree\w*|conflict\w*|differ\w* from (?:what|the expected))\b/i,
    evidence: /\b(?:mismatch\w*|inconsisten\w*|discrepanc\w*|disagree\w*|conflict\w*|contradic\w*|higher|lower|expected|measurements?)\b/i,
  },
  {
    name: "fundamental-change",
    generic: /\b(?:effect\w*|impact\w*|chang\w*)\b/i,
    candidate: /\b(?:transform\w*|revolutioniz\w*|overhaul\w*)\b/i,
    teaching: /\b(?:fundamental\w*|radical\w*|complete\w*|transform\w*|revolution\w*)\b/i,
    evidence: /\b(?:fundamental\w*|radical\w*|complete\w*|transform\w*|revolution\w*|structural change|entirely new|into (?:a |an )?(?:different|new)\b)/i,
  },
  {
    name: "functional-failure",
    generic: /\b(?:problem\w*|issue\w*|difficulty|trouble)\b/i,
    candidate: /\b(?:malfunction\w*|breakdown\w*)\b/i,
    teaching: /\b(?:malfunction\w*|fail\w* to (?:work|function|operate)|not (?:work|function|operat)\w*|functional failure)\b/i,
    evidence: /\b(?:malfunction\w*|breakdown\w*|fail\w* to (?:work|function|operate)|stopp?ed (?:working|functioning|operating)|not (?:work|function|operat)\w*|work\w* (?:incorrectly|improperly)|function\w* (?:incorrectly|improperly))\b/i,
  },
  {
    name: "possible-harm",
    generic: /\b(?:concern\w*|worr\w*|issue\w*)\b/i,
    candidate: /\b(?:risk\w*|hazard\w*|danger\w*)\b/i,
    teaching: /\b(?:risk\w*|hazard\w*|danger\w*|harm\w*|possib\w* (?:of )?(?:loss|injury|damage))\b/i,
    evidence: /\b(?:risk\w*|hazard\w*|danger\w*|harm\w*|injur\w*|damage\w*|loss|unsafe|may be hurt)\b/i,
  },
  {
    name: "deliberate-intervention",
    generic: /\b(?:help\w*|support\w*|assist\w*)\b/i,
    candidate: /\b(?:interven\w*|intervention\w*)\b/i,
    teaching: /\b(?:interven\w*|treat\w*|deliberate action|step in)\b/i,
    evidence: /\b(?:interven\w*|treat\w*|deliberate action|stepp?ed in|took action|took steps)\b/i,
  },
];

export function semanticSpecificity(source: string, candidate: string, teaching: string) {
  return dimensions.filter(d => {
    if (!d.generic.test(source) || !(d.candidate.test(candidate) || d.teaching.test(teaching))) return false;
    // Negative evidence is not a license for a positive subtype claim.
    const supported = [...source.matchAll(new RegExp(d.evidence.source, 'gi'))].some(m =>
      !/\b(?:no|not|never|without|neither)\s+(?:\w+\s+){0,3}$/i.test(source.slice(Math.max(0, m.index! - 50), m.index)),
    );
    return !supported;
  }).map(d => d.name);
}

/** Positive evidence is deliberately narrower than absence of an objection.
 * The ownership-history sense is the only compression currently proven. */
export function supportedSpecificityCompression(
  source: string,
  sourceSpan: string,
  candidate: string,
  definition: string,
  teaching: string,
) {
  const unsupported = semanticSpecificity(source, candidate, teaching);
  if (unsupported.length || !/^ownership history$/i.test(sourceSpan.trim()) ||
      !/^provenance$/i.test(candidate.trim()) ||
      !/^(?:the )?origin and ownership history of an object\.?$/i.test(definition.trim()) ||
      /\b(?:no|not|never|without|neither|possible|possibly|potential|alleged|uncertain|incomplete|partial)\b/i.test(source)) return null;
  return {dimension: "origin-or-ownership-history", sourceEvidence: sourceSpan,
    candidateSense: "ownership history", unsupportedDimensions: unsupported};
}
