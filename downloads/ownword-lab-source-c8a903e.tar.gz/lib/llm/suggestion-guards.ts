import { resolveSource } from "../domain/anchors";
import type { WritingAnalysis } from "../domain/types";
import { hasWordEvidence } from "./evaluation-guards";
import { mapReplacement, type MappingEvidence } from "./source-mapping";

type Suggestion = WritingAnalysis["suggestions"][number];
type Token = { text: string; start: number; end: number };
const tokenize = (text: string): Token[] =>
  [...text.matchAll(/[\p{L}\p{N}]+(?:['’-][\p{L}\p{N}]+)*|[^\s]/gu)].map(
    (m) => ({ text: m[0], start: m.index!, end: m.index! + m[0].length }),
  );
const words = (text: string) =>
  text.toLowerCase().match(/[a-z]+(?:-[a-z]+)*/g) ?? [];
const functionWords = new Set(
  "a an the about at by for from in into of on onto over to with without and or but as than".split(
    " ",
  ),
);
const irregular: Record<string, string> = {
  am: "be",
  is: "be",
  are: "be",
  was: "be",
  were: "be",
  been: "be",
  has: "have",
  had: "have",
  does: "do",
  did: "do",
  went: "go",
  gone: "go",
  saw: "see",
  seen: "see",
  gave: "give",
  given: "give",
  took: "take",
  taken: "take",
  told: "tell",
  made: "make",
  wrote: "write",
  written: "write",
};
const stem = (word: string) =>
  irregular[word] ?? word.replace(/ies$/, "y").replace(/(?:ing|ed|es|s)$/, "");
const edits = (a: string, b: string) => {
  if (Math.abs(a.length - b.length) > 1) return false;
  let i = 0,
    j = 0,
    count = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) {
      i++;
      j++;
      continue;
    }
    if (++count > 1) return false;
    if (a.length >= b.length) i++;
    if (a.length <= b.length) j++;
  }
  return count + (a.length - i) + (b.length - j) <= 1;
};
export function grammarOnly(before: string, after: string): boolean {
  const a = words(before).filter((w) => !functionWords.has(w));
  const b = words(after).filter((w) => !functionWords.has(w));
  return (
    a.length === b.length &&
    a.every(
      (w, i) =>
        w === b[i] ||
        stem(w) === stem(b[i]) ||
        hasWordEvidence(w, b[i]) ||
        (Math.min(w.length, b[i].length) >= 4 && edits(w, b[i])),
    )
  );
}

/** Minimal token edits, bounded to avoid quadratic work on pathological output. */
function changes(before: string, after: string) {
  const a = tokenize(before),
    b = tokenize(after);
  if (!a.length || !b.length || a.length > 700 || b.length > 700) return null;
  const width = b.length + 1,
    dp = new Uint16Array((a.length + 1) * width);
  for (let i = a.length - 1; i >= 0; i--)
    for (let j = b.length - 1; j >= 0; j--)
      dp[i * width + j] =
        a[i].text === b[j].text
          ? 1 + dp[(i + 1) * width + j + 1]
          : Math.max(dp[(i + 1) * width + j], dp[i * width + j + 1]);
  const hunks: { start: number; end: number; replacement: string }[] = [];
  let i = 0,
    j = 0;
  while (i < a.length || j < b.length) {
    if (i < a.length && j < b.length && a[i].text === b[j].text) {
      i++;
      j++;
      continue;
    }
    const ai = i,
      bj = j;
    while (i < a.length || j < b.length) {
      if (i < a.length && j < b.length && a[i].text === b[j].text) break;
      if (
        j < b.length &&
        (i === a.length || dp[i * width + j + 1] >= dp[(i + 1) * width + j])
      )
        j++;
      else i++;
    }
    hunks.push({
      start: a[ai]?.start ?? before.length,
      end: i > ai ? a[i - 1].end : (a[ai]?.start ?? before.length),
      replacement: j > bj ? after.slice(b[bj].start, b[j - 1].end) : "",
    });
  }
  return hunks;
}

export function guardSuggestion(
  text: string,
  suggestion: Suggestion,
): Suggestion | null {
  if (!suggestion.source) return null;
  const original = resolveSource(
    text,
    suggestion.originalText,
    "",
    suggestion.source ?? {},
  );
  if (!original || !suggestion.suggestedSentence) return null;
  const rewrite = suggestion.suggestedSentence.trim();
  const hunks = changes(original.sentence, rewrite);
  if (!hunks?.length) return null;
  const anchorStart = original.start - original.sentenceStart;
  const anchorEnd = original.end - original.sentenceStart;
  const lexical = hunks.filter(
    (h) =>
      h.start < anchorEnd &&
      h.end > anchorStart &&
      words(
        original.sentence.slice(h.start, Math.max(h.start, anchorStart)),
      ).every((w) => functionWords.has(w)) &&
      words(original.sentence.slice(Math.min(h.end, anchorEnd), h.end)).every(
        (w) => functionWords.has(w),
      ) &&
      hasWordEvidence(suggestion.word, h.replacement) &&
      !grammarOnly(original.sentence.slice(h.start, h.end), h.replacement),
  );
  if (lexical.length !== 1) return null;
  // Unrelated edits outside the declared lexical span must be grammar-only.
  if (
    hunks.some(
      (h) =>
        !lexical.includes(h) &&
        !grammarOnly(original.sentence.slice(h.start, h.end), h.replacement),
    )
  )
    return null;
  // Conservative restraint for compact noun phrases rewritten as equally long
  // noun phrases (e.g. adjective+noun -> adjective+noun). This cannot establish
  // a new distinction and can suppress valid options; rubric review measures it.
  if (
    /^noun$/i.test(suggestion.partOfSpeech) &&
    words(suggestion.originalText).length === 2 &&
    words(lexical[0].replacement).length >= 2 &&
    !/\b(?:and|or|but)\b/i.test(suggestion.originalText)
  )
    return null;
  const first = hunks[0],
    last = hunks.at(-1)!;
  const start = original.sentenceStart + first.start;
  const end = original.sentenceStart + last.end;
  const exact = text.slice(start, end);
  if (!exact || exact.length > 300) return null;
  const source = resolveSource(text, exact, "", { start, end });
  if (!source) return null;
  // Common prefix/suffix must survive verbatim; a single replacement at the
  // repaired span must reconstruct the entire proposed sentence exactly.
  const prefix = original.sentence.slice(0, first.start),
    suffix = original.sentence.slice(last.end);
  if (!rewrite.startsWith(prefix) || !rewrite.endsWith(suffix)) return null;
  const replacement = rewrite.slice(
    prefix.length,
    suffix.length ? -suffix.length : undefined,
  );
  if (
    !replacement ||
    !hasWordEvidence(suggestion.word, replacement) ||
    grammarOnly(exact, replacement)
  )
    return null;
  if (prefix + replacement + suffix !== rewrite) return null;
  return {
    ...suggestion,
    originalText: exact,
    source,
    suggestedSentence: rewrite,
  };
}

export type SuggestionInspection = {
  suggestion: Suggestion | null;
  reason: string;
  repaired: boolean;
  mapping?: MappingEvidence;
};

/** One bounded replacement, never arbitrary permission for a multi-hunk rewrite. */
export function inspectSuggestion(
  text: string,
  suggestion: Suggestion,
  replacementText?: string | null,
): SuggestionInspection {
  let mapping: MappingEvidence = mapReplacement(
    suggestion.originalText,
    replacementText,
    suggestion.word,
    suggestion.partOfSpeech,
  );
  const reject = (reason: string): SuggestionInspection => ({
    suggestion: null,
    reason,
    repaired: false,
    mapping,
  });
  if (!suggestion.source) return reject("ambiguous-or-invalid-source");
  const original = resolveSource(
    text,
    suggestion.originalText,
    "",
    suggestion.source,
  );
  if (!original) return reject("ambiguous-or-invalid-source");
  const start = original.start - original.sentenceStart;
  const end = original.end - original.sentenceStart;
  if (
    (/[\p{L}\p{N}]/u.test(text[original.start - 1] ?? "") &&
      /^[\p{L}\p{N}]/u.test(original.exact)) ||
    (/[\p{L}\p{N}]/u.test(text[original.end] ?? "") &&
      /[\p{L}\p{N}]$/u.test(original.exact))
  )
    return reject("partial-token-source");
  let local = replacementText?.trim();
  const full = suggestion.suggestedSentence?.trim();
  const hunks = full ? changes(original.sentence, full) : null;
  if (full && !hunks) return reject("alignment-bound");
  if (hunks) {
    // A declared span is not permission to change an unrelated fact elsewhere.
    for (const h of hunks) {
      if (h.end <= start || h.start >= end) {
        if (
          !grammarOnly(original.sentence.slice(h.start, h.end), h.replacement)
        )
          return reject("unrelated-semantic-edit");
      } else if (h.start < start || h.end > end) {
        // Crossing the boundary cannot be guessed apart. The legacy checker
        // can still handle its bounded article/grammar expansion cases.
        const legacy = guardSuggestion(text, suggestion);
        if (!local && legacy)
          return inspectSuggestion(
            text,
            { ...legacy, suggestedSentence: null },
            extractReplacement(legacy),
          );
        return reject("unmappable-multi-hunk");
      }
    }
  }
  if (!local) {
    if (!hunks?.length) return reject("missing-replacement");
    const inside = hunks.filter(
      (h) => h.start >= start && h.end <= end && h.start < end && h.end > start,
    );
    if (!inside.length) return reject("no-lexical-change");
    local = original.exact;
    // Only edits inside the exact quoted phrase are applied. Harmless grammar
    // changes outside it are deliberately left out, preserving the source.
    for (const h of inside.toReversed())
      local =
        local.slice(0, h.start - start) +
        h.replacement +
        local.slice(h.end - start);
    local = local.replace(/[ \t]{2,}/g, " ").trim();
  }
  mapping = mapReplacement(
    original.exact,
    local,
    suggestion.word,
    suggestion.partOfSpeech,
    {
      prefix: original.sentence.slice(0, start),
      suffix: original.sentence.slice(end),
      definition: suggestion.definition,
    },
  );
  local = mapping.local ?? undefined;
  if (!local || local.length > 600 || /[\r\n.!?;]/.test(local))
    return reject("unsafe-replacement-shape");
  if (!hasWordEvidence(suggestion.word, local))
    return reject("missing-candidate-evidence");
  if (grammarOnly(original.exact, local))
    return reject("grammar-or-spelling-only");
  const oldWords = words(original.exact),
    newWords = words(local);
  const unitParts = suggestion.word.toLowerCase().split(" ");
  if (
    /^noun$/i.test(suggestion.partOfSpeech) &&
    oldWords.length === 2 &&
    newWords.length >= 2 &&
    !/\b(?:and|or|but)\b/i.test(original.exact)
  )
    return reject("formal-noun-swap");
  const copulas = new Set([
    "be",
    "am",
    "is",
    "are",
    "was",
    "were",
    "been",
    "being",
    "that",
    "which",
    "who",
  ]);
  if (
    newWords.some(
      (w) =>
        !hasWordEvidence(suggestion.word, w) &&
        !(
          unitParts.length > 1 &&
          (hasWordEvidence(unitParts[0], w) || unitParts.slice(1).includes(w))
        ) &&
        !functionWords.has(w) &&
        !copulas.has(w) &&
        !mapping.licensedTokens.includes(w) &&
        !oldWords.some((old) => grammarOnly(old, w)),
    )
  )
    return reject("unrelated-content-in-replacement");
  if (
    /^adjective$/i.test(suggestion.partOfSpeech) &&
    oldWords.length === 3 &&
    /^(?:very|really|quite|extremely|so|too)$/.test(oldWords[0]) &&
    newWords.length === 1
  )
    return reject("missing-modified-noun");
  const rebuilt =
    original.sentence.slice(0, start) + local + original.sentence.slice(end);
  if (rebuilt.length > 5000) return reject("replacement-bound");
  const edits = changes(original.sentence, rebuilt);
  if (!edits?.length) return reject("no-lexical-change");
  const first = edits[0],
    last = edits.at(-1)!;
  // Shrink an oversized quote to the actual continuous replacement. Multiple
  // internal edits are safe to map because everything outside this span is exact.
  const changedText = original.sentence.slice(first.start, last.end);
  // A pure insertion has no nonempty changed substring. Keep the verified
  // declared phrase as the replacement anchor rather than manufacturing offsets.
  const source = resolveSource(
    text,
    changedText || original.exact,
    "",
    changedText
      ? {
          start: original.sentenceStart + first.start,
          end: original.sentenceStart + last.end,
        }
      : { start: original.start, end: original.end },
  );
  if (!source || source.exact.length > 300)
    return reject("ambiguous-or-invalid-source");
  const result = {
    ...suggestion,
    originalText: source.exact,
    source,
    suggestedSentence: rebuilt,
  };
  const replacement = extractReplacement(result);
  if (
    !replacement ||
    !(
      hasWordEvidence(suggestion.word, replacement) ||
      (unitParts.length > 1 &&
        hasWordEvidence(unitParts[0], replacement) &&
        hasWordEvidence(suggestion.word, rebuilt))
    ) ||
    grammarOnly(source.exact, replacement)
  )
    return reject("grammar-or-spelling-only");
  if (
    source.sentence.slice(0, source.start - source.sentenceStart) +
      replacement +
      source.sentence.slice(source.end - source.sentenceStart) !==
    rebuilt
  )
    return reject("replacement-reconstruction");
  const repaired =
    !!mapping?.repair ||
    source.exact !== suggestion.originalText ||
    (!!full && (rebuilt !== full || (hunks?.length ?? 0) > 1));
  return {
    suggestion: result,
    reason:
      mapping?.repair ??
      (repaired ? "minimal-replacement-reconstructed" : "retained"),
    repaired,
    mapping,
  };
}

function extractReplacement(s: Suggestion): string | null {
  if (!s.source || !s.suggestedSentence) return null;
  const prefix = s.source.sentence.slice(
    0,
    s.source.start - s.source.sentenceStart,
  );
  const suffix = s.source.sentence.slice(s.source.end - s.source.sentenceStart);
  if (
    !s.suggestedSentence.startsWith(prefix) ||
    !s.suggestedSentence.endsWith(suffix)
  )
    return null;
  return s.suggestedSentence.slice(
    prefix.length,
    suffix.length ? -suffix.length : undefined,
  );
}
