import { lexicalTokens } from "./lexical-units";

export type FrameConfidence = "known-safe" | "known-unsafe" | "unknown-frame";
const prep =
  /^(?:to|on|upon|in|at|about|of|for|from|into|onto|with|without|over|under|by|through|up|out|off|back)$/;
const boundary =
  /^(?:and|or|but|that|which|who|how|whether|when|where|why|if|because|although)$/;
const copula =
  /^(?:be|am|is|are|was|were|been|being|seem|seems|seemed|remain|remains|remained)$/;
const determiner =
  /^(?:a|an|the|this|that|these|those|my|our|your|his|her|its|their|some|every|each)$/;
const degree = /^(?:very|really|quite|extremely|so|too)$/;
const plural = (s: string) => /(?:s|ies)$/.test(s) && !/(?:ss|us|is)$/.test(s);
function verbEvidence(s: string, preceding: string[]) {
  const previous = preceding.at(-1) ?? "";
  // A suffix is not source POS evidence: plural cats and finite verbs both end
  // in s. Require a bounded subject/modal slot as well. Ambiguity fails closed.
  if (
    /^(?:can|could|may|might|must|should|will|would|we|they|i|you|he|she|it)$/.test(
      previous,
    )
  )
    return true;
  const tail = preceding.slice(-4);
  return (
    /(?:ed|ing|s)$/.test(s) &&
    tail.some(
      (t, i) =>
        determiner.test(t) &&
        i < tail.length - 1 &&
        tail.length - i <= 4 &&
        tail
          .slice(i + 1)
          .every(
            (t) =>
              !prep.test(t) && !boundary.test(t) && !/(?:ed|ing|s)$/.test(t),
          ),
    )
  );
}

/** Compare only a bounded local edit. Shared tokens are evidence, never model
 * POS/preservation claims. Unknown complement-taking items require frame evidence;
 * equal prepositions alone do not establish that an unseen verb licenses them. */
export function inspectUnknownShape(
  original: string,
  rewritten: string,
  start: number,
  end: number,
  pos: string,
) {
  const before = original.slice(0, start),
    after = original.slice(end);
  const local = rewritten.slice(
    before.length,
    after.length ? -after.length : undefined,
  );
  const old = lexicalTokens(original.slice(start, end)),
    next = lexicalTokens(local);
  let left = 0;
  while (left < old.length && left < next.length && old[left] === next[left])
    left++;
  let right = 0;
  while (
    right < old.length - left &&
    right < next.length - left &&
    old.at(-1 - right) === next.at(-1 - right)
  )
    right++;
  const a = old.slice(left, right ? -right : undefined),
    b = next.slice(left, right ? -right : undefined);
  const previous = old[left - 1] ?? lexicalTokens(before).at(-1) ?? "";
  const following = old[old.length - right] ?? lexicalTokens(after)[0] ?? "";
  const oldShape = { changed: a, previous, following };
  const risk = (detail: string) => ({
    safe: false,
    detail,
    oldShape,
    newShape: b,
  });
  const pass = () => ({
    safe: true,
    detail: "minimal-same-shape",
    oldShape,
    newShape: b,
  });
  if (/[,:;.!?]/.test(original.slice(start, end)) || /[,:;.!?]/.test(local))
    return risk("clause-boundary-edit");
  if (a.some((t) => boundary.test(t)) || b.some((t) => boundary.test(t)))
    return risk("clause-structure-change");
  if (a.some((t) => prep.test(t)) || b.some((t) => prep.test(t)))
    return risk("preposition-or-particle-change");
  if (/^adverb$/i.test(pos)) {
    if (b.length !== 1 || !/ly$/.test(b[0]))
      return risk("unverified-adverb-shape");
    if (a.length === 1 && /ly$/.test(a[0])) return pass();
    // An insertion must precede the same unchanged, morphologically evidenced event.
    if (
      !a.length &&
      /(?:ed|ing)$/.test(following) &&
      !determiner.test(previous)
    )
      return pass();
    return risk("unverified-adverb-attachment");
  }
  if (/^adjective$/i.test(pos)) {
    const core = a.filter((t) => !degree.test(t));
    const encodedState =
      a.join(" ") === "not final" &&
      /^(?:tentative|provisional|preliminary)$/.test(b.join(" "));
    if ((!encodedState && core.length !== 1) || b.length !== 1)
      return risk("category-or-predicate-change");
    if (prep.test(following) || prep.test(previous))
      return risk("unverified-adjective-complement");
    if (
      !(
        copula.test(previous) ||
        determiner.test(previous) ||
        degree.test(previous)
      )
    )
      return risk("unverified-adjective-slot");
    if (determiner.test(previous) && (!following || boundary.test(following)))
      return risk("missing-modified-noun");
    return pass();
  }
  if (/^(?:verb|phrasal verb)$/i.test(pos)) {
    if (a.length !== 1 || b.length !== 1)
      return risk("argument-or-category-change");
    if (prep.test(following) || boundary.test(following))
      return risk("unverified-complement-frame");
    if (
      determiner.test(previous) ||
      copula.test(previous) ||
      !verbEvidence(a[0], [...lexicalTokens(before), ...old.slice(0, left)])
    )
      return risk("unverified-verb-slot");
    // One verb at the same location leaves all objects and clause boundaries
    // byte-identical. Tense shape may not drift on an unknown frame either.
    const inflection = (s: string) =>
      /ing$/.test(s)
        ? "ing"
        : /ed$/.test(s)
          ? "past"
          : /s$/.test(s)
            ? "third"
            : "base";
    if (inflection(a[0]) !== inflection(b[0]))
      return risk("unknown-inflection-change");
    return pass();
  }
  if (/^noun$/i.test(pos)) {
    if (a.length !== 1 || b.length !== 1)
      return risk("noun-wrapper-or-category-change");
    if (!determiner.test(previous) && !plural(a[0]))
      return risk("unverified-noun-slot");
    if (plural(a[0]) !== plural(b[0])) return risk("noun-number-change");
    if (/^(?:a|an)$/.test(previous) && plural(b[0]))
      return risk("singular-determiner-plural-noun");
    if (
      (previous === "a" && /^[aeiou]/.test(b[0])) ||
      (previous === "an" && !/^[aeiou]/.test(b[0]))
    )
      return risk("unverified-article-compatibility");
    return pass();
  }
  return risk("unverified-lexical-category");
}
