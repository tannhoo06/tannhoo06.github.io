/** Bounded evidence, not a general parser or an animacy classifier. Only
 * clear inanimate-subject/passive clauses with intentional modifiers qualify. */
export function danglingExampleModifiers(examples: string[]) {
  const noun = "(?:data|evidence|reports?|polic(?:y|ies)|arguments?|results?|documents?|information|statistics|proposals?|sentences?|objects?|process(?:es)?|systems?)";
  const modifier = "(?:hoping|trying|intending|seeking|aiming|wishing|wanting|believing|deciding|expecting|fearing|realizing|realising|knowing|considering|planning|attempting)";
  const subject = `(?:(?:the|a|an|new|updated|revised|submitted|available|recent|relevant|additional|these|those|this|that)\\s+){0,4}${noun}`;
  const passive = "(?:was|were|is|are|has been|have been|had been)";
  const final = new RegExp(`^(${subject})\\s+${passive}\\s+[^,.;!?]+,\\s*(${modifier}\\b[^.!?;]*)`, "i");
  const initial = new RegExp(`^(${modifier}\\b[^,.;!?]*),\\s*(${subject})\\s+${passive}\\b`, "i");
  return examples.flatMap((example, index) => {
    const trimmed=example.trim();
    const end=trimmed.match(final), start=trimmed.match(initial);
    if (!end && !start) return [];
    const controller=(end ? end[1] : start![2]).trim();
    const phrase=(end ? end[2] : start![1]).trim();
    return [{exampleIndex:index,example,modifierPhrase:phrase,inferredController:controller,
      controllerPlausibility:"inanimate-not-intentional-agent",modifierPredicate:phrase.split(/\s+/)[0].toLowerCase(),disposition:"reject-suggestion"}];
  });
}
