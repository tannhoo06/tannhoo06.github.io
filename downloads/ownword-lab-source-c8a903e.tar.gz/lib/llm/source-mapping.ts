import { resolveSource, type AnchorHint } from "../domain/anchors";
import { lexicalTokens, wordForms } from "./lexical-units";

export function resolveProposalAnchor(
  text: string,
  exact: string,
  hint: AnchorHint = {},
) {
  // Model offsets are never consulted. The domain resolver still computes and
  // verifies every UTF-16 offset; only proposal context-hint priority changes.
  const context = {
    sentence: typeof hint.sentence === "string" ? hint.sentence : undefined,
    before: typeof hint.before === "string" ? hint.before : undefined,
    after: typeof hint.after === "string" ? hint.after : undefined,
  };
  const unique = resolveSource(text, exact, "");
  if (unique) {
    const matched = resolveSource(text, exact, "", context);
    return {
      source: unique,
      status: "exact-unique" as const,
      diagnostic: matched
        ? null
        : "context-hint-mismatch-ignored-unique-anchor",
    };
  }
  if (
    !exact ||
    !text.includes(exact) ||
    /^[\uDC00-\uDFFF]/.test(exact) ||
    /[\uD800-\uDBFF]$/.test(exact)
  )
    return {
      source: null,
      status: "invalid" as const,
      diagnostic: "invalid-exact-quote",
    };
  const matched = resolveSource(text, exact, "", context);
  return matched
    ? {
        source: matched,
        status: "exact-disambiguated" as const,
        diagnostic: null,
      }
    : {
        source: null,
        status: "ambiguous" as const,
        diagnostic: "ambiguous-exact-quote",
      };
}

const supportWords = new Set(
  "a an the about at by for from in into of on onto over to with without and or but as than be am is are was were been being that which who so it can could may might must should will would shall".split(
    " ",
  ),
);
export type MappingEvidence = {
  functionWordRepairAttempted: boolean;
  grammaticalAdditions: string[];
  semanticAdditions: string[];
  repair: string | null;
  local: string | null;
  diagnostics: string[];
  licensedTokens: string[];
  actualSemanticAdditions: string[];
  frameProof: ReturnType<typeof proveEventNominalization>;
};
type MappingContext = { prefix?: string; suffix?: string; definition?: string };
const nounNumber = (phrase: string) =>
  /\b(?:people|children|men|women|feet)$|(?<!s)s$/i.test(phrase) &&
  !/(?:ss|is|us)$/i.test(phrase)
    ? "plural"
    : "singular";
function simpleNoun(phrase: string) {
  return (
    /^(?:the|a|an|our|this|that)\s+(?:[a-z-]+\s+){0,3}[a-z-]+$/i.test(phrase) &&
    !/\b(?:and|or|of|to|with|for|from|about|in|regarding|another)\b/i.test(
      phrase,
    ) &&
    !(/^an?\b/i.test(phrase) && nounNumber(phrase) === "plural")
  );
}
/** Closed affect/effect (or influence/influence) adjunct proof. It licenses
 * no new lexical valency: the source subject and following object are copied.
 * Model metadata cannot assert this proof; the final gate recomputes it. */
export function proveEventNominalization(
  old: string,
  local: string,
  word: string,
  pos: string,
  context: MappingContext = {},
) {
  if (!/^adjective$/i.test(pos)) return null;
  const event = old.match(
    /^too (?:small|minor|slight|weak) to (affect|influence)$/i,
  );
  const nominal = local.match(
    /^([a-z-]+) in (its|their) (effect|influence) on$/i,
  );
  if (!event || !nominal || nominal[1].toLowerCase() !== word.toLowerCase())
    return null;
  if (
    (event[1].toLowerCase() === "affect" ? "effect" : "influence") !==
    nominal[3].toLowerCase()
  )
    return null;
  const clause =
    (context.prefix ?? "")
      .split(/[,;.!?]/)
      .at(-1)
      ?.replace(/^\s*so\s+/i, "")
      .trim() ?? "";
  const subject = clause.match(/^(.{1,65}) (?:is|was|are|were)$/i)?.[1];
  if (
    !subject ||
    !simpleNoun(subject) ||
    !/^\s+(?:the|a|an|our|their|your|my|his|her|its)\s+[a-z-]+/i.test(
      context.suffix ?? "",
    )
  )
    return null;
  if (
    (nounNumber(subject) === "plural" ? "their" : "its") !==
    nominal[2].toLowerCase()
  )
    return null;
  if (
    !/\b(?:unimportant|insignific\w*|inconsequential|not worth|little practical|no practical)\b/i.test(
      context.definition ?? "",
    )
  )
    return null;
  return {
    kind: "source-event-adjunct" as const,
    sourceEvent: event[1].toLowerCase(),
    nominalEvent: nominal[3].toLowerCase(),
    antecedent: subject,
    argumentSuffix: context.suffix!,
  };
}
/** Local mapping evidence only. Nothing here exempts a proposal from the
 * unchanged v5 syntax/meaning/qualifier/benefit validators. */
export function mapReplacement(
  old: string,
  replacement: string | null | undefined,
  word: string,
  pos: string,
  context: MappingContext = {},
): MappingEvidence {
  let local = replacement?.trim() || null;
  const a = lexicalTokens(old),
    b = lexicalTokens(local ?? "");
  const unit = word.toLowerCase().split(" ");
  const candidate = (t: string) =>
    wordForms(unit[0]).has(t) || unit.slice(1).includes(t);
  const introduced = b.filter((t) => !a.includes(t) && !candidate(t));
  const grammaticalAdditions = introduced.filter((t) => supportWords.has(t));
  const semanticAdditions = introduced.filter((t) => !supportWords.has(t));
  let repair: string | null = null;
  const diagnostics: string[] = [],
    licensedTokens: string[] = [];
  let functionWordRepairAttempted = introduced.some(
    (t) => supportWords.has(t) || t === "so" || t === "it",
  );
  // Bounded clause restatement with one literal, singular antecedent NP.
  // Multiple objects, additional clauses, a changed modal/audience/event or an
  // extra lexical token cannot acquire permission from a connective/pronoun.
  const clause = old.match(
    /^([a-z-]+)\s+((?:a|an|the)\s+(?:[a-z-]+\s+){0,3}[a-z-]+)\s+in (?:words|terms|language) (?:that|which) ((?:everyone|everybody|we|you|they) (?:can|could|may|might|would) (?:understand|follow|comprehend))$/i,
  );
  if (local && clause && simpleNoun(clause[2])) {
    const head = lexicalTokens(local)[0];
    const rest = local.slice(head?.length ?? 0).trim();
    const expected = clause[2] + " so " + clause[3];
    if (
      head &&
      candidate(head) &&
      (rest.toLowerCase() === expected.toLowerCase() ||
        [
          nounNumber(clause[2]) === "plural" ? "them" : "it",
          ...(nounNumber(clause[2]) === "singular" ? ["this", "that"] : []),
        ].some(
          (ref) => rest.toLowerCase() === (expected + " " + ref).toLowerCase(),
        ))
    ) {
      for (const t of [
        "so",
        ...(/\b(?:it|them|this|that)$/i.test(rest)
          ? [rest.split(" ").at(-1)!.toLowerCase()]
          : []),
      ]) {
        if (!grammaticalAdditions.includes(t)) grammaticalAdditions.push(t);
        const index = semanticAdditions.indexOf(t);
        if (index >= 0) semanticAdditions.splice(index, 1);
        licensedTokens.push(t);
      }
      repair = "source-supported-clause-glue";
      functionWordRepairAttempted = true;
      diagnostics.push("referential-support-verified");
    }
  }
  // Preserve the complete source NP modifiers when the proposal supplies only
  // a replacement head. No source qualifier is inferred or discarded.
  if (
    local &&
    /^noun$/i.test(pos) &&
    b.length === 1 &&
    candidate(b[0]) &&
    /^(?:(?:the|a|an) )?(?:(?:small|tiny|minor|meaningful|important|significant|initial|partial|temporary|slight|fine|subtle|notable|clear|several|many|few|two|three|only|but|and) ){1,6}[a-z-]+$/i.test(
      old,
    ) &&
    nounNumber(old) === nounNumber(b[0])
  ) {
    local = old.replace(/[a-z-]+$/i, b[0]);
    repair = "qualifier-preserving-noun-head";
    diagnostics.push(repair);
  }
  // A small set of semantic dimensions, not candidate synonym pairs. Speed
  // and partiality retain the source's explicit protected token in output.
  for (const t of introduced.filter((t) =>
    /^(?:further|additional|additionally|rapidly|significantly|partially)$/.test(
      t,
    ),
  )) {
    const next = b[b.indexOf(t) + 1];
    const adjacent =
      !!next &&
      candidate(next) &&
      (t === "additional"
        ? /^noun$/i.test(pos)
        : /^(?:verb|phrasal verb)$/i.test(pos));
    const dimension = /^(?:further|additional|additionally)$/.test(t)
      ? /\b(?:more|additional) (?:support|evidence)\b/i.test(old)
      : t === "rapidly"
        ? /\b(?:quickly|rapidly)\b/i.test(old)
        : t === "partially"
          ? /\b(?:partly|partially)\b/i.test(old)
          : /\b(?:large|major|significant)\b.{0,30}\b(?:effect|change|reduction|improvement)\b/i.test(
              old,
            );
    if (adjacent && dimension) {
      diagnostics.push("supported-evidence-modifier");
      licensedTokens.push(t);
      if (t === "rapidly" && /\bquickly\b/i.test(old)) {
        local = local!.replace(/\brapidly\b/i, "quickly");
        if (
          /^[a-z-]+ quickly$/i.test(old) &&
          /^quickly [a-z-]+(?: [a-z-]+)?$/i.test(local)
        )
          local = local.replace(/^quickly (.+)$/i, "$1 quickly");
      }
      if (t === "partially" && /\bpartly\b/i.test(old))
        local = local!.replace(/\bpartially\b/i, "partly");
      repair ??= "supported-evidence-modifier";
    } else diagnostics.push("unsupported-added-modifier");
  }
  const frameProof = local
    ? proveEventNominalization(old, local, word, pos, context)
    : null;
  if (frameProof) {
    licensedTokens.push(...lexicalTokens(local!).filter((t) => !candidate(t)));
    repair = "event-nominalization-supported";
    diagnostics.push(repair, "referential-support-verified");
  } else if (
    local &&
    /\b(?:effect|influence) on\b|\b[a-z-]+(?:tion|ment) of\b/i.test(local) &&
    !a.includes(
      lexicalTokens(local).find((t) =>
        /effect|influence|tion$|ment$/.test(t),
      ) ?? "",
    )
  )
    diagnostics.push("event-nominalization-unsafe");
  // A bundled fine-scale modifier may restate source evidence, but may not
  // erase its contrast/significance. Map the noun head and keep the original
  // modifiers verbatim. This yields e.g. small but meaningful <new plural noun>
  // rather than licensing arbitrary new adjectives or weakening v5 frames.
  if (
    local &&
    /^noun$/i.test(pos) &&
    b.length === 2 &&
    candidate(b[1]) &&
    /^(?:subtle|fine)$/.test(b[0]) &&
    /^(?:small|tiny|minor) but (?:meaningful|important|significant) [a-z-]+$/i.test(
      old,
    ) &&
    /s$/.test(a.at(-1) ?? "") &&
    /s$/.test(b[1])
  ) {
    local = old.replace(/[a-z-]+$/i, b[1]);
    repair = "supported-modifier-mapped-to-source";
  }
  return {
    functionWordRepairAttempted,
    grammaticalAdditions,
    semanticAdditions,
    repair,
    local,
    diagnostics,
    licensedTokens,
    frameProof,
    actualSemanticAdditions: lexicalTokens(local ?? "").filter(
      (t) => !a.includes(t) && !candidate(t) && !supportWords.has(t),
    ),
  };
}
