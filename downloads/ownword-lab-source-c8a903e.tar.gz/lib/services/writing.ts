import { nextUtcDay } from "../domain/request-limits";
import { z } from "zod";
import type { Clock, IdGenerator } from "../domain/types";
import { diagnosticSubmissionSchema, type DiagnosticReport, type DiagnosticSubmission } from "../writing/contracts";
import { detailWritingFocus, groupWritingFocusProblems, matchBaselineFocusKeys, selectWritingFocusSuggestions, summarizeWritingFocus, writingFocusBoardProblems, writingFocusHistoryKey, writingFocusTargets,
  WRITING_FOCUS_PIN_LIMIT, type WritingFocusBoard } from "../writing/focus";
import { uncaughtFocusTargets, WRITING_FOCUS_TIMEOUT_MS } from "../writing/focus-check";
import { diagnosticPromptChoices, discussionBlueprint, getDiagnosticBlueprint, getDiagnosticPrompt, writingInterests } from "../writing/prompt-bank";
import type { WritingEvaluator, WritingFocusEvaluator, WritingLimits, WritingRepository, WritingRun, WritingTask } from "../writing/persistence";
import type { WritingRevisionCheck, WritingRevisionEvaluator } from "../writing/revision-check";
import { buildWritingProfile, getWritingProfileSessions } from "../writing/profile";
import { buildWritingImprovements } from "../writing/profile-improvements";
import { prepareWritingTrendAnalysis, readWritingTrendAnalysis, writingTrendSourceKey, type WritingTrendAnalyst,
  type WritingTrendPolicy } from "../writing/profile-trends";
import { selectWritingSkillTargets } from "../writing/skill-targets";
import { readWritingSkillVerification, type WritingSkillVerifier } from "../writing/skill-verification";
import { AppError } from "./app-error";
import type { LearningStreakService } from "./learning-streak";
import { getWritingPracticeExercises, getWritingPracticeRecommendations } from "../writing/personalized-practice";
import { checkWritingPracticeRepair, getWritingPracticeRepair, writingPracticeRepairLimit } from "../writing/practice-repair";

const interestId = z.enum(Object.keys(writingInterests) as (keyof typeof writingInterests)[]);
export const writingId = z.uuid();
const interestIds = z.array(interestId).max(2).refine((ids) => new Set(ids).size === ids.length, "Choose distinct interests.");
export const writingTaskRequest = z.strictObject({
  requestId: writingId,
  promptId: diagnosticSubmissionSchema.shape.promptId,
  interestIds,
  locale: z.enum(["en", "vi"]),
});
export const writingSubmissionRequest = z.strictObject({
  requestId: writingId,
  taskId: writingId,
  parentSubmissionId: writingId.optional(),
  assistance: z.enum(["unassisted", "external_help", "ownword_hint", "unknown"]).default("unknown"),
  text: diagnosticSubmissionSchema.shape.text.refine(
    (text) => !text.includes("\0") && !/[\uD800-\uDFFF]/u.test(text),
    "Enter valid Unicode text.",
  ),
});
export const writingRetryRequest = z.strictObject({ requestId: writingId });
const focusKey = z.string().min(1).max(128).regex(/^[a-z0-9_.:-]+$/i);
const focusUpdate = z.strictObject({ key: focusKey, action: z.enum(["add", "remove", "dismiss", "restore"]) });

export const WRITING_LEASE_MS = 60_000;
const wordSegmenter = new Intl.Segmenter("en", { granularity: "word" });

function writingNotFound() {
  return new AppError("That writing submission or task was not found.", 404);
}

export class WritingService {
  constructor(
    private readonly repository: WritingRepository,
    private readonly userId: string,
    private readonly ensureUser: () => Promise<unknown>,
    private readonly clock: Clock,
    private readonly ids: IdGenerator,
    private readonly limits: WritingLimits,
    private readonly evaluate: WritingEvaluator,
    private readonly evaluateRevision?: WritingRevisionEvaluator,
    private readonly analyzeTrends?: WritingTrendAnalyst,
    private readonly trendPolicy: WritingTrendPolicy | "disabled" = "release",
    private readonly verifySkills?: WritingSkillVerifier,
    readonly streak?: LearningStreakService,
    private readonly evaluateFocus?: WritingFocusEvaluator,
  ) {}

  prompts(interests: string[]) {
    return {
      blueprint: discussionBlueprint,
      interests: writingInterests,
      choices: diagnosticPromptChoices(interestIds.parse(interests)),
    };
  }

  async createTask(body: unknown) {
    const request = writingTaskRequest.parse(body);
    const { interestIds, locale, promptId, requestId } = request;
    const prompt = diagnosticPromptChoices(interestIds).find(({ id }) => id === promptId);
    if (!prompt) throw new AppError("Choose one of the offered writing prompts.");
    const blueprint = getDiagnosticBlueprint(prompt);
    await this.ensureUser();
    const task: WritingTask = {
      id: this.ids.next(),
      promptId,
      promptVersion: blueprint.version,
      snapshot: { prompt, blueprint, interestIds, locale },
      createdAt: this.clock.now().toISOString(),
    };
    const saved = await this.repository.createTask(this.userId, task, requestId);
    if (saved.status !== "saved") throw new AppError("This request ID already belongs to a different task.", 409);
    return saved.record;
  }

  async submit(body: unknown) {
    const request = writingSubmissionRequest.parse(body);
    const { taskId, requestId, text, parentSubmissionId } = request;
    const saved = await this.repository.createSubmission(this.userId, {
      id: this.ids.next(),
      taskId,
      parentSubmissionId: parentSubmissionId ?? null,
      text,
      wordCount: Array.from(wordSegmenter.segment(text)).filter(({ isWordLike }) => isWordLike).length,
      assistance: parentSubmissionId && request.assistance !== "external_help" ? "ownword_hint" : request.assistance,
      createdAt: this.clock.now().toISOString(),
    }, requestId);
    if (saved.status === "not_found") throw writingNotFound();
    if (saved.status !== "saved") throw new AppError("This task or request ID already has a different submission.", 409);
    if (parentSubmissionId) return { record: await this.getSubmission(saved.record.id), quotaReached: false, completedActivity: false };
    return this.assess(saved.record.id, `initial:${requestId}`, "initial");
  }

  async retry(submissionId: string, body: unknown) {
    const { requestId } = writingRetryRequest.parse(body);
    return this.assess(writingId.parse(submissionId), `retry:${requestId}`, "retry");
  }

  private async assess(submissionId: string, requestId: string, mode: "initial" | "retry") {
    const record = await this.getSubmission(submissionId);
    if (record.submission.parentSubmissionId) throw writingNotFound();
    const started = this.clock.now();
    const reservation = await this.repository.reserveRun(this.userId, {
      id: this.ids.next(), submissionId, requestId, mode,
      now: started.toISOString(),
      leaseExpiresAt: new Date(started.getTime() + WRITING_LEASE_MS).toISOString(),
      limits: this.limits,
    });
    if (reservation.status === "not_found") throw writingNotFound();
    if (reservation.status === "conflict") throw new AppError("This request ID already belongs to a different assessment.", 409);
    let completedActivity = false;
    if (reservation.status === "claimed") {
      let report = null;
      try {
        const prompt = getDiagnosticPrompt(record.task.promptId);
        if (prompt && record.task.promptVersion === getDiagnosticBlueprint(prompt).version) {
          const input = { submissionId, text: record.submission.text, promptId: record.task.promptId };
          const result = await this.evaluate(input);
          if (result.status === "validated" && result.report.submissionId === submissionId &&
            result.report.promptId === record.task.promptId && result.report.promptVersion === record.task.promptVersion) {
            report = await this.withSkillVerification(record, input, result.report, reservation.run);
            report = await this.withFocusCheck(record, input, report, reservation.run);
          }
        }
      } catch {
        // Keep raw evaluator errors and writing outside persistent state and response bodies.
      }
      const saved = await this.repository.finishRun(this.userId, reservation.run, this.clock.now().toISOString(), report);
      completedActivity = saved && report !== null;
    }
    return { record: await this.getSubmission(submissionId), quotaReached: reservation.status === "quota", completedActivity };
  }

  private async focusTargetsForEvaluation(signal: AbortSignal) {
    const states = await this.repository.listFocusStates(this.userId);
    if (!states.length) return [];
    signal.throwIfAborted();
    const records = await this.repository.listFocusRecords(this.userId);
    signal.throwIfAborted();
    const problems = groupWritingFocusProblems(records, false, new Set(states.map(({ key }) => key)));
    if (states.some(({ key }) => !problems.has(key))) {
      const physical = groupWritingFocusProblems(records, true);
      if (states.some(({ key }) => !physical.has(key))) {
        // Older rows could outlive a deleted source. Retire them before a report can revive them.
        await this.repository.pruneFocusStates(this.userId, {
          historyKey: writingFocusHistoryKey(records), retainKeys: [...physical.keys()],
        });
      }
    }
    return writingFocusTargets(states.filter(({ status, key }) => status === "active" && problems.has(key)).map(({ key }) => key));
  }

  private async withFocusCheck(record: Awaited<ReturnType<WritingService["getSubmission"]>>,
    input: DiagnosticSubmission, report: DiagnosticReport, run: WritingRun) {
    const evaluateFocus = this.evaluateFocus;
    if (!evaluateFocus || !report.issueFirstObservations || report.focusContext) return report;
    // Preserve time to settle the base assessment even if optional work stalls.
    const budget = Math.min(WRITING_FOCUS_TIMEOUT_MS, Date.parse(run.leaseExpiresAt) - this.clock.now().getTime() - 3_000);
    if (budget <= 0) return report;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const deadline = new Promise<null>((resolve) => {
      timer = setTimeout(() => { controller.abort(); resolve(null); }, budget);
    });
    try {
      const focused = async () => {
        const pins = await this.focusTargetsForEvaluation(controller.signal);
        controller.signal.throwIfAborted();
        if (!pins.length) return { check: null, attempted: false };
        const keys = matchBaselineFocusKeys({ ...record, run: { ...run, status: "succeeded", report } });
        const baseline = report.issueFirstObservations!.flatMap((observation, index) =>
          observation.kind === "problem" ? [{ key: keys.get(index) ?? null, observation }] : []);
        const targets = uncaughtFocusTargets(input.text, pins, baseline);
        if (!targets.length) return { check: null, attempted: false };
        controller.signal.throwIfAborted();
        return { check: await evaluateFocus(input, targets, baseline, controller.signal), attempted: true };
      };
      const result = await Promise.race([focused(), deadline]);
      if (!result || result.attempted && !result.check) console.warn("Writing Focus check unavailable.");
      return result?.check && !controller.signal.aborted ? { ...report, focusCheck: result.check } : report;
    } catch {
      console.warn("Writing Focus check unavailable.");
      return report;
    } finally {
      clearTimeout(timer);
    }
  }

  async focusBoard(): Promise<WritingFocusBoard> {
    const [records, states] = await Promise.all([
      this.repository.listFocusRecords(this.userId), this.repository.listFocusStates(this.userId),
    ]);
    const status = new Map(states.map(({ key, status }) => [key, status]));
    const board: WritingFocusBoard = {
      active: [], suggestions: [], dismissed: [],
      pinCount: states.filter(({ status }) => status === "active").length, pinLimit: WRITING_FOCUS_PIN_LIMIT,
      coachedCount: 0, coachingAvailable: !!this.evaluateFocus,
    };
    const problems = writingFocusBoardProblems(records, new Set(status.keys()));
    const returned = [];
    for (const problem of problems.values()) {
      const state = status.get(problem.key);
      if (state === "dismissed") {
        board.dismissed.push({ key: problem.key, title: problem.title });
        continue;
      }
      if (state === "active") board.active.push(summarizeWritingFocus(problem));
      if (state === "returned") returned.push(summarizeWritingFocus(problem));
    }
    board.suggestions = [...returned, ...selectWritingFocusSuggestions(problems, new Set(status.keys()))];
    const monitored = board.active.flatMap(({ key }) => problems.get(key)?.historicalOnly ? [] : [key]);
    const coached = new Set(this.evaluateFocus ? writingFocusTargets(monitored).map(({ key }) => key) : []);
    board.active = board.active.map((card) => ({ ...card, coached: coached.has(card.key) }));
    board.coachedCount = coached.size;
    return board;
  }

  async focusDetail(rawKey: string) {
    const key = focusKey.parse(rawKey);
    const [records, states] = await Promise.all([
      this.repository.listFocusRecords(this.userId), this.repository.listFocusStates(this.userId),
    ]);
    const problem = writingFocusBoardProblems(records, new Set(states.map((state) => state.key))).get(key);
    if (!problem || states.some((state) => state.key === key && state.status === "dismissed")) {
      throw new AppError("That writing problem was not found.", 404);
    }
    return detailWritingFocus(problem);
  }

  async updateFocus(body: unknown) {
    const { key, action } = focusUpdate.parse(body);
    const [records, states] = await Promise.all([
      this.repository.listFocusRecords(this.userId), this.repository.listFocusStates(this.userId),
    ]);
    const savedKeys = new Set(states.map((state) => state.key));
    const problems = writingFocusBoardProblems(records, savedKeys);
    const problem = problems.get(key);
    if (!problem) throw new AppError("That writing problem was not found.", 404);
    const sources = [...new Set(problem.occurrences.map(({ item }) => item.submissionId))];
    // A returned card may fall below admission or outside the shortlist.
    let rememberReturn = false;
    if (action === "remove" || action === "restore") {
      savedKeys.delete(key);
      rememberReturn = !selectWritingFocusSuggestions(writingFocusBoardProblems(records, savedKeys), savedKeys)
        .some((card) => card.key === key || problem.canonicalKeys.has(card.key));
    }
    if (!await this.repository.updateFocusState(this.userId, key, action, sources, rememberReturn)) {
      if (action === "add" && (await this.repository.listFocusStates(this.userId))
        .filter(({ status }) => status === "active").length >= WRITING_FOCUS_PIN_LIMIT) {
        throw new AppError("Writing Focus is full. Remove a pin before adding another.", 409);
      }
      throw new AppError("This writing problem has changed. Refresh and try again.", 409);
    }
    return this.focusBoard();
  }

  private async withSkillVerification(record: Awaited<ReturnType<WritingService["getSubmission"]>>,
    input: DiagnosticSubmission, report: DiagnosticReport, run: NonNullable<typeof record.run>): Promise<DiagnosticReport> {
    if (this.trendPolicy !== "improvement-pilot" || !this.verifySkills || record.submission.assistance !== "unassisted") return report;
    try {
      const history = (await this.repository.listProfileRecords(this.userId)).filter(({ submission }) => submission.id !== input.submissionId);
      const currentRecord = { ...record, run: { ...run, status: "succeeded" as const, report } };
      // Apply the original/assistance/duplicate rules before incurring a verification call.
      const sessions = getWritingProfileSessions([...history, { ...record, run: null }], true);
      if (!sessions.some(({ submission }) => submission.id === input.submissionId)) return report;
      const current = getWritingProfileSessions([currentRecord], true)[0];
      const targets = current ? selectWritingSkillTargets(current, sessions) : [];
      if (!targets.length) return report;
      const verification = readWritingSkillVerification(record.submission, await this.verifySkills(input, targets));
      if (verification && verification.results.every(({ targetId, baselineEvidenceId }) =>
        targets.some(({ id, evidenceId }) => id === targetId && evidenceId === baselineEvidenceId))) {
        return { ...report, skillVerification: verification };
      }
    } catch {
      // Targeted analysis is optional. Provider or evidence failures preserve ordinary feedback.
    }
    return report;
  }

  async getSubmission(submissionId: string) {
    const record = await this.repository.getSubmission(this.userId, writingId.parse(submissionId));
    if (!record) throw writingNotFound();
    if (record.run?.status === "pending" && record.run.leaseExpiresAt <= this.clock.now().toISOString()) {
      return { ...record, run: { ...record.run, status: "expired" as const, finishedAt: record.run.leaseExpiresAt } };
    }
    return record;
  }

  async submissionDetail(submissionId: string) {
    const record = await this.getSubmission(submissionId);
    const latestRevisionId = await this.repository.latestSubmissionId(this.userId, record.task.id);
    return { ...record, latestRevisionId };
  }

  async revisions(originalId: string) {
    const original = await this.getSubmission(originalId);
    if (original.submission.parentSubmissionId) throw writingNotFound();
    return this.repository.listRevisions(this.userId, original.submission.id);
  }

  async getRevisionCheck(revisionId: string) {
    const saved = await this.repository.getRevisionCheck(this.userId, writingId.parse(revisionId), this.clock.now().toISOString());
    if (!saved) throw writingNotFound();
    return saved;
  }

  async checkRevision(revisionId: string, onCompleted?: () => void) {
    if (!this.evaluateRevision) throw writingNotFound();
    const saved = await this.getRevisionCheck(revisionId);
    if (saved.check) return saved.check;
    if (saved.pending) throw new AppError("This revision is already being checked.", 409);
    const revision = await this.getSubmission(revisionId);
    if (!revision.submission.parentSubmissionId) throw writingNotFound();
    const original = await this.getSubmission(revision.submission.parentSubmissionId);
    if (original.submission.parentSubmissionId || original.task.id !== revision.task.id) throw writingNotFound();
    const report = original.run?.report;
    if (original.run?.status !== "succeeded" || !report?.issueFirstObservations || report.submissionId !== original.submission.id) {
      throw new AppError("Writing feedback is required before checking a revision.", 409);
    }
    if (revision.submission.text.trim() === original.submission.text.trim()) {
      throw new AppError("Make a change to your writing before checking it.", 409);
    }
    const started = this.clock.now();
    const leaseToken = this.ids.next();
    const reservation = await this.repository.reserveRevisionCheck(this.userId, {
      revisionId,
      leaseToken,
      now: started.toISOString(),
      leaseExpiresAt: new Date(started.getTime() + WRITING_LEASE_MS).toISOString(),
      attemptLimit: Math.min(5, this.limits.attempts),
    });
    if (reservation.status === "not_found") throw writingNotFound();
    if (reservation.status === "completed") return reservation.check;
    if (reservation.status === "pending") throw new AppError("This revision is already being checked.", 409);
    if (reservation.status === "quota") {
      throw new AppError("You have reached today's limit for revision checks.", 429);
    }
    let result: WritingRevisionCheck | null = null;
    try {
      const check = await this.evaluateRevision({
        report,
        original: original.submission.text,
        revised: revision.submission.text,
        revisionId,
        prompt: original.task.snapshot.prompt.scenario,
      });
      if (check?.revisionId === revisionId && check.originalId === original.submission.id) result = check;
    } catch {
      // Keep raw provider errors out of the response and release the reservation for retry.
    }
    if (!await this.repository.finishRevisionCheck(this.userId, revisionId, leaseToken, result, this.clock.now().toISOString())) {
      const saved = await this.getRevisionCheck(revisionId);
      if (saved.check) return saved.check;
      if (saved.pending) throw new AppError("This revision is already being checked.", 409);
      result = null;
    }
    if (!result) throw new AppError("The revision check did not finish. Your revision is still saved.", 503);
    onCompleted?.();
    return result;
  }

  async completePractice(submissionId: string, body: unknown) {
    const { observationIndex, exerciseIndex, segment, replacement } = z.strictObject({
      observationIndex: z.int().nonnegative(),
      exerciseIndex: z.int().nonnegative(),
      segment: z.string().min(1).max(100),
      replacement: z.string().trim().min(1).max(writingPracticeRepairLimit),
    }).parse(body);
    const { submission, run } = await this.getSubmission(submissionId);
    const report = run?.report;
    if (submission.parentSubmissionId || run?.status !== "succeeded" || report?.submissionId !== submissionId)
      throw writingNotFound();
    const practice = getWritingPracticeRecommendations(report, submission.text)
      .find((item) => item.observationIndex === observationIndex);
    if (!practice || !getWritingPracticeExercises(practice.skill)[exerciseIndex]) throw writingNotFound();
    const exercise = getWritingPracticeRepair(practice.skill, exerciseIndex);
    if (checkWritingPracticeRepair(exercise, segment, replacement).status !== "successful")
      throw new AppError("Complete this exercise to record your practice.");
    return { completed: true };
  }

  async profile() {
    return { latestSubmissionId: await this.repository.latestSubmissionId(this.userId) };
  }

  private async profileEvidence() {
    const records = await this.repository.listProfileRecords(this.userId);
    const sessions = getWritingProfileSessions(records);
    const input = this.trendPolicy === "disabled" ? null : prepareWritingTrendAnalysis(sessions, this.trendPolicy);
    return { records, sessions, input, key: input?.candidates.length ? await writingTrendSourceKey(input) : null };
  }

  async profileOverview() {
    const { records, sessions, input, key } = await this.profileEvidence();
    const saved = key ? await this.repository.getProfileAnalysis(this.userId) : null;
    const now = this.clock.now().toISOString();
    const sameEvidence = !!saved && saved.evidenceKey === key;
    const analysis = sameEvidence && input ? readWritingTrendAnalysis(input, saved.result) : null;
    const independent = this.trendPolicy === "improvement-pilot" ? getWritingProfileSessions(records, true) : [];
    const improvements = this.trendPolicy === "improvement-pilot" ? buildWritingImprovements(independent, this.trendPolicy) : [];
    const byId = new Map([...sessions, ...independent].flatMap((session) => session.evidence.map((evidence) => [evidence.id, evidence] as const)));
    const trends = [...improvements, ...(analysis?.trends ?? [])].flatMap(({ evidenceIds, ...trend }) => {
      const evidence = evidenceIds.flatMap((id) => byId.get(id) ?? []);
      return evidence.length === evidenceIds.length && evidence.length >= 2 ? [{ ...trend, evidence }] : [];
    });
    const state = !input ? "disabled" : !key ? improvements.length ? "ready" : "emerging" : analysis ? "ready" : saved?.leaseToken && saved.nextAttemptAt > now ? "pending"
      : !this.analyzeTrends ? "unavailable" : sameEvidence ? "retry" : "available";
    return { ...buildWritingProfile(records, sessions, trends),
      trends: { state, items: trends, updatedAt: analysis && saved ? saved.updatedAt : null,
      retryAt: sameEvidence && state === "retry" && saved.nextAttemptAt > now ? saved.nextAttemptAt : null } };
  }

  async refreshProfileTrends() {
    const analyze = this.analyzeTrends;
    if (!analyze || this.trendPolicy === "disabled") throw new AppError("Writing trend analysis is unavailable.", 503);
    const { key, input } = await this.profileEvidence();
    if (!key || !input) return this.profileOverview();
    const saved = await this.repository.getProfileAnalysis(this.userId);
    const replaceInvalidResult = saved?.evidenceKey === key && !readWritingTrendAnalysis(input, saved.result)
      ? saved.resultJson ?? undefined : undefined;
    const started = this.clock.now();
    const leaseToken = this.ids.next();
    const reservation = await this.repository.reserveProfileAnalysis(this.userId, {
      leaseToken, evidenceKey: key, now: started.toISOString(),
      leaseExpiresAt: new Date(started.getTime() + WRITING_LEASE_MS).toISOString(), dailyLimit: 2, replaceInvalidResult,
    });
    if (reservation === "quota") {
      const overview = await this.profileOverview();
      if (overview.trends.state === "ready" || overview.trends.state === "pending") return overview;
      throw new AppError("You have reached today's limit for writing trend analysis.", 429);
    }
    if (reservation !== "claimed") return this.profileOverview();

    let result: unknown = null;
    try {
      const latest = await this.profileEvidence();
      if (latest.key === key && latest.input) {
        const analysis = await analyze(latest.input);
        if (analysis && readWritingTrendAnalysis(latest.input, analysis) && (await this.profileEvidence()).key === key) {
          result = { version: analysis.version, policy: analysis.policy, selections: analysis.selections };
        }
      }
    } catch {
      // A failed optional trend analysis does not hide feedback, practice, or history.
    }
    const finished = this.clock.now();
    await this.repository.finishProfileAnalysis(this.userId, leaseToken, finished.toISOString(),
      new Date(finished.getTime() + (result === null ? 30_000 : 0)).toISOString(), result);
    return this.profileOverview();
  }

  async history() {
    return this.repository.listOriginalSubmissions(this.userId);
  }

  async quotas() {
    const now = this.clock.now().toISOString();
    const used = await this.repository.getQuota(this.userId, now);
    return {
      limits: this.limits,
      pending: used.pending,
      remaining: Math.max(0, Math.min(this.limits.successes - used.successes - used.pending, this.limits.attempts - used.attempts)),
      resetAt: nextUtcDay(new Date(now)),
    };
  }

  async deleteSubmission(id: string) {
    const submissionId = writingId.parse(id);
    const { submission } = await this.getSubmission(submissionId);
    if (submission.parentSubmissionId) {
      if (!await this.repository.deleteSubmission(this.userId, submissionId)) throw writingNotFound();
      return;
    }
    for (let attempt = 0; attempt < 3; attempt++) {
      const records = await this.repository.listFocusRecords(this.userId);
      const remaining = records.filter(({ submission }) => submission.id !== submissionId);
      if (remaining.length === records.length) throw writingNotFound();
      const plan = {
        historyKey: writingFocusHistoryKey(records),
        retainKeys: [...groupWritingFocusProblems(remaining, true).keys()],
      };
      if (await this.repository.deleteSubmission(this.userId, submissionId, plan)) return;
    }
    throw new AppError("Your writing history changed. Please retry the deletion.", 409);
  }

  async deleteAll() {
    await this.repository.deleteAll(this.userId);
  }
}
