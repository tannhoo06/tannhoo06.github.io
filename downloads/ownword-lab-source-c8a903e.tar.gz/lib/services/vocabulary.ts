import { resolveSource } from "../domain/anchors";
import { wordCloud } from "../domain/word-cloud";
import type { LlmProvider, Repository } from "../domain/ports";
import type {
  AppState,
  ConceptDiscovery,
  Attempt,
  Clock,
  Exercise,
  HintLevel,
  Identity,
  IdGenerator,
  Lexeme,
  LearningJourneySummary,
  PublicExercise,
  PracticeSession,
  PracticeOutcome,
  Suggestion,
  UserWord,
} from "../domain/types";
import {
  DEFAULT_POLICY,
  practiceCandidates,
  practiceReviewDate,
  DAY,
  dueWords,
  introductionQueue,
  evidence,
  exerciseKind,
  progress,
  type LearningPolicy,
} from "../domain/learning";
import { CATALOG, CONTEXT_DOMAINS } from "../llm/catalog";
import { findInsights } from "./insights";
import { AppError } from "./app-error";

export { AppError } from "./app-error";
export class VocabularyService {
  constructor(
    private repo: Repository,
    private llm: LlmProvider,
    private identity: Identity,
    private clock: Clock,
    private ids: IdGenerator,
    private policy: LearningPolicy = DEFAULT_POLICY,
  ) {}
  private now() {
    return this.clock.now().toISOString();
  }
  private async profile() {
    return this.repo.ensureUser(this.identity, this.now());
  }
  private async word(id: string) {
    const word = (await this.repo.listWords(this.identity.id)).find(
      (w) => w.userWordId === id,
    );
    if (!word)
      throw new AppError("That word was not found on your board.", 404);
    return word;
  }
  async state(): Promise<AppState> {
    const profile = await this.profile();
    const words = await this.repo.listWords(this.identity.id);
    const writing = await this.repo.listWriting(this.identity.id);
    const insights = findInsights(writing);
    return {
      profile,
      words,
      cloudWords: wordCloud(words, this.clock.now().getTime(), writing),
      ...this.summarizeLearningJourney(words, profile.dailyLimit),
      queuedCount: words.filter((w) => !w.introducedAt).length,
      writingCount: writing.length,
      insights,
      mockMode: this.llm.mode === "mock",
    };
  }
  private summarizeLearningJourney(words: UserWord[], dailyLimit: number): LearningJourneySummary {
    const now = this.clock.now();
    const today = now.toISOString().slice(0, 10);
    return {
      dueCount: Math.min(dailyLimit, dueWords(words, now, dailyLimit).length +
        introductionQueue(words, now, this.policy).length),
      practicedToday: words.some((word) => !word.demo && word.attempts.some((attempt) =>
        attempt.at.slice(0, 10) === today && attempt.kind !== "spontaneous" && attempt.answer.trim() &&
        !(attempt.context === "quick-review" && attempt.answer === "skip"))),
    };
  }
  async learningJourney(): Promise<LearningJourneySummary> {
    const profile = await this.profile();
    const words = await this.repo.listWords(this.identity.id);
    return this.summarizeLearningJourney(words, profile.dailyLimit);
  }
  async addManual(input: string, override = false) {
    await this.profile();
    const word = input.normalize("NFKC").trim().replace(/\s+/g, " ").toLowerCase();
    if (word.length < 2 || word.length > 45 || !/^[a-z][a-z' -]*$/.test(word))
      throw new AppError("Enter an English word or short phrase using letters.");
    const words = await this.repo.listWords(this.identity.id);
    const existing = words.find((item) => item.word.toLowerCase() === word);
    if (existing) return { status: "already" as const, userWordId: existing.userWordId };
    const known = CATALOG.find((item) => item.word.toLowerCase() === word);
    let check = known ? { status: "valid" as const, suggestion: null } : await this.repo.getManualWordCheck(this.identity.id, word, new Date(this.clock.now().getTime() - 7 * DAY).toISOString());
    if (!check) {
      check = await this.llm.checkWord(word);
      await this.repo.saveManualWordCheck(this.identity.id, word, check, this.now());
    }
    if (check.status !== "valid" && !(override && check.status === "uncertain"))
      return { status: "review" as const, check };
    const id = await this.repo.addWord(this.identity.id, known ?? {
      id: this.ids.next(), word, partOfSpeech: "", definition: "", nuance: "", collocations: [], examples: [],
    }, { source: "Manual", sourceText: "", now: this.now(), introduced: false });
    await this.repo.setProfile(this.identity.id, { onboarded: true });
    return { status: "added" as const, userWordId: id };
  }
  async discoverConcept(concept: string) {
    await this.profile();
    const candidates = await this.llm.discoverConcept(concept);
    const seen = new Set<string>();
    return candidates.filter((candidate) => {
      const word = candidate.word.trim().toLowerCase();
      if (!/^[a-z][a-z' -]{1,59}$/.test(word) || !candidate.definition.trim() || seen.has(word)) return false;
      seen.add(word);
      return true;
    });
  }
  async recentConceptDiscovery(concept: string) {
    await this.profile();
    return this.repo.recentConceptDiscovery(this.identity.id, concept, new Date(this.clock.now().getTime() - DAY).toISOString());
  }
  async saveConceptDiscovery(concept: string, candidates: Lexeme[]): Promise<ConceptDiscovery> {
    await this.profile();
    const discovery = {
      id: this.ids.next(),
      concept: concept.trim(),
      candidates,
      createdAt: this.now(),
    };
    await this.repo.saveConceptDiscovery(this.identity.id, discovery);
    return discovery;
  }
  async latestConceptDiscovery() {
    await this.profile();
    return this.repo.latestConceptDiscovery(this.identity.id);
  }
  async translateConceptCandidate(discoveryId: string, candidateId: string) {
    await this.profile();
    const discovery = await this.repo.getConceptDiscovery(this.identity.id, discoveryId);
    const candidate = discovery?.candidates.find((item) => item.id === candidateId);
    if (!candidate) throw new AppError("That word suggestion is no longer available.", 404);
    if (candidate.vietnameseMeaning?.trim()) return { meaning: candidate.vietnameseMeaning.trim() };
    const meaning = await this.llm.translateLexeme(candidate);
    await this.repo.saveConceptCandidateTranslation(this.identity.id, discoveryId, candidateId, meaning);
    return { meaning };
  }
  async addConceptCandidate(discoveryId: string, candidateId: string) {
    await this.profile();
    const discovery = await this.repo.getConceptDiscovery(this.identity.id, discoveryId);
    const candidate = discovery?.candidates.find((item) => item.id === candidateId);
    if (!discovery || !candidate) throw new AppError("That word suggestion is no longer available.", 404);
    await this.repo.enrichWord(candidate);
    const words = await this.repo.listWords(this.identity.id);
    const existing = words.find((item) => item.word.toLowerCase() === candidate.word.toLowerCase());
    if (existing) return { status: "already" as const, userWordId: existing.userWordId };
    const userWordId = await this.repo.addWord(this.identity.id, candidate, {
      source: "Concept", sourceText: discovery.concept, now: this.now(), introduced: false,
    });
    await this.repo.setProfile(this.identity.id, { onboarded: true });
    return { status: "added" as const, userWordId };
  }
  async analyze(text: string, prompt: string) {
    await this.profile();
    const words = await this.repo.listWords(this.identity.id);
    const analysisSignature = this.writingSignature(words);
    const cached = await this.repo.recentWritingReview(this.identity.id, text, prompt, analysisSignature, new Date(this.clock.now().getTime() - DAY).toISOString());
    if (cached) return cached;
    const result = await this.llm.analyzeWriting(text, words);
    const now = this.now();
    const sampleId = await this.repo.saveWriting(
      this.identity.id,
      text,
      prompt,
      now,
    );
    const unique = result.suggestions.filter(
      (s, i, all) =>
        all.findIndex((a) => a.word.toLowerCase() === s.word.toLowerCase()) ===
        i,
    );
    const suggestions = await this.repo.saveSuggestions(
      this.identity.id,
      sampleId,
      unique.map((s) => {
        const source =
          s.source === null
            ? null
            : resolveSource(text, s.originalText, sampleId, s.source ?? {});
        return {
          ...s,
          source,
          suggestedSentence: source ? (s.suggestedSentence ?? null) : null,
        };
      }),
    );
    const usages = [];
    for (const usage of result.usages) {
      const word = words.find((w) => w.userWordId === usage.userWordId);
      if (!word) continue;
      // Evidence from free writing is only recorded once per sample and lexical item.
      const attempt: Attempt = {
        id: this.ids.next(),
        userWordId: word.userWordId,
        exerciseId: `${sampleId}:${word.userWordId}`,
        at: now,
        kind: "spontaneous",
        hint: "none",
        answer: text,
        context: "free-writing",
        ...usage.evaluation,
      };
      const history = [...word.attempts, attempt];
      const stage = progress(word.stage, history, this.policy);
      await this.repo.recordAttempt(
        this.identity.id,
        attempt,
        stage,
        practiceReviewDate(word, stage, history, this.clock.now(), this.policy),
      );
      usages.push({
        word: word.word,
        feedback: usage.evaluation.feedback,
        correct: usage.evaluation.precise,
      });
    }
    await this.repo.saveInsights(
      this.identity.id,
      findInsights(await this.repo.listWriting(this.identity.id)),
      now,
    );
    const review = {
      sampleId,
      text,
      suggestions,
      opportunities: result.opportunities.map((o) => ({
        ...o,
        source:
          o.source === null
            ? null
            : resolveSource(text, o.originalText, sampleId, o.source ?? {}),
      })),
      usages,
      summary: result.summary,
      analysisSignature,
    };
    await this.repo.saveReview(this.identity.id, review);
    return review;
  }
  private writingSignature(words: UserWord[]) {
    return JSON.stringify(words.map((word) => [word.userWordId, word.word, word.definition]).sort((a, b) => a[0].localeCompare(b[0])));
  }
  async recentWritingReview(text: string, prompt: string) {
    await this.profile();
    const words = await this.repo.listWords(this.identity.id);
    return this.repo.recentWritingReview(this.identity.id, text, prompt, this.writingSignature(words), new Date(this.clock.now().getTime() - DAY).toISOString());
  }
  async review(sampleId: string) {
    const review = await this.repo.getReview(this.identity.id, sampleId);
    if (!review)
      throw new AppError("This writing review could not be found.", 404);
    const words = await this.repo.listWords(this.identity.id);
    return {
      ...review,
      opportunities: review.opportunities.filter((opportunity) =>
        words.some((word) => word.userWordId === opportunity.userWordId),
      ),
      suggestions: review.suggestions.map((s) => {
        const word = words.find((w) => w.userWordId === s.savedWordId);
        return {
          ...s,
          queued: s.status === "added" && word ? !word.introducedAt : s.queued,
        };
      }),
    };
  }
  async decide(id: string, decision: Suggestion["status"]) {
    const suggestion = await this.repo.getSuggestion(this.identity.id, id);
    if (!suggestion)
      throw new AppError("This suggestion could not be found.", 404);
    const words = await this.repo.listWords(this.identity.id);
    const prior = words.find((w) => w.userWordId === suggestion.savedWordId);
    if (suggestion.status === decision)
      return {
        status: decision,
        userWordId: prior?.userWordId,
        queued: prior ? !prior.introducedAt : false,
        addedWord: false,
      };
    if (suggestion.status === "added" && suggestion.ownsSavedWord && prior) {
      if (
        !(await this.repo.removeUnpracticedWord(
          this.identity.id,
          prior.userWordId,
          `Writing suggestion:${id}`,
        ))
      )
        throw new AppError(
          "This word has entered practice. Its saved word and learning history are preserved; this save can no longer be undone.",
          409,
        );
    }
    let userWordId: string | undefined;
    let queued = false;
    let ownsSavedWord = false;
    if (decision === "added") {
      const existing = words.find(
        (w) => w.word.toLowerCase() === suggestion.word.toLowerCase(),
      );
      if (existing) {
        userWordId = existing.userWordId;
        queued = !existing.introducedAt;
      } else {
        const now = this.now();
        queued =
          words.filter((w) => w.introducedAt?.slice(0, 10) === now.slice(0, 10))
            .length >= this.policy.newPerDay;
        userWordId = await this.repo.addWord(
          this.identity.id,
          { ...suggestion, id: this.ids.next() },
          {
            source: `Writing suggestion:${id}`,
            sourceText: suggestion.source?.sentence ?? suggestion.originalText,
            now,
            introduced: !queued,
          },
        );
        ownsSavedWord = true;
      }
      await this.repo.setProfile(this.identity.id, { onboarded: true });
    }
    await this.repo.saveDecision(this.identity.id, id, {
      status: decision,
      savedWordId: userWordId ?? null,
      queued,
      ownsSavedWord,
    });
    return { status: decision, userWordId, queued, addedWord: ownsSavedWord };
  }
  async addInsight(wordName: string) {
    await this.profile();
    const catalog = CATALOG.find((w) => w.word === wordName);
    if (!catalog)
      throw new AppError(
        "Try exploring this word in a piece of writing first.",
      );
    const now = this.now();
    const words = await this.repo.listWords(this.identity.id);
    const existing = words.find((word) => word.word === wordName);
    if (existing)
      return {
        userWordId: existing.userWordId,
        queued: !existing.introducedAt,
        addedWord: false,
      };
    const introduced =
      words.filter((w) => w.introducedAt?.slice(0, 10) === now.slice(0, 10))
        .length < this.policy.newPerDay;
    const pattern = findInsights(
      await this.repo.listWriting(this.identity.id),
    ).find((item) =>
      item.alternatives.some((alternative) => alternative.word === wordName),
    );
    return {
      userWordId: await this.repo.addWord(this.identity.id, catalog, {
        source: "Your patterns",
        sourceText:
          pattern?.sources?.[0]?.sentence ?? "Chosen from Your patterns",
        now,
        introduced,
      }),
      queued: !introduced,
      addedWord: true,
    };
  }
  async removeWord(id: string) {
    if (!(await this.repo.removeWord(this.identity.id, id, this.now())))
      throw new AppError("That word was not found on your board.", 404);
    return { removed: true };
  }
  async startPractice(wordId?: string, quick = false, quickSessionId?: string, wordIds?: string[]) {
    const profile = await this.profile();
    if (wordIds && (wordId || quick || quickSessionId))
      throw new AppError("Choose one practice source.");
    const requested = wordIds ? new Set(wordIds) : undefined;
    if (requested && (!requested.size || requested.size !== wordIds?.length || requested.size > profile.dailyLimit))
      throw new AppError("Choose a valid set of words to practice.");
    let words = await this.repo.listWords(this.identity.id);
    const now = this.now();
    const queued = introductionQueue(words, this.clock.now(), this.policy);
    await this.repo.introduce(
      this.identity.id,
      queued.map((w) => w.userWordId),
      now,
    );
    words = await this.repo.listWords(this.identity.id);
    let forgotten: UserWord[] | undefined;
    if (quickSessionId) {
      if (quick || wordId) throw new AppError("Choose one practice source.");
      const source = await this.repo.getSession(
        this.identity.id,
        quickSessionId,
      );
      if (
        !source.length ||
        source.some((e) => e.context !== "quick-review" || !e.answeredAt)
      )
        throw new AppError("Complete Quick Review before continuing.", 409);
      forgotten = source
        .flatMap((e) => {
          const w = words.find((w) => w.userWordId === e.userWordId);
          return w?.attempts.some(
            (a) =>
              a.exerciseId === e.id &&
              a.context === "quick-review" &&
              a.answer === "forgot",
          )
            ? [w]
            : [];
        })
        .slice(0, profile.dailyLimit);
      if (!forgotten.length)
        throw new AppError("No forgotten words to practice.", 409);
    }
    const chosen = requested
      ? words.filter((word) => requested.has(word.userWordId) && word.definition.trim())
      : undefined;
    if (chosen && chosen.length !== requested?.size)
      throw new AppError("Some selected words are no longer available. Refresh your WordBoard and try again.", 409);
    const selected =
      forgotten ??
      (wordId
        ? words.filter((w) => w.userWordId === wordId)
        : practiceCandidates(
            chosen ?? words,
            this.clock.now(),
            quick ? 5 : profile.dailyLimit,
          ));
    if (wordId && selected.some((word) => !word.definition.trim()))
      throw new AppError("This word’s definition is still being prepared. Try again shortly.", 409);
    if (selected.some((word) => !word.definition.trim()))
      throw new AppError("A word’s definition is still being prepared. Try again shortly.", 409);
    if (!selected.length)
      throw new AppError(
        wordId
          ? "This word is waiting in your introduction queue. We’ll introduce a few new words each day."
          : "You’re up to date. Your words will be ready when a little time has passed.",
        409,
      );
    const sessionId = this.ids.next();
    const exercises = await Promise.all(
      selected.map(async (word) => {
        const kind = exerciseKind(word);
        const known = CATALOG.find((w) => w.word === word.word);
        const contexts =
          known?.contexts.map((c) => c.domain) ?? CONTEXT_DOMAINS;
        const used = new Set(
          word.attempts.filter((a) => a.precise).map((a) => a.context),
        );
        const context =
          contexts.find((c) => !used.has(c)) ??
          contexts[word.attempts.length % contexts.length];
        const definition = word.definition.trim();
        const targetInDefinition = new RegExp(`\\b${word.word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(definition);
        const content = quick
          ? { prompt: definition, semanticHint: definition }
          : definition && !targetInDefinition
            ? {
                prompt: kind === "strong"
                  ? `Bring to mind a word meaning: ${definition}`
                  : `Describe a situation of your choice where this idea applies: ${definition.replace(/[.!?]+$/, "")}.`,
                semanticHint: definition,
              }
            : await this.llm.generateExercise(word, kind, context);
        return {
          id: this.ids.next(),
          sessionId,
          userWordId: word.userWordId,
          kind,
          context: quick ? "quick-review" : context,
          ...content,
          hint: "none" as const,
          sentencePending: false,
          answeredAt: null,
        };
      }),
    );
    await this.repo.createSession(this.identity.id, exercises, now);
    return {
      sessionId,
      exercise: this.publicExercise(exercises[0], 1, exercises.length),
      total: exercises.length,
    };
  }
  async quickRate(id: string, rating: "got" | "forgot" | "skip") {
    const exercise = await this.repo.getExercise(this.identity.id, id);
    if (!exercise || exercise.answeredAt || exercise.context !== "quick-review")
      throw new AppError("This exercise is no longer open.", 409);
    const word = await this.word(exercise.userWordId);
    const saved = await this.repo.recordAttempt(
      this.identity.id,
      {
        id: this.ids.next(),
        userWordId: word.userWordId,
        exerciseId: id,
        at: this.now(),
        kind: "strong",
        hint: "revealed",
        answer: rating,
        context: "quick-review",
        retrieved: rating === "got",
        precise: false,
        majorMisuse: false,
        feedback: rating,
        spellingCorrection: null,
      },
      word.stage,
      word.nextReviewAt,
    );
    if (!saved)
      throw new AppError("That response has already been saved.", 409);
    return { saved: true, completedActivity: !word.demo && rating !== "skip" };
  }
  private publicExercise(
    e: Exercise,
    position: number,
    total: number,
  ): PublicExercise {
    return {
      id: e.id,
      kind: e.kind,
      prompt: e.prompt,
      hint: e.hint,
      sentencePending: e.sentencePending,
      position,
      total,
    };
  }
  async session(id: string): Promise<PracticeSession> {
    const exercises = await this.repo.getSession(this.identity.id, id);
    if (!exercises.length)
      throw new AppError("That practice session could not be found.", 404);
    const nextIndex = exercises.findIndex((e) => !e.answeredAt);
    const words = await this.repo.listWords(this.identity.id);
    const sessionWords = exercises.flatMap((exercise) => {
      const word = words.find((w) => w.userWordId === exercise.userWordId);
      return word
        ? [
            {
              userWordId: word.userWordId,
              word: word.word,
              ...(exercise.context === "quick-review"
                ? { exerciseId: exercise.id }
                : {}),
            },
          ]
        : [];
    });
    const results: PracticeOutcome[] = exercises.flatMap((exercise) => {
      const word = words.find((w) => w.userWordId === exercise.userWordId);
      const attempt = word?.attempts.find((a) => a.exerciseId === exercise.id);
      if (!word || !attempt) return [];
      const outcome =
        attempt.hint === "revealed" || !attempt.retrieved || attempt.majorMisuse
          ? "reviewed"
          : !attempt.answer
            ? "recalled-skipped"
            : attempt.precise
              ? attempt.hint === "none"
                ? "recalled-used"
                : "hinted-used"
              : "reviewed";
      return [{ userWordId: word.userWordId, word: word.word, outcome }];
    });
    if (nextIndex === -1)
      return {
        complete: true,
        total: exercises.length,
        exercise: null,
        words: sessionWords,
        results,
      };
    const e = exercises[nextIndex];
    const dto = this.publicExercise(e, nextIndex + 1, exercises.length);
    const word = await this.word(e.userWordId);
    dto.definition = word.definition;
    if (e.hint !== "none" || e.sentencePending)
      dto.hintText = e.sentencePending
        ? word.word
        : this.hintText(e.hint, word, e);
    return {
      complete: false,
      total: exercises.length,
      exercise: dto,
      words: sessionWords,
      results,
    };
  }
  private hintText(level: HintLevel, word: UserWord, e: Exercise) {
    return level === "semantic"
      ? e.semanticHint
      : level === "letter"
        ? `It starts with “${word.word[0]}”.`
        : level === "partial"
          ? `${word.word.slice(0, 3)}${"_".repeat(Math.max(0, word.word.length - 3))}`
          : word.word;
  }
  async hint(id: string, level: HintLevel) {
    const e = await this.repo.getExercise(this.identity.id, id);
    if (!e || e.answeredAt)
      throw new AppError("This exercise is no longer open.", 409);
    if (e.sentencePending)
      throw new AppError(
        "Finish the sentence step before requesting another hint.",
        409,
      );
    const levels: HintLevel[] = [
      "none",
      "semantic",
      "letter",
      "partial",
      "revealed",
    ];
    const effective =
      levels[Math.max(levels.indexOf(e.hint), levels.indexOf(level))];
    await this.repo.setHint(this.identity.id, id, effective);
    const actual = (await this.repo.getExercise(this.identity.id, id))!;
    const word = await this.word(e.userWordId);
    return {
      hint: actual.hint,
      hintText: this.hintText(actual.hint, word, e),
      followup:
        actual.hint === "revealed"
          ? `Use “${word.word}” in a sentence of your own. ${word.definition}`
          : null,
    };
  }
  async answer(id: string, answer: string) {
    let exercise = await this.repo.getExercise(this.identity.id, id);
    if (!exercise) throw new AppError("This exercise could not be found.", 404);
    if (exercise.context === "quick-review")
      throw new AppError("Use the quick review rating controls.", 409);
    if (exercise.answeredAt)
      throw new AppError(
        "That response has already been saved. Continue to the next word.",
        409,
      );
    const word = await this.word(exercise.userWordId);
    // V2 starts every word with meaning recall. The stored context is learning
    // ledger metadata; it is never sent to the sentence grader.
    const recalling = !exercise.sentencePending && exercise.hint !== "revealed";
    if (!recalling && answer.trim().split(/\s+/).length < 4)
      return {
        evaluation: {
          retrieved: false, precise: false, majorMisuse: false, validAlternative: false,
          spellingCorrection: null, feedback: "Use the shown word in a complete, natural sentence that shows its meaning.", nuance: "",
        },
        retry: true, stage: word.stage, moved: false, target: word.word,
        revealed: exercise.hint === "revealed", sentencePending: exercise.sentencePending,
      };
    // Exact recall needs no model judgment. Save the transition through the
    // normal repository path while keeping open-ended sentence evaluation.
    const exactRecall = recalling && answer.trim().replace(/\s+/g, " ").toLocaleLowerCase("en") === word.word.trim().replace(/\s+/g, " ").toLocaleLowerCase("en");
    const evaluation = exactRecall
      ? { retrieved: true, precise: false, majorMisuse: false, validAlternative: false, spellingCorrection: null, feedback: "Correct!", nuance: "" }
      : await this.llm.evaluateRecall(
          word,
          recalling ? { ...exercise, kind: "strong" } : exercise,
          answer,
        );
    if (
      evaluation.validAlternative &&
      !evaluation.retrieved &&
      !exercise.sentencePending &&
      exercise.hint !== "revealed"
    )
      return {
        evaluation,
        retry: true,
        stage: word.stage,
        moved: false,
        target: null,
      };
    if (
      !evaluation.retrieved &&
      !exercise.sentencePending &&
      exercise.hint !== "revealed"
    ) {
      return {
        evaluation,
        retry: true,
        stage: word.stage,
        moved: false,
        target: null,
        incorrect: true,
      };
    }
    if (
      evaluation.retrieved &&
      !exercise.sentencePending &&
      exercise.hint !== "revealed"
    ) {
      if (!(await this.repo.setSentencePending(this.identity.id, id)))
        throw new AppError("This exercise is no longer open.", 409);
      return {
        evaluation: {
          ...evaluation,
          feedback:
            "You found the word. Now use it in a complete sentence to finish this step.",
        },
        retry: true,
        stage: word.stage,
        moved: false,
        target: word.word,
        sentencePending: true,
      };
    }
    if (
      (exercise.hint === "revealed" || exercise.sentencePending) &&
      (!evaluation.precise || answer.trim().split(/\s+/).length < 4)
    ) {
      return {
        evaluation: {
          ...evaluation,
          feedback: evaluation.retrieved
            ? "The word is right, but this step needs a complete sentence that shows its meaning."
            : "Use the shown word in a complete, natural sentence that shows its meaning.",
        },
        retry: true,
        stage: word.stage,
        moved: false,
        target: word.word,
        revealed: exercise.hint === "revealed",
        sentencePending: exercise.sentencePending,
      };
    }
    // Re-read the authoritative hint after the LLM call; browser input cannot set credit.
    exercise = (await this.repo.getExercise(this.identity.id, id))!;
    const attempt: Attempt = {
      id: this.ids.next(),
      userWordId: word.userWordId,
      exerciseId: id,
      at: this.now(),
      kind: exercise.kind,
      hint: exercise.hint,
      answer,
      context: exercise.context,
      ...evaluation,
      retrieved: evaluation.retrieved && exercise.hint !== "revealed",
    };
    const history = [...word.attempts, attempt];
    const stage = progress(word.stage, history, this.policy);
    const saved = await this.repo.recordAttempt(
      this.identity.id,
      attempt,
      stage,
      practiceReviewDate(word, stage, history, this.clock.now(), this.policy),
    );
    if (!saved)
      throw new AppError("That response has already been saved.", 409);
    return {
      evaluation,
      retry: false,
      stage,
      moved: stage !== word.stage,
      target: word.word,
      revealed: exercise.hint === "revealed",
      sentencePending: exercise.sentencePending,
      evidence: evidence(history, this.policy),
      completedActivity: !word.demo,
    };
  }
  async skip(id: string) {
    const exercise = await this.repo.getExercise(this.identity.id, id);
    if (!exercise || exercise.answeredAt)
      throw new AppError("This exercise is no longer open.", 409);
    if (!exercise.sentencePending && exercise.hint !== "revealed")
      throw new AppError(
        "You can skip the sentence after recalling or being shown the word.",
        409,
      );
    const word = await this.word(exercise.userWordId);
    const feedback = "You can practice this word again when it is due.";
    const attempt: Attempt = {
      id: this.ids.next(),
      userWordId: word.userWordId,
      exerciseId: id,
      at: this.now(),
      kind: exercise.kind,
      hint: exercise.hint,
      answer: "",
      context: exercise.context,
      retrieved: exercise.sentencePending && exercise.hint !== "revealed",
      precise: false,
      majorMisuse: false,
      feedback,
      spellingCorrection: null,
    };
    const history = [...word.attempts, attempt];
    const stage = progress(word.stage, history, this.policy);
    const saved = await this.repo.recordAttempt(
      this.identity.id,
      attempt,
      stage,
      practiceReviewDate(word, stage, history, this.clock.now(), this.policy),
    );
    if (!saved)
      throw new AppError("That response has already been saved.", 409);
    return {
      evaluation: {
        retrieved: attempt.retrieved,
        precise: false,
        majorMisuse: false,
        validAlternative: false,
        spellingCorrection: null,
        feedback,
        nuance: "",
      },
      retry: false,
      skipped: true,
      completedActivity: !word.demo && attempt.retrieved,
      stage,
      moved: stage !== word.stage,
      target: word.word,
      revealed: exercise.hint === "revealed",
      sentencePending: exercise.sentencePending,
    };
  }
  async settings(changes: { name?: string; dailyLimit?: number }) {
    await this.repo.setProfile(this.identity.id, changes);
    return { saved: true };
  }
  async seed() {
    await this.profile();
    const existing = await this.repo.listWords(this.identity.id);
    if (existing.some((w) => w.demo)) return { seeded: false };
    const now = this.clock.now();
    for (let i = 0; i < Math.min(CATALOG.length, 9); i++) {
      const word = CATALOG[i];
      if (existing.some((w) => w.word === word.word)) continue;
      const stage = i < 3 ? "new" : i < 6 ? "practicing" : "active";
      const addedAt = new Date(
        now.getTime() - (i < 3 ? 1 : 18) * DAY,
      ).toISOString();
      const userWordId = await this.repo.addWord(this.identity.id, word, {
        source: "Sample collection",
        sourceText: word.examples[0],
        now: addedAt,
        introduced: true,
        demo: true,
        stage,
        nextReviewAt: new Date(
          now.getTime() + (i < 6 ? -DAY : 7 * DAY),
        ).toISOString(),
      });
      const count = stage === "new" ? 0 : stage === "practicing" ? 2 : 5;
      for (let j = 0; j < count; j++) {
        const at = new Date(now.getTime() - (16 - j * 3) * DAY).toISOString();
        const attempt: Attempt = {
          id: this.ids.next(),
          userWordId,
          exerciseId: `seed:${userWordId}:${j}`,
          at,
          kind: j === 4 ? "open" : "completion",
          hint: "none",
          answer: word.contexts[j % 3].sentence.replace("____", word.word),
          retrieved: true,
          precise: true,
          majorMisuse: false,
          context: word.contexts[j % 3].domain,
          feedback: "Illustrative practice history from the sample collection.",
          spellingCorrection: null,
        };
        await this.repo.recordAttempt(
          this.identity.id,
          attempt,
          stage,
          new Date(
            now.getTime() + (stage === "active" ? 7 * DAY : -DAY),
          ).toISOString(),
        );
      }
    }
    await this.repo.setProfile(this.identity.id, { onboarded: true });
    return { seeded: true };
  }
  async clearDemo() {
    await this.repo.removeDemo(this.identity.id);
    return { removed: true };
  }
}
