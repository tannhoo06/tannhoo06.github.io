import type { Clock } from "../domain/types";
import { learningDay, summarizeStreak } from "../domain/learning-streak";

type ActivityDays = {
  insertActivityDay(userId: string, day: string): Promise<boolean>;
  listActivityDays(userId: string): Promise<{ day: string }[]>;
};

export class LearningStreakService {
  constructor(private readonly days: ActivityDays, private readonly userId: string, private readonly clock: Clock) {}

  async current() {
    const day = learningDay(this.clock.now());
    return summarizeStreak(await this.days.listActivityDays(this.userId), day);
  }

  async complete() {
    const day = learningDay(this.clock.now());
    if (!await this.days.insertActivityDay(this.userId, day)) return null;
    return summarizeStreak(await this.days.listActivityDays(this.userId), day);
  }
}
