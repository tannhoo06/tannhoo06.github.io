import type { Insight } from "../domain/types";
const defaults: {
  phrase: string;
  pattern: RegExp;
  alternatives: Insight["alternatives"];
}[] = [
  {
    phrase: "important",
    pattern: /\bimportant\b/gi,
    alternatives: [
      { word: "crucial", meaning: "Necessary for a particular outcome." },
      {
        word: "pivotal",
        meaning: "Important because it changes what happens next.",
      },
      { word: "significant", meaning: "Meaningful or large enough to matter." },
      {
        word: "paramount",
        meaning: "More important than everything else in that situation.",
      },
    ],
  },
  {
    phrase: "very big",
    pattern: /\bvery (?:big|large)\b/gi,
    alternatives: [
      {
        word: "substantial",
        meaning: "Large in amount or importance: a substantial investment.",
      },
    ],
  },
  {
    phrase: "very small",
    pattern: /\bvery small\b/gi,
    alternatives: [
      {
        word: "negligible",
        meaning:
          "Too small to make a practical difference, not simply small in size.",
      },
    ],
  },
  {
    phrase: "interesting",
    pattern: /\binteresting\b/gi,
    alternatives: [
      {
        word: "compelling",
        meaning: "Persuasive or strong enough to hold attention.",
      },
    ],
  },
];
export function findInsights(
  samples: { id?: string; text: string }[],
): Insight[] {
  return defaults
    .map((d) => ({
      phrase: d.phrase,
      count: samples.reduce(
        (n, s) => n + (s.text.match(d.pattern)?.length ?? 0),
        0,
      ),
      alternatives: d.alternatives,
      sources: samples
        .flatMap((sample) =>
          Array.from(sample.text.matchAll(new RegExp(d.pattern))).map(
            (match) => {
              const start = match.index!;
              const end = start + match[0].length;
              const before = sample.text.slice(0, start);
              const sentenceStart =
                Math.max(
                  before.lastIndexOf("."),
                  before.lastIndexOf("!"),
                  before.lastIndexOf("?"),
                  before.lastIndexOf("\n"),
                ) + 1;
              const after = sample.text.slice(end).search(/[.!?\n]/);
              const sentenceEnd =
                after < 0 ? sample.text.length : end + after + 1;
              return {
                sampleId: sample.id,
                sentence: sample.text.slice(sentenceStart, sentenceEnd).trim(),
                text: sample.text,
                start,
                end,
              };
            },
          ),
        )
        .slice(0, 5),
    }))
    .filter((i) => i.count > 0)
    .sort((a, b) => b.count - a.count);
}
