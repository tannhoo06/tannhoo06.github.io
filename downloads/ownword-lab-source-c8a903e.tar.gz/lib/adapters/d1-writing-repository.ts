import { SQLiteAsyncDialect } from "drizzle-orm/sqlite-core";
import { sql, type SQL } from "drizzle-orm";
import type { getDb } from "@/db";
import { SqlWritingRepository } from "./writing-repository";

export class D1WritingRepository extends SqlWritingRepository {
  constructor(db: ReturnType<typeof getDb>) {
    const dialect = new SQLiteAsyncDialect();
    const prepare = (statement: SQL) => {
      const query = dialect.sqlToQuery(statement);
      return db.$client.prepare(query.sql).bind(...query.params);
    };
    super({
      concatHistoryEntries: sql`group_concat(entry, ',')`,
      textValues: (json) => sql`select value from json_each(${json})`,
      async read(query) {
        return (await prepare(query).all<Record<string, unknown>>()).results;
      },
      async write(_userId, statements) {
        const results = await db.$client.batch<Record<string, unknown>>(statements.map(prepare));
        return results.map(({ results }) => results);
      },
    });
  }
}
