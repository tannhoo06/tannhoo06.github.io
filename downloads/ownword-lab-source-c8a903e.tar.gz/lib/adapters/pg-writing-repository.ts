import { sql } from "drizzle-orm";
import type { getPgDb } from "@/db/pg";
import { SqlWritingRepository } from "./writing-repository";

export class PgWritingRepository extends SqlWritingRepository {
  constructor(db: ReturnType<typeof getPgDb>) {
    super({
      concatHistoryEntries: sql`string_agg(entry, ',' order by entry collate "C")`,
      textValues: (json) => sql`select jsonb_array_elements_text(${json}::jsonb)`,
      async read(query) {
        return (await db.execute(query)).rows;
      },
      write(userId, statements) {
        return db.transaction(async (tx) => {
          await tx.execute(sql`select id from app_user where id = ${userId} for update`);
          const results = [];
          for (const statement of statements) results.push((await tx.execute(statement)).rows);
          return results;
        });
      },
    });
  }
}
