import { getChatGPTUser } from "@/app/chatgpt-auth";
import type { AuthProvider } from "../domain/ports";
export const sitesAuth: AuthProvider = {
  async currentIdentity() {
    const user = await getChatGPTUser();
    return user
      ? {
          id: user.userId,
          name: user.fullName ?? "My space",
          email: user.email,
        }
      : null;
  },
};
