import { sql } from "drizzle-orm";
import type { getDb } from "@/db";
import { llmKeyRotation } from "@/db/schema";
import type { KeyRotationStore } from "../llm/key-pool";

export class D1KeyRotationStore implements KeyRotationStore {
  constructor(private readonly db: ReturnType<typeof getDb>) {}

  async reserve(poolId: string, size: number): Promise<number> {
    if (!Number.isSafeInteger(size) || size < 2)
      throw new Error("Invalid key pool size.");
    // One write + RETURNING avoids read/modify/write races across Worker instances.
    const [row] = await this.db
      .insert(llmKeyRotation)
      .values({ id: poolId, position: 0 })
      .onConflictDoUpdate({
        target: llmKeyRotation.id,
        set: { position: sql`(${llmKeyRotation.position} + 1) % ${size}` },
      })
      .returning({ position: llmKeyRotation.position });
    if (!row)
      throw new Error("The language service key selector is unavailable.");
    return row.position;
  }
}
