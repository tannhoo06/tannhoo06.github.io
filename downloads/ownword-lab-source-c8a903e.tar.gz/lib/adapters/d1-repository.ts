import { and, desc, eq, inArray, isNull, lt, sql } from "drizzle-orm";
import type { getDb } from "@/db";
import * as s from "@/db/schema";
import type { Repository } from "../domain/ports";
import type {
  Attempt,
  ConceptDiscovery,
  Exercise,
  Identity,
  Insight,
  Lexeme,
  Suggestion,
  UserWord,
  WritingAnalysis,
  WritingReview,
  WordCheck,
} from "../domain/types";

// The only database-specific repository. Domain/services never import D1 or Drizzle.
export class D1Repository implements Repository {
  constructor(
    private db: ReturnType<typeof getDb>,
    private id: () => string,
  ) {}
  async insertActivityDay(userId: string, day: string) {
    const rows = await this.db.insert(s.learningActivityDays).values({ userId, day })
      .onConflictDoNothing().returning({ day: s.learningActivityDays.day });
    return rows.length > 0;
  }
  async listActivityDays(userId: string) {
    return this.db.select({ day: s.learningActivityDays.day }).from(s.learningActivityDays)
      .where(eq(s.learningActivityDays.userId, userId)).orderBy(desc(s.learningActivityDays.day));
  }
  async ensureUser(identity: Identity, now: string) {
    // V2 defaults apply only to new profiles; never rewrite existing preferences.
    await this.db
      .insert(s.users)
      .values({
        id: identity.id,
        name: identity.name,
        createdAt: now,
        dailyLimit: 7,
      })
      .onConflictDoNothing();
    return (
      await this.db.select().from(s.users).where(eq(s.users.id, identity.id))
    )[0];
  }
  async setProfile(
    userId: string,
    changes: { dailyLimit?: number; onboarded?: boolean; name?: string },
  ) {
    await this.db.update(s.users).set(changes).where(eq(s.users.id, userId));
  }
  async getManualWordCheck(userId: string, word: string, after: string): Promise<WordCheck | null> {
    const [row] = await this.db.select().from(s.manualWordChecks)
      .where(and(eq(s.manualWordChecks.userId, userId), eq(s.manualWordChecks.word, word), sql`${s.manualWordChecks.checkedAt} >= ${after}`)).limit(1);
    return row ? { status: row.status, suggestion: row.suggestion } : null;
  }
  async saveManualWordCheck(userId: string, word: string, check: WordCheck, now: string) {
    await this.db.insert(s.manualWordChecks)
      .values({ userId, word, status: check.status, suggestion: check.suggestion, checkedAt: now })
      .onConflictDoUpdate({ target: [s.manualWordChecks.userId, s.manualWordChecks.word], set: { status: check.status, suggestion: check.suggestion, checkedAt: now } });
  }
  async enrichWord(word: Lexeme) {
    await this.db.update(s.words).set({
      partOfSpeech: word.partOfSpeech,
      definition: word.definition,
      nuance: word.nuance,
      collocations: word.collocations,
      examples: word.examples,
    }).where(and(eq(s.words.word, word.word.trim().toLowerCase()), eq(s.words.definition, "")));
  }
  async saveConceptDiscovery(userId: string, discovery: ConceptDiscovery) {
    await this.db.insert(s.conceptDiscoveries).values({ ...discovery, userId });
  }
  async getConceptDiscovery(userId: string, id: string): Promise<ConceptDiscovery | null> {
    const [row] = await this.db.select().from(s.conceptDiscoveries)
      .where(and(eq(s.conceptDiscoveries.userId, userId), eq(s.conceptDiscoveries.id, id))).limit(1);
    return row ? { id: row.id, concept: row.concept, candidates: row.candidates, createdAt: row.createdAt } : null;
  }
  async latestConceptDiscovery(userId: string): Promise<ConceptDiscovery | null> {
    const [row] = await this.db.select().from(s.conceptDiscoveries)
      .where(eq(s.conceptDiscoveries.userId, userId))
      .orderBy(desc(s.conceptDiscoveries.createdAt), desc(s.conceptDiscoveries.id)).limit(1);
    return row ? { id: row.id, concept: row.concept, candidates: row.candidates, createdAt: row.createdAt } : null;
  }
  async recentConceptDiscovery(userId: string, concept: string, after: string): Promise<ConceptDiscovery | null> {
    const normalized = concept.trim().replace(/\s+/g, " ").toLocaleLowerCase();
    const rows = await this.db.select().from(s.conceptDiscoveries)
      .where(and(eq(s.conceptDiscoveries.userId, userId), sql`${s.conceptDiscoveries.createdAt} >= ${after}`))
      .orderBy(desc(s.conceptDiscoveries.createdAt)).limit(30);
    const row = rows.find((item) => item.concept.trim().replace(/\s+/g, " ").toLocaleLowerCase() === normalized);
    return row ? { id: row.id, concept: row.concept, candidates: row.candidates, createdAt: row.createdAt } : null;
  }
  async saveConceptCandidateTranslation(userId: string, discoveryId: string, candidateId: string, meaning: string) {
    const discovery = await this.getConceptDiscovery(userId, discoveryId);
    if (!discovery) return;
    const index = discovery.candidates.findIndex((item) => item.id === candidateId);
    if (index < 0) return;
    await this.db.update(s.conceptDiscoveries)
      .set({ candidates: sql`json_set(${s.conceptDiscoveries.candidates}, ${`$[${index}].vietnameseMeaning`}, ${meaning})` })
      .where(and(eq(s.conceptDiscoveries.userId, userId), eq(s.conceptDiscoveries.id, discoveryId)));
  }
  async listWords(userId: string): Promise<UserWord[]> {
    const [rows, history] = await Promise.all([
      this.db
        .select({ entry: s.userWords, word: s.words })
        .from(s.userWords)
        .innerJoin(s.words, eq(s.userWords.wordId, s.words.id))
        .where(
          and(eq(s.userWords.userId, userId), isNull(s.userWords.removedAt)),
        ),
      this.db
        .select()
        .from(s.attempts)
        .where(eq(s.attempts.userId, userId))
        .orderBy(s.attempts.at),
    ]);
    return rows.map(({ entry, word }) => ({
      ...word,
      ...entry,
      ...(entry.lexemeOverride ?? {}),
      id: word.id,
      userWordId: entry.id,
      attempts: history.filter((a) => a.userWordId === entry.id) as Attempt[],
    }));
  }
  async addWord(
    userId: string,
    word: Lexeme,
    options: {
      source: string;
      sourceText: string;
      now: string;
      introduced: boolean;
      demo?: boolean;
      stage?: UserWord["stage"];
      nextReviewAt?: string;
    },
  ) {
    const canonical = word.word.toLowerCase().trim();
    await this.db
      .insert(s.words)
      .values({ ...word, word: canonical })
      .onConflictDoNothing();
    const stored = (
      await this.db.select().from(s.words).where(eq(s.words.word, canonical))
    )[0];
    await this.db
      .insert(s.userWords)
      .values({
        id: this.id(),
        userId,
        wordId: stored.id,
        stage: options.stage ?? "new",
        addedAt: options.now,
        introducedAt: options.introduced ? options.now : null,
        nextReviewAt: options.nextReviewAt ?? options.now,
        source: options.source,
        sourceText: options.sourceText,
        lexemeOverride: options.source === "Concept" ? { partOfSpeech: word.partOfSpeech, definition: word.definition, nuance: word.nuance, collocations: word.collocations, examples: word.examples } : null,
        demo: options.demo ?? false,
      })
      .onConflictDoUpdate({
        target: [s.userWords.userId, s.userWords.wordId],
        set: {
          removedAt: null,
          source: options.source,
          sourceText: options.sourceText,
          lexemeOverride: options.source === "Concept" ? { partOfSpeech: word.partOfSpeech, definition: word.definition, nuance: word.nuance, collocations: word.collocations, examples: word.examples } : null,
          demo: options.demo ?? false,
        },
      });
    return (
      await this.db
        .select()
        .from(s.userWords)
        .where(
          and(
            eq(s.userWords.userId, userId),
            eq(s.userWords.wordId, stored.id),
          ),
        )
    )[0].id;
  }
  async introduce(userId: string, wordIds: string[], now: string) {
    if (wordIds.length)
      await this.db
        .update(s.userWords)
        .set({ introducedAt: now, nextReviewAt: now })
        .where(
          and(eq(s.userWords.userId, userId), inArray(s.userWords.id, wordIds)),
        );
  }
  async saveWriting(userId: string, text: string, prompt: string, now: string) {
    const id = this.id();
    await this.db
      .insert(s.writingSamples)
      .values({ id, userId, text, prompt, createdAt: now });
    return id;
  }
  async listWriting(userId: string) {
    return this.db
      .select({
        id: s.writingSamples.id,
        text: s.writingSamples.text,
        createdAt: s.writingSamples.createdAt,
      })
      .from(s.writingSamples)
      .where(eq(s.writingSamples.userId, userId))
      .orderBy(s.writingSamples.createdAt);
  }
  async saveSuggestions(
    userId: string,
    sampleId: string,
    suggestions: WritingAnalysis["suggestions"],
  ): Promise<Suggestion[]> {
    const rows = suggestions.map((x) => ({
      ...x,
      id: this.id(),
      userId,
      sampleId,
      status: "pending" as const,
    }));
    if (rows.length) await this.db.insert(s.suggestions).values(rows);
    return rows;
  }
  async getSuggestion(userId: string, id: string) {
    return (
      (
        await this.db
          .select()
          .from(s.suggestions)
          .where(
            and(eq(s.suggestions.userId, userId), eq(s.suggestions.id, id)),
          )
      )[0] ?? null
    );
  }
  async saveReview(userId: string, review: WritingReview) {
    await this.db
      .insert(s.writingReviews)
      .values({ userId, sampleId: review.sampleId, review });
  }
  async getReview(userId: string, sampleId: string) {
    const row = (
      await this.db
        .select()
        .from(s.writingReviews)
        .where(
          and(
            eq(s.writingReviews.userId, userId),
            eq(s.writingReviews.sampleId, sampleId),
          ),
        )
    )[0];
    if (!row) return null;
    const suggestions = await this.db
      .select()
      .from(s.suggestions)
      .where(
        and(
          eq(s.suggestions.userId, userId),
          eq(s.suggestions.sampleId, sampleId),
        ),
      );
    return { ...row.review, suggestions };
  }
  async recentWritingReview(userId: string, text: string, prompt: string, signature: string, after: string): Promise<WritingReview | null> {
    const rows = await this.db.select({ sample: s.writingSamples, review: s.writingReviews.review })
      .from(s.writingSamples)
      .innerJoin(s.writingReviews, eq(s.writingSamples.id, s.writingReviews.sampleId))
      .where(and(eq(s.writingSamples.userId, userId), eq(s.writingSamples.text, text), eq(s.writingSamples.prompt, prompt), sql`${s.writingSamples.createdAt} >= ${after}`))
      .orderBy(desc(s.writingSamples.createdAt)).limit(5);
    const row = rows.find((item) => item.review.analysisSignature === signature);
    return row ? this.getReview(userId, row.sample.id) : null;
  }
  async saveDecision(
    userId: string,
    id: string,
    decision: Pick<
      Suggestion,
      "status" | "savedWordId" | "queued" | "ownsSavedWord"
    >,
  ) {
    await this.db
      .update(s.suggestions)
      .set(decision)
      .where(and(eq(s.suggestions.userId, userId), eq(s.suggestions.id, id)));
  }
  async removeUnpracticedWord(userId: string, id: string, source: string) {
    // One conditional SQL statement protects history even if a practice request races Undo.
    const removed = await this.db
      .delete(s.userWords)
      .where(
        and(
          eq(s.userWords.userId, userId),
          eq(s.userWords.id, id),
          eq(s.userWords.source, source),
          isNull(s.userWords.removedAt),
          sql`not exists(select 1 from practice_attempt where user_word_id = ${id})`,
          sql`not exists(select 1 from exercise where user_word_id = ${id})`,
        ),
      )
      .returning({ id: s.userWords.id });
    return removed.length > 0;
  }
  async removeWord(userId: string, id: string, now: string) {
    const results = await this.db.batch([
      this.db
        .update(s.userWords)
        .set({ removedAt: now })
        .where(
          and(
            eq(s.userWords.userId, userId),
            eq(s.userWords.id, id),
            isNull(s.userWords.removedAt),
          ),
        )
        .returning({ id: s.userWords.id }),
      this.db
        .update(s.suggestions)
        .set({
          status: "pending",
          savedWordId: null,
          queued: null,
          ownsSavedWord: null,
        })
        .where(
          and(
            eq(s.suggestions.userId, userId),
            eq(s.suggestions.savedWordId, id),
          ),
        ),
    ]);
    return results[0].length > 0;
  }
  async decideSuggestion(
    userId: string,
    id: string,
    decision: Suggestion["status"],
  ) {
    await this.db
      .update(s.suggestions)
      .set({ status: decision })
      .where(and(eq(s.suggestions.userId, userId), eq(s.suggestions.id, id)));
  }
  async saveInsights(userId: string, items: Insight[], now: string) {
    for (const item of items)
      await this.db
        .insert(s.insights)
        .values({ ...item, id: this.id(), userId, updatedAt: now })
        .onConflictDoUpdate({
          target: [s.insights.userId, s.insights.phrase],
          set: {
            count: item.count,
            updatedAt: now,
            alternatives: item.alternatives,
          },
        });
  }
  async createSession(userId: string, exercises: Exercise[], now: string) {
    const id = exercises[0]?.sessionId ?? this.id();
    if (!exercises.length) {
      await this.db.insert(s.sessions).values({ id, userId, createdAt: now });
      return id;
    }
    // D1 limits bound variables per statement. Keep multiword sessions below it.
    const inserts = [];
    for (let offset = 0; offset < exercises.length; offset += 6)
      inserts.push(
        this.db.insert(s.exercises).values(
          exercises.slice(offset, offset + 6).map((e, index) => ({
            ...e,
            userId,
            position: offset + index,
          })),
        ),
      );
    await this.db.batch([
      this.db.insert(s.sessions).values({ id, userId, createdAt: now }),
      ...inserts,
    ]);
    return id;
  }
  async getExercise(userId: string, id: string) {
    return (
      ((
        await this.db
          .select()
          .from(s.exercises)
          .innerJoin(s.userWords, eq(s.exercises.userWordId, s.userWords.id))
          .where(
            and(
              eq(s.exercises.userId, userId),
              eq(s.exercises.id, id),
              isNull(s.userWords.removedAt),
            ),
          )
      )[0]?.exercise as Exercise | undefined) ?? null
    );
  }
  async getSession(userId: string, sessionId: string) {
    return (
      await this.db
        .select({ exercise: s.exercises })
        .from(s.exercises)
        .innerJoin(s.userWords, eq(s.exercises.userWordId, s.userWords.id))
        .where(
          and(
            eq(s.exercises.userId, userId),
            eq(s.exercises.sessionId, sessionId),
            isNull(s.userWords.removedAt),
          ),
        )
        .orderBy(s.exercises.position)
    ).map((row) => row.exercise) as Exercise[];
  }
  async setHint(userId: string, exerciseId: string, hint: Exercise["hint"]) {
    const levels = ["none", "semantic", "letter", "partial", "revealed"];
    // Never let concurrent or repeated requests lower the stored hint level.
    await this.db
      .update(s.exercises)
      .set({ hint })
      .where(
        and(
          eq(s.exercises.userId, userId),
          eq(s.exercises.id, exerciseId),
          inArray(s.exercises.hint, levels.slice(0, levels.indexOf(hint) + 1)),
        ),
      );
  }
  async setSentencePending(userId: string, exerciseId: string) {
    const updated = await this.db
      .update(s.exercises)
      .set({ sentencePending: true })
      .where(
        and(
          eq(s.exercises.userId, userId),
          eq(s.exercises.id, exerciseId),
          isNull(s.exercises.answeredAt),
        ),
      )
      .returning({ id: s.exercises.id });
    return updated.length > 0;
  }
  async recordAttempt(
    userId: string,
    attempt: Attempt,
    stage: UserWord["stage"],
    nextReviewAt: string,
  ) {
    const inserted = sql`exists(select 1 from practice_attempt where id = ${attempt.id})`;
    const results = await this.db.batch([
      this.db
        .insert(s.attempts)
        .values({ ...attempt, userId })
        .onConflictDoNothing()
        .returning({ id: s.attempts.id }),
      this.db
        .update(s.userWords)
        .set({ stage, nextReviewAt })
        .where(
          and(
            eq(s.userWords.userId, userId),
            eq(s.userWords.id, attempt.userWordId),
            inserted,
          ),
        ),
      this.db
        .update(s.exercises)
        .set({ answeredAt: attempt.at })
        .where(
          and(
            eq(s.exercises.userId, userId),
            eq(s.exercises.id, attempt.exerciseId),
            inserted,
          ),
        ),
    ]);
    return results[0].length > 0;
  }
  async removeDemo(userId: string) {
    const demo = await this.db
      .select({ id: s.userWords.id })
      .from(s.userWords)
      .where(
        and(
          eq(s.userWords.userId, userId),
          eq(s.userWords.demo, true),
          isNull(s.userWords.removedAt),
        ),
      );
    const ids = demo.map((x) => x.id);
    if (!ids.length) return;
    await this.db.batch([
      this.db
        .delete(s.attempts)
        .where(
          and(
            eq(s.attempts.userId, userId),
            inArray(s.attempts.userWordId, ids),
          ),
        ),
      this.db
        .delete(s.exercises)
        .where(
          and(
            eq(s.exercises.userId, userId),
            inArray(s.exercises.userWordId, ids),
          ),
        ),
      this.db
        .delete(s.userWords)
        .where(
          and(eq(s.userWords.userId, userId), inArray(s.userWords.id, ids)),
        ),
    ]);
  }
  async consumeRateLimit(userId: string, now: string, maximum: number) {
    const id = `${userId}:${now.slice(0, 13)}`;
    const rows = await this.db
      .insert(s.rateLimits)
      .values({ id, count: 1 })
      .onConflictDoUpdate({
        target: s.rateLimits.id,
        set: { count: sql`${s.rateLimits.count} + 1` },
      })
      .returning({ count: s.rateLimits.count });
    return rows[0].count <= maximum;
  }
  async discoveryCount(userId: string, day: string, kind: "concept" | "writing") {
    const id = `discovery:${userId}:${day}:${kind}`;
    const rows = await this.db.select({ count: s.rateLimits.count }).from(s.rateLimits).where(eq(s.rateLimits.id, id));
    return rows[0]?.count ?? 0;
  }
  async consumeDiscovery(userId: string, day: string, kind: "concept" | "writing", maximum: number) {
    const id = `discovery:${userId}:${day}:${kind}`;
    const rows = await this.db.insert(s.rateLimits).values({ id, count: 1 }).onConflictDoUpdate({
      target: s.rateLimits.id,
      set: { count: sql`${s.rateLimits.count} + 1` },
      setWhere: lt(s.rateLimits.count, maximum),
    }).returning({ count: s.rateLimits.count });
    return rows.length === 1;
  }
}
