import { sql } from "drizzle-orm";
import type { getDb } from "@/db";
import { rateLimits } from "@/db/schema";
import type { LlmCallBudget } from "../llm/call-budget";

export class D1DailyLlmBudget implements LlmCallBudget {
  constructor(
    private readonly db: ReturnType<typeof getDb>,
    private readonly limit: number,
    private readonly now: () => Date = () => new Date(),
  ) {}
  async take(): Promise<boolean> {
    const id = "llm:global:" + this.now().toISOString().slice(0, 10);
    const [row] = await this.db
      .insert(rateLimits)
      .values({ id, count: 1 })
      .onConflictDoUpdate({
        target: rateLimits.id,
        set: { count: sql`${rateLimits.count} + 1` },
      })
      .returning({ count: rateLimits.count });
    return !!row && row.count <= this.limit;
  }
}
