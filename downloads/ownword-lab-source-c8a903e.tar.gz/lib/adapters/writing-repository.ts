import { sql, type SQL } from "drizzle-orm";
import type { DiagnosticReport } from "../writing/contracts";
import { WRITING_FOCUS_PIN_LIMIT, WRITING_FOCUS_RETURNED_PREFIX, type WritingFocusAction, type WritingFocusState, type WritingFocusStatus } from "../writing/focus";
import type {
  WritingRepository,
  WritingHistoryItem,
  SavedRevisionCheck,
  WritingFocusPrune,
  WritingRevisionSummary,
  WritingRun,
  WritingSubmission,
  WritingTask,
  WritingTaskSnapshot,
} from "../writing/persistence";
import type { WritingRevisionCheck } from "../writing/revision-check";

type Row = Record<string, unknown>;

export interface WritingDatabase {
  read(query: SQL): Promise<Row[]>;
  // Every statement runs atomically. PostgreSQL also holds the same owner lock
  // for every mutation, while D1 batches serialize writes.
  write(userId: string, statements: SQL[]): Promise<Row[][]>;
  concatHistoryEntries: SQL;
  textValues(json: string): SQL;
}

const taskColumns = sql.raw(`
  id, prompt_id as "promptId", prompt_version as "promptVersion", snapshot, created_at as "createdAt"
`);
const submissionColumns = sql.raw(`
  id, task_id as "taskId", parent_submission_id as "parentSubmissionId", text,
  word_count as "wordCount", assistance, created_at as "createdAt"
`);
const runColumns = sql.raw(`
  id, submission_id as "submissionId", status, quota_day as "quotaDay",
  lease_expires_at as "leaseExpiresAt", started_at as "startedAt", finished_at as "finishedAt", report
`);

function decodeTask(row: Row): WritingTask {
  const task = row as unknown as WritingTask;
  return { ...task, snapshot: typeof row.snapshot === "string" ? JSON.parse(row.snapshot) : task.snapshot };
}

function decodeRun(row: Row): WritingRun {
  const run = row as unknown as WritingRun;
  return { ...run, report: typeof row.report === "string" ? JSON.parse(row.report) : run.report };
}

function decodeSubmissionRecord(row: Row) {
  const { id, taskId, parentSubmissionId, text, wordCount, assistance, createdAt } = row as unknown as WritingSubmission;
  return {
    submission: { id, taskId, parentSubmissionId, text, wordCount, assistance, createdAt },
    task: decodeTask({ id: taskId, promptId: row.promptId, promptVersion: row.promptVersion,
      snapshot: row.snapshot, createdAt: row.taskCreatedAt }),
    run: row.runId === null ? null : decodeRun({ id: row.runId, submissionId: id, status: row.status,
      quotaDay: row.quotaDay, leaseExpiresAt: row.leaseExpiresAt, startedAt: row.startedAt,
      finishedAt: row.finishedAt, report: row.report }),
  };
}

const profileColumns = sql`source.id, source.task_id as "taskId", source.parent_submission_id as "parentSubmissionId",
  source.text, source.word_count as "wordCount", source.assistance, source.created_at as "createdAt",
  task.prompt_id as "promptId", task.prompt_version as "promptVersion", task.snapshot, task.created_at as "taskCreatedAt",
  run.id as "runId", run.status, run.quota_day as "quotaDay", run.lease_expires_at as "leaseExpiresAt",
  run.started_at as "startedAt", run.finished_at as "finishedAt", run.report`;

const submissionWithRun = sql`from writing_submission as source
  join writing_task as task on task.id = source.task_id and task.user_id = source.user_id
  left join writing_run as run on run.id = (
    select candidate.id from writing_run as candidate where candidate.user_id = source.user_id
      and candidate.task_id = source.task_id and candidate.submission_id = source.id and candidate.purpose = 'diagnostic'
    order by case candidate.status when 'succeeded' then 0 when 'pending' then 1 else 2 end,
      candidate.started_at desc, candidate.id desc limit 1
  )`;

function ownedRevision(userId: string, revisionId: string) {
  return sql`select id from writing_submission
    where user_id = ${userId} and id = ${revisionId} and parent_submission_id is not null`;
}

function revisionCheckRow(userId: string, revisionId: string) {
  return sql`select saved.lease_token as "leaseToken", saved.lease_expires_at as "leaseExpiresAt", saved.result
    from (${ownedRevision(userId, revisionId)}) as revision
    left join writing_revision_check as saved on saved.revision_id = revision.id`;
}

function decodeRevisionCheck(row: Row, now: string): SavedRevisionCheck {
  return {
    check: typeof row.result === "string" ? JSON.parse(row.result) : row.result as WritingRevisionCheck | null,
    pending: typeof row.leaseExpiresAt === "string" && row.leaseExpiresAt > now,
  };
}

function quotaKey(userId: string, day: string, kind: "attempts" | "successes") {
  return `writing:diagnostic:${kind}:${day}:${userId}`;
}

function countFromLedger(key: string) {
  return sql`coalesce((select count from request_limit where id = ${key}), 0)`;
}

function pendingCount(userId: string, day: string, now: string) {
  return sql`(select count(*) from writing_run
    where user_id = ${userId} and purpose = 'diagnostic' and quota_day = ${day}
      and status = 'pending' and lease_expires_at > ${now})`;
}

function addQuotaUse(key: string, qualifyingRun: SQL) {
  return sql`insert into request_limit (id, count)
    select ${key}, 1 from writing_run where ${qualifyingRun}
    on conflict (id) do update set count = request_limit.count + 1`;
}

const retiredRevisionPrefix = "writing:deleted-revision:";
function retiredRevisionKey(taskId: string, requestId: string) {
  return `${retiredRevisionPrefix}${taskId}:${requestId}`;
}

function retiredRevisionForTask(taskId: SQL) {
  const prefix = sql`${retiredRevisionPrefix} || ${taskId} || ':'`;
  return sql`substr(request_limit.id, 1, length(${prefix})) = (${prefix})`;
}

export class SqlWritingRepository implements WritingRepository {
  constructor(private readonly db: WritingDatabase) {}

  async createTask(userId: string, task: WritingTask, requestId: string) {
    const [ , [row]] = await this.db.write(userId, [
      sql`insert into writing_task (id, user_id, client_request_id, prompt_id, prompt_version, snapshot, created_at)
          values (${task.id}, ${userId}, ${requestId}, ${task.promptId}, ${task.promptVersion},
            ${JSON.stringify(task.snapshot)}, ${task.createdAt})
          on conflict (user_id, client_request_id) do nothing`,
      sql`select ${taskColumns} from writing_task where user_id = ${userId} and client_request_id = ${requestId}`,
    ]);
    if (!row) return { status: "not_found" as const };
    const saved = decodeTask(row);
    if (saved.promptId !== task.promptId || saved.snapshot.locale !== task.snapshot.locale ||
      saved.snapshot.interestIds.join(",") !== task.snapshot.interestIds.join(",")) {
      return { status: "conflict" as const };
    }
    return { status: "saved" as const, record: saved };
  }

  async createSubmission(userId: string, submission: WritingSubmission, requestId: string) {
    const { id, taskId, parentSubmissionId, text, wordCount, assistance, createdAt } = submission;
    const ownedTask = sql`exists (select 1 from writing_task where user_id = ${userId} and id = ${taskId})`;
    const eligibleParent = parentSubmissionId === null ? sql`true` : sql`exists (
      select 1 from writing_submission as parent join writing_run as evaluation
        on evaluation.user_id = parent.user_id and evaluation.task_id = parent.task_id
        and evaluation.submission_id = parent.id and evaluation.status = 'succeeded'
      where parent.user_id = ${userId} and parent.task_id = ${taskId} and parent.id = ${parentSubmissionId}
        and parent.parent_submission_id is null
    )`;
    const [ , [row], [availability]] = await this.db.write(userId, [
      sql`insert into writing_submission
          (id, user_id, task_id, client_request_id, parent_submission_id, text, word_count, assistance, created_at)
          select ${id}, ${userId}, ${taskId}, ${requestId}, ${parentSubmissionId}, ${text}, ${wordCount},
            ${assistance}, ${createdAt}
          where ${ownedTask} and ${eligibleParent}
            and not exists (select 1 from request_limit where id = ${retiredRevisionKey(taskId, requestId)})
          on conflict do nothing`,
      sql`select ${submissionColumns} from writing_submission
          where user_id = ${userId} and client_request_id = ${requestId}`,
      sql`select case when ${ownedTask} and ${eligibleParent} then 1 else 0 end as available`,
    ]);
    if (!row) return { status: availability.available ? "conflict" as const : "not_found" as const };
    const saved = row as unknown as WritingSubmission;
    if (saved.taskId !== taskId || saved.parentSubmissionId !== parentSubmissionId ||
      saved.text !== text || saved.assistance !== assistance) {
      return { status: "conflict" as const };
    }
    return { status: "saved" as const, record: saved };
  }

  async getSubmission(userId: string, id: string) {
    const [row] = await this.db.read(sql`
      select ${profileColumns} ${submissionWithRun} where source.user_id = ${userId} and source.id = ${id}
    `);
    return row ? decodeSubmissionRecord(row) : null;
  }

  async listFocusRecords(userId: string) {
    const rows = await this.db.read(sql`
      select ${profileColumns} ${submissionWithRun}
      where source.user_id = ${userId} and source.parent_submission_id is null
      order by source.created_at desc, source.id desc
    `);
    return rows.map(decodeSubmissionRecord);
  }

  async listFocusStates(userId: string): Promise<{ key: string; status: WritingFocusState }[]> {
    const rows = await this.db.read(sql`select problem_key as "key", status from writing_focus_state
      where user_id = ${userId}`);
    return (rows as { key: string; status: WritingFocusStatus }[]).map((row) => row.key.startsWith(WRITING_FOCUS_RETURNED_PREFIX)
      ? { key: row.key.slice(WRITING_FOCUS_RETURNED_PREFIX.length), status: "returned" } : row);
  }

  async updateFocusState(userId: string, key: string, action: WritingFocusAction, sourceIds: readonly string[], rememberReturn = false) {
    const sourceExists = sql`exists (select 1 from writing_submission
      where user_id = ${userId} and parent_submission_id is null
        and id in (${this.db.textValues(JSON.stringify(sourceIds))}))`;
    const hasPinSpace = action === "add" ? sql`and (select count(*) from writing_focus_state
      where user_id = ${userId} and status = 'active') < ${WRITING_FOCUS_PIN_LIMIT}` : sql.empty();
    // A prefixed key records an explicit return using the existing status constraint.
    const returnedKey = WRITING_FOCUS_RETURNED_PREFIX + key;
    if (action === "remove" || action === "restore") {
      const transition = rememberReturn
        ? sql`update writing_focus_state set problem_key = ${returnedKey}, status = 'dismissed'`
        : sql`delete from writing_focus_state`;
      const [rows] = await this.db.write(userId, [sql`${transition} where user_id = ${userId} and problem_key = ${key}
        and status = ${action === "remove" ? "active" : "dismissed"} and ${sourceExists} returning problem_key`]);
      return rows.length === 1;
    }
    const update = sql`insert into writing_focus_state (user_id, problem_key, status)
          select ${userId}, ${key}, ${action === "add" ? "active" : "dismissed"} where ${sourceExists} ${hasPinSpace}
          on conflict (user_id, problem_key) do nothing returning problem_key`;
    const [rows] = await this.db.write(userId, [update, sql`delete from writing_focus_state
      where user_id = ${userId} and problem_key = ${returnedKey} and exists (
        select 1 from writing_focus_state where user_id = ${userId} and problem_key = ${key}
      )`]);
    return rows.length === 1;
  }

  private matchesFocusHistory(userId: string, historyKey: string) {
    // Compare under the same owner write lock / D1 batch as state pruning.
    // Only completed reports and original identity can change Focus grouping.
    return sql`${historyKey} = (
      select coalesce(${this.db.concatHistoryEntries}, '') from (
        select source.id || ':' || case when run.status = 'succeeded' then run.id else '' end as entry
        ${submissionWithRun}
        where source.user_id = ${userId} and source.parent_submission_id is null
        order by source.id
      ) as focus_history
    )`;
  }

  private focusPrune(userId: string, plan: WritingFocusPrune, current: SQL) {
    const keys = plan.retainKeys.flatMap((key) => [key, WRITING_FOCUS_RETURNED_PREFIX + key]);
    return sql`delete from writing_focus_state where user_id = ${userId} and ${current}
      and problem_key not in (${this.db.textValues(JSON.stringify(keys))})`;
  }

  async pruneFocusStates(userId: string, plan: WritingFocusPrune) {
    await this.db.write(userId, [this.focusPrune(userId, plan, this.matchesFocusHistory(userId, plan.historyKey))]);
  }

  async listProfileRecords(userId: string) {
    const revisions = sql`revision.user_id = source.user_id and revision.task_id = source.task_id and revision.parent_submission_id = source.id`;
    const rows = await this.db.read(sql`
      select ${profileColumns},
        (select revision.id from writing_submission as revision where ${revisions}
          order by revision.created_at desc, revision.id desc limit 1) as "latestRevisionId",
        profile_check.result as "revisionResult", profile_check.checked_at as "revisionCheckedAt"
      ${submissionWithRun}
      left join writing_revision_check as profile_check on profile_check.revision_id = (
        select revision.id from writing_submission as revision
          join writing_revision_check as checked on checked.revision_id = revision.id
          where ${revisions} and checked.result is not null
          order by revision.created_at desc, revision.id desc limit 1)
      where source.user_id = ${userId} and source.parent_submission_id is null
      order by source.created_at desc, source.id desc limit 100
    `);
    return rows.map((row) => ({ ...decodeSubmissionRecord(row), latestRevisionId: row.latestRevisionId as string | null,
      revisionCheck: decodeRevisionCheck({ result: row.revisionResult }, "").check, revisionCheckedAt: row.revisionCheckedAt as string | null }));
  }

  async getProfileAnalysis(userId: string) {
    const [row] = await this.db.read(sql`select evidence_key as "evidenceKey", lease_token as "leaseToken",
      next_attempt_at as "nextAttemptAt", updated_at as "updatedAt", result from writing_profile_analysis where user_id = ${userId}`);
    if (!row) return null;
    const { evidenceKey, leaseToken, nextAttemptAt, updatedAt } = row as unknown as NonNullable<Awaited<ReturnType<WritingRepository["getProfileAnalysis"]>>>;
    const resultJson = typeof row.result === "string" ? row.result : null;
    let result: unknown = null;
    if (resultJson !== null) {
      try {
        result = JSON.parse(resultJson);
      } catch {
        // The profile can still show recent feedback while the cache is repaired.
      }
    }
    return { evidenceKey, leaseToken, nextAttemptAt, updatedAt, result, resultJson };
  }

  async reserveProfileAnalysis(userId: string, input: Parameters<WritingRepository["reserveProfileAnalysis"]>[1]) {
    const { evidenceKey, leaseToken, now, leaseExpiresAt, dailyLimit, replaceInvalidResult } = input;
    const quota = `writing:profile-trend:attempts:${now.slice(0, 10)}:${userId}`;
    const [[claim], , [limit]] = await this.db.write(userId, [
      sql`insert into writing_profile_analysis (user_id, evidence_key, lease_token, next_attempt_at, updated_at)
        select id, ${evidenceKey}, ${leaseToken}, ${leaseExpiresAt}, ${now} from app_user
        where id = ${userId} and ${countFromLedger(quota)} < ${dailyLimit}
        on conflict (user_id) do update set evidence_key = excluded.evidence_key, lease_token = excluded.lease_token,
          next_attempt_at = excluded.next_attempt_at, updated_at = excluded.updated_at, result = null
        where writing_profile_analysis.next_attempt_at <= ${now} and
          (writing_profile_analysis.result is null or writing_profile_analysis.evidence_key <> ${evidenceKey}
            or writing_profile_analysis.result = ${replaceInvalidResult ?? null})
        returning user_id`,
      sql`insert into request_limit (id, count) select ${quota}, 1 from writing_profile_analysis
        where user_id = ${userId} and lease_token = ${leaseToken}
        on conflict (id) do update set count = request_limit.count + 1`,
      sql`select ${countFromLedger(quota)} as used`,
    ]);
    return claim ? "claimed" : Number(limit.used) >= dailyLimit ? "quota" : "busy";
  }

  async finishProfileAnalysis(userId: string, leaseToken: string, now: string, retryAt: string, result: unknown) {
    const [[row]] = await this.db.write(userId, [sql`update writing_profile_analysis
      set lease_token = null, next_attempt_at = ${retryAt}, updated_at = ${now}, result = ${result === null ? null : JSON.stringify(result)}
      where user_id = ${userId} and lease_token = ${leaseToken} and next_attempt_at > ${now} returning user_id`]);
    return !!row;
  }

  async latestSubmissionId(userId: string, taskId?: string) {
    const selection = taskId === undefined ? sql`parent_submission_id is null` :
      sql`task_id = ${taskId} and parent_submission_id is not null`;
    const [row] = await this.db.read(sql`
      select id from writing_submission where user_id = ${userId} and ${selection}
      order by created_at desc, id desc limit 1
    `);
    return typeof row?.id === "string" ? row.id : null;
  }

  async listOriginalSubmissions(userId: string): Promise<WritingHistoryItem[]> {
    const rows = await this.db.read(sql`
      select source.id, task.prompt_id as "promptId", task.snapshot,
        source.created_at as "createdAt", substr(source.text, 1, 140) as preview
      from writing_submission as source
      join writing_task as task on task.id = source.task_id and task.user_id = source.user_id
      where source.user_id = ${userId} and source.parent_submission_id is null
      order by source.created_at desc, source.id desc
      limit 100
    `);
    return rows.map((row) => {
      const snapshot = typeof row.snapshot === "string" ? JSON.parse(row.snapshot) as WritingTaskSnapshot : row.snapshot as WritingTaskSnapshot;
      return { id: String(row.id), promptId: String(row.promptId),
        title: "title" in snapshot.prompt && snapshot.prompt.title ? snapshot.prompt.title : snapshot.prompt.scenario,
        createdAt: String(row.createdAt), preview: String(row.preview) };
    });
  }

  async listRevisions(userId: string, originalId: string): Promise<WritingRevisionSummary[]> {
    const rows = await this.db.read(sql`
      select id, created_at as "createdAt", word_count as "wordCount"
      from writing_submission
      where user_id = ${userId} and parent_submission_id = ${originalId}
      order by created_at desc, id desc
    `);
    return rows.map(({ id, createdAt, wordCount }) => ({
      id: String(id), createdAt: String(createdAt), wordCount: Number(wordCount),
    }));
  }

  async getRevisionCheck(userId: string, revisionId: string, now: string) {
    const [row] = await this.db.read(revisionCheckRow(userId, revisionId));
    return row ? decodeRevisionCheck(row, now) : null;
  }

  async reserveRevisionCheck(userId: string, input: Parameters<WritingRepository["reserveRevisionCheck"]>[1]) {
    const { revisionId, leaseToken, now, leaseExpiresAt, attemptLimit } = input;
    const key = `writing:revision-check:attempts:${now.slice(0, 10)}:${userId}`;
    const [, , [row]] = await this.db.write(userId, [
      sql`insert into writing_revision_check (revision_id, lease_token, lease_expires_at)
          select id, ${leaseToken}, ${leaseExpiresAt} from (${ownedRevision(userId, revisionId)}) as revision
          where ${countFromLedger(key)} < ${attemptLimit}
          on conflict (revision_id) do update set lease_token = excluded.lease_token,
            lease_expires_at = excluded.lease_expires_at
          where writing_revision_check.result is null and writing_revision_check.lease_expires_at <= ${now}`,
      sql`insert into request_limit (id, count)
          select ${key}, 1 from writing_revision_check where revision_id = ${revisionId} and lease_token = ${leaseToken}
          on conflict (id) do update set count = request_limit.count + 1`,
      revisionCheckRow(userId, revisionId),
    ]);
    if (!row) return { status: "not_found" as const };
    const { check, pending } = decodeRevisionCheck(row, now);
    if (check) return { status: "completed" as const, check };
    if (row.leaseToken === leaseToken) return { status: "claimed" as const };
    return { status: pending ? "pending" as const : "quota" as const };
  }

  async finishRevisionCheck(userId: string, revisionId: string, leaseToken: string, check: WritingRevisionCheck | null, checkedAt?: string) {
    const claim = sql`revision_id in (${ownedRevision(userId, revisionId)}) and lease_token = ${leaseToken}`;
    const [rows] = await this.db.write(userId, [check
      ? sql`update writing_revision_check set lease_token = null, lease_expires_at = null, result = ${JSON.stringify(check)}, checked_at = ${checkedAt ?? null}
          where ${claim} returning revision_id`
      : sql`delete from writing_revision_check where ${claim} returning revision_id`]);
    return rows.length > 0;
  }

  async reserveRun(userId: string, input: Parameters<WritingRepository["reserveRun"]>[1]) {
    const { id, submissionId, requestId, mode, now, leaseExpiresAt, limits } = input;
    const day = now.slice(0, 10);
    const attemptsKey = quotaKey(userId, day, "attempts");
    const successesKey = quotaKey(userId, day, "successes");
    const eligibleSubmission = sql`user_id = ${userId} and id = ${submissionId} and parent_submission_id is null`;
    const existingRun = sql`user_id = ${userId} and submission_id = ${submissionId} and purpose = 'diagnostic'
      and (${mode === "initial" ? sql`true` : sql`status in ('pending', 'succeeded')`})`;
    const [, , , [newRun], [original], [replayed], [active]] = await this.db.write(userId, [
      sql`update writing_run set status = 'expired', finished_at = ${now}
          where user_id = ${userId} and submission_id = ${submissionId}
            and status = 'pending' and lease_expires_at <= ${now}`,
      sql`insert into writing_run
          (id, user_id, task_id, submission_id, idempotency_key, purpose, status, quota_day, lease_expires_at, started_at)
          select ${id}, user_id, task_id, writing_submission.id, ${requestId}, 'diagnostic', 'pending', ${day},
            ${leaseExpiresAt}, ${now} from writing_submission
          where ${eligibleSubmission} and not exists (select 1 from writing_run where ${existingRun})
            and ${countFromLedger(successesKey)} + ${pendingCount(userId, day, now)} < ${limits.successes}
            and ${countFromLedger(attemptsKey)} < ${limits.attempts}
          on conflict do nothing`,
      addQuotaUse(attemptsKey, sql`id = ${id} and user_id = ${userId} and status = 'pending'`),
      sql`select ${runColumns} from writing_run where id = ${id} and user_id = ${userId}`,
      sql`select id from writing_submission where ${eligibleSubmission}`,
      sql`select submission_id as "submissionId" from writing_run where user_id = ${userId} and idempotency_key = ${requestId}`,
      sql`select id from writing_run where ${existingRun} limit 1`,
    ]);
    if (newRun) return { status: "claimed" as const, run: decodeRun(newRun) };
    if (!original) return { status: "not_found" as const };
    if (replayed && replayed.submissionId !== submissionId) return { status: "conflict" as const };
    return { status: replayed || active ? "existing" as const : "quota" as const };
  }

  async finishRun(userId: string, run: WritingRun, now: string, report: DiagnosticReport | null) {
    // Each claim has a new unpredictable run ID. Only that exact pending row can settle.
    const live = sql`id = ${run.id} and user_id = ${userId} and submission_id = ${run.submissionId}
      and quota_day = ${run.quotaDay} and status = 'pending' and lease_expires_at > ${now}`;
    const update = sql`update writing_run set status = ${report ? "succeeded" : "failed"}, finished_at = ${now},
        report = ${report ? JSON.stringify(report) : null} where ${live} returning id`;
    const statements = report ? [addQuotaUse(quotaKey(userId, run.quotaDay, "successes"), live), update] : [update];
    const results = await this.db.write(userId, statements);
    return results[results.length - 1].length === 1;
  }

  async getQuota(userId: string, now: string) {
    const day = now.slice(0, 10);
    const [row] = await this.db.read(sql`select
      ${countFromLedger(quotaKey(userId, day, "successes"))} as successes,
      ${countFromLedger(quotaKey(userId, day, "attempts"))} as attempts,
      ${pendingCount(userId, day, now)} as pending`);
    return { successes: Number(row.successes), attempts: Number(row.attempts), pending: Number(row.pending) };
  }

  async deleteSubmission(userId: string, id: string, focus?: WritingFocusPrune) {
    const owned = sql`user_id = ${userId} and id = ${id}`;
    const current = focus ? this.matchesFocusHistory(userId, focus.historyKey) : sql`1 = 0`;
    const originalTask = sql`select task_id from writing_submission where ${owned} and parent_submission_id is null and ${current}`;
    const results = await this.db.write(userId, [
      ...(focus ? [this.focusPrune(userId, focus, sql`exists (${originalTask})`)] : []),
      sql`insert into request_limit (id, count)
          select ${retiredRevisionPrefix} || task_id || ':' || client_request_id, 1
          from writing_submission where ${owned} and parent_submission_id is not null
          on conflict (id) do nothing`,
      sql`delete from request_limit where exists (
          select 1 from (${originalTask}) as original
          where ${retiredRevisionForTask(sql`original.task_id`)}
        )`,
      sql`delete from writing_profile_analysis where user_id = ${userId}
        and exists (select 1 from writing_submission where ${owned} and (parent_submission_id is not null or ${current}))`,
      sql`delete from writing_task where user_id = ${userId} and id in (${originalTask}) returning id`,
      sql`delete from writing_submission where ${owned} and parent_submission_id is not null returning id`,
    ]);
    return results.slice(-2).some((rows) => rows.length > 0);
  }

  async deleteAll(userId: string) {
    await this.db.write(userId, [
      sql`delete from writing_profile_analysis where user_id = ${userId}`,
      sql`delete from writing_focus_state where user_id = ${userId}`,
      sql`delete from request_limit where exists (
          select 1 from writing_task where user_id = ${userId}
            and ${retiredRevisionForTask(sql`writing_task.id`)}
        )`,
      sql`delete from writing_task where user_id = ${userId}`,
    ]);
  }
}
