import { lt, sql } from "drizzle-orm";
import type { getPgDb } from "@/db/pg";
import { rateLimits } from "@/db/schema.pg";
import { LanguageBudgetExceeded, type LlmCallBudget } from "../llm/call-budget";
import { nextUtcDay } from "../domain/request-limits";

export class PgDailyLlmBudget implements LlmCallBudget {
  constructor(
    private readonly db: ReturnType<typeof getPgDb>,
    private readonly globalLimit: number,
    private readonly userId: string,
    private readonly perUserLimit: number,
    private readonly now: () => Date = () => new Date(),
  ) {}
  async take(): Promise<boolean> {
    const now = this.now();
    const day = now.toISOString().slice(0, 10);
    return this.db.transaction(async (tx) => {
      const global = await tx.insert(rateLimits)
        .values({ id: `llm:global:${day}`, count: 1 })
        .onConflictDoUpdate({
          target: rateLimits.id,
          set: { count: sql`${rateLimits.count} + 1` },
          setWhere: lt(rateLimits.count, this.globalLimit),
        }).returning({ count: rateLimits.count });
      if (!global.length) throw new LanguageBudgetExceeded("service", nextUtcDay(now));
      const user = await tx.insert(rateLimits)
        .values({ id: `llm:user:${this.userId}:${day}`, count: 1 })
        .onConflictDoUpdate({
          target: rateLimits.id,
          set: { count: sql`${rateLimits.count} + 1` },
          setWhere: lt(rateLimits.count, this.perUserLimit),
        }).returning({ count: rateLimits.count });
      if (!user.length) throw new LanguageBudgetExceeded("account", nextUtcDay(now));
      return true;
    });
  }
}
