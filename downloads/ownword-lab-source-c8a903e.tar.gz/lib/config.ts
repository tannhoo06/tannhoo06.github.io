import { z } from "zod";
import { DEFAULT_POLICY } from "./domain/learning";
const policySchema = z
  .object({
    minOccasionHours: z.number().min(1),
    practicingSuccesses: z.number().int().min(2),
    activeSuccesses: z.number().int().min(3),
    activeSpanDays: z.number().min(1),
    activeContexts: z.number().int().min(1),
    recentWindow: z.number().int().min(3),
    recentRecall: z.number().min(0.5).max(1),
    activeIndependent: z.number().int().min(1),
    demotionFailures: z.number().int().min(2),
    sessionSize: z.number().int().min(1).max(8),
    maintenanceDays: z.array(z.number().positive()).min(1),
    newPerDay: z.number().int().min(1).max(8),
  })
  .partial();
export function readConfig(environment: Record<string, unknown>) {
  const llm = readLlmConfig(environment);
  const overrides =
    typeof environment.LEARNING_POLICY_JSON === "string"
      ? policySchema.parse(JSON.parse(environment.LEARNING_POLICY_JSON))
      : {};
  return {
    llm,
    discoveryLimits: {
      concept: z.coerce.number().int().min(1).max(1000).parse(environment.CONCEPT_DISCOVERY_DAILY_LIMIT ?? 20),
      writing: z.coerce.number().int().min(1).max(1000).parse(environment.WRITING_DISCOVERY_DAILY_LIMIT ?? 10),
    },
    llmDailyCallLimit: z.coerce
      .number()
      .int()
      .min(1)
      .max(100_000)
      .parse(environment.LLM_DAILY_CALL_LIMIT ?? 1000),
    llmPerUserDailyCallLimit: z.coerce
      .number()
      .int()
      .min(1)
      .max(100_000)
      .parse(environment.LLM_PER_USER_DAILY_CALL_LIMIT ?? 8),
    policy: { ...DEFAULT_POLICY, ...overrides },
  };
}

export type LlmConfig =
  | { provider: "mock" }
  | { provider: "openrouter"; key: string; model: string }
  | {
      provider: "gemini";
      keys: string[];
      model: string;
      keyStrategy: "single" | "round-robin";
    };

function readLlmConfig(environment: Record<string, unknown>): LlmConfig {
  // LLM_MODE remains supported for existing installations. Select exactly one provider.
  const provider = environment.LLM_PROVIDER ?? environment.LLM_MODE ?? "mock";
  if (provider === "mock") return { provider };
  if (provider === "openrouter") {
    const key = typeof environment.OPENROUTER_API_KEY === "string" ? environment.OPENROUTER_API_KEY.trim() : "";
    if (!key || /[\r\n]/.test(key)) throw new Error("OpenRouter needs a valid server-side OPENROUTER_API_KEY.");
    const model = typeof environment.OPENROUTER_MODEL === "string" ? environment.OPENROUTER_MODEL.trim() : "google/gemini-3.6-flash";
    if (!model || !/^[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._:-]*$/i.test(model)) throw new Error("OpenRouter needs an explicit provider/model identifier.");
    return { provider: "openrouter", key, model };
  }
  if (provider !== "gemini")
    throw new Error(
      "Unsupported LLM provider. Configure an installed provider: mock, gemini or openrouter.",
    );
  const numbered = Object.keys(environment)
    .filter((name) => /^GEMINI_API_KEY_[1-9]\d*$/.test(name))
    .sort((a, b) => Number(a.slice(15)) - Number(b.slice(15)))
    .map((name) => environment[name]);
  const keys = [environment.GEMINI_API_KEY, ...numbered]
    .filter(
      (value): value is string => typeof value === "string" && !!value.trim(),
    )
    .map((value) => value.trim());
  if (!keys.length)
    throw new Error(
      "Gemini needs a server-side GEMINI_API_KEY or numbered GEMINI_API_KEY_1, GEMINI_API_KEY_2, … settings.",
    );
  if (new Set(keys).size !== keys.length)
    throw new Error(
      "Gemini API key settings must contain distinct keys. Remove duplicate entries.",
    );
  if (keys.some((key) => /[\r\n]/.test(key)))
    throw new Error("Each Gemini API key must be a single-line value.");
  const keyStrategy = environment.GEMINI_KEY_STRATEGY ?? "round-robin";
  if (keyStrategy !== "single" && keyStrategy !== "round-robin")
    throw new Error("GEMINI_KEY_STRATEGY must be single or round-robin.");
  const model =
    typeof environment.GEMINI_MODEL === "string"
      ? environment.GEMINI_MODEL.trim()
      : "gemini-3.5-flash-lite";
  if (!model) throw new Error("GEMINI_MODEL cannot be empty.");
  return { provider, keys, model, keyStrategy };
}
