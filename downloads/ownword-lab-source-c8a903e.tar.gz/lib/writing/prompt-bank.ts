import { z } from "zod";
import { discussionPrompts } from "./discussion-prompts";

export const writingInterests = {
  technology: { en: "Technology & Internet", vi: "Công nghệ & Internet" },
  work_study: { en: "Study & work", vi: "Học tập & công việc" },
  creativity: { en: "Entertainment & creativity", vi: "Giải trí & sáng tạo" },
  health_movement: { en: "Health & movement", vi: "Sức khỏe & vận động" },
  relationships: { en: "People & relationships", vi: "Con người & mối quan hệ" },
  travel: { en: "Travel & exploration", vi: "Du lịch & khám phá" },
  daily_life: { en: "Food & everyday life", vi: "Ẩm thực & đời sống" },
  community_environment: { en: "Community & environment", vi: "Xã hội & môi trường" },
} as const;

const interestId = z.enum(Object.keys(writingInterests) as (keyof typeof writingInterests)[]);

export const diagnosticRequirements = {
  position: "Recommend one of the two options. An implicit recommendation is fine if the reader can identify it.",
  reasons: "Give two distinct reasons for your choice and explain how they support it.",
  trade_off: "Acknowledge one drawback of your preferred option.",
} as const;

export const diagnosticBlueprint = {
  id: "everyday-decision",
  version: "v1",
  format: "opinion",
  wordRange: { min: 130, max: 160 },
  instructions: "Use the details in the scenario and your own reasoning. No research or specialist knowledge is needed.",
  requirements: diagnosticRequirements,
} as const;

export const discussionBlueprint = {
  id: "everyday-discussion",
  version: "v2",
  format: "opinion",
  wordRange: diagnosticBlueprint.wordRange,
  instructions: "Answer the main question in your own way. No research or personal experience is required. The length is a suggestion, and any essay structure is acceptable.",
  requirements: {
    position: "Address the main question. Accept an implicit, qualified or conditional answer when the writer's view is clear.",
    reasons: "Identify the writer's own reasoning in response to the main question. A single developed line of reasoning can meet this check.",
  },
} as const;

const promptCore = {
  id: z.string().regex(/^[a-z]+(?:-[a-z]+)+$/),
  title: z.string().trim().min(3).max(44).optional(),
  scenario: z.string().trim().min(20).max(450),
};
const legacyPromptSchema = z.strictObject({
  ...promptCore,
  interestId: interestId.nullable(),
  options: z.tuple([z.string().trim().min(12).max(130), z.string().trim().min(12).max(130)]).readonly(),
}).readonly();

const discussionPromptSchema = z.strictObject({
  ...promptCore,
  id: z.enum(discussionPrompts.map(({ id }) => id)),
  title: z.string().trim().min(3).max(44),
  scenario: z.string().trim().min(20).max(180).refine((text) => text.endsWith("?")),
  interestIds: z.array(interestId).max(2).refine((ids) => new Set(ids).size === ids.length).readonly(),
}).readonly();

type LegacyPrompt = z.infer<typeof legacyPromptSchema>;
export type DiagnosticPrompt = LegacyPrompt | z.infer<typeof discussionPromptSchema>;
type InterestId = z.infer<typeof interestId>;

// Assigned IDs are immutable because saved responses and evaluator fixtures refer to them.
const archivedPrompts: LegacyPrompt[] = [
  {
    id: "club-updates",
    interestId: "technology",
    scenario: "A hobby club needs a way to share schedule changes. Everyone can access the club website and receive text messages. The volunteers can maintain only one channel.",
    options: ["Send a text message whenever the schedule changes.", "Post every update on the club website at a fixed time."],
  },
  {
    id: "shared-tablets",
    interestId: "technology",
    scenario: "A library has a few tablets for visitors who do not have a device with them. It can manage one lending system. Visitors usually have about half an hour at the library.",
    options: ["Let visitors reserve tablets before arriving.", "Lend tablets in arrival order and keep a short waiting list."],
  },
  {
    id: "team-start-times",
    interestId: "work_study",
    scenario: "A small team will work the same number of hours next month. Some tasks need people to work together, and some can be done alone.",
    options: ["Give everyone the same start time.", "Let people choose their start time and set one shared work hour."],
  },
  {
    id: "class-project",
    interestId: "work_study",
    scenario: "A class has two weeks for a project. Each student has the same amount of class time, and everyone must present what they learned.",
    options: ["Pair students to work on one project together.", "Let each student work alone and share a draft halfway through."],
  },
  {
    id: "community-arts",
    interestId: "creativity",
    scenario: "A community centre has the budget for one free evening for neighbours. It has a meeting room, a projector and basic craft materials.",
    options: ["Run a workshop where visitors make small crafts.", "Screen a short film and invite visitors to discuss it afterwards."],
  },
  {
    id: "local-exhibition",
    interestId: "creativity",
    scenario: "A community group is preparing a small art exhibition with the same number of artworks in either format. Only two volunteers are available to set it up.",
    options: ["Open for one evening and invite the artists to attend.", "Display the work for a week during regular community-centre hours."],
  },
  {
    id: "movement-breaks",
    interestId: "health_movement",
    scenario: "A club wants to spend twenty minutes a week moving together. Members have asked for an activity that fits a regular club visit.",
    options: ["Take two short movement breaks during regular meetings.", "Use all twenty minutes for a group walk after one meeting."],
  },
  {
    id: "park-activity",
    interestId: "health_movement",
    scenario: "A neighbourhood group is planning a free outdoor activity. The park has an open area and a short easy path. People can join without equipment.",
    options: ["Hold simple active games in one area for the whole session.", "Follow the path as a group and stop briefly at two places."],
  },
  {
    id: "group-plans",
    interestId: "relationships",
    scenario: "A group of friends meets each month. Last-minute changes sometimes mean people miss the meeting. The group wants a clearer way to make plans.",
    options: ["Set the date one week before each meeting and keep it fixed.", "Choose a first-choice date and one backup date in advance."],
  },
  {
    id: "shared-chores",
    interestId: "relationships",
    scenario: "Four housemates want to share the same weekly chores. Some prefer predictable routines, while others have changing schedules.",
    options: ["Give everyone a fixed chore for the month.", "Rotate chores weekly and let people agree to swap."],
  },
  {
    id: "weekend-trip",
    interestId: "travel",
    scenario: "A group is planning a short trip with a fixed budget. They can afford either plan, and travel takes about the same amount of time.",
    options: ["Visit three nearby places with a set timetable.", "Spend most of the day in one place with time to explore freely."],
  },
  {
    id: "town-visit",
    interestId: "travel",
    scenario: "A group of visitors has one afternoon in a small town. A map is available, and a volunteer can lead a walk at no extra cost.",
    options: ["Join the volunteer's walk along a fixed route.", "Use the map to choose where to spend the afternoon."],
  },
  {
    id: "canteen-orders",
    interestId: "daily_life",
    scenario: "A shared canteen serves a small lunch menu. It wants to make service easier for customers and staff. Meals cost the same under either plan.",
    options: ["Ask customers to choose and order before lunchtime.", "Let customers choose and order when they arrive."],
  },
  {
    id: "shared-meal",
    interestId: "daily_life",
    scenario: "Neighbours are organising a shared meal. They have a small kitchen, a common budget and the same number of volunteers for either plan.",
    options: ["Cook one meal together at the venue.", "Ask each small group to prepare one dish in advance."],
  },
  {
    id: "park-litter",
    interestId: "community_environment",
    scenario: "A neighbourhood can spend the same amount on one change to reduce litter in a small park. Most visitors enter through one gate and use the picnic area.",
    options: ["Put clearly marked bins closer to the picnic area.", "Place a reminder at the gate and mark the bins already in the park."],
  },
  {
    id: "neighbourhood-swap",
    interestId: "community_environment",
    scenario: "A neighbourhood wants people to exchange useful items they no longer need. The volunteers can organise one kind of exchange using an available room.",
    options: ["Run a two-hour swap where neighbours meet in person.", "Set up a clearly labelled shelf for drop-offs and collections during the week."],
  },
  {
    id: "shared-room",
    interestId: null,
    scenario: "A building has one shared meeting room. Residents use it for quiet work and small gatherings. The building wants a simple way to manage access.",
    options: ["Let residents book the room in advance.", "Leave the room open and ask residents to give others a turn."],
  },
  {
    id: "notice-board",
    interestId: null,
    scenario: "A building wants one notice board with enough space for announcements. Everyone passes both possible locations. The entrance is busier, and the other location has space to stop and read.",
    options: ["Install the notice board beside the main entrance.", "Install it in the quieter hall next to the entrance."],
  },
  {
    id: "learn-an-app",
    interestId: "technology",
    title: "Getting the hang of a new app",
    scenario: "When you try a new app, would you rather watch a short tutorial or explore it on your own?",
    options: ["Watch a short tutorial.", "Explore the app on your own."],
  },
  {
    id: "study-together",
    interestId: "work_study",
    title: "Getting ready for class",
    scenario: "Before a class on a difficult topic, would you rather study alone or talk through the material with a classmate?",
    options: ["Study the material alone.", "Talk through the material with a classmate."],
  },
  {
    id: "weekend-watch",
    interestId: "creativity",
    title: "What to watch this weekend",
    scenario: "When you have a free evening, would you rather rewatch a favorite film or watch one you haven't seen?",
    options: ["Rewatch a favorite film.", "Try a film you haven't seen."],
  },
  {
    id: "movement-routine",
    interestId: "health_movement",
    title: "Making time to move",
    scenario: "Would you rather take a couple of short walks during the day or save that time for one longer walk?",
    options: ["Take a couple of short walks.", "Take one longer walk."],
  },
  {
    id: "friend-catchup",
    interestId: "relationships",
    title: "Catching up with a friend",
    scenario: "If a friend moved away, would you rather keep in touch with short messages or set aside time for a regular call?",
    options: ["Keep in touch with short messages.", "Set aside time for a regular call."],
  },
  {
    id: "day-trip-style",
    interestId: "travel",
    title: "A day somewhere new",
    scenario: "For a day trip somewhere new, would you rather plan where to go in advance or decide as you explore?",
    options: ["Plan where to go in advance.", "Decide where to go as you explore."],
  },
  {
    id: "evening-meal",
    interestId: "daily_life",
    title: "Dinner after a busy day",
    scenario: "On a busy weekday, would you rather cook a simple dinner or pick up a ready-made meal?",
    options: ["Cook a simple dinner.", "Pick up a ready-made meal."],
  },
  {
    id: "pass-it-on",
    interestId: "community_environment",
    title: "A second life for useful things",
    scenario: "If you had something useful you no longer needed, would you rather give it to someone you know or donate it locally?",
    options: ["Give the item to someone you know.", "Donate the item locally."],
  },
  {
    id: "quiet-or-music",
    interestId: null,
    title: "Music or quiet?",
    scenario: "When you need to concentrate on something important, would you rather listen to music or work in silence?",
    options: ["Listen to music while working.", "Work in silence."],
  },
  {
    id: "free-afternoon",
    interestId: null,
    title: "An afternoon to yourself",
    scenario: "If you unexpectedly had an afternoon free, would you rather stay home and relax or go out for a change of scene?",
    options: ["Stay home and relax.", "Go out for a change of scene."],
  },
];

const currentPrompts = z.array(discussionPromptSchema).parse(discussionPrompts);
const legacyPrompts = z.array(legacyPromptSchema).parse(archivedPrompts);
const promptBank = [...legacyPrompts, ...currentPrompts];
const promptsById = new Map<string, DiagnosticPrompt>(promptBank.map((prompt) => [prompt.id, prompt]));
if (promptsById.size !== promptBank.length) {
  throw new Error("Duplicate prompt ID in the Writing diagnostic bank.");
}
if (legacyPrompts.some(({ options: [first, second] }) => first === second)) {
  throw new Error("Each archived decision prompt needs two distinct options.");
}
const generalPrompts = currentPrompts.filter((prompt) => prompt.interestIds.length === 0);
if (generalPrompts.length !== 2 ||
  interestId.options.some((interest) => !currentPrompts.some((prompt) => prompt.interestIds.includes(interest)))) {
  throw new Error("The active Writing bank needs coverage for every interest and two general prompts.");
}

const interestSelection = z.array(interestId).max(2).refine(
  (ids) => new Set(ids).size === ids.length,
  "Choose distinct interests.",
);

export function diagnosticPromptChoices(selection: readonly InterestId[]) {
  const selected = interestSelection.parse(selection);
  const choices = new Set(selected.flatMap((id) => currentPrompts.filter((prompt) => prompt.interestIds.includes(id))));
  return [...choices, ...generalPrompts].slice(0, selected.length === 2 ? 3 : 2);
}

export function getDiagnosticPrompt(id: string) {
  return promptsById.get(id);
}

export function getDiagnosticBlueprint(prompt: DiagnosticPrompt) {
  return "interestIds" in prompt ? discussionBlueprint : diagnosticBlueprint;
}

export type DiagnosticBlueprint = ReturnType<typeof getDiagnosticBlueprint>;
