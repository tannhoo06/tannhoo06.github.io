import type { IssueFirstReportObservation } from "./contracts";

/** The evaluator orders ties by impact and learning value. Optional polish never leads. */
export function orderWritingFeedback(observations: readonly IssueFirstReportObservation[]) {
  function priority(item: IssueFirstReportObservation) {
    if (item.kind === "strength") return 3;
    if (item.feedback?.category === "optional") return 2;
    return item.materiality === "meaningful" ? 0 : 1;
  }
  return [...observations].sort((a, b) => priority(a) - priority(b));
}
