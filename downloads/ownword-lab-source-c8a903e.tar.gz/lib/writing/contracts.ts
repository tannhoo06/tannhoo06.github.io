import { z } from "zod";
import type { SourceAnchor } from "../domain/types";
import type { diagnosticRequirements } from "./prompt-bank";
import { PILOT_SKILL_IDS, type PilotSkillId } from "./rubric";
import type { WritingSkillVerification } from "./skill-verification";

export const DIAGNOSTIC_SCHEMA_VERSION = "diagnostic-output-v2";
export const MAX_DIAGNOSTIC_FINDINGS = 3;

export const diagnosticSubmissionSchema = z.strictObject({
  submissionId: z.string().trim().min(1).max(150),
  promptId: z.string().trim().min(1).max(100),
  text: z.string().max(5_000).refine((text) => text.trim().length > 0, "Enter a response."),
});
export type DiagnosticSubmission = z.infer<typeof diagnosticSubmissionSchema>;

const opportunity = z.enum(["adequate", "limited", "not_applicable"]);
const judgment = z.enum(["positive", "weak", "mixed"]);
const evidence = z.strictObject({
  quote: z.string().min(1).max(500),
  segmentId: z.number().int().min(1).nullable(),
});
const taskFulfillmentCheck = z.strictObject({
  status: z.enum(["met", "partly_met", "missing", "undetermined"]),
  evidence: z.array(evidence).max(3),
});

export const diagnosticOutputSchema = z.strictObject({
  opportunities: z.strictObject({
    "ARG.SUPPORT": opportunity,
    "ORG.PROGRESSION": opportunity,
    "LEX.PRECISION": opportunity,
    "GRAM.ACCURACY": opportunity,
  } satisfies Record<PilotSkillId, typeof opportunity>),
  taskFulfillment: z.strictObject({
    position: taskFulfillmentCheck,
    reasons: taskFulfillmentCheck,
    trade_off: taskFulfillmentCheck,
  } satisfies Record<keyof typeof diagnosticRequirements, typeof taskFulfillmentCheck>),
  findings: z.array(z.strictObject({
    skillId: z.enum(PILOT_SKILL_IDS),
    judgment,
    evidence: z.array(evidence).min(1).max(3),
    readerImpact: z.string().trim().min(1).max(400),
    revisionCue: z.string().trim().min(1).max(250).nullable(),
  })).max(PILOT_SKILL_IDS.length),
});

export const diagnosticOutputJsonSchema = z.toJSONSchema(diagnosticOutputSchema);
export type DiagnosticOutput = z.infer<typeof diagnosticOutputSchema>;
export type ProposedEvidence = z.infer<typeof evidence>;
export type RequirementId = keyof DiagnosticOutput["taskFulfillment"];

export interface DiagnosticFinding extends Omit<DiagnosticOutput["findings"][number], "evidence"> {
  evidence: SourceAnchor[];
}

/** Optional pilot payload. Historical four-skill reports keep their original shape. */
export interface IssueFirstReportObservation {
  kind: "problem" | "strength";
  problem: string;
  readerImpact: string;
  revisionCue: string | null;
  evidence: SourceAnchor[];
  attribution: {
    primary: PilotSkillId | null;
    secondary: PilotSkillId | null;
    certainty: "clear" | "overlapping" | "uncertain";
  };
  issueKind: string;
  materiality: "meaningful" | "minor";
  feedback?: {
    category: "mistake" | "clarity" | "optional" | "strength";
    /** Suggested English replacement for evidence[0], when the span is safe to replace. */
    replacement: string | null;
    vi: { problem: string; readerImpact: string; revisionCue: string | null };
  };
  /** Nominates evidence for longitudinal review. The profile independently verifies what it uses. */
  profileEvidenceCandidate: boolean;
}

export interface WritingFocusCheckObservation extends IssueFirstReportObservation {
  kind: "problem";
  focusTopicKey: string;
  profileEvidenceCandidate: false;
}

export interface WritingFocusCheck {
  version: 1;
  checkedTopicKeys: readonly string[];
  observations: WritingFocusCheckObservation[];
}

export interface DiagnosticReport {
  scope: "submitted_response";
  provisional: true;
  status: "observed" | "no_actionable_findings" | "insufficient_evidence";
  submissionId: string;
  promptId: string;
  promptVersion: string;
  registryVersion: string;
  rubricVersion: string;
  schemaVersion: string;
  findings: DiagnosticFinding[];
  issueFirstObservations?: IssueFirstReportObservation[];
  issueFirstCoverage?: { proposed: number; rejected: number };
  /** Server-owned provenance for reports generated with extra coaching prompts. */
  focusContext?: { version: 1; topicKeys: readonly string[] };
  focusCheck?: WritingFocusCheck;
  skillVerification?: WritingSkillVerification;
  skills: Record<PilotSkillId, {
    opportunity: DiagnosticOutput["opportunities"][PilotSkillId];
    judgment: DiagnosticFinding["judgment"] | "undetermined";
  }>;
  taskFulfillment: Record<RequirementId, {
    status: DiagnosticOutput["taskFulfillment"][RequirementId]["status"];
    evidence: SourceAnchor[];
  }>;
}
