import { resolveSource, validSource } from "../domain/anchors";
import type { SourceAnchor } from "../domain/types";
import { comparableWritingAssessments, type WritingProfileEvidence, type WritingProfileSession } from "./profile";
import { hasWholeWritingSkillSpan, supportsWritingSkillAnchor } from "./skill-evidence";
import { MAX_WRITING_SKILL_TARGETS, type WritingSkillTarget, type WritingSkillTargetId } from "./skill-verification";

const targetIds = ["subject-verb-agreement", "however-contrast", "local:word-borrow-lend"] as const;
const sentences = new Intl.Segmenter("en", { granularity: "sentence" });

function describesTarget(evidence: WritingProfileEvidence, target: WritingSkillTargetId) {
  if (evidence.kind === "problem" && evidence.practice?.skill === target) return true;
  const description = [evidence.title.en, evidence.description.en, evidence.cue?.en].filter(Boolean).join(" ");
  const strength = evidence.kind === "strength";
  switch (target) {
    case "subject-verb-agreement":
      return (strength || evidence.issueKind === "grammar_construction") && (
        /\bsubject[\s–—-]+verb[\s–—-]+(?:dis)?agreement\b/iu.test(description) ||
        /\b(?:singular|third[- ]person)\b/iu.test(description) && /\b(?:present(?:[- ]tense)?|habit\w*|endings?|agree\w*)\b/iu.test(description));
    case "however-contrast":
      return strength ? /\bhowever\b/iu.test(description) && /\b(?:contrast\w*|punctuat\w*|commas?|semicolons?|clauses?)\b/iu.test(description)
        : ["clause_connection", "punctuation", "grammar_construction"].includes(evidence.issueKind ?? "") &&
          /\b(?:commas?|semicolons?|punctuat\w*|sentence break)\b/iu.test(description);
    case "local:word-borrow-lend":
      return (strength || evidence.issueKind === "word_meaning_or_fit") &&
        /\b(?:borrow(?:s|ed|ing)?|lend(?:s|ing)?|lent)\b/iu.test(description) &&
        /\b(?:temporar\w*|giv\w*|receiv\w*|recipient|revers\w*|direction)\b/iu.test(description);
  }
}

function contextualAnchor(anchor: SourceAnchor, text: string) {
  const range = sentences.segment(anchor.sentence).containing(anchor.start - anchor.sentenceStart);
  if (!range || range.index + range.segment.length < anchor.end - anchor.sentenceStart) return null;
  const start = anchor.sentenceStart + range.index + range.segment.length - range.segment.trimStart().length;
  const exact = range.segment.trim();
  return resolveSource(text, exact, anchor.version, { start, end: start + exact.length });
}

function groundedUse(evidence: WritingProfileEvidence, target: WritingSkillTargetId, text: string, polarity: "correct" | "incorrect") {
  return evidence.source === "observation" && evidence.materiality === "meaningful" &&
    describesTarget(evidence, target) && evidence.anchors.some((anchor) => {
      if (!validSource(text, evidence.submissionId, anchor) || !hasWholeWritingSkillSpan(text, anchor)) return false;
      if (supportsWritingSkillAnchor(target, anchor, polarity, { text })) return true;
      // Feedback may highlight only the word to edit. Recover enough of that
      // same cited sentence to assess it, with the original citation as focus.
      const context = contextualAnchor(anchor, text);
      return context !== null && supportsWritingSkillAnchor(target, context, polarity, { text, focus: anchor });
    });
}

export function getWritingEvidenceSkillTarget(evidence: WritingProfileEvidence, text: string): WritingSkillTargetId | null {
  if (evidence.kind !== "problem") return null;
  for (const target of targetIds) if (groundedUse(evidence, target, text, "incorrect")) return target;
  return null;
}

export function supportsWritingEvidenceSkillUse(evidence: WritingProfileEvidence, target: WritingSkillTargetId, text: string) {
  return evidence.kind === "strength" && groundedUse(evidence, target, text, "correct");
}

export function selectWritingSkillTargets(current: WritingProfileSession, previous: readonly WritingProfileSession[]): WritingSkillTarget[] {
  const report = current.report;
  if (!report || current.submission.assistance !== "unassisted" || current.submission.parentSubmissionId) return [];
  const comparable = previous.filter((session) => session.report && !session.submission.parentSubmissionId &&
    session.submission.assistance === "unassisted" && session.submission.createdAt < current.submission.createdAt &&
    session.task.snapshot.blueprint.format === current.task.snapshot.blueprint.format &&
    comparableWritingAssessments(report, session.report)).slice(0, 12);
  const targets = new Map<WritingSkillTargetId, { evidenceId: string; count: number }>();
  for (const session of comparable) {
    const seen = new Set<WritingSkillTargetId>();
    for (const evidence of session.evidence) {
      const id = getWritingEvidenceSkillTarget(evidence, session.submission.text);
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const target = targets.get(id);
      if (target) target.count++;
      else targets.set(id, { evidenceId: evidence.id, count: 1 });
    }
  }
  return [...targets.entries()].sort((a, b) => b[1].count - a[1].count).slice(0, MAX_WRITING_SKILL_TARGETS)
    .map(([id, { evidenceId }]) => ({ id, evidenceId }));
}
