import { comparableWritingAssessments, type WritingProfileEvidence, type WritingProfileSession } from "./profile";
import type { WritingProfileTrend, WritingTrendPolicy } from "./profile-trends";
import { getWritingEvidenceSkillTarget, supportsWritingEvidenceSkillUse } from "./skill-targets";
import { writingSkillDefinitions, type WritingSkillTargetId } from "./skill-verification";

const SESSION_LIMIT = 12;
const sentenceSegmenter = new Intl.Segmenter("en", { granularity: "sentence" });
type SessionEvidence = { session: WritingProfileSession; evidence: WritingProfileEvidence };

function comparableOriginals(sessions: readonly WritingProfileSession[]) {
  const recent = sessions.filter(({ submission, run, report }) => submission.parentSubmissionId === null &&
    submission.assistance === "unassisted" && run?.status === "succeeded" && !!report && !report.focusContext)
    .sort((a, b) => b.submission.createdAt.localeCompare(a.submission.createdAt) || a.submission.id.localeCompare(b.submission.id))
    .slice(0, SESSION_LIMIT);
  const newest = recent[0];
  if (!newest?.report || !recent.some(({ skillVerification }) => skillVerification?.results.length)) return [];
  return recent.filter(({ report, task }) => comparableWritingAssessments(newest.report!, report!) &&
    task.snapshot.blueprint.format === newest.task.snapshot.blueprint.format);
}

function distinctPassages(uses: SessionEvidence[]) {
  const creditedSentences = new Set<string>();
  return uses.filter(({ session, evidence }) => {
    const segments = sentenceSegmenter.segment(session.submission.text);
    const sentences = [...new Set(evidence.anchors.flatMap(({ start, end }) => {
      const first = segments.containing(start);
      const last = segments.containing(end - 1);
      if (!first || !last) return [];
      return [first.segment, last.segment].map((sentence) => sentence.normalize("NFKC").toLowerCase()
        .match(/[\p{L}\p{N}]+/gu)?.join(" ") ?? "");
    }))];
    if (!sentences.length || sentences.some((sentence) => !sentence || creditedSentences.has(sentence))) return false;
    sentences.forEach((sentence) => creditedSentences.add(sentence));
    return true;
  });
}

/** Derive pilot-only gains from current, validated evidence of independent originals. */
export function buildWritingImprovements(sessions: readonly WritingProfileSession[], policy: WritingTrendPolicy): WritingProfileTrend[] {
  if (policy !== "improvement-pilot") return [];
  const cohort = comparableOriginals(sessions);
  const earlierProblems = new Map<string, SessionEvidence & { target: WritingSkillTargetId }>();
  for (const session of cohort) for (const evidence of session.evidence) {
    const target = getWritingEvidenceSkillTarget(evidence, session.submission.text);
    if (target) earlierProblems.set(evidence.id, { target, session, evidence });
  }

  const improvements: WritingProfileTrend[] = [];
  for (const target of Object.keys(writingSkillDefinitions) as WritingSkillTargetId[]) {
    const difficulties: SessionEvidence[] = [];
    const laterUses: SessionEvidence[] = [];
    const successes: string[] = [];
    for (const session of cohort) {
      const { id, createdAt, text } = session.submission;
      const reportedProblem = session.evidence.find(({ id }) => earlierProblems.get(id)?.target === target);
      const result = session.skillVerification?.results.find(({ targetId, baselineEvidenceId }) => {
        const baseline = earlierProblems.get(baselineEvidenceId);
        return targetId === target && baseline?.target === target && baseline.session.submission.createdAt < createdAt;
      });
      const verified = result && session.evidence.find((item) => item.source === "verification" &&
        item.id === `verification:${id}:${target}:${result.status}`);
      const verifiedDifficulty = verified && (verified.kind === "mixed" || verified.kind === "problem") ? verified : null;
      const difficulty = verifiedDifficulty ?? reportedProblem;
      if (difficulty) {
        difficulties.push({ session, evidence: difficulty });
        continue;
      }
      const verifiedUse = verified?.kind === "strength" ? verified : null;
      if (verifiedUse) laterUses.push({ session, evidence: verifiedUse });
      if (verifiedUse || session.evidence.some((evidence) => supportsWritingEvidenceSkillUse(evidence, target, text))) successes.push(createdAt);
    }

    const baseline = difficulties[0];
    if (!baseline) continue;
    const baselineTime = baseline.session.submission.createdAt;
    // The latest difficulty sets the boundary. The scope permits progress from
    // a mixed baseline, but earlier clean use makes a later lapse ambiguous.
    const earlier = distinctPassages([baseline, ...difficulties.filter(({ session }) => session.submission.createdAt < baselineTime)]).slice(0, 2);
    if (earlier.length < 2 || successes.some((time) => time <= baselineTime)) continue;
    const positives = distinctPassages(laterUses.filter(({ session }) => session.submission.createdAt > baselineTime)).slice(0, 2);
    if (positives.length < 2) continue;

    improvements.push({ id: `improvement:${target}`, kind: "improvement", skill: writingSkillDefinitions[target].skill,
      title: writingSkillDefinitions[target].title,
      description: {
        en: "Earlier responses included errors. The later examples shown both use this construction correctly.",
        vi: "Các bài trước còn mắc lỗi. Hai ví dụ từ các bài sau đều dùng đúng cấu trúc này.",
      },
      evidenceIds: [...earlier, ...positives].sort((a, b) => a.session.submission.createdAt.localeCompare(b.session.submission.createdAt) ||
        a.session.submission.id.localeCompare(b.session.submission.id)).map(({ evidence }) => evidence.id), revisionId: null });
  }
  return improvements;
}
