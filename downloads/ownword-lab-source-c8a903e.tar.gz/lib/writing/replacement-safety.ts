import type { IssueFirstReportObservation } from "./contracts";

const englishPunctuation = /^[\x20-\x7E\u2018\u2019\u201C\u201D\u2013\u2014\u2026]+$/u;
const grammarWords = new Set((
  "a an the am is are was were be been being do does did have has had to of in on by for from at with as and or but than " +
  "so yet nor because while although however which that who when"
).split(" "));
const irregulars = [
  ["be", "am", "is", "are", "was", "were", "been"], ["bring", "brings", "brought"],
  ["build", "builds", "built"], ["buy", "buys", "bought"], ["do", "does", "did", "done"],
  ["find", "finds", "found"], ["get", "gets", "got", "gotten"], ["give", "gives", "gave", "given"],
  ["go", "goes", "went", "gone"], ["have", "has", "had"],
  ["borrow", "borrows", "borrowed", "borrowing", "lend", "lends", "lent", "lending"],
  ["make", "makes", "made"], ["run", "runs", "ran"], ["say", "says", "said"],
  ["see", "sees", "saw", "seen"], ["send", "sends", "sent"], ["take", "takes", "took", "taken"],
  ["think", "thinks", "thought"], ["write", "writes", "wrote", "written"],
];

export function sanitizeReplacement(quote: string, replacement: string | null): string | null {
  if (!replacement || quote === replacement) return null;
  if (englishPunctuation.test(quote) && !englishPunctuation.test(replacement)) return null;
  if (!/[^\p{Script=Latin}\p{N}\p{P}\p{Z}\p{M}\s]/u.test(quote) &&
    /[^\p{Script=Latin}\p{N}\p{P}\p{Z}\p{M}\s]/u.test(replacement)) return null;
  const words = (value: string) => value.toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? [];
  const source = words(quote);
  if (source.length < 12) return replacement;
  const revised = words(replacement);
  const last = source.at(-1)!;
  const revisedLast = revised.at(-1);
  const ending = /[.!?](?:["'’”)]*)$/u;
  // The provider can cut a full-sentence correction to fit its replacement field.
  if (!revisedLast || ending.test(quote) && !ending.test(replacement) ||
    revisedLast.length >= 3 && last.startsWith(revisedLast) && last !== revisedLast &&
    !/^(?:s|es|d|ed|ing)$/u.test(last.slice(revisedLast.length))) return null;
  const before = new Set(source);
  return revised.every((word) => before.has(word) || grammarWords.has(word) ||
    word.length >= 3 && source.some((original) => original.startsWith(word.slice(0, 3))) ||
    irregulars.some((forms) => forms.includes(word) && forms.some((form) => before.has(form)))) ? replacement : null;
}

export function sanitizeWritingObservation<T extends IssueFirstReportObservation>(observation: T): T | null {
  const { feedback, evidence: [source] } = observation;
  if (!feedback || !source || observation.kind !== "problem") return observation;
  const replacement = feedback.category === "clarity" ? null : sanitizeReplacement(source.exact, feedback.replacement);
  if (!replacement && !observation.revisionCue) return null;
  return replacement === feedback.replacement ? observation : { ...observation, feedback: { ...feedback, replacement } };
}
