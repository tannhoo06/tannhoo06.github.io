import { validSource } from "../domain/anchors";
import { oneWritingTypo } from "./focus-lexemes";
import type { DiagnosticReport, IssueFirstReportObservation } from "./contracts";
import { checkWritingHoweverAttempt, getWritingHoweverExercises } from "./practice-however";
import { expandedPracticeId, expandedPracticeObjectives, getExpandedPracticeObjective, getExpandedPracticeScenario } from "./practice-library";
import { checkPracticeChoice, practiceEdit, practiceEntryLimit, type ExpandedPracticeSkill, type PracticeEdit } from "./practice-objective";
import type { WritingRevisionCheck } from "./revision-check";

type Copy = { en: string; vi: string };
export type CoreWritingPracticeSkill = "subject-verb-agreement" | "comma-splice" | "however-contrast";
export type WritingPracticeSkill = CoreWritingPracticeSkill | ExpandedPracticeSkill;

export type WritingPracticeRecommendation = {
  observationIndex: number;
  skill: WritingPracticeSkill;
  title: Copy;
  label: Copy;
  quote: string;
  reason: Copy;
  category: "mistake" | "clarity";
  revisionStatus: WritingRevisionCheck["items"][number]["status"] | null;
};

type PracticePrompt = {
  id: string;
  before: string;
  after: string;
  prompt: Copy;
  hint: Copy;
  context?: string;
};

export type WritingPracticeResult = {
  status: "successful" | "revise" | "unverified";
  feedback: Copy;
  nextStep: Copy;
  answer?: string;
};

export const writingPracticeAnswerLimit = practiceEntryLimit;

const titles: Record<CoreWritingPracticeSkill, Copy> = {
  "subject-verb-agreement": { en: "Match the subject and verb", vi: "Dùng đúng dạng động từ theo chủ ngữ" },
  "comma-splice": { en: "Connect two complete thoughts", vi: "Nối hai vế câu" },
  "however-contrast": { en: "Where does the punctuation go with ‘however’?", vi: "Dùng dấu câu với ‘however’ thế nào?" },
};
const labels: Record<CoreWritingPracticeSkill, Copy> = {
  "subject-verb-agreement": { en: "Practice verb agreement", vi: "Luyện chia động từ" },
  "comma-splice": { en: "Practice joining clauses", vi: "Luyện nối hai vế câu" },
  "however-contrast": { en: "Practice punctuation with ‘however’", vi: "Luyện dùng dấu câu với ‘however’" },
};

const transitionWords = "however|therefore|nevertheless|nonetheless|moreover|furthermore|instead|otherwise|meanwhile|consequently|thus|hence|as a result|on the other hand";
const clauseLead = /^(?:although|after|as|because|before|even if|if|since|though|unless|until|when|whenever|whereas|while)\b/iu;
const coordination = /^(?:and|but|yet|so|or|nor|for)\b/iu;
const subjectPronoun = /^(?:i|you|he|she|it|we|they)\b/iu;
const independentStart = /^\p{L}+\s+(?!(?:and|or|but)\b)\p{L}/iu;
const identifiableSubject = /^(?:(?:i|you|he|she|it|we|they)\s+|(?:the|a|an|this|that|these|those|my|your|his|her|our|their)\s+\p{L}+\s+)\p{L}/iu;

function isAgreementEdit(edit: PracticeEdit, attributed: boolean) {
  const plain = (form: string) => form.toLowerCase().replace(/[’‘]/gu, "'");
  const inflect = (base: string) => {
    if (base === "are") return "is";
    if (base === "aren't") return "isn't";
    if (base === "have") return "has";
    if (base === "haven't") return "hasn't";
    if (base === "do") return "does";
    if (base === "don't") return "doesn't";
    if (/[^aeiou]y$/u.test(base)) return base.slice(0, -1) + "ies";
    return base + (/(?:[sxz]|ch|sh|go)$/u.test(base) ? "es" : "s");
  };
  const from = plain(edit.before);
  const to = plain(edit.after);
  if (!/^[a-z]+(?:n't)?$/u.test(from) || !/^[a-z]+(?:n't)?$/u.test(to)) return false;
  const becomesSingular = inflect(from) === to;
  const becomesBase = inflect(to) === from;
  if (attributed) return becomesSingular || becomesBase;
  const lead = edit.left.trimEnd();
  return (
    becomesSingular && /\b(?:he|she|it|(?:each|every)\s+\p{L}+)$/iu.test(lead) ||
    becomesBase && /\b(?:i|you|we|they)$/iu.test(lead)
  );
}

function coreSkillFor(observation: IssueFirstReportObservation, source: IssueFirstReportObservation["evidence"][number],
  edit: PracticeEdit | null, attributed: boolean): CoreWritingPracticeSkill | null {
  const { issueKind, problem, readerImpact, revisionCue } = observation;
  const description = [problem, readerImpact, revisionCue].filter(Boolean).join(" ");
  if (issueKind === "grammar_construction" && (edit ? isAgreementEdit(edit, attributed) : attributed && !observation.feedback?.replacement) && (
    /\bsubject[\s–—-]+verb[\s–—-]+(?:dis)?agreement\b/iu.test(description) ||
    /\bsubject[\s–—-]+verb[\s–—-]+mismatch\b/iu.test(description) ||
    /\bverb\b[^.!?]{0,25}\bagree\w*[^.!?]{0,25}\bsubject\b/iu.test(description) ||
    /\b(?:match|agree)\w* (?:the )?(?:(?:main|singular|plural) )?verb (?:form )?(?:to|with) (?:(?:the|a|its) )?(?:(?:singular|plural) )?subject\b/iu.test(description) ||
    /\bmatch (?:the )?(?:singular|plural) subjects? (?:and|with) (?:(?:their|the) )?verbs?\b/iu.test(description) ||
    /\b(?:singular|plural) subjects?\b[^.!?]{0,55}\b(?:singular|plural|agree)\w*\b[^.!?]{0,18}\bverb\b/iu.test(description)
  )) return "subject-verb-agreement";
  if (!["clause_connection", "punctuation", "grammar_construction"].includes(issueKind)) return null;
  const { sentence } = source;
  const start = source.start - source.sentenceStart;
  const end = source.end - source.sentenceStart;
  const named = description.match(new RegExp(`[‘“"'](${transitionWords})[’”"']`, "iu"))?.[1].toLowerCase();
  const splice = /\bcomma splice\b/iu.test(description) ||
    (/\b(?:comma alone|only a comma|just a comma|comma by itself|comma (?:cannot|can’t|can't|does not|doesn't) (?:join|connect)|(?:joined|connected|linked) (?:by|with|using) a comma)\b/iu.test(description) &&
      /\b(?:independent clauses?|complete (?:clauses?|sentences?|thoughts?))\b/iu.test(description));
  const commaAfter = /\bcomma (?:right |immediately )?after\b/iu.test(description);
  const missingAfterHowever = commaAfter && /\bhowever\b/iu.test(description);
  for (const boundary of sentence.matchAll(/(^|[,;])\s*([\p{L}]+)\b(?=(,?))/giu)) {
    if (boundary.index >= end || boundary.index + boundary[0].length <= start) continue;
    const [, mark, connector, trailingComma] = boundary;
    const word = connector.toLowerCase();
    const typo = word !== "however" && oneWritingTypo(word, "however");
    if (word !== "however" && !typo) {
      if (new RegExp(`^(?:${transitionWords})$`, "iu").test(word)) return null;
      continue;
    }
    if (named && named !== "however" || typo && !/\bhowever,/iu.test(edit?.revisedSentence ?? "")) return null;
    const next = sentence.slice(boundary.index + boundary[0].length + trailingComma.length).trimStart();
    if (clauseLead.test(next) || !independentStart.test(next) || /^(?:much|many|little|few|hard|long|well|fast)\b/iu.test(next)) return null;
    const initialEdit = !mark && !trailingComma && missingAfterHowever && edit?.left.trim().toLowerCase() === word &&
      edit.before === "" && edit.after === "," && !/^[^.!?]*,/u.test(next) &&
      (identifiableSubject.test(next) || /^\p{L}+ing\s+[^.!?]{1,45}\s(?:is|are|was|were|can|could|will|would|should)\b/iu.test(next));
    if (initialEdit) return "however-contrast";
    if (!attributed && (named !== "however" || !identifiableSubject.test(next) && !(typo && edit))) return null;
    if (mark === "," && (splice || typo && edit?.left.length === boundary.index &&
      /^(?:;|\.)\s+however,$/iu.test(edit.after))) return "however-contrast";
    if (!trailingComma && missingAfterHowever && (mark === ";" || (!mark && /[.!?][^\S\n]*$/u.test(source.before)))) return "however-contrast";
    return null;
  }
  if (!splice || named || clauseLead.test(sentence.trimStart())) return null;
  // A comma elsewhere in the sentence does not ground a comma-splice finding.
  for (const mark of sentence.matchAll(/,\s*/gu)) {
    if (mark.index >= end || mark.index + mark[0].length < start) continue;
    const left = sentence.slice(0, mark.index).trim();
    const next = sentence.slice(mark.index + mark[0].length);
    if (!/\p{L}\s+\p{L}/u.test(left) || !independentStart.test(next) || coordination.test(next) || clauseLead.test(next) ||
      new RegExp(`^(?:${transitionWords})\\b`, "iu").test(next)) continue;
    if (attributed && !observation.feedback?.replacement && subjectPronoun.test(next)) return "comma-splice";
    if (edit?.left.length !== mark.index || (!attributed && !identifiableSubject.test(next))) continue;
    if (edit.before === "," && /^(?:[.;—]|,\s*(?:and|but|nor|or|so|yet))$/iu.test(edit.after)) return "comma-splice";
    const beforeSubject = edit.before.match(/^,\s*(\p{L}+)$/u)?.[1];
    const afterSubject = edit.after.match(/^\.\s*(\p{L}+)$/u)?.[1];
    if (beforeSubject && beforeSubject.toLowerCase() === afterSubject?.toLowerCase()) return "comma-splice";
  }
  return null;
}

export function getWritingPracticeRecommendations(
  report: DiagnosticReport,
  originalText: string,
  revisionCheck?: WritingRevisionCheck | null,
): WritingPracticeRecommendation[] {
  const revisionItems = revisionCheck?.originalId === report.submissionId ? revisionCheck.items : [];
  return (report.issueFirstObservations ?? []).flatMap((observation, observationIndex) => {
    const { attribution, evidence: [source], feedback, kind } = observation;
    if (kind !== "problem" || (feedback?.category !== "mistake" && feedback?.category !== "clarity") ||
      !source || !observation.evidence.every((anchor) => validSource(originalText, report.submissionId, anchor))) return [];
    const attributed = attribution.certainty === "clear";
    const edit = practiceEdit(source, feedback.replacement);
    const core = feedback.category === "mistake" ? coreSkillFor(observation, source, edit, attributed) : null;
    const exactUnattributedEdit = !!edit && feedback.category === "mistake" && attribution.primary === null;
    const matches = core ? [] : expandedPracticeObjectives.filter((objective) =>
      (attributed || exactUnattributedEdit && objective.verifiesUnattributedEdit) && objective.matches({ observation, source, edit }));
    const objective = matches.length === 1 ? matches[0] : undefined;
    const lesson = core ? { skill: core, title: titles[core], label: labels[core] }
      : objective ? { skill: `local:${objective.id}` as const, title: objective.title, label: objective.label } : null;
    if (!lesson) return [];
    const checked = revisionItems.find(({ id, before, after, status }) =>
      id === observationIndex && before === source.exact && (status === "uncertain" || !!after?.trim()));
    return [{
      observationIndex,
      ...lesson,
      quote: source.exact,
      reason: { en: observation.readerImpact, vi: feedback.vi.readerImpact },
      category: feedback.category,
      revisionStatus: checked?.status ?? null,
    }];
  });
}


type AgreementExercise = PracticePrompt & { format: "verb"; verb: string; inflected: string; singular: boolean };
type ClauseExercise = PracticePrompt & { format: "join" };
export type WritingPracticeExercise = AgreementExercise | ClauseExercise | (PracticePrompt & { format: "however" | "phrase" });

function agreementExercise(id: string, before: string, after: string, verb: string, inflected: string, singular: boolean): AgreementExercise {
  return {
    id, format: "verb", before, after, verb, inflected, singular,
    prompt: {
      en: `Fill in the present-simple form of “${verb}”.`,
      vi: `Điền dạng hiện tại đơn của “${verb}”.`,
    },
    hint: {
      en: "Find the subject. Most present-simple verbs add an -s ending with he, she, it, or a singular noun. Plural nouns use the base form.",
      vi: "Tìm chủ ngữ của câu. Ở thì hiện tại đơn, phần lớn động từ thêm đuôi -s với he, she, it hoặc danh từ số ít. Với danh từ số nhiều, dùng dạng nguyên mẫu.",
    },
  };
}

function clauseExercise(id: string, before: string, after: string): ClauseExercise {
  return {
    id, format: "join", before, after,
    prompt: {
      en: "Add punctuation or a connecting word between the two thoughts.",
      vi: "Điền dấu câu hoặc từ nối giữa hai vế.",
    },
    hint: {
      en: "Each thought could stand alone. Try a full stop, a semicolon, or a comma with a word showing how they connect.",
      vi: "Mỗi vế đều có thể đứng riêng. Thử dùng dấu chấm, dấu chấm phẩy hoặc dấu phẩy kèm một từ nối phù hợp.",
    },
  };
}

const agreements = [
  agreementExercise("brother-need", "My younger brother", "more sleep.", "need", "needs", true),
  agreementExercise("neighbors-share", "My neighbors", "the driveway.", "share", "shares", false),
  agreementExercise("nurse-carry", "Each nurse", "a radio on shift.", "carry", "carries", true),
];
const clauses = [
  clauseExercise("late-bus", "The bus was late", "I called my manager."),
  clauseExercise("full-library", "The library was full", "we studied outside."),
  clauseExercise("flooded-field", "Rain flooded the field", "the coach canceled practice."),
];
const howeverExercises = getWritingHoweverExercises().map((exercise) => ({ ...exercise, format: "however" as const }));

export function getWritingPracticeExercises(skill: WritingPracticeSkill): readonly WritingPracticeExercise[] {
  switch (skill) {
    case "however-contrast": return howeverExercises;
    case "subject-verb-agreement": return agreements;
    case "comma-splice": return clauses;
    default: return getExpandedPracticeObjective(skill)?.scenarios.map(({ guided }, index) => ({
      id: expandedPracticeId(skill, index), format: "phrase", before: guided.before, after: guided.after,
      prompt: guided.prompt, hint: guided.hint, context: guided.context,
    })) ?? [];
  }
}

const transferAgreement: Copy = {
  en: "In your next essay, read one subject and its verb together.",
  vi: "Trong bài viết tiếp theo, hãy đọc thử một chủ ngữ cùng với động từ của nó.",
};
const transferClauses: Copy = {
  en: "At your next comma, check whether each side could stand on its own.",
  vi: "Khi dùng dấu phẩy, thử xem mỗi vế có thể đứng riêng thành câu không.",
};

function checkAgreement(exercise: AgreementExercise, answer: string): WritingPracticeResult {
  const { before: subject, verb, inflected, singular } = exercise;
  const correct = singular ? inflected : verb;
  const opposite = singular ? verb : inflected;
  const aux = answer === "do " + verb || answer === "do not " + verb || answer === "don't " + verb ? "do"
    : answer === "does " + verb || answer === "does not " + verb || answer === "doesn't " + verb ? "does" : null;
  if (answer === correct || aux === (singular ? "does" : "do")) return {
    status: "successful",
    feedback: {
      en: `“${subject}” is ${singular ? "singular" : "plural"}. Your verb agrees with it.`,
      vi: `“${subject}” là chủ ngữ ${singular ? "số ít" : "số nhiều"}, và động từ bạn điền đã khớp với chủ ngữ này.`,
    },
    nextStep: transferAgreement,
  };
  if (answer === opposite || aux) return {
    status: "revise",
    feedback: {
      en: `“${subject}” is ${singular ? "singular" : "plural"}. How does that change the verb?`,
      vi: `“${subject}” là chủ ngữ ${singular ? "số ít" : "số nhiều"}. Bạn thử xem động từ cần đổi thế nào.`,
    },
    nextStep: { en: "Change just the verb in the blank.", vi: "Chỉ cần sửa động từ trong ô trống." },
  };
  return {
    status: "unverified",
    feedback: { en: `Use a present-simple form of “${verb}”.`, vi: `Hãy dùng dạng hiện tại đơn của “${verb}”.` },
    nextStep: { en: "The rest of the sentence is already filled in.", vi: "Các phần còn lại của câu đã có sẵn." },
  };
}

/** The curated plain-splice examples express a result or sequence. Keep both propositions intact. */
export function formatCoreClauseJunction(answer: string, subject?: string): string | null {
  const stop = /^([.;–—])\s*(.*)$/u.exec(answer);
  if (stop) {
    const [, mark, tail] = stop;
    const originalSubject = subject?.toLowerCase();
    const connector = tail === originalSubject ? "" : originalSubject && tail.endsWith(` ${originalSubject}`)
      ? tail.slice(0, -originalSubject.length).trimEnd() : tail;
    if (connector && !/^(?:therefore,|consequently,|as a result,|so|and)$/u.test(connector)) return null;
    if (connector && ((mark === ";" && !connector.endsWith(",")) || mark === "–" || mark === "—")) return null;
    const first = connector || subject || "";
    const written = mark === "." ? first.charAt(0).toUpperCase() + first.slice(1) : first;
    const boundary = mark === "—" || mark === "–" ? ` ${mark}` : mark;
    return boundary + (written ? ` ${written}` : "") + (connector && subject ? ` ${subject}` : "");
  }
  const join = /^(?:,\s*)?(so|and)(?:\s+([a-z]+))?$/u.exec(answer);
  if (join && (!join[2] || join[2] === subject?.toLowerCase())) return `, ${join[1]}` + (subject ? ` ${subject}` : "");
  return null;
}

function checkClauses(answer: string): WritingPracticeResult {
  const corrected = formatCoreClauseJunction(answer);
  if (corrected) return {
    status: "successful",
    answer: corrected.trim(),
    feedback: { en: "You gave the two complete thoughts a clear connection or break.",
      vi: "Bạn đã nối hai vế rõ ràng hoặc dùng dấu câu để tách hai vế." },
    nextStep: transferClauses,
  };
  const commaOnly = answer === "," || /^,\s*(?:however|therefore|instead|nevertheless|as a result|consequently),?$/u.test(answer);
  return {
    status: commaOnly ? "revise" : "unverified",
    feedback: commaOnly ? { en: "Each side can stand alone. A comma by itself does not connect them.",
      vi: "Mỗi vế đều có thể đứng riêng. Chỉ dùng dấu phẩy thì chưa đủ để nối hai vế." }
      : { en: "Try punctuation or a connecting word that fits between these thoughts.",
        vi: "Thử điền dấu câu hoặc từ nối phù hợp vào giữa hai vế." },
    nextStep: { en: "Use the blank for the connection only.", vi: "Chỉ điền phần nối vào ô trống." },
  };
}

export function checkWritingPracticeAttempt(exerciseId: string, answer: string, after = ""): WritingPracticeResult | null {
  if (!answer.trim() || answer.length > writingPracticeAnswerLimit) return null;
  const assigned = getExpandedPracticeScenario(exerciseId);
  if (assigned) {
    const { objective, scenario: { guided } } = assigned;
    const result = checkPracticeChoice(guided, answer);
    return { ...result, nextStep: result.status === "successful" ? objective.takeaway : result.status === "unverified" ? guided.hint : {
      en: "Try the blank again with that clue in mind.", vi: "Dựa vào gợi ý này, hãy thử điền lại.",
    } };
  }
  const normalized = answer.trim().toLowerCase().replace(/[’‘]/gu, "'").replace(/\s+/gu, " ");
  const agreement = agreements.find(({ id }) => id === exerciseId);
  if (agreement) return checkAgreement(agreement, normalized);
  if (clauses.some(({ id }) => id === exerciseId)) return checkClauses(normalized);
  return checkWritingHoweverAttempt(exerciseId, { before: answer, after });
}
