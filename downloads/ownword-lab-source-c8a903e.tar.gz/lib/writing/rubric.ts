import { diagnosticBlueprint } from "./prompt-bank";
import { writingRegistry } from "./registry";

export const PILOT_SKILL_IDS = [
  "ARG.SUPPORT",
  "ORG.PROGRESSION",
  "LEX.PRECISION",
  "GRAM.ACCURACY",
] as const;
export type PilotSkillId = (typeof PILOT_SKILL_IDS)[number];

export const DIAGNOSTIC_RUBRIC_VERSION = "diagnostic-v3";
export const TASK_FULFILLMENT_ID = "TASK.FULFILLMENT";

export const diagnosticSkillRules = {
  "ARG.SUPPORT": {
    minimumSpans: 1,
    minimumWordsPerSpan: 1,
    opportunity: "The task asks for reasons and the response gives a position or claim and enough context to assess a specific reason or example.",
    focus: "Check whether a stated reason or example genuinely supports the claim. If clarifying a word leaves the reason irrelevant, circular, or without a defensible link, assess support and explain what link or reasoning must change. Precise details can be irrelevant. Do not call a relevant and interpretable reason unsupported solely because it contains vague or mistaken wording. Use the task check for omitted requirements. Do not fact-check outside the brief.",
  },
  "ORG.PROGRESSION": {
    minimumSpans: 2,
    minimumWordsPerSpan: 2,
    opportunity: "At least three connected propositions or more than one substantive paragraph provide a sequence to assess.",
    focus: "Look at the actual order of ideas and cite distinct parts of the sequence. A short single paragraph can progress clearly. Do not require transitions or criticize a connector, isolated syntax or grammar error as organization.",
  },
  "LEX.PRECISION": {
    minimumSpans: 1,
    minimumWordsPerSpan: 1,
    opportunity: "The writer's meaning and the word's context are clear enough to assess whether the word fits.",
    focus: "Assess a specific word or short phrase whose intended meaning is clear in context. Flag it when a local wording change would make the intended meaning clearer or more accurate without adding a new reason. Accept ordinary words and valid styles. If the reasoning itself supplies no concrete idea, do not guess the writer's meaning or relabel that gap as imprecise vocabulary. Exclude spelling and grammar.",
  },
  "GRAM.ACCURACY": {
    minimumSpans: 2,
    minimumWordsPerSpan: 2,
    opportunity: "The response has a construction that clearly shows an assessable grammatical feature, such as agreement, tense, articles or prepositions.",
    focus: "For a local grammatical error, identify the specific construction and its effect, even when only one clear span is available. For positive or mixed grammar feedback, cite at least two distinct constructions of the same feature. Never infer a recurring weakness or consistent proficiency from one response. Respect standard regional variation and exclude stylistic polish and spelling preferences.",
  },
} satisfies Record<PilotSkillId, {
  minimumSpans: 1 | 2;
  minimumWordsPerSpan: 1 | 2;
  opportunity: string;
  focus: string;
}>;

const skills = PILOT_SKILL_IDS.map((id) => {
  const registrySkill = writingRegistry.trainable_skills.find((entry) => entry.id === id);
  if (!registrySkill?.eligible_practice_formats.includes(diagnosticBlueprint.format)) {
    throw new Error(`Ineligible Writing skill in the diagnostic rubric: ${id}.`);
  }
  return { ...registrySkill, id, ...diagnosticSkillRules[id] };
});
const taskCheck = writingRegistry.internal_checks.find(({ id }) => id === TASK_FULFILLMENT_ID);
if (!taskCheck) throw new Error("The Writing rubric requires the task-fulfillment check.");

export const diagnosticRubric = {
  version: DIAGNOSTIC_RUBRIC_VERSION,
  scope: "Describe evidence in this response. Allow abstention. Do not infer persistent strengths, weaknesses, levels or scores. Positive findings and a result with zero criticism are valid.",
  skills,
  taskCheck: {
    ...taskCheck,
    requirements: diagnosticBlueprint.requirements,
    instructions: "Assess each explicit requirement separately from language and argument quality. Accept a clear implicit recommendation or a clear choice under stated conditions. When the response weighs options without a discernible choice, use undetermined for the position. Use partly_met only for one of two reasons. Quote the material that supports met or partly_met. Use missing with no quote only when the requirement is clearly absent from the entire response. When uncertain, use undetermined.",
  },
} as const;
