import { z } from "zod";
import { diagnosticOutputJsonSchema, type DiagnosticSubmission } from "./contracts";
import { validateWritingDiagnostic, type DiagnosticRejection } from "./evidence";
import { prepareWritingEvaluationInput, type WritingEvaluation } from "./openrouter-evaluator";

export type LunaInferenceProfile = "global.openai.gpt-6-luna" | "us.openai.gpt-6-luna";
export const lunaWritingMaxOutputTokens = 2400;

// Keep the canonical schema authoritative. These wire omissions are still enforced locally.
const unsupportedKeywords = new Set(["$schema", "minimum", "maximum", "multipleOf", "minLength", "maxLength", "maxItems"]);
function toBedrockSchema(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(toBedrockSchema);
  if (value === null || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !unsupportedKeywords.has(key))
    .map(([key, child]) => [key, toBedrockSchema(child)]));
}
const bedrockSchema = JSON.stringify(toBedrockSchema(diagnosticOutputJsonSchema));

export function prepareBedrockWritingRequest(submission: DiagnosticSubmission, profile: LunaInferenceProfile) {
  if (profile !== "global.openai.gpt-6-luna" && profile !== "us.openai.gpt-6-luna") {
    throw new Error("A pinned GPT‑6 Luna Runtime inference profile is required.");
  }
  const { instructions, input } = prepareWritingEvaluationInput(submission);
  return {
    modelId: profile,
    system: [{ text: instructions }],
    messages: [{ role: "user" as const, content: [{ text: JSON.stringify({ input }) }] }],
    inferenceConfig: { maxTokens: lunaWritingMaxOutputTokens },
    outputConfig: {
      textFormat: {
        type: "json_schema" as const,
        structure: { jsonSchema: { name: "ownword_writing_diagnostic_v2", schema: bedrockSchema } },
      },
    },
    additionalModelRequestFields: { text: { format: { strict: true } }, reasoning: { effort: "none" } },
  };
}

const tokenCount = z.int().nonnegative();
const usageSchema = z.object({ inputTokens: tokenCount, outputTokens: tokenCount });
const outputSchema = z.object({
  stopReason: z.string(),
  output: z.object({
    message: z.object({
      role: z.literal("assistant"),
      content: z.array(z.object({ text: z.string().optional() })),
    }),
  }),
});

type Converse = (request: ReturnType<typeof prepareBedrockWritingRequest>) => Promise<unknown>;
type BedrockWritingEvaluation = Exclude<WritingEvaluation, { status: "request_failed" }>
  | { status: "request_failed"; reason: "converse"; telemetry: WritingEvaluation["telemetry"] };

/** For local synthetic evaluation only. The caller supplies the pinned, single-attempt Converse transport. */
export function createBedrockWritingEvaluator(profile: LunaInferenceProfile, converse: Converse) {
  return async (
    submission: DiagnosticSubmission, onRejection?: (rejection: DiagnosticRejection) => void,
  ): Promise<BedrockWritingEvaluation> => {
    const request = prepareBedrockWritingRequest(submission, profile);
    const start = performance.now();
    const elapsed = () => Math.round(performance.now() - start);
    let response: unknown;
    try {
      response = await converse(request);
    } catch {
      return { status: "request_failed", reason: "converse", telemetry: { model: profile, latencyMs: elapsed() } };
    }
    const usage = z.object({ usage: usageSchema }).safeParse(response);
    const telemetry = { model: profile, latencyMs: elapsed(), ...(usage.success ? usage.data.usage : {}) };
    const parsed = outputSchema.safeParse(response);
    if (!usage.success || !parsed.success) return { status: "invalid_response", reason: "envelope", telemetry };

    const { stopReason, output } = parsed.data;
    const [block] = output.message.content;
    if (stopReason !== "end_turn" || output.message.content.length !== 1 || !block?.text) {
      return { status: "invalid_response", reason: "incomplete", telemetry };
    }

    let proposal: unknown;
    try {
      proposal = JSON.parse(block.text);
    } catch {
      return { status: "invalid_response", reason: "invalid_json", telemetry };
    }
    return { status: "evaluated", validation: validateWritingDiagnostic(submission, proposal, onRejection), telemetry };
  };
}
