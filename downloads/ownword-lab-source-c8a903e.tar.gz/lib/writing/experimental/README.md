# Issue-first Writing evaluator candidate

The local Writing pilot imports this candidate through `lib/writing/issue-first-pilot.ts` only when the development-only feature flag is enabled. Production composition remains on its existing evaluator. See `docs/WRITING_ISSUE_FIRST_PILOT.md` for the learner preview.

`issue-first.ts` accepts the current `{ submissionId, promptId, text }` input and uses the same prompt bank, four broad skills, task checks, exact quote anchors, strict OpenRouter JSON schema, pinned provider controls, and three-item learner-facing selection limit as the frozen evaluator. The system instructions put problem identification and reader impact before optional skill attribution. Raw proposals remain available through the callback so an experiment can score issue detection separately from accepted feedback and classification.

```ts
const evaluate = createIssueFirstWritingEvaluator(key, model, fetch, {
  endpoint: "azure/us",
  provider: "Azure",
  maxTokens: 2400,
  completionTokenField: "max_completion_tokens",
  maxPricePerMillion: { prompt: 0.11, completion: 0.55 },
  reasoningEffort: "medium",
});
const result = await evaluate({ submissionId, promptId, text }, (raw) => saveResearchProposal(raw));
```

Run the isolated offline checks with:

```sh
npx esbuild tests/writing-issue-first.experimental.test.ts --bundle --platform=node --format=esm --target=node22 --outfile=.sites-runtime/tests/writing-issue-first.experimental.test.mjs
node --test .sites-runtime/tests/writing-issue-first.experimental.test.mjs
```

The validator checks schema, source anchors, task-check evidence, relational evidence spans, attribution shape, duplicate observations, opportunity, and the three-item limit. Invalid skill attribution is withheld and reported in `attributionWarnings`; it does not discard otherwise grounded feedback. These are **structural** checks. It cannot establish whether an observation is true, a repair preserves meaning, or a profile pattern is warranted. `profileEvidenceCandidate` is only an offline candidate flag and does not write to any profile.
