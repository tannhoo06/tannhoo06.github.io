export const discussionPrompts = [
  {
    id: "group-chat-expectations",
    interestIds: ["technology", "relationships"],
    title: "Pressure to reply",
    scenario: "Group chats help friends stay in touch, but people can feel pressured to reply quickly. What should friends expect from each other in a group chat?",
  },
  {
    id: "recorded-lectures",
    interestIds: ["work_study"],
    title: "Recorded or in-person lectures?",
    scenario: "When a university records a lecture, should students be free to watch it later instead of attending in person?",
  },
  {
    id: "reviews-before-films",
    interestIds: ["creativity"],
    title: "Read the reviews first?",
    scenario: "Reviews can help people choose a film, but they can also shape what people notice. Does reading reviews before watching a film improve the experience?",
  },
  {
    id: "choice-in-physical-education",
    interestIds: ["health_movement"],
    title: "More choice in PE",
    scenario: "In school physical education, should the whole class do the same activity or should students choose how they exercise?",
  },
  {
    id: "sharing-quiet-places",
    interestIds: ["travel"],
    title: "Share a quiet spot online?",
    scenario: "An online post can make a quiet place popular with visitors. When is sharing a spot worth it, and when might it be better to keep it private?",
  },
  {
    id: "repair-before-replacing",
    interestIds: ["daily_life", "community_environment"],
    title: "Repair or replace?",
    scenario: "When something at home breaks, does trying to repair it first usually make sense? What would change your answer?",
  },
  {
    id: "music-while-studying",
    interestIds: [],
    title: "Music while studying",
    scenario: "Music can make studying more enjoyable, but it can also take attention away from the work. When, if ever, is listening to music while studying a good idea?",
  },
  {
    id: "fair-group-plans",
    interestIds: [],
    title: "A fair way to make plans",
    scenario: "When friends choose what to do together, is it fairer to find something everyone likes or take turns picking?",
  },
] as const;

export type DiscussionPromptId = typeof discussionPrompts[number]["id"];
