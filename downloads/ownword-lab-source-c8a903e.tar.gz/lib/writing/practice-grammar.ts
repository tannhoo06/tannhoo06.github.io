import type { PracticeObjective } from "./practice-objective";

type GrammarEdit = { from: string; to: string; left: string; right: string };
type Copy = PracticeObjective["title"];

// Reliable sound cases and common named exceptions only. Initialisms, names, numbers and regional “an historic” stay unclassified.
const vowelSound = new Set([
  "apple", "animal", "answer", "appointment", "article", "artist", "average", "easy", "egg", "empty",
  "elephant", "engine", "engineer", "english", "enormous", "excellent", "example", "eye", "idea", "important", "impossible", "interesting",
  "invitation", "old", "orange", "ordinary", "outdoor", "umbrella", "unusual", "uncomfortable", "unfair", "unexpected", "honest", "hour", "hourly", "heir",
]);
const consonantSound = new Set([
  "backpack", "band", "book", "bus", "car", "chair", "class", "coat", "course", "desk", "doctor", "game", "group", "home", "house",
  "meeting", "minute", "new", "nice", "phone", "picture", "plan", "rainy", "room", "school", "small", "student", "teacher", "trip", "village",
  "way", "week", "one", "european", "uniform", "university", "unique", "unit", "useful", "usual", "used",
]);

function isArticleEdit({ from, to, right }: GrammarEdit) {
  if (!/^(a|an)$/u.test(from) || !/^(a|an)$/u.test(to) || from === to) return false;
  const word = right.trimStart().match(/^\p{L}+(?![\p{L}\p{N}-])/u)?.[0];
  if (!word || /^[A-Z]{2,}$/u.test(word)) return false;
  const normalized = word.toLowerCase();
  return to === "an" ? vowelSound.has(normalized) : consonantSound.has(normalized);
}

const pastForms: Record<string, readonly string[]> = {
  built: ["build", "builds", "have built", "has built"], brought: ["bring", "brings", "have brought", "has brought"],
  decided: ["decide", "decides", "have decided", "has decided"],
  asked: ["ask", "asks"], bought: ["buy", "buys", "have bought", "has bought"], called: ["call", "calls", "have called", "has called"],
  came: ["come", "comes", "have come", "has come"], caught: ["catch", "catches", "have caught", "has caught"],
  chose: ["choose", "chooses", "have chosen", "has chosen"], did: ["do", "does", "have done", "has done"],
  ate: ["eat", "eats", "have eaten", "has eaten"], ended: ["end", "ends"], felt: ["feel", "feels", "have felt", "has felt"],
  found: ["find", "finds", "have found", "has found"], gave: ["give", "gives", "have given", "has given"],
  got: ["get", "gets"], heard: ["hear", "hears", "have heard", "has heard"], helped: ["help", "helps"],
  left: ["leave", "leaves", "have left", "has left"], lost: ["lose", "loses", "have lost", "has lost"],
  made: ["make", "makes", "have made", "has made"], met: ["meet", "meets", "have met", "has met"], opened: ["open", "opens"],
  played: ["play", "plays", "have played", "has played"], saw: ["see", "sees", "have seen", "has seen"], sent: ["send", "sends", "have sent", "has sent"],
  spoke: ["speak", "speaks", "have spoken", "has spoken"], started: ["start", "starts"], stayed: ["stay", "stays"],
  took: ["take", "takes", "have taken", "has taken"], told: ["tell", "tells", "have told", "has told"],
  used: ["use", "uses"], visited: ["visit", "visits", "have visited", "has visited"], waited: ["wait", "waits"],
  walked: ["walk", "walks"], went: ["go", "goes", "have gone", "has gone"], worked: ["work", "works"],
  wrote: ["write", "writes", "have written", "has written"],
};

const finishedTime = /\b(?:in (?:19|20)\d{2}|yesterday(?: morning| afternoon| evening)?|last (?:night|week|month|year|summer|winter|spring|fall|autumn|semester|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)|(?:\d+|one|two|three|four|five|six|seven) (?:hours?|days?|weeks?|months?|years?) ago)\b(?![’'])/iu;

function isPastForm(from: string, to: string) {
  if (Object.hasOwn(pastForms, to) && pastForms[to].includes(from)) return true;
  if (!/^[a-z]{3,}$/u.test(from) || !/^[a-z]+ed$/u.test(to)) return false;
  const stem = to.slice(0, -2);
  const base = [stem, `${stem}e`, stem.endsWith("i") ? `${stem.slice(0, -1)}y` : "",
    /([^aeiou])\1$/u.test(stem) ? stem.slice(0, -1) : ""];
  return base.some((word) => word && (from === word || from === `${word}s` || from === `${word}es` ||
    word.endsWith("y") && from === `${word.slice(0, -1)}ies`));
}

function isFinishedPast({ from, to, left, right }: GrammarEdit, note: string) {
  if (!/\b(?:past|tense)\b/iu.test(note)) return false;
  const sameParticiple = !to && /^ha(?:ve|s)$/u.test(from) && right.trimStart().match(/^\p{L}+/u)?.[0];
  const past = sameParticiple ? sameParticiple.toLowerCase() : to;
  const originalWords = from.match(/[a-z]+/gu) ?? [];
  const revisedWords = to.match(/[a-z]+/gu) ?? [];
  const pairedEdits = originalWords.length > 1 && originalWords.length === revisedWords.length &&
    originalWords.some((word, index) => word !== revisedWords[index]) &&
    originalWords.every((word, index) => word === revisedWords[index] || isPastForm(word, revisedWords[index]));
  if (!isPastForm(sameParticiple ? `${from} ${past}` : from, past) && !pairedEdits) return false;
  const sentence = `${left} ${from} ${right}`;
  const time = finishedTime.exec(sentence);
  if (!time) return false;
  const beforeTime = sentence.slice(0, time.index).trimEnd();
  const afterTime = sentence.slice(time.index + time[0].length);
  // A time expression inside a noun phrase does not date the verb: “I see the notice from yesterday.”
  const datesVerb = beforeTime.length === 0 ||
    finishedTime.test(right) && !/\b(?:from|dated|issued|in|of|for|until|by|since)\s*$/iu.test(beforeTime) &&
    /^[\s.!?]*$/u.test(afterTime) && !/\b(?:and|or|but)\b/iu.test(right);
  // Leave subordinate, habitual, future, and since/until readings to feedback.
  const datedNarration = beforeTime.length === 0 && /^in (?:19|20)\d{2}\b/iu.test(time[0]);
  return datesVerb && (datedNarration
    ? !/\b(?:since|until|tomorrow|next|every year|always)\b/iu.test(sentence)
    : !/\b(?:when|whenever|while|since|until|after|before|because|although|if|unless|every|usually|often|always|tomorrow|next|whether)\b/iu.test(sentence) &&
      !/\b(?:that|(?:I|you|he|she|we|they)\s+\p{L}+)\b/iu.test(right));
}

type PrepositionPattern = { id: string; before: RegExp; from: readonly string[]; to: readonly string[]; after?: RegExp };

const contextualPrepositions = [
  { id: "depend-on", before: /\bdepend(?:s|ed|ing)?\s*$/iu, from: ["of"], to: ["on", "upon"], after: /^(?!\s*course\b)/iu },
  { id: "interested-in", before: /\b(?:am|is|are|was|were|be|been|[’'](?:m|s|re)|became)\s+(?:(?:quite|very|really)\s+)?interested\s*$/iu,
    from: ["on"], to: ["in"],
    after: /^\s*(?:learning|joining|making|building|working|studying|practi[cs]ing|writing|reading|helping|volunteering|travel[l]?ing|nature|history|science|photography|astronomy|(?:the|this)\s+(?:club|project|book|article|subject|topic))\b/iu },
  { id: "listen-to", before: /\blisten(?:s|ed|ing)?\s*$/iu, from: ["", "of"], to: ["to"],
    after: /^\s*(?:me|us|him|her|them|music|(?:the|a|an|my|your|our)\s+(?:speaker|music|song|podcast|teacher|story|radio|lecture))\b/iu },
  { id: "wait-for", before: /\bwait(?:s|ed|ing)?\s*$/iu, from: ["", "to"], to: ["for"],
    after: /^\s*(?:me|us|you|him|her|them)(?=\s*(?:[.!?,;:]|$)|\s+(?:to|at|in|by|outside|inside)\b)/iu },
] as const satisfies readonly PrepositionPattern[];

function usesEnjoyGerund({ from, to, left }: GrammarEdit) {
  const verb = /^to ([a-z]{2,})$/u.exec(from)?.[1];
  if (!verb || !/\benjoy(?:s|ed|ing)?\s*$/iu.test(left)) return false;
  return to === `${verb}ing` ||
    verb.endsWith("e") && !/(?:ee|ye|oe|ie)$/u.test(verb) && to === `${verb.slice(0, -1)}ing` ||
    verb.endsWith("ie") && to === `${verb.slice(0, -2)}ying` ||
    (/[aeiou][bdgmnprt]$/u.test(verb) || verb === "travel") && to === `${verb}${verb.at(-1)}ing`;
}

function isDoubleComparative({ from, to, right }: GrammarEdit, note: string) {
  return from === "more" && !to && /\bcomparative\b/iu.test(note) &&
    /^\s*(?:better|easier|safer|faster|shorter|cheaper|quieter|stronger|smaller|larger|longer|colder|warmer)(?=\s*(?:[.!?,;:]|$)|\s+(?:than|to|for|in|with|on|at|because)\b)/iu.test(right);
}

function copy(en: string, vi: string): Copy {
  return { en, vi };
}

type GuidedSeed = { before: string; after: string; answers: readonly string[]; incorrect?: readonly string[]; prompt?: Copy };
type RepairSeed = { parts: readonly string[]; target: number; answers: readonly string[]; incorrect?: readonly string[] };

function scenarios(prompt: Copy, hint: Copy, explanation: Copy, pairs: readonly [GuidedSeed, RepairSeed][]) {
  return pairs.map(([guided, repair]) => ({
    guided: { ...guided, prompt: guided.prompt ?? prompt, hint, explanation },
    repair: { ...repair, hint, explanation },
  }));
}

type Diagnosis = Parameters<PracticeObjective["matches"]>[0];

function grammarMatch(diagnosis: Diagnosis, test: (edit: GrammarEdit, note: string) => boolean, preposition = false) {
  const { observation, edit } = diagnosis;
  if (!edit || observation.kind !== "problem" || observation.feedback?.category !== "mistake") return false;
  const note = [observation.problem, observation.readerImpact, observation.revisionCue].filter(Boolean).join(" ");
  if (observation.issueKind !== "grammar_construction" && !(preposition && /\bpreposition\b/iu.test(note) && observation.issueKind === "word_meaning_or_fit")) return false;
  return test({ from: edit.before.trim().toLowerCase(), to: edit.after.trim().toLowerCase(), left: edit.left, right: edit.right }, note);
}

const articleExplanation = copy("Choose ‘a’ or ‘an’ from the first sound of the word that follows.",
  "Chọn ‘a’ hay ‘an’ theo âm đầu của từ đứng ngay sau.");
const article = {
  id: "article-sound",
  title: copy("Choose ‘a’ or ‘an’ by sound", "Chọn ‘a’ hoặc ‘an’ theo âm đầu"),
  label: copy("Practice ‘a’ and ‘an’", "Luyện dùng ‘a’ và ‘an’"),
  verifiesUnattributedEdit: true,
  matches: (diagnosis) => grammarMatch(diagnosis, isArticleEdit),
  takeaway: copy("Say the next word aloud. ‘Hour’ starts with a vowel sound, while ‘university’ starts with a ‘y’ sound.",
    "Hãy đọc từ kế tiếp thành tiếng. ‘Hour’ bắt đầu bằng âm nguyên âm, còn ‘university’ bắt đầu bằng âm giống ‘y’."),
  scenarios: scenarios(
    copy("Fill in ‘a’ or ‘an’.", "Điền ‘a’ hoặc ‘an’."),
    copy("Say the following word aloud and listen to its first sound.", "Đọc thành tiếng từ đứng sau và để ý âm đầu."), articleExplanation,
    [
      [{ before: "We waited", after: "hour before the doors opened.", answers: ["an"], incorrect: ["a"] },
        { parts: ["She gave", " a", " honest answer", " to the question."], target: 1, answers: ["an"], incorrect: ["a"] }],
      [{ before: "My cousin studies at", after: "university near the coast.", answers: ["a"], incorrect: ["an"] },
        { parts: ["The program gave me", " an", " useful way", " to track my progress."], target: 1, answers: ["a"], incorrect: ["an"] }],
      [{ before: "I packed", after: "orange with my lunch.", answers: ["an"], incorrect: ["a"] },
        { parts: ["I found", " a", " empty seat", " near the window."], target: 1, answers: ["an"], incorrect: ["a"] }],
    ],
  ),
} satisfies PracticeObjective;

function pastPrompt(verb: string) {
  return copy(`Use “${verb}” to describe the completed past action.`, `Dùng “${verb}” để kể về việc đã xảy ra.`);
}
const finishedPast = {
  id: "finished-past",
  title: copy("Use the simple past for finished events", "Dùng quá khứ đơn để kể việc đã xảy ra"),
  label: copy("Practice finished past events", "Luyện kể việc trong quá khứ"),
  verifiesUnattributedEdit: true,
  matches: (diagnosis) => grammarMatch(diagnosis, isFinishedPast),
  takeaway: copy("When you describe a completed event, look for a finished time such as ‘yesterday’ or ‘last night’ and check the tense.",
    "Khi kể về một việc đã xảy ra, hãy tìm mốc thời gian như ‘yesterday’ hay ‘last night’ rồi kiểm tra thì của động từ."),
  scenarios: scenarios(
    pastPrompt("go"),
    copy("Look at the time expression. Is the event over?", "Nhìn cụm từ chỉ thời gian. Việc này đã kết thúc chưa?"),
    copy("The time expression points to a completed past event, so the simple past fits.",
      "Cụm từ chỉ thời gian cho biết việc đã xảy ra và đã kết thúc, nên dùng thì quá khứ đơn."),
    [
      [{ before: "Yesterday, Maya", after: "to the market before noon.", answers: ["went", "did go"], incorrect: ["go", "goes", "has gone"] },
        { parts: ["Last night, our neighbor", " takes", " a taxi", " to the station."], target: 1,
          answers: ["took", "did take"], incorrect: ["takes", "take", "has taken"] }],
      [{ before: "We", after: "our grandparents last Sunday.", prompt: pastPrompt("visit"), answers: ["visited", "did visit"], incorrect: ["visit", "have visited"] },
        { parts: ["The class", " watches", " a documentary", " two weeks ago."], target: 1,
          answers: ["watched", "did watch"], incorrect: ["watches", "watch", "has watched"] }],
      [{ before: "Two days ago, I", after: "a fox near the trail.", prompt: pastPrompt("see"), answers: ["saw", "did see"], incorrect: ["see", "seen", "have seen"] },
        { parts: ["We", " have found", " three owl nests", " yesterday."], target: 1,
          answers: ["found", "did find"], incorrect: ["have found", "find", "finds"] }],
    ],
  ),
} satisfies PracticeObjective;

function nounPrompt(noun: string) {
  return copy(`Fill in the correct form of “${noun}”.`, `Điền dạng đúng của “${noun}”.`);
}
const countPlural = {
  id: "count-plural",
  title: copy("Use plural nouns for more than one", "Dùng danh từ số nhiều khi đếm từ hai trở lên"),
  label: copy("Practice plural count nouns", "Luyện danh từ số nhiều"),
  verifiesUnattributedEdit: true,
  matches: (diagnosis) => grammarMatch(diagnosis, isCountNoun),
  takeaway: copy("Find what the quantity counts. When it refers to more than one of a regular count noun, that noun takes the plural ending.",
    "Xác định danh từ đang được đếm. Nếu có hơn một và danh từ theo quy tắc thông thường, hãy dùng dạng số nhiều."),
  scenarios: scenarios(
    nounPrompt("map"), copy("Which noun does the quantity count?", "Từ chỉ số lượng đang đếm danh từ nào?"),
    copy("The quantity refers to more than one, so the count noun needs its plural form.", "Số lượng lớn hơn một, nên danh từ đếm được cần ở dạng số nhiều."),
    [
      [{ before: "The guide handed us three", after: "before we left.", answers: ["maps"], incorrect: ["map", "map's"] },
        { parts: ["We needed two", " ticket", " for the ferry."], target: 1, answers: ["tickets"], incorrect: ["ticket", "ticket's"] }],
      [{ before: "There were four", after: "beside the window.", prompt: nounPrompt("chair"), answers: ["chairs"], incorrect: ["chair"] },
        { parts: ["I bought two", " shirt", " after work."], target: 1, answers: ["shirts"], incorrect: ["shirt", "shirt's"] }],
      [{ before: "The team discussed several", after: "at the meeting.", prompt: nounPrompt("idea"), answers: ["ideas"], incorrect: ["idea"] },
        { parts: ["I have three", " plan", " for the fundraiser."], target: 1, answers: ["plans"], incorrect: ["plan", "plan's"] }],
    ],
  ),
} satisfies PracticeObjective;

function prepositionObjective(
  id: (typeof contextualPrepositions)[number]["id"], expression: string, meaning: Copy, pairs: readonly [GuidedSeed, RepairSeed][],
): PracticeObjective {
  const pattern: PrepositionPattern = contextualPrepositions.find((entry) => entry.id === id)!;
  return {
    id,
    verifiesUnattributedEdit: true,
    title: copy(`Use “${expression}” in context`, `Dùng “${expression}” trong câu`),
    label: copy(`Practice “${expression}”`, `Luyện dùng “${expression}”`),
    matches: (diagnosis) => grammarMatch(diagnosis, ({ from, to, left, right }) =>
      pattern.from.includes(from) && pattern.to.includes(to) && pattern.before.test(left) && (!pattern.after || pattern.after.test(right)), true),
    takeaway: meaning,
    scenarios: scenarios(
      copy("Fill in the preposition.", "Điền giới từ phù hợp."),
      copy("Read the words just before the blank and think about how they relate to what follows.",
        "Đọc cụm từ ngay trước ô trống rồi xem nó liên hệ thế nào với phần đứng sau."),
      meaning, pairs,
    ),
  };
}

const depend = prepositionObjective("depend-on", "depend on",
  copy("Use ‘depend on’ or ‘depend upon’ to name a condition that affects what happens.",
    "Dùng ‘depend on’ hoặc ‘depend upon’ để nêu điều kiện ảnh hưởng đến kết quả."),
  [
    [{ before: "The picnic still depends", after: "the weather.", answers: ["on", "upon"], incorrect: ["of", "in", "to"] },
      { parts: ["Our lunch plans", " depend", " of", " the train schedule."], target: 2, answers: ["on", "upon"], incorrect: ["of", "in", "to"] }],
    [{ before: "The garden depends", after: "regular rainfall.", answers: ["on", "upon"], incorrect: ["of", "in", "to"] },
      { parts: ["The final cost", " depends", " of", " how many people sign up."], target: 2, answers: ["on", "upon"], incorrect: ["of", "in", "to"] }],
    [{ before: "Delivery depends", after: "the address you enter.", answers: ["on", "upon"], incorrect: ["of", "in", "to"] },
      { parts: ["Our travel date", " depends", " of", " when the school closes."], target: 2, answers: ["on", "upon"], incorrect: ["of", "in", "to"] }],
  ],
);

const interested = prepositionObjective("interested-in", "interested in",
  copy("Use ‘interested in’ before a topic or activity that interests someone.",
    "Dùng ‘interested in’ trước chủ đề hoặc hoạt động mà ai đó quan tâm."),
  [
    [{ before: "Rina is interested", after: "learning how to knit.", answers: ["in"], incorrect: ["on", "to"] },
      { parts: ["My neighbor", " is interested", " on", " joining the walking club."], target: 2, answers: ["in"], incorrect: ["on", "to"] }],
    [{ before: "They’re interested", after: "local history.", answers: ["in"], incorrect: ["on", "to"] },
      { parts: ["Our class", " is interested", " on", " volunteering at the library."], target: 2, answers: ["in"], incorrect: ["on", "to"] }],
    [{ before: "I’m interested", after: "photography.", answers: ["in"], incorrect: ["on", "to"] },
      { parts: ["He has always", " been interested", " on", " astronomy."], target: 2, answers: ["in"], incorrect: ["on", "to"] }],
  ],
);

const listen = prepositionObjective("listen-to", "listen to",
  copy("Use ‘listen to’ to name a person, recording or sound you are paying attention to.",
    "Dùng ‘listen to’ trước người, bản ghi âm hoặc âm thanh mà bạn đang lắng nghe."),
  [
    [{ before: "I listen", after: "the radio while I cook.", answers: ["to"], incorrect: ["of"] },
      { parts: ["We listened", " of", " the podcast", " on the way home."], target: 1, answers: ["to"], incorrect: ["of"] }],
    [{ before: "The students listened", after: "the teacher before taking notes.", answers: ["to"], incorrect: ["of"] },
      { parts: ["I listen", " of", " the radio", " on my commute."], target: 1, answers: ["to"], incorrect: ["of"] }],
    [{ before: "At bedtime, we listen", after: "a story to wind down.", answers: ["to"], incorrect: ["of"] },
      { parts: ["My sister listens", " of", " a lecture", " while walking home."], target: 1, answers: ["to"], incorrect: ["of"] }],
  ],
);

const wait = prepositionObjective("wait-for", "wait for",
  copy("Use ‘wait for’ before the person you expect to arrive.", "Dùng ‘wait for’ trước người mà bạn đang chờ đến."),
  [
    [{ before: "Stay here and wait", after: "me to come back.", answers: ["for"], incorrect: ["to", "at"] },
      { parts: ["My family waits", " to", " me", " by the entrance."], target: 1, answers: ["for"], incorrect: ["to", "at"] }],
    [{ before: "We’ll wait", after: "you at the café.", answers: ["for"], incorrect: ["to", "at"] },
      { parts: ["The driver waited", " to", " us", " outside the station."], target: 1, answers: ["for"], incorrect: ["to", "at"] }],
    [{ before: "Malik waited", after: "them by the front door.", answers: ["for"], incorrect: ["to", "at"] },
      { parts: ["Can you wait", " to", " her", " by the ticket desk?"], target: 1, answers: ["for"], incorrect: ["to", "at"] }],
  ],
);

function complementPrompt(verb: string) {
  return copy(`Add the correct form of “${verb}” after ‘enjoy’.`, `Điền dạng đúng của “${verb}” sau ‘enjoy’.`);
}
const enjoy = {
  id: "enjoy-gerund",
  title: copy("Use an -ing verb after ‘enjoy’", "Dùng động từ đuôi -ing sau ‘enjoy’"),
  label: copy("Practice ‘enjoy’ with an activity", "Luyện ‘enjoy’ với hoạt động"),
  verifiesUnattributedEdit: true,
  matches: (diagnosis) => grammarMatch(diagnosis, usesEnjoyGerund),
  takeaway: copy("To name an activity after ‘enjoy’, use the -ing form, as in ‘enjoy reading’.",
    "Khi nêu một hoạt động sau ‘enjoy’, dùng dạng -ing như trong ‘enjoy reading’."),
  scenarios: scenarios(
    complementPrompt("cook"), copy("Here the second verb names the activity you enjoy.", "Động từ thứ hai nêu hoạt động bạn thích làm."),
    copy("A verb after ‘enjoy’ takes the -ing form when it names an activity.", "Sau ‘enjoy’, động từ nêu hoạt động có dạng -ing."),
    [
      [{ before: "I enjoy", after: "dinner for my friends.", answers: ["cooking"], incorrect: ["to cook", "cook"] },
        { parts: ["I enjoy", " to draw", " plants", " in my sketchbook."], target: 1, answers: ["drawing"], incorrect: ["to draw", "draw"] }],
      [{ before: "They enjoy", after: "around the lake on Sundays.", prompt: complementPrompt("walk"), answers: ["walking"], incorrect: ["to walk", "walk"] },
        { parts: ["Dana enjoyed", " to read", " on the train", " each morning."], target: 1, answers: ["reading"], incorrect: ["to read", "read"] }],
      [{ before: "My friends enjoy", after: "by train.", prompt: complementPrompt("travel"), answers: ["traveling", "travelling"], incorrect: ["to travel", "travel"] },
        { parts: ["I enjoy", " to swim", " in the sea", " before breakfast."], target: 1, answers: ["swimming"], incorrect: ["to swim", "swim"] }],
    ],
  ),
} satisfies PracticeObjective;

function comparativePrompt(adjective: string) {
  return copy(`Use the comparative form of “${adjective}”.`, `Dùng dạng so sánh hơn của “${adjective}”.`);
}
const comparative = {
  id: "double-comparative",
  title: copy("Use one comparative form", "Dùng một dạng so sánh hơn"),
  label: copy("Practice comparatives", "Luyện so sánh hơn"),
  verifiesUnattributedEdit: true,
  matches: (diagnosis) => grammarMatch(diagnosis, isDoubleComparative),
  takeaway: copy("Some adjectives already express comparison through ‘-er’ or a word like ‘better’. Those forms do not take ‘more’.",
    "Một số tính từ đã có dạng so sánh hơn nhờ ‘-er’ hoặc dạng riêng như ‘better’. Không cần thêm ‘more’ trước các dạng này."),
  scenarios: scenarios(
    comparativePrompt("easy"),
    copy("Check whether the adjective already expresses the comparison.", "Xem tính từ đã mang ý so sánh hơn chưa."),
    copy("This adjective already expresses the comparison, so it works on its own.", "Tính từ này đã mang ý so sánh hơn, nên có thể dùng trực tiếp."),
    [
      [{ before: "This route is", after: "than the one through town.", answers: ["easier"], incorrect: ["more easier", "easy"] },
        { parts: ["The new bridge", " is", " more safer", " than the old one."], target: 2, answers: ["safer"], incorrect: ["more safer", "safe"] }],
      [{ before: "The express train is", after: "than the bus.", prompt: comparativePrompt("fast"), answers: ["faster"], incorrect: ["more faster", "fast"] },
        { parts: ["The later appointment", " is", " more better", " for our group."], target: 2, answers: ["better"], incorrect: ["more better", "good"] }],
    ],
  ),
} satisfies PracticeObjective;

export const grammarPracticeObjectives: readonly PracticeObjective[] = [
  article, finishedPast, countPlural, depend, interested, listen, wait, enjoy, comparative,
];

const regularPlurals = new Set(["book", "chair", "cup", "dog", "egg", "friend", "game", "hour", "idea", "map", "meeting", "minute", "month",
  "note", "orange", "page", "pen", "photo", "plan", "room", "shirt", "song", "student", "table", "teacher", "ticket", "week", "word", "year"]);

function isCountNoun({ from, to, left, right }: GrammarEdit, note: string) {
  if (!/\bplural\b/iu.test(note) || !regularPlurals.has(from) || to !== from + "s") return false;
  if (!/\b(?:two|three|four|five|six|seven|eight|nine|ten|several|many|[2-9]|[1-9][0-9]+)\s*$/iu.test(left)) return false;
  // A noun before another noun can instead be a valid singular modifier, as in “two book covers”.
  return /^\s*(?:[.!?,;:]|$|(?:in|on|at|for|with|from|to|near|under|beside|by|were|are|have|had|can|will)\b)/iu.test(right);
}
