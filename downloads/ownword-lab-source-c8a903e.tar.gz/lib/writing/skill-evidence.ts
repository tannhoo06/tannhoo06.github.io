import type { SourceAnchor } from "../domain/types";
import type { WritingSkillTargetId } from "./skill-verification";

type Range = { start: number; end: number };
type Token = Range & { word: string };
type Polarity = "correct" | "incorrect";
type AnchorContext = { text?: string; focus?: Range };

const agreementSubjects = new Set("he she it everyone everybody someone somebody nobody anyone anybody everything something nothing".split(" "));
const otherSubjects = new Set("i you we they there".split(" "));
const determiners = new Set("a an the this that each every one another my your his her its our their".split(" "));
const pluralDeterminers = new Set("these those some most several many two three four both".split(" "));
const pluralNouns = new Set("people men women children teeth feet mice geese lice oxen police cattle".split(" "));
const ambiguousHeads = new Set("team staff family crew jury band committee faculty government audience deer sheep fish series species media".split(" "));
const singularEndingInS = new Set("bus boss class canvas compass gas address analysis news status lens focus".split(" "));
const midClauseOpeners = new Set("if when while unless because that though although whether where once since but so said think know believe notice remember".split(" "));
const adverbs = new Set("always usually often sometimes rarely seldom never normally already also still really just regularly generally occasionally typically frequently not hardly barely probably nearly almost even only now".split(" "));
const auxiliary = new Set("am is are was were can could will would shall should must might may cannot can't couldn't won't wouldn't shouldn't mustn't isn't aren't wasn't weren't has have had hasn't haven't hadn't do does did don't doesn't didn't".split(" "));

// These high-frequency, recognisable verb forms support a bounded syntax check.
// A familiar spelling alone never establishes that a token is a finite verb.
const baseVerbs = new Set(("accept add afford agree allow answer appear apply approach arrange arrive ask avoid bake begin belong borrow break bring build buy call care carry catch change check choose clean climb close collect come compare cook copy cost count cover cross cry cut cycle decide deliver depend describe dislike discuss do drive drop earn eat end enjoy escape expect explain face fail fall feed feel fight find finish fit fix follow forget gain get give go grow happen hate have hear help hide hit hold hope hurt improve include invite join jump keep kick know learn leave lend let lie like listen live look lose love make manage mark mean meet melt miss move need notice offer open order organise organize pack paint pass pay phone pick place plan play point post prefer prepare press promise pull push put raise reach read realise realize receive recognize record remember remove rent repair repeat replace replay reply rest return ride ring rise roll run save say see seem sell send serve set share show sign sing sit sleep smile solve sound speak spend stand start stay stop study suggest support swim switch take talk teach tell think throw travel train try turn understand use visit vote wait wake walk want watch wear win wish work worry write").split(" "));
const invariantPast = new Set("cost cut fit hit hurt let put read set".split(" "));
const irregularPast = new Set("ate began broke brought bought built came caught chose did drank drove fell fed felt found forgot gave got grew had heard held hid hit hurt kept knew lay learnt left lent lost made met paid ran rang read rode rose said sang sat saw sent set shut slept sold spoke spent stood swam taught thought threw told took understood woke wore went won wrote".split(" "));
const restRequired = new Set("accept afford answer borrow bring buy carry catch choose collect compare consider describe enjoy expect get give have keep know leave lend like love make mean need offer order pay prefer put read receive repay sell send set share take teach tell use want write".split(" "));
const subjectBoundaries = new Set("about across after against along around at before behind below beneath beside between beyond by down during for from in inside into near of off on onto outside over through to toward under until up upon via with within without and or".split(" "));
const mannerActions = new Set("angle arrange cut describe do fold format hold lay make move organise organize orient pack paint phrase place position put rotate set sort stack tilt turn use wrap".split(" "));
const bareComplement = new Set("help let make".split(" "));
const habitualAdverbs = new Set("always usually often sometimes rarely seldom normally regularly generally occasionally typically frequently never".split(" "));

function thirdPerson(base: string) {
  if (base === "have") return "has";
  if (base === "do" || base === "go" || /(?:[sxz]|ch|sh)$/u.test(base)) return `${base}es`;
  if (/[^aeiou]y$/u.test(base)) return `${base.slice(0, -1)}ies`;
  return `${base}s`;
}

const thirdPersonVerbs = new Map(Array.from(baseVerbs, (base) => [thirdPerson(base), base]));
function plain(word: string) { return word.toLowerCase().replaceAll("’", "'"); }

function tokens(text: string): Token[] {
  return Array.from(text.matchAll(/[\p{L}\p{M}\p{N}]+(?:['’\-][\p{L}\p{M}\p{N}]+)*/gu), ({ 0: word, index }) =>
    ({ word: plain(word), start: index, end: index + word.length }));
}

function inflectedBase(word: string) {
  if (irregularPast.has(word)) return word;
  if (!word.endsWith("ed")) return null;
  const stem = word.slice(0, -2);
  return [stem, `${stem}e`, `${stem.slice(0, -1)}y`, stem.slice(0, -1)].find((base) => baseVerbs.has(base)) ?? null;
}

function hasAdjacentPredicate(base: string, next: string) {
  if (bareComplement.has(base) && baseVerbs.has(next)) return false;
  return auxiliary.has(next) || baseVerbs.has(next) || thirdPersonVerbs.has(next) || inflectedBase(next) !== null;
}

function overlaps(a: Range, b: Range) { return a.start < b.end && b.start < a.end; }

export function hasWholeWritingSkillSpan(source: string, range: Range) {
  // Include compound words, contractions, combining marks and token prefixes.
  const insideWord = (point: number) => /[\p{L}\p{M}\p{N}](?:['’\-])?$/u.test(source.slice(0, point)) &&
    /^(?:['’\-])?[\p{L}\p{M}\p{N}]/u.test(source.slice(point));
  return !insideWord(range.start) && !insideWord(range.end);
}

function sourceContext(anchor: SourceAnchor, text?: string) {
  if (text !== undefined) return { source: text, offset: 0 };
  const offset = Math.min(anchor.sentenceStart, anchor.start - anchor.before.length);
  return { offset, source: anchor.before.slice(0, anchor.sentenceStart - offset) + anchor.sentence +
    anchor.after.slice(Math.max(0, anchor.sentenceEnd - anchor.end)) };
}

function singularNoun(word: string) {
  return /^[\p{L}\p{M}-]+$/u.test(word) && !ambiguousHeads.has(word) && !pluralNouns.has(word) &&
    (!word.endsWith("s") || singularEndingInS.has(word));
}

function numberOfSubject(subject: Token[]) {
  const [first] = subject;
  if (subject.length === 1 && agreementSubjects.has(first.word)) return "singular";
  if (subject.length === 1 && otherSubjects.has(first.word)) return "other";
  if ((determiners.has(first.word) || pluralDeterminers.has(first.word)) && subject.length >= 2) {
    const head = subject.at(-1)!.word;
    if (pluralDeterminers.has(first.word) || pluralNouns.has(head) || head.endsWith("s") && !singularEndingInS.has(head)) return "other";
    if (singularNoun(head) && !adverbs.has(head) && !auxiliary.has(head)) return "singular";
  }
  return null;
}

function agreementExample(source: string, range: Range, focus: Range, polarity: Polarity) {
  const prefix = source.slice(0, range.start);
  const context = source.slice(Math.max(prefix.lastIndexOf("."), prefix.lastIndexOf("!"), prefix.lastIndexOf("?"), prefix.lastIndexOf("\n")) + 1);
  const quote = source.slice(range.start, range.end);
  const words = tokens(quote);
  for (let index = 1; index < words.length; index++) {
    const verb = words[index];
    if (!overlaps({ start: range.start + verb.start, end: range.start + verb.end }, focus)) continue;
    const base = polarity === "correct" ? thirdPersonVerbs.get(verb.word) : baseVerbs.has(verb.word) ? verb.word : null;
    if (!base) continue;
    const afterVerb = source.slice(range.start + verb.end);
    // Auxiliary have/do, an attached infinitive, and a noun followed by a
    // separate finite predicate cannot supply a lexical agreement instance.
    if ((base === "have" || base === "do") && !/^\s+(?:a|an|the|this|that|some|no|my|your|his|her|its|our|their)\s+\p{L}/iu.test(afterVerb)) continue;
    const following = tokens(afterVerb)[0];
    if (following && !afterVerb.slice(0, following.start).trim() && hasAdjacentPredicate(base, following.word)) continue;
    const habitual = /\b(?:always|usually|often|regularly|sometimes|every|each|now|most mornings|most evenings|on [\p{L}]+s)\b/iu.test(context.split(/[.!?\n]/u)[0]);
    if (polarity === "incorrect" && ((invariantPast.has(base) && !habitual) || /\b(?:yesterday|last (?:night|week|month|year)|ago)\b/iu.test(context.split(/[.!?\n]/u)[0]))) continue;
    let end = index;
    while (end > 0 && adverbs.has(words[end - 1].word)) end--;
    for (let start = Math.max(0, end - 4); start < end; start++) {
      const subject = words.slice(start, end);
      const absoluteStart = range.start + subject[0].start;
      const before = source.slice(0, absoluteStart).trimEnd();
      const previous = tokens(before).at(-1)?.word;
      const clauseStart = !before || /[,.!?;:\n“"(]$/u.test(before) || (previous && midClauseOpeners.has(previous));
      const contiguous = words.slice(start, index + 1)
        .every((word, i, sequence) => i === 0 || /^\s+$/u.test(quote.slice(sequence[i - 1].end, word.start)));
      if (contiguous && clauseStart && numberOfSubject(subject) === "singular" &&
        !subject.some(({ word }) => subjectBoundaries.has(word) || word.includes("'"))) return true;
    }
  }
  return false;
}

function clausePredicate(clause: string): Token | null {
  const words = tokens(clause);
  const first = words[0]?.word;
  if (!first || ["however", "to", "for", "from", "although", "because", "while", "if", "when", "before", "after", "despite", "without", "with", "in", "theirs", "and", "or"].includes(first)) return null;
  for (let index = 1; index < Math.min(words.length, 12); index++) {
    const verb = words[index];
    const subject = words.slice(0, index).filter(({ word }) => !adverbs.has(word));
    if (!subject.length || /[,;:]/u.test(clause.slice(0, verb.start))) break;
    const obvious = numberOfSubject(subject);
    // Allow longer noun phrases for clause boundaries, such as "the one I read".
    // Base verbs need evidence of a plural or non-third-singular subject.
    const gerund = first.endsWith("ing") && [first.slice(0, -3), `${first.slice(0, -3)}e`].some((base) => baseVerbs.has(base));
    const nounPhrase = subject.length >= 2 && (determiners.has(first) || pluralDeterminers.has(first) || gerund) ||
      subject.length === 1 && /^[\p{L}]+$/u.test(first);
    if (!obvious && !nounPhrase || subject.length === 1 && (determiners.has(first) || pluralDeterminers.has(first))) continue;
    const lexical = thirdPersonVerbs.get(verb.word) ?? inflectedBase(verb.word) ??
      (baseVerbs.has(verb.word) && (obvious === "other" || invariantPast.has(verb.word)) ? verb.word : null);
    const complement = words[index + 1];
    const required = auxiliary.has(verb.word) || lexical !== null && restRequired.has(lexical);
    if ((!lexical && !auxiliary.has(verb.word)) || (required && !complement)) continue;
    if (complement && lexical && !auxiliary.has(verb.word) && hasAdjacentPredicate(lexical, complement.word)) continue;
    if (invariantPast.has(verb.word) && (!complement || restRequired.has(verb.word) &&
      /^(?:at|by|in|on|over|under|with|without)$/u.test(complement.word))) continue;
    // A modal needs a lexical predicate, optionally after adverbs/negation.
    if (/^(?:can|could|will|would|shall|should|must|might|may|cannot|can't|couldn't|won't|wouldn't|shouldn't|mustn't)$/u.test(verb.word) &&
      !baseVerbs.has(words.slice(index + 1).find(({ word }) => !adverbs.has(word))?.word ?? "") &&
      !/^(?:be|have)$/u.test(words.slice(index + 1).find(({ word }) => !adverbs.has(word))?.word ?? "")) continue;
    return verb;
  }
  return null;
}

function howeverExample(source: string, range: Range, focus: Range, polarity: Polarity) {
  const quote = source.slice(range.start, range.end);
  for (const { start, end, word } of tokens(quote)) {
    if (word !== "however" || !overlaps({ start: range.start + start, end: range.start + end }, focus)) continue;
    const left = source.slice(0, range.start + start).trimEnd();
    const mark = left.at(-1);
    if (!mark || !/[;,.!?]/u.test(mark)) continue;
    const precedingClause = left.slice(0, -1).split(/[.!?;\n]+/u).at(-1)?.trim();
    if (!precedingClause || !clausePredicate(precedingClause)) continue;
    const after = /^\s*(,?)\s*/u.exec(source.slice(range.start + end))!;
    const rightStart = range.start + end + after[0].length;
    const followingClause = source.slice(rightStart).split(/[.!?;\n]+/u)[0];
    const right = clausePredicate(followingClause);
    if (!right || rightStart + right.end > range.end) continue;
    // With no trailing comma, "however you angled it" and "however they
    // arranged the room, …" can be manner adjuncts. Abstain on these shapes.
    const tail = tokens(followingClause);
    const afterPredicate = tail.filter((token) => token.start > right.start && !adverbs.has(token.word) && !token.word.endsWith("ly"));
    const shortPronominalTail = afterPredicate.length === 1 && /^(?:it|them|her|him|this|that|so)$/u.test(afterPredicate[0].word);
    const action = thirdPersonVerbs.get(right.word) ?? (baseVerbs.has(right.word) ? right.word : inflectedBase(right.word));
    const habit = tail.some(({ start, word }) => start < right.start && habitualAdverbs.has(word));
    if (!after[1] && (followingClause.includes(",") || shortPronominalTail || !habit && action && mannerActions.has(action))) continue;
    const punctuated = mark !== "," && after[1] === ",";
    if ((polarity === "correct") === punctuated) return true;
  }
  return false;
}

// Prefer tangible, ordinary loan objects. This explicit scope abstains on
// figurative heads and uncommon/ambiguous objects rather than inferring sense.
const objects = new Set(("adapter apron bag ball basket battery bicycle bib bike blanket board book boots bottle box camera cable calculator case charger chair coat comb compass computer container cooker crutch cutter dvd drill eraser flask flashlight fork frame guitar hammer hat helmet headphones instrument jacket jersey key kit ladder lamp laptop lens light map mat microphone monitor mouse notebook outlet paddles paper pencil pen phone pillow plate pot projector pump racket radio razor recorder rope ruler saddle saw scanner scissors screen screwdriver shoes shovel skates spade speaker spoon stand stove sweater switch tablet tape telescope tent thermometer tool toolbox towel tripod umbrella uniform vacuum violin wrench").split(" "));
const objectHeads = new Set([...objects, ...Array.from(objects, thirdPerson), "batteries", "keys", "loaves", "gloves", "supplies"]);
const recipientPronouns = new Set("me you him her us them".split(" "));
const objectPronouns = new Set("it them one another mine yours his hers ours theirs".split(" "));
const transferForms = new Map(["borrow", "borrows", "borrowed", "borrowing", "lend", "lends", "lent", "lending"].map((word) => [word, word.startsWith("borrow")]));
const nominalEnd = new Set("after as at before because but by during for from if in into of on once out since so that through till to together until when which while with without yesterday today tomorrow back away here there upstairs downstairs".split(" "));
const people = new Set("aunt uncle parent classmate friend cousin neighbor neighbour keeper caretaker ranger teacher tutor coach owner colleague librarian boss sister brother manager shopkeeper family student stranger volunteer child visitor seller worker customer".split(" "));
const institutions = new Set("library gym school college university club shop store centre center office workshop canteen bank lab laboratory".split(" "));

function transferParticipant(context: string, words: Token[], allowInstitution: boolean) {
  const after = words.findIndex(({ word }, index) => nominalEnd.has(word) || /^(?:and|or|returned|said|let)$/u.test(word) ||
    index > 0 && determiners.has(word));
  const phrase = words.slice(0, after < 0 ? undefined : after);
  const head = phrase.at(-1);
  if (!head || phrase.length > 6) return false;
  if (recipientPronouns.has(phrase[0].word) || people.has(head.word) || allowInstitution && institutions.has(head.word)) return true;
  return phrase.length === 1 && /^\p{Lu}[\p{L}'’-]+$/u.test(context.slice(head.start, head.end));
}

function literalLoan(source: string, quote: Range, focus: Range, polarity: Polarity) {
  const words = tokens(source.slice(quote.start, quote.end));
  for (const verb of words) {
    const isBorrow = transferForms.get(verb.word);
    const start = quote.start + verb.start, end = quote.start + verb.end;
    if (isBorrow === undefined || !overlaps({ start, end }, focus)) continue;
    const right = source.slice(end).split(/[.!?,;:\n]/u)[0];
    const tail = tokens(right);
    if (!tail.length || !/^\s+$/u.test(right.slice(0, tail[0].start))) continue;
    const recipient = recipientPronouns.has(tail[0].word) && tail.length > 1 &&
      (tail[0].word !== "her" || determiners.has(tail[1].word) || pluralDeterminers.has(tail[1].word)) ? 1 : 0;
    const objectStart = tail.findIndex(({ word }, index) => index > recipient &&
      (determiners.has(word) || pluralDeterminers.has(word)) && !nominalEnd.has(tail[index - 1].word));
    let nounStart = recipient;
    if (!isBorrow && !recipient && objectStart > 1 && determiners.has(tail[0].word)) nounStart = objectStart;
    const nounStop = tail.findIndex(({ word }, index) => index >= nounStart &&
      (nominalEnd.has(word) && !(word === "of" && tail[index - 1]?.word === "pair") || index > nounStart && determinerAfterNoun(tail, index)));
    const noun = tail.slice(nounStart, nounStop < 0 ? undefined : nounStop);
    const head = noun.at(-1);
    if (!head || noun.length > 7 || end + head.end > quote.end) continue;
    const remainder = nounStop < 0 ? [] : tail.slice(nounStop);
    const from = remainder[0]?.word === "from";
    const to = remainder[0]?.word === "to";
    const dativeBorrow = isBorrow && recipient === 1;
    const objectPronoun = noun.length === 1 && objectPronouns.has(head.word);
    const previous = source.slice(Math.max(0, start - 420), start);
    const agent = tokens(previous).reverse().find(({ word }) => !auxiliary.has(word) && !adverbs.has(word));
    if (/^(?:argument|article|description|idea|language|metaphor|novel|philosophy|plan|policy|proposal|rhetoric|speech|theory)$/u.test(agent?.word ?? "")) continue;
    const hasObject = objectHeads.has(head.word) || (objectPronoun && tokens(previous).some(({ word }) => objectHeads.has(word)) &&
      (to || from || recipient || /^\s+for\s+\p{L}/iu.test(right.slice(head.end))));
    if (!hasObject) continue;
    if (dativeBorrow && remainder.some(({ word }) => word === "from")) continue;
    const participant = (from || to) && transferParticipant(right, remainder.slice(1), isBorrow && from);
    const toRecipient = to && participant;
    const purpose = to && baseVerbs.has(remainder[1]?.word ?? "");
    if (from && !participant || to && !toRecipient && !purpose) continue;
    if (!isBorrow && from && remainder.some(({ word }) => word === "to")) continue;
    if (polarity === (dativeBorrow || isBorrow && toRecipient || !isBorrow && from ? "incorrect" : "correct")) return true;
  }
  return false;
}

function determinerAfterNoun(tail: Token[], index: number) {
  return determiners.has(tail[index].word) && tail[index - 1].word !== "of";
}

/** The provider proposes a reading. This guard credits a bounded, inspectable construction. */
export function supportsWritingSkillAnchor(id: WritingSkillTargetId, anchor: SourceAnchor, polarity: Polarity, options?: AnchorContext) {
  const { source, offset } = sourceContext(anchor, options?.text);
  const range = { start: anchor.start - offset, end: anchor.end - offset };
  const focused = options?.focus ?? anchor;
  const focus = { start: focused.start - offset, end: focused.end - offset };
  if (source.slice(range.start, range.end) !== anchor.exact || !hasWholeWritingSkillSpan(source, range)) return false;
  switch (id) {
    case "subject-verb-agreement": return agreementExample(source, range, focus, polarity);
    case "however-contrast": return howeverExample(source, range, focus, polarity);
    case "local:word-borrow-lend": return literalLoan(source, range, focus, polarity);
  }
}
