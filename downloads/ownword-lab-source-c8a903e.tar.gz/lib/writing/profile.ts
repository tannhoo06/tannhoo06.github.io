import { validSource } from "../domain/anchors";
import type { SourceAnchor } from "../domain/types";
import type { DiagnosticReport } from "./contracts";
import { getWritingPracticeRecommendations, type WritingPracticeRecommendation } from "./personalized-practice";
import type { WritingHistoryItem, WritingRun, WritingSubmission, WritingTask } from "./persistence";
import { writingPracticeHref } from "./practice-path";
import type { WritingProfileTrend } from "./profile-trends";
import type { WritingRevisionCheck } from "./revision-check";
import { PILOT_SKILL_IDS, type PilotSkillId } from "./rubric";
import { readWritingSkillVerification, writingSkillDefinitions, type WritingSkillVerification } from "./skill-verification";

type Copy = { en: string; vi: string | null };

export type WritingProfileRecord = {
  task: WritingTask;
  submission: WritingSubmission;
  run: WritingRun | null;
  latestRevisionId?: string | null;
  revisionCheck?: WritingRevisionCheck | null;
  revisionCheckedAt?: string | null;
};

export type WritingProfileEvidence = {
  id: string;
  submissionId: string;
  index: number;
  source: "observation" | "finding" | "verification";
  skill: PilotSkillId | null;
  kind: "problem" | "strength" | "mixed";
  issueKind: string | null;
  materiality: "meaningful" | "minor";
  title: Copy;
  description: Copy;
  cue: Copy | null;
  anchors: SourceAnchor[];
  trendEligible: boolean;
  practice: WritingPracticeRecommendation | null;
  revisionStatus: WritingRevisionCheck["items"][number]["status"] | null;
  sessionTitle: string;
  createdAt: string;
};

export type WritingProfileSession = WritingProfileRecord & {
  report: DiagnosticReport | null;
  evidence: WritingProfileEvidence[];
  skillVerification?: WritingSkillVerification;
  title: string;
};

export type WritingProfileAssessment = {
  submissionId: string;
  title: string;
  createdAt: string;
  skills: Record<PilotSkillId, DiagnosticReport["skills"][PilotSkillId] & { evidence: WritingProfileEvidence[] }>;
};

export type WritingProfileNextStep = {
  kind: "practice" | "feedback";
  href: string;
  title: Copy;
  reason: Copy;
  evidence: WritingProfileEvidence;
};

type ProfilePattern = Pick<WritingProfileTrend, "kind"> & { evidence: readonly WritingProfileEvidence[] };

export type WritingProfileHistoryItem = WritingHistoryItem & {
  feedbackStatus: WritingRun["status"] | null;
  latestRevisionId: string | null;
};

export type WritingProfile = {
  latestSubmissionId: string | null;
  independentSessionCount: number;
  assessedSessionCount: number;
  recentSessionIds: string[];
  radar: { current: WritingProfileAssessment | null; previous: WritingProfileAssessment | null };
  recentInsights: WritingProfileEvidence[];
  nextStep: WritingProfileNextStep | null;
  history: WritingProfileHistoryItem[];
};

function sourceTitle({ task }: WritingProfileRecord) {
  return task.snapshot.prompt.title || task.snapshot.prompt.scenario;
}

export function validatedReport({ task, submission, run }: WritingProfileRecord) {
  const report = run?.status === "succeeded" ? run.report : null;
  return report?.scope === "submitted_response" && run?.submissionId === submission.id && report.submissionId === submission.id &&
    task.id === submission.taskId && report.promptId === task.promptId && report.promptVersion === task.promptVersion ? report : null;
}

function orderedOriginals(records: readonly WritingProfileRecord[]) {
  const seen = new Set<string>();
  return [...records].sort((a, b) => b.submission.createdAt.localeCompare(a.submission.createdAt) ||
    b.submission.id.localeCompare(a.submission.id) || Number(!!validatedReport(b)) - Number(!!validatedReport(a)) ||
    (b.run?.startedAt ?? "").localeCompare(a.run?.startedAt ?? "") || (b.run?.id ?? "").localeCompare(a.run?.id ?? ""))
    .filter(({ submission }) => {
      if (submission.parentSubmissionId !== null || seen.has(submission.id)) return false;
      seen.add(submission.id);
      return true;
    });
}

function signature(text: string) {
  const words = text.normalize("NFKC").replace(/[‘’]/gu, "'").toLowerCase()
    .match(/[\p{L}\p{N}]+(?:['-][\p{L}\p{N}]+)*/gu) ?? [];
  return { words, key: words.join(" ") };
}

type Original = { record: WritingProfileRecord; signature: ReturnType<typeof signature>; report: DiagnosticReport | null };

function repeatsOriginal(a: Original, b: Original, verification: boolean) {
  if (a.signature.key === b.signature.key) return true;
  const { words: first } = a.signature;
  const { words: second } = b.signature;
  const shortest = Math.min(first.length, second.length);
  // Require high whole-response overlap. On longer pilot essays, a proportional
  // tolerance catches localized changes beyond the ordinary profile's fixed limit.
  const ordinaryLimit = Math.min(4, Math.floor(shortest / 15));
  const limit = verification && shortest >= 60 ? Math.max(ordinaryLimit, Math.min(14, Math.floor(shortest * .08))) : ordinaryLimit;
  if (!limit || Math.abs(first.length - second.length) > limit) return false;
  const outside = limit + 1;
  let previous = Array.from({ length: second.length + 1 }, (_, index) => Math.min(index, outside));
  let current = Array<number>(second.length + 1).fill(outside);
  for (let index = 1; index <= first.length; index++) {
    const start = Math.max(1, index - limit);
    const end = Math.min(second.length, index + limit);
    current[start - 1] = start === 1 ? Math.min(index, outside) : outside;
    let best = current[start - 1];
    for (let column = start; column <= end; column++) {
      current[column] = Math.min(previous[column] + 1, current[column - 1] + 1,
        previous[column - 1] + Number(first[index - 1] !== second[column - 1]));
      best = Math.min(best, current[column]);
    }
    if (best > limit) return false;
    if (end < second.length) current[end + 1] = outside;
    [previous, current] = [current, previous];
  }
  return previous[second.length] <= limit;
}

function observedEvidence(record: WritingProfileRecord, report: DiagnosticReport, title: string): WritingProfileEvidence[] {
  const { id: submissionId, text, createdAt } = record.submission;
  const valid = (anchors: SourceAnchor[]) => anchors.length > 0 && anchors.every((anchor) => validSource(text, submissionId, anchor));
  const metadata = { submissionId, sessionTitle: title, createdAt };
  const revision = record.revisionCheck?.originalId === submissionId ? record.revisionCheck : null;
  if (report.issueFirstObservations) {
    const practice = new Map(getWritingPracticeRecommendations(report, text, revision).map((item) => [item.observationIndex, item]));
    return report.issueFirstObservations.flatMap((item, index) => {
      const { feedback, attribution, evidence: anchors } = item;
      if (!valid(anchors) || feedback?.category === "optional" ||
        (feedback && (feedback.category === "strength") !== (item.kind === "strength"))) return [];
      const skill = attribution.certainty === "clear" && attribution.primary && !attribution.secondary &&
        report.skills[attribution.primary]?.opportunity === "adequate" ? attribution.primary : null;
      const status = revision?.items.find(({ id, before, after, status }) => id === index && before === anchors[0].exact &&
        (status === "uncertain" || (!!after?.trim() && (status !== "resolved" || before !== after))))?.status ?? null;
      const suggested = practice.get(index);
      const recommendation = suggested ? { ...suggested, revisionStatus: status } : null;
      const meaningful = item.materiality === "meaningful" && item.issueKind !== "other_or_uncertain";
      return [{
        ...metadata, id: `observation:${submissionId}:${index}`, index, source: "observation", kind: item.kind,
        issueKind: item.issueKind, materiality: item.materiality, skill,
        title: { en: item.problem, vi: feedback?.vi.problem ?? null },
        description: { en: item.readerImpact, vi: feedback?.vi.readerImpact ?? null },
        cue: item.revisionCue ? { en: item.revisionCue, vi: feedback?.vi.revisionCue ?? null } : null,
        anchors, practice: recommendation, revisionStatus: status,
        trendEligible: meaningful && (item.profileEvidenceCandidate && !!skill || !!recommendation),
      }];
    });
  }
  return report.findings.flatMap((item, index) => {
    if (report.skills[item.skillId]?.opportunity !== "adequate" || !valid(item.evidence)) return [];
    const kind = item.judgment === "positive" ? "strength" : item.judgment === "mixed" ? "mixed" : "problem";
    const copy = { en: item.readerImpact, vi: null };
    return [{
      ...metadata, id: `finding:${submissionId}:${index}`, index, source: "finding", kind,
      issueKind: null, materiality: "meaningful", skill: item.skillId, title: copy, description: copy,
      cue: item.revisionCue ? { en: item.revisionCue, vi: null } : null,
      anchors: item.evidence, trendEligible: false, practice: null, revisionStatus: null,
    }];
  });
}

export function getWritingFeedbackEvidence(record: WritingProfileRecord) {
  const report = validatedReport(record);
  return report?.status === "observed" ? observedEvidence(record, report, sourceTitle(record)) : [];
}

/** Pilot evidence treats the first submission as the source, even if its assessment is absent. */
export function getWritingProfileSessions(records: readonly WritingProfileRecord[], includeVerification = false): WritingProfileSession[] {
  const originals: Original[] = orderedOriginals(records).map((record) => ({
    record, signature: signature(record.submission.text), report: validatedReport(record),
  }));
  const knownAssisted = originals.filter(({ record }) => ["external_help", "ownword_hint"].includes(record.submission.assistance));
  const eligible = new Set(originals.filter((candidate) => candidate.signature.key &&
    !knownAssisted.some((item) => repeatsOriginal(item, candidate, includeVerification))));
  const chronological = (a: Original, b: Original) => a.record.submission.createdAt.localeCompare(b.record.submission.createdAt) ||
    (includeVerification ? Number(a.record.submission.assistance === "unassisted") - Number(b.record.submission.assistance === "unassisted") : 0) ||
    a.record.submission.id.localeCompare(b.record.submission.id);
  const candidates = includeVerification ? [...originals].sort(chronological) : [...eligible].sort((a, b) =>
    Number(b.report?.status === "observed") - Number(a.report?.status === "observed") || chronological(a, b));
  const selected = new Set<Original>();
  const earlier: Original[] = [];
  for (const candidate of candidates) {
    const previous = includeVerification ? earlier : [...selected];
    if (eligible.has(candidate) && !previous.some((item) => item.record.task.id === candidate.record.task.id ||
      repeatsOriginal(item, candidate, includeVerification))) selected.add(candidate);
    // A series of near-copies can drift from the first text. Compare with
    // earlier discarded copies too so the latest one cannot supply fresh proof.
    if (includeVerification && candidate.signature.key) earlier.push(candidate);
  }
  return originals.filter((item) => selected.has(item)).map(({ record, report }) => {
    const title = sourceTitle(record);
    const evidence = report?.status === "observed" ? observedEvidence(record, report, title) : [];
    const skillVerification = includeVerification && record.submission.assistance === "unassisted" &&
      readWritingSkillVerification(record.submission, report?.skillVerification);
    if (skillVerification) {
      for (const { targetId, status, examples } of skillVerification.results) {
        const definition = writingSkillDefinitions[targetId];
        for (const polarity of ["correct", "incorrect", "mixed"] as const) {
          if (polarity === "mixed" && status !== "mixed") continue;
          const anchors = examples.filter(({ kind }) => kind === polarity || polarity === "mixed").map(({ anchor }) => anchor);
          if (!anchors.length) continue;
          const description = polarity === "correct" ? { en: "You used this successfully in this response.", vi: "Bạn đã dùng đúng trong bài viết này." }
            : polarity === "incorrect" ? { en: "This difficulty came up in this response.", vi: "Bài viết này gặp lại điểm cần sửa." }
            : { en: "This response contains both correct examples and errors.", vi: "Bài viết này có cả ví dụ dùng đúng và chỗ cần sửa." };
          const { id: submissionId, createdAt } = record.submission;
          evidence.push({ id: `verification:${submissionId}:${targetId}:${polarity}`, index: evidence.length, source: "verification",
            submissionId, createdAt, sessionTitle: title, skill: definition.skill, kind: polarity === "correct" ? "strength" : polarity === "incorrect" ? "problem" : "mixed",
            issueKind: null, materiality: "meaningful", title: definition.title, description, cue: null,
            anchors: polarity === "mixed" ? [examples.find(({ kind }) => kind === "correct")!.anchor,
              examples.find(({ kind }) => kind === "incorrect")!.anchor].sort((a, b) => a.start - b.start) : anchors,
            trendEligible: false, practice: null, revisionStatus: null });
        }
      }
      return { ...record, title, report, evidence, skillVerification };
    }
    return { ...record, title, report, evidence };
  });
}

export function comparableWritingAssessments(a: DiagnosticReport, b: DiagnosticReport) {
  return !a.focusContext && !b.focusContext && a.promptVersion === b.promptVersion && a.rubricVersion === b.rubricVersion &&
    a.registryVersion === b.registryVersion && a.schemaVersion === b.schemaVersion;
}

function assessSession(session: WritingProfileSession & { report: DiagnosticReport }): WritingProfileAssessment {
  const { submission, report, title } = session;
  const skills = {} as WritingProfileAssessment["skills"];
  for (const skill of PILOT_SKILL_IDS) {
    const evidence = session.evidence.filter((item) => item.source !== "verification" && item.skill === skill && item.materiality === "meaningful" &&
      item.issueKind !== "other_or_uncertain");
    const positive = evidence.some(({ kind }) => kind === "strength");
    const concern = evidence.some(({ kind }) => kind === "problem");
    const mixed = evidence.some(({ kind }) => kind === "mixed") || (positive && concern);
    const judgment = mixed ? "mixed" : positive ? "positive" : concern ? "weak" : "undetermined";
    skills[skill] = { opportunity: report.skills[skill]?.opportunity ?? "limited", judgment, evidence };
  }
  return { submissionId: submission.id, title, createdAt: submission.createdAt, skills };
}

function radarFor(sessions: WritingProfileSession[]): WritingProfile["radar"] {
  const assessed = sessions.filter((session): session is WritingProfileSession & { report: DiagnosticReport } => !!session.report);
  const latest = assessed[0];
  if (!latest) return { current: null, previous: null };
  const current = assessSession(latest);
  const previous = assessed.slice(1).filter(({ report }) => comparableWritingAssessments(latest.report, report))
    .map(assessSession).find(({ skills }) => PILOT_SKILL_IDS.some((id) =>
      current.skills[id].judgment !== "undetermined" && skills[id].judgment !== "undetermined")) ?? null;
  return { current, previous };
}

function sameObservation(a: WritingProfileEvidence, b: WritingProfileEvidence) {
  return a.id === b.id || (a.practice && b.practice && a.practice.skill === b.practice.skill);
}

function recentInsights(sessions: WritingProfileSession[], represented: readonly WritingProfileEvidence[]) {
  const ranked = sessions.flatMap(({ evidence }) => evidence).filter(({ source }) => source !== "verification").map((item) => ({
    item,
    priority: (item.materiality === "meaningful" ? 2 : 0) + Number(!represented.some((shown) => sameObservation(shown, item))),
  })).sort((a, b) => b.priority - a.priority);
  const first = ranked[0]?.item;
  if (!first) return [];
  const remaining = ranked.filter(({ item }) => !sameObservation(first, item));
  if (!remaining.length) return [first];
  const peers = remaining.filter(({ priority }) => priority === remaining[0].priority).map(({ item }) => item);
  return [first, peers.find((item) => item.submissionId !== first.submissionId && item.kind !== first.kind) ??
    peers.find((item) => item.submissionId !== first.submissionId && item.skill !== first.skill) ??
    peers.find((item) => item.submissionId !== first.submissionId) ?? peers.find((item) => item.kind !== first.kind) ?? peers[0]];
}

function nextStepForEvidence(evidence: WritingProfileEvidence, pattern?: ProfilePattern): WritingProfileNextStep {
  const { practice } = evidence;
  const count = new Set(pattern?.evidence.map(({ submissionId }) => submissionId)).size;
  const reason = !practice ? evidence.description : pattern && count >= 2 ? {
    en: `This came up in ${count} separate responses.`,
    vi: `Điểm này xuất hiện ở ${count} bài khác nhau.`,
  } : evidence.revisionStatus === "still_present" ? {
    en: "This came up again when you checked your revision.",
    vi: "Lượt kiểm tra bản sửa vẫn ghi nhận điểm này.",
  } : {
    en: "This came up in your recent feedback.",
    vi: "Góp ý gần đây có nhắc đến điểm này.",
  };
  return {
    kind: practice ? "practice" : "feedback",
    href: practice ? writingPracticeHref(evidence.submissionId, practice.observationIndex) : `/writing/submissions/${encodeURIComponent(evidence.submissionId)}`,
    title: practice?.title ?? evidence.title,
    reason,
    evidence,
  };
}

function nextStepFor(sessions: WritingProfileSession[], trends: readonly ProfilePattern[]) {
  const issues = sessions.flatMap(({ evidence }) => evidence).filter(({ source, kind, revisionStatus }) =>
    source !== "verification" && kind === "problem" && revisionStatus !== "resolved");
  for (const trend of trends) {
    if (trend.kind !== "persistent_issue" && trend.kind !== "recurring_issue") continue;
    const match = issues.find((item) => item.practice && trend.evidence.some((shown) => sameObservation(shown, item)));
    if (match) return nextStepForEvidence(match, trend);
  }
  const next = issues.find(({ practice, materiality }) => practice && materiality === "meaningful") ??
    issues.find(({ materiality }) => materiality === "meaningful") ?? issues.find(({ practice }) => practice) ?? issues[0];
  return next ? nextStepForEvidence(next) : null;
}

export function buildWritingProfile(records: readonly WritingProfileRecord[], sessions = getWritingProfileSessions(records),
  trends: readonly ProfilePattern[] = []): WritingProfile {
  const recent = sessions.slice(0, 2);
  const nextStep = nextStepFor(recent, trends);
  const represented = trends.flatMap(({ evidence }) => evidence);
  if (nextStep) represented.push(nextStep.evidence);
  const history = orderedOriginals(records).map((record): WritingProfileHistoryItem => ({
    id: record.submission.id, promptId: record.task.promptId, title: sourceTitle(record), createdAt: record.submission.createdAt,
    preview: record.submission.text.slice(0, 140), latestRevisionId: record.latestRevisionId ?? null, feedbackStatus: record.run?.status ?? null,
  }));
  return {
    latestSubmissionId: history[0]?.id ?? null,
    independentSessionCount: sessions.length,
    assessedSessionCount: sessions.filter(({ report }) => !!report).length,
    recentSessionIds: recent.map(({ submission }) => submission.id),
    radar: radarFor(sessions),
    recentInsights: recentInsights(recent, represented),
    nextStep,
    history,
  };
}
