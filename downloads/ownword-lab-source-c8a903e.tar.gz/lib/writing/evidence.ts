import { resolveSource } from "../domain/anchors";
import type { SourceAnchor } from "../domain/types";
import {
  DIAGNOSTIC_SCHEMA_VERSION,
  MAX_DIAGNOSTIC_FINDINGS,
  diagnosticOutputSchema,
  diagnosticSubmissionSchema,
  type DiagnosticFinding,
  type DiagnosticOutput,
  type DiagnosticReport,
  type DiagnosticSubmission,
  type ProposedEvidence,
  type RequirementId,
} from "./contracts";
import { diagnosticRequirements, getDiagnosticBlueprint, getDiagnosticPrompt } from "./prompt-bank";
import { WRITING_REGISTRY_VERSION } from "./registry";
import { diagnosticReportState } from "./report-state";
import { diagnosticRubric, diagnosticSkillRules } from "./rubric";

const sentenceSegmenter = new Intl.Segmenter("en", { granularity: "sentence" });
const wordSegmenter = new Intl.Segmenter("en", { granularity: "word" });

function hasEnoughWords(text: string, minimum: number) {
  let count = 0;
  for (const { isWordLike } of wordSegmenter.segment(text)) {
    if (isWordLike && ++count === minimum) return true;
  }
  return false;
}

function segmentResponse(text: string) {
  const segments = [];
  for (const { index, segment } of sentenceSegmenter.segment(text)) {
    const content = segment.trim();
    if (content) {
      segments.push({
        id: segments.length + 1,
        start: index + segment.length - segment.trimStart().length,
        text: content,
      });
    }
  }
  return segments;
}

export function prepareWritingDiagnostic(submission: DiagnosticSubmission) {
  const input = diagnosticSubmissionSchema.parse(submission);
  const prompt = getDiagnosticPrompt(input.promptId);
  if (!prompt) throw new Error("Unknown Writing diagnostic prompt.");
  return {
    ...input,
    prompt,
    blueprint: getDiagnosticBlueprint(prompt),
    rubric: diagnosticRubric,
    segments: segmentResponse(input.text),
  };
}

type PreparedDiagnostic = ReturnType<typeof prepareWritingDiagnostic>;

function anchorEvidence(input: PreparedDiagnostic, proposed: ProposedEvidence) {
  const { quote, segmentId } = proposed;
  const { text, submissionId } = input;
  if (!/[\p{L}\p{N}]/u.test(quote)) return null;
  if (segmentId === null) return resolveSource(text, quote, submissionId);

  const segment = input.segments[segmentId - 1];
  if (!segment) return null;
  const localAnchor = resolveSource(segment.text, quote, submissionId);
  if (!localAnchor) return null;
  return resolveSource(text, quote, submissionId, {
    start: segment.start + localAnchor.start,
    end: segment.start + localAnchor.end,
  });
}

function overlaps(first: SourceAnchor, second: SourceAnchor) {
  return first.start < second.end && second.start < first.end;
}

function validateEvidence(input: PreparedDiagnostic, proposed: ProposedEvidence[]) {
  const anchors: SourceAnchor[] = [];
  for (const evidence of proposed) {
    const anchor = anchorEvidence(input, evidence);
    if (!anchor) return { rejectedSpan: evidence } as const;
    if (anchors.some(({ start, end }) => anchor.start === start && anchor.end === end)) continue;
    anchors.push(anchor);
  }
  return { anchors } as const;
}

function explainRejectedSpan(input: PreparedDiagnostic, { quote, segmentId }: ProposedEvidence) {
  if (!/[\p{L}\p{N}]/u.test(quote)) return "no_word_or_number_in_quote";
  const scope = segmentId === null ? input.text : input.segments[segmentId - 1]?.text;
  if (scope === undefined) return "unknown_segment";
  const start = scope.indexOf(quote);
  if (start < 0) return input.text.includes(quote) ? "quote_outside_segment" : "quote_not_found";
  if (scope.lastIndexOf(quote) !== start) return "ambiguous_quote";
  return "invalid_anchor_boundary";
}

function hasDistinctSpans(anchors: SourceAnchor[], minimum: 1 | 2) {
  if (minimum === 1) return anchors.length > 0;
  return anchors.some((first, index) =>
    anchors.slice(index + 1).some((second) => !overlaps(first, second)),
  );
}

function conflictsOnEvidence(a: DiagnosticFinding, b: DiagnosticFinding) {
  const first = a.evidence;
  const second = b.evidence;
  if (!first.some((anchor) => second.some((other) => overlaps(anchor, other)))) return false;
  const hasSeparateSpan = (anchors: SourceAnchor[], other: SourceAnchor[]) =>
    anchors.some((anchor) => other.every((otherAnchor) => !overlaps(anchor, otherAnchor)));
  if (hasSeparateSpan(first, second) && hasSeparateSpan(second, first)) return false;

  // A targeted grammatical construction and the reasoning or sequence around
  // it are structurally different evidence. Exact reuse alone cannot show that.
  const [grammar, discourse] = a.skillId === "GRAM.ACCURACY" ? [a, b] : [b, a];
  if (grammar.skillId !== "GRAM.ACCURACY" ||
      (discourse.skillId !== "ARG.SUPPORT" && discourse.skillId !== "ORG.PROGRESSION")) return true;
  return !grammar.evidence.every((target) => discourse.evidence.every((context) =>
    !overlaps(target, context) || (contains(context, target) && hasEnoughWords(
      `${context.exact.slice(0, target.start - context.start)} ${context.exact.slice(target.end - context.start)}`, 2,
    )),
  ));
}

function contains(outer: SourceAnchor, inner: SourceAnchor) {
  return outer.start <= inner.start && outer.end >= inner.end;
}

function morePrecise(narrow: DiagnosticFinding, broad: DiagnosticFinding) {
  if (narrow.skillId !== broad.skillId || narrow.judgment !== broad.judgment ||
      narrow.evidence.length !== broad.evidence.length) return false;
  // Check that a narrower candidate preserves support at each original location.
  return narrow.evidence.every((span) => broad.evidence.filter((other) => contains(other, span)).length === 1) &&
    broad.evidence.every((span) => narrow.evidence.filter((other) => contains(span, other)).length === 1) &&
    narrow.evidence.reduce((size, span) => size + span.exact.length, 0) < broad.evidence.reduce((size, span) => size + span.exact.length, 0);
}

function priority(finding: DiagnosticFinding) {
  if (finding.judgment === "positive") return 2;
  return finding.revisionCue ? 0 : 1;
}

type RejectedFinding = {
  index: number;
  reason: "ineligible_opportunity" | "invalid_evidence" | "duplicate_skill" | "overlapping_evidence" | "finding_limit";
};

export type DiagnosticRejection =
  | (RejectedFinding & {
      target: "finding";
      skillId: DiagnosticFinding["skillId"];
      judgment: DiagnosticFinding["judgment"];
      evidence: ProposedEvidence[];
      detail?: string;
    })
  | { target: "requirement"; requirement: RequirementId; evidence: ProposedEvidence[]; detail: string }
  | { target: "contract"; path: string[]; code: string; skillId?: string; evidence?: { quote?: string; segmentId?: number | string | null }[] };

function asRecord(value: unknown) {
  return typeof value === "object" && value !== null ? value as Record<string, unknown> : undefined;
}

function invalidProposal(output: unknown, path: PropertyKey[]) {
  const payload = asRecord(output);
  const finding = path[0] === "findings" && typeof path[1] === "number" && Array.isArray(payload?.findings)
    ? asRecord(payload.findings[path[1]]) : undefined;
  const check = path[0] === "taskFulfillment" && typeof path[1] === "string"
    ? asRecord(asRecord(payload?.taskFulfillment)?.[path[1]]) : undefined;
  const proposed = finding ?? check;
  return {
    skillId: typeof finding?.skillId === "string" ? finding.skillId : undefined,
    evidence: Array.isArray(proposed?.evidence) ? proposed.evidence.map((value: unknown) => {
      const span = asRecord(value);
      return {
        quote: typeof span?.quote === "string" ? span.quote : undefined,
        segmentId: span?.segmentId === null || typeof span?.segmentId === "number" || typeof span?.segmentId === "string"
          ? span.segmentId : undefined,
      };
    }) : undefined,
  };
}

export type DiagnosticValidation =
  | { status: "invalid_output"; reason: "invalid_contract" | "unusable_evidence" }
  | {
      status: "validated";
      report: DiagnosticReport;
      rejectedFindings: RejectedFinding[];
      rejectedRequirements: RequirementId[];
    };

export function validateWritingDiagnostic(
  submission: DiagnosticSubmission,
  output: unknown,
  // Optional inspection for the synthetic harness. The app never supplies a callback.
  onRejection?: (rejection: DiagnosticRejection) => void,
): DiagnosticValidation {
  const input = prepareWritingDiagnostic(submission);
  const parsed = diagnosticOutputSchema.safeParse(output);
  if (!parsed.success) {
    if (onRejection) for (const { path, code } of parsed.error.issues) {
      onRejection({ target: "contract", path: path.map(String), code, ...invalidProposal(output, path) });
    }
    return { status: "invalid_output", reason: "invalid_contract" };
  }
  const proposed = parsed.data;

  const findings: DiagnosticFinding[] = [];
  const candidates: { finding: DiagnosticFinding; index: number }[] = [];
  const rejectedFindings: RejectedFinding[] = [];
  const skills = {} as DiagnosticReport["skills"];
  const hasWordContext = hasEnoughWords(input.text, 2);
  for (const skill of diagnosticRubric.skills) {
    const opportunity = proposed.opportunities[skill.id];
    skills[skill.id] = {
      opportunity: !hasWordContext && opportunity === "adequate" ? "limited" : opportunity,
      judgment: "undetermined",
    };
  }
  function reject(index: number, finding: DiagnosticOutput["findings"][number], reason: RejectedFinding["reason"], detail?: string) {
    rejectedFindings.push({ index, reason });
    onRejection?.({ target: "finding", index, reason, detail, skillId: finding.skillId, judgment: finding.judgment, evidence: finding.evidence });
  }
  for (const [index, finding] of proposed.findings.entries()) {
    const { skillId } = finding;
    const rule = diagnosticSkillRules[skillId];
    const singleGrammarError = skillId === "GRAM.ACCURACY" && finding.judgment === "weak" && finding.evidence.length === 1;
    const minimumSpans = singleGrammarError ? 1 : rule.minimumSpans;
    const { anchors, rejectedSpan } = validateEvidence(input, finding.evidence);
    if (skills[skillId].opportunity !== "adequate") {
      reject(index, finding, "ineligible_opportunity");
    } else if (!anchors) {
      reject(index, finding, "invalid_evidence", onRejection ? explainRejectedSpan(input, rejectedSpan) : undefined);
    } else if (!anchors.every(({ exact }) => hasEnoughWords(exact, rule.minimumWordsPerSpan))) {
      reject(index, finding, "invalid_evidence", "span_too_short");
    } else if (!hasDistinctSpans(anchors, minimumSpans)) {
      reject(index, finding, "invalid_evidence", "too_few_distinct_spans");
    } else candidates.push({ finding: { ...finding, evidence: anchors }, index });
  }
  // Stable within each priority, so the model's ordering of actionable issues is preserved.
  candidates.sort((first, second) => priority(first.finding) - priority(second.finding));
  for (const { index, finding } of candidates) {
    const proposal = proposed.findings[index];
    if (findings.some((accepted) => accepted.skillId === finding.skillId) ||
        candidates.some((candidate) => priority(candidate.finding) === priority(finding) && morePrecise(candidate.finding, finding))) {
      reject(index, proposal, "duplicate_skill");
    } else if (findings.some((accepted) => conflictsOnEvidence(accepted, finding))) {
      reject(index, proposal, "overlapping_evidence");
    } else if (findings.length === MAX_DIAGNOSTIC_FINDINGS) {
      reject(index, proposal, "finding_limit");
    } else {
      findings.push(finding);
      skills[finding.skillId].judgment = finding.judgment;
    }
  }
  rejectedFindings.sort((first, second) => first.index - second.index);

  const taskFulfillment = {} as DiagnosticReport["taskFulfillment"];
  const rejectedRequirements: RequirementId[] = [];
  for (const requirement of Object.keys(diagnosticRequirements) as RequirementId[]) {
    // Keep the historical report shape. Discussion tasks have no mandatory trade-off check.
    if (!Object.hasOwn(input.blueprint.requirements, requirement)) {
      taskFulfillment[requirement] = { status: "undetermined", evidence: [] };
      continue;
    }
    const check = proposed.taskFulfillment[requirement];
    const { anchors, rejectedSpan } = validateEvidence(input, check.evidence);
    const requiredSpans = input.blueprint.version === "v1" && requirement === "reasons" && check.status === "met" ? 2 : 1;
    const valid = check.status === "met" || (requirement === "reasons" && check.status === "partly_met")
      ? anchors && hasDistinctSpans(anchors, requiredSpans)
      : (check.status === "missing" || check.status === "undetermined") && check.evidence.length === 0;
    if (!valid) {
      rejectedRequirements.push(requirement);
      if (onRejection) onRejection({ target: "requirement", requirement, evidence: check.evidence,
        detail: rejectedSpan ? explainRejectedSpan(input, rejectedSpan) :
          check.status === "met" || (requirement === "reasons" && check.status === "partly_met")
            ? "too_few_distinct_spans" : "evidence_inconsistent_with_status" });
      taskFulfillment[requirement] = { status: "undetermined", evidence: [] };
    } else {
      taskFulfillment[requirement] = { status: check.status, evidence: anchors ?? [] };
    }
  }

  if (!findings.length && rejectedFindings.some(({ reason }) => reason === "invalid_evidence")) {
    return { status: "invalid_output", reason: "unusable_evidence" };
  }
  if (!findings.length && rejectedRequirements.length &&
    Object.values(taskFulfillment).every(({ status }) => status === "undetermined")) {
    return { status: "invalid_output", reason: "unusable_evidence" };
  }
  return {
    status: "validated",
    report: {
      scope: "submitted_response",
      provisional: true,
      status: diagnosticReportState({ findings, skills, taskFulfillment }),
      submissionId: input.submissionId,
      promptId: input.prompt.id,
      promptVersion: input.blueprint.version,
      registryVersion: WRITING_REGISTRY_VERSION,
      rubricVersion: input.rubric.version,
      schemaVersion: DIAGNOSTIC_SCHEMA_VERSION,
      skills,
      findings,
      taskFulfillment,
    },
    rejectedFindings,
    rejectedRequirements,
  };
}
