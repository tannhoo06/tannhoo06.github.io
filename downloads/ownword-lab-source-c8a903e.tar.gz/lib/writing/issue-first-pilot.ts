import type { DiagnosticReport, DiagnosticSubmission, IssueFirstReportObservation } from "./contracts";
import { createIssueFirstWritingEvaluator, type IssueFirstRoute, type IssueFirstValidation } from "./experimental/issue-first";
import { prepareWritingDiagnostic } from "./evidence";
import type { WritingEvaluator } from "./persistence";
import { WRITING_REGISTRY_VERSION } from "./registry";
import { diagnosticRubric } from "./rubric";
import { diagnosticReportState } from "./report-state";
import { sanitizeWritingObservation } from "./replacement-safety";

export const ISSUE_FIRST_PILOT_MODEL = "openai/gpt-6.1-terra";
export const ISSUE_FIRST_PILOT_ROUTE: IssueFirstRoute = {
  endpoint: "azure/us",
  provider: "Azure",
  maxTokens: 6400,
  completionTokenField: "max_completion_tokens",
  maxPricePerMillion: { prompt: 1.1, completion: 5.5 },
  reasoningEffort: "low",
};
export const HOSTED_WRITING_ROUTE: IssueFirstRoute = { ...ISSUE_FIRST_PILOT_ROUTE, endpoint: "azure" };
export const ISSUE_FIRST_PILOT_SCHEMA_VERSION = "diagnostic-issue-first-pilot-v2";

/** Development opt-in. Hosted Writing uses its separate release configuration. */
export function issueFirstPilotEnabled(environment: Record<string, unknown>, nodeEnv = process.env.NODE_ENV) {
  return nodeEnv === "development" && environment.WRITING_ISSUE_FIRST_PILOT === "true";
}

function protectRevisionCue(observation: IssueFirstReportObservation): IssueFirstReportObservation {
  if (observation.kind !== "problem") return observation;
  const anchor = observation.evidence[0];
  const source = observation.evidence.map(({ sentence }) => sentence).join(" ");
  const cue = observation.revisionCue ?? "";
  const feedback = observation.feedback;
  const replacement = feedback?.replacement;
  const revised = replacement && anchor.sentence.slice(0, anchor.start - anchor.sentenceStart) +
    replacement + anchor.sentence.slice(anchor.end - anchor.sentenceStart);
  // A one-word replacement in this construction leaves "help visitors from finding ...".
  if (/\bprevent\b[\s\S]{0,100}\bfrom\b/i.test(source) && (
      (revised && /\b(?:help|guide)\b[^.!?]{0,85}\bfrom\s+\w+ing\b/i.test(revised)) ||
      (/\b(?:change|replace|swap|substitute)\b[\s\S]{0,60}\bprevent\b[\s\S]{0,40}\b(?:help|guide)\b/i.test(cue) &&
        !/\b(?:help|guide)\s+\w+\s+(?:find|reach|locate)\b/i.test(cue)))) {
    return { ...observation,
      revisionCue: "Check the whole phrase so it expresses the action you intend and remains grammatical.",
      ...(feedback && { feedback: { ...feedback, replacement: null,
        vi: { ...feedback.vi, revisionCue: "Xem lại cả cụm từ để câu đúng ngữ pháp và diễn đạt đúng ý bạn." } } }),
      profileEvidenceCandidate: false };
  }
  return observation;
}

export function toIssueFirstPilotReport(
  submission: DiagnosticSubmission,
  validated: IssueFirstValidation,
): DiagnosticReport | null {
  if (validated.status !== "validated") return null;
  const input = prepareWritingDiagnostic(submission);
  const observations = validated.report.observations.flatMap((item) => sanitizeWritingObservation(protectRevisionCue(item)) ?? []);
  const skills = validated.report.opportunities;
  const report: DiagnosticReport = {
    scope: "submitted_response",
    provisional: true,
    status: observations.length || validated.report.status !== "observed" ? validated.report.status
      : diagnosticReportState({ findings: [], skills, taskFulfillment: validated.report.taskFulfillment }),
    submissionId: input.submissionId,
    promptId: input.prompt.id,
    promptVersion: input.blueprint.version,
    registryVersion: WRITING_REGISTRY_VERSION,
    rubricVersion: diagnosticRubric.version,
    schemaVersion: ISSUE_FIRST_PILOT_SCHEMA_VERSION,
    findings: [],
    issueFirstObservations: observations,
    issueFirstCoverage: { proposed: validated.proposedCount, rejected: validated.proposedCount - observations.length },
    skills,
    taskFulfillment: validated.report.taskFulfillment,
  };
  return report;
}

export function createIssueFirstPilotEvaluator(
  key: string,
  request: typeof fetch = fetch,
  route: IssueFirstRoute = ISSUE_FIRST_PILOT_ROUTE,
): WritingEvaluator {
  // Cloudflare Workers reject redirect: "error". A manual response plus an explicit
  // redirect rejection has the same no-follow privacy behavior in the local pilot.
  const noRedirectRequest: typeof fetch = async (input, init) => {
    const response = await request(input, { ...init, redirect: "manual" });
    if (response.status >= 300 && response.status < 400) throw new Error("Writing provider redirect rejected.");
    return response;
  };
  const evaluate = createIssueFirstWritingEvaluator(key, ISSUE_FIRST_PILOT_MODEL, noRedirectRequest, route, "learner");
  return async (submission) => {
    const result = await evaluate(submission);
    if (result.status !== "evaluated") {
      console.error("Writing pilot evaluation unavailable.", result.status, result.reason, result.telemetry.httpStatus ?? "no_http");
      return { status: "invalid_output", reason: "invalid_contract" };
    }
    const report = toIssueFirstPilotReport(submission, result.validation);
    if (!report) console.error("Writing pilot output did not pass structural validation.", result.validation.status);
    return report ? { status: "validated", report, rejectedFindings: [], rejectedRequirements: [] }
      : { status: "invalid_output", reason: "invalid_contract" };
  };
}
