export function writingPracticeHref(submissionId: string, observationIndex: number) {
  return `/writing/submissions/${encodeURIComponent(submissionId)}/practice/${observationIndex}`;
}
