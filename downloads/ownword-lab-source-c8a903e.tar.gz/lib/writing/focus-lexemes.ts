// One insertion, deletion, substitution, or adjacent transposition.
export function oneWritingTypo(word: string, root: string) {
  if (word.length < 5 || root.length < 5 || Math.abs(word.length - root.length) > 1) return false;
  let index = 0;
  while (index < word.length && word[index] === root[index]) index++;
  if (word.length > root.length) return word.slice(index + 1) === root.slice(index);
  if (word.length < root.length) return word.slice(index) === root.slice(index + 1);
  return word.slice(index + 1) === root.slice(index + 1) ||
    word[index] === root[index + 1] && word[index + 1] === root[index] && word.slice(index + 2) === root.slice(index + 2);
}
