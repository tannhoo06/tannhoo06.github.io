import { grammarPracticeObjectives } from "./practice-grammar";
import { meaningPracticeObjectives } from "./practice-meaning";
import { validatePracticeObjectives, type ExpandedPracticeSkill } from "./practice-objective";
import { wordPracticeObjectives } from "./practice-words";

const authored = [...grammarPracticeObjectives, ...wordPracticeObjectives, ...meaningPracticeObjectives];
const invalid = new Set(validatePracticeObjectives(authored).map((error) => error.split(":")[0]));

export const expandedPracticeObjectives = authored.filter(({ id }) => !invalid.has(id));
const byId = new Map(expandedPracticeObjectives.map((objective) => [objective.id, objective]));

export function getExpandedPracticeObjective(skill: string) {
  return skill.startsWith("local:") ? byId.get(skill.slice("local:".length)) : undefined;
}

export function expandedPracticeId(skill: ExpandedPracticeSkill, index: number) {
  return `${skill}:${index}`;
}

export function getExpandedPracticeScenario(id: string) {
  const match = /^(local:[a-z0-9-]+):(\d+)$/.exec(id);
  if (!match) return undefined;
  const objective = getExpandedPracticeObjective(match[1]);
  const scenario = objective?.scenarios[Number(match[2])];
  return objective && scenario ? { objective, scenario } : undefined;
}
