import type { WritingPracticeResult } from "./personalized-practice";

export type WritingHoweverExercise = {
  id: string;
  before: string;
  after: string;
  prompt: WritingPracticeResult["feedback"];
  hint: WritingPracticeResult["feedback"];
};

const prompt = {
  en: "Add the punctuation before and after ‘however’.",
  vi: "Điền dấu câu trước và sau ‘however’.",
};
const hint = {
  en: "Each idea could be a sentence on its own. A comma alone is too weak to separate the two ideas.",
  vi: "Mỗi vế đều có thể đứng riêng thành câu. Một dấu phẩy không đủ để tách hai vế này.",
};

const exercises = [
  { id: "however-library", before: "The library was quiet", after: "I still had trouble concentrating." },
  { id: "however-interview", before: "The interview was short", after: "it covered everything I wanted to ask." },
  { id: "however-walk", before: "We planned to walk home", after: "the rain changed our plans." },
].map((exercise) => ({ ...exercise, prompt, hint }));

export function getWritingHoweverExercises(): readonly WritingHoweverExercise[] {
  return exercises;
}

export const writingHoweverTakeaway = {
  en: "When ‘however’ introduces a contrast between two complete ideas, use a semicolon or a period before it and a comma after it.",
  vi: "Khi ‘however’ nối hai ý đối lập và mỗi ý có thể đứng riêng, đặt dấu chấm phẩy hoặc dấu chấm trước từ này và dấu phẩy sau nó.",
};

export function formatWritingHoweverJunction(before: string, after: string): string | null {
  if (after.trim() !== ",") return null;
  switch (before.trim()) {
    case ";": return "; however,";
    case ".": return ". However,";
    default: return null;
  }
}

export function checkWritingHoweverAttempt(
  id: string,
  answer: { before: string; after: string },
): WritingPracticeResult | null {
  if (!exercises.some((item) => item.id === id)) return null;
  const { before, after } = answer;
  if (!before.trim() && !after.trim()) return null;
  if (formatWritingHoweverJunction(before, after)) {
    return {
      status: "successful",
      feedback: writingHoweverTakeaway,
      nextStep: {
        en: "Find and fix the same punctuation problem in a new sentence.",
        vi: "Tìm và sửa lỗi dấu câu tương tự trong một câu khác.",
      },
    };
  }
  if (before.trim() !== ";" && before.trim() !== ".") {
    return {
      status: "revise",
      feedback: hint,
      nextStep: {
        en: "Look at the gap before ‘however’. Try a mark that can separate two complete thoughts.",
        vi: "Xem lại ô trước ‘however’. Thử dùng dấu câu có thể tách hai vế hoàn chỉnh.",
      },
    };
  }
  return {
    status: "revise",
    feedback: {
      en: "The punctuation before ‘however’ works. The gap after it needs a short pause before the second idea starts.",
      vi: "Dấu câu trước ‘however’ đã đúng. Ô sau từ này cần một dấu ngắt nhẹ trước khi bắt đầu ý thứ hai.",
    },
    nextStep: {
      en: "Try a different mark just after ‘however’.",
      vi: "Thử đổi dấu câu ngay sau ‘however’.",
    },
  };
}
