import { z } from "zod";
import registryData from "./registry.json";

const nonempty = z.string().trim().min(1);
const canonicalId = z.string().regex(/^[A-Z]+\.[A-Z][A-Z_]*$/);
const writingFormat = z.enum(["opinion", "revision", "image_description", "audience_task"]);
const source = z.strictObject({
  title: nonempty,
  url: z.url({ protocol: /^https$/ }),
  constructs: z.array(nonempty).min(1),
  role: nonempty,
});
const skill = z.strictObject({
  id: canonicalId,
  name_en: nonempty,
  name_vi: nonempty,
  domain: nonempty,
  definition: nonempty,
  evidence_strong: nonempty,
  evidence_weak: nonempty,
  do_not_infer_when: nonempty,
  eligible_practice_formats: z.array(writingFormat).min(1),
  source_keys: z.array(nonempty).min(1),
  initial_priority: z.enum(["core", "later"]),
  evidence_gate: nonempty,
  aliases: z.array(nonempty),
});
const internalCheck = z.strictObject({
  id: canonicalId,
  title: nonempty,
  source_keys: z.array(nonempty).min(1),
  rule: nonempty,
});

const registrySchema = z.strictObject({
  name: nonempty,
  version: z.literal("1.0.0-proposal"),
  last_reviewed: z.iso.date(),
  status: z.literal("research-grounded-unvalidated"),
  sources: z.record(nonempty, source),
  trainable_skills: z.array(skill).length(17),
  internal_checks: z.array(internalCheck).length(5),
  allowed_formats: z.array(writingFormat).length(writingFormat.options.length),
  policy: z.strictObject({
    max_targets_initial: z.number().int().min(1),
    strengths_in_default_selector: z.literal(false),
    separate_practice_and_reassessment_caps: z.literal(true),
    require_source_evidence: z.literal(true),
    status_thresholds_unvalidated: z.literal(true),
    unknown_skill_ids: z.literal("reject"),
    broad_rubric_name_normalization: nonempty,
  }),
  document: nonempty,
});

function ensureUnique(values: readonly string[], label: string) {
  if (new Set(values).size !== values.length) {
    throw new Error(`Duplicate ${label} in the Writing registry.`);
  }
}

export function validateWritingRegistry(input: unknown) {
  const registry = registrySchema.parse(input);
  const entries = [...registry.trainable_skills, ...registry.internal_checks];
  ensureUnique(entries.map(({ id }) => id), "canonical ID");
  ensureUnique(registry.allowed_formats, "task format");
  for (const label of ["name_en", "name_vi"] as const) {
    ensureUnique(registry.trainable_skills.map((entry) => entry[label].toLowerCase()), label);
  }
  for (const entry of entries) {
    ensureUnique(entry.source_keys, `source reference for ${entry.id}`);
    if (entry.source_keys.some((key) => !Object.hasOwn(registry.sources, key))) {
      throw new Error(`Unknown source for Writing registry ID ${entry.id}.`);
    }
  }
  for (const entry of registry.trainable_skills) {
    ensureUnique(entry.eligible_practice_formats, `task format for ${entry.id}`);
  }
  return registry;
}

export const WRITING_REGISTRY_VERSION = "candidate-v1";
export const writingRegistry = validateWritingRegistry(registryData);
