import type { DiagnosticReport, DiagnosticSubmission, IssueFirstReportObservation, WritingFocusCheck } from "./contracts";
import type { DiagnosticValidation } from "./evidence";
import type { WritingFocusAction, WritingFocusState } from "./focus";
import type { DiagnosticBlueprint, DiagnosticPrompt, writingInterests } from "./prompt-bank";
import type { WritingRevisionCheck } from "./revision-check";

export const writingAssistance = ["unassisted", "external_help", "ownword_hint", "unknown"] as const;
export type WritingAssistance = (typeof writingAssistance)[number];
export type WritingRunStatus = "pending" | "succeeded" | "failed" | "expired";

export interface WritingTaskSnapshot {
  prompt: DiagnosticPrompt;
  blueprint: DiagnosticBlueprint;
  interestIds: (keyof typeof writingInterests)[];
  locale: "en" | "vi";
}

export interface WritingTask {
  id: string;
  promptId: string;
  promptVersion: string;
  snapshot: WritingTaskSnapshot;
  createdAt: string;
}

export interface WritingSubmission {
  id: string;
  taskId: string;
  parentSubmissionId: string | null;
  text: string;
  wordCount: number;
  assistance: WritingAssistance;
  createdAt: string;
}

export interface WritingHistoryItem {
  id: string;
  promptId: string;
  title: string;
  createdAt: string;
  preview: string;
}

export type WritingRevisionSummary = Pick<WritingSubmission, "id" | "createdAt" | "wordCount">;

export interface WritingRun {
  id: string;
  submissionId: string;
  status: WritingRunStatus;
  quotaDay: string;
  leaseExpiresAt: string;
  startedAt: string;
  finishedAt: string | null;
  report: DiagnosticReport | null;
}

export type WritingLimits = { successes: number; attempts: number };
export type WritingQuota = WritingLimits & { pending: number };
export type WritingEvaluationContext = { focusGuidance: readonly string[]; focusTopicKeys?: readonly string[] };
export type WritingFocusPrune = { historyKey: string; retainKeys: readonly string[] };
export type WritingEvaluator = (submission: DiagnosticSubmission, context?: WritingEvaluationContext) =>
  DiagnosticValidation | Promise<DiagnosticValidation>;
export type WritingFocusTarget = { key: string; guidance: string };
export type WritingFocusBaselineProblem = { key: string | null; observation: IssueFirstReportObservation };
export type WritingFocusEvaluator = (submission: DiagnosticSubmission, targets: readonly WritingFocusTarget[],
  baseline: readonly WritingFocusBaselineProblem[], signal: AbortSignal) => Promise<WritingFocusCheck | null>;

type Saved<T> = { status: "saved"; record: T } | { status: "conflict" | "not_found" };
export type RunReservation =
  | { status: "claimed"; run: WritingRun }
  | { status: "existing" | "quota" | "not_found" | "conflict" };
export type SavedRevisionCheck = { check: WritingRevisionCheck | null; pending: boolean };
export type WritingProfileAnalysisRecord = {
  evidenceKey: string;
  leaseToken: string | null;
  nextAttemptAt: string;
  updatedAt: string;
  result: unknown;
  resultJson: string | null;
};
export type RevisionCheckReservation =
  | { status: "completed"; check: WritingRevisionCheck }
  | { status: "claimed" | "pending" | "quota" | "not_found" };

export interface WritingRepository {
  createTask(userId: string, task: WritingTask, requestId: string): Promise<Saved<WritingTask>>;
  createSubmission(userId: string, submission: WritingSubmission, requestId: string): Promise<Saved<WritingSubmission>>;
  getSubmission(userId: string, id: string): Promise<{
    task: WritingTask;
    submission: WritingSubmission;
    run: WritingRun | null;
  } | null>;
  latestSubmissionId(userId: string, taskId?: string): Promise<string | null>;
  listOriginalSubmissions(userId: string): Promise<WritingHistoryItem[]>;
  listFocusRecords(userId: string): Promise<{ submission: WritingSubmission; task: WritingTask; run: WritingRun | null }[]>;
  listFocusStates(userId: string): Promise<{ key: string; status: WritingFocusState }[]>;
  updateFocusState(userId: string, key: string, action: WritingFocusAction, sourceIds: readonly string[], rememberReturn?: boolean): Promise<boolean>;
  pruneFocusStates(userId: string, plan: WritingFocusPrune): Promise<void>;
  listProfileRecords(userId: string): Promise<{
    submission: WritingSubmission;
    task: WritingTask;
    run: WritingRun | null;
    latestRevisionId: string | null;
    revisionCheck: WritingRevisionCheck | null;
    revisionCheckedAt: string | null;
  }[]>;
  getProfileAnalysis(userId: string): Promise<WritingProfileAnalysisRecord | null>;
  reserveProfileAnalysis(userId: string, input: {
    evidenceKey: string; leaseToken: string; now: string; leaseExpiresAt: string; dailyLimit: number;
    replaceInvalidResult?: string;
  }): Promise<"claimed" | "busy" | "quota">;
  finishProfileAnalysis(userId: string, leaseToken: string, now: string, retryAt: string, result: unknown): Promise<boolean>;
  listRevisions(userId: string, originalId: string): Promise<WritingRevisionSummary[]>;
  getRevisionCheck(userId: string, revisionId: string, now: string): Promise<SavedRevisionCheck | null>;
  reserveRevisionCheck(userId: string, input: {
    revisionId: string;
    leaseToken: string;
    now: string;
    leaseExpiresAt: string;
    attemptLimit: number;
  }): Promise<RevisionCheckReservation>;
  finishRevisionCheck(userId: string, revisionId: string, leaseToken: string, check: WritingRevisionCheck | null, checkedAt?: string): Promise<boolean>;
  reserveRun(userId: string, input: {
    id: string;
    submissionId: string;
    requestId: string;
    mode: "initial" | "retry";
    now: string;
    leaseExpiresAt: string;
    limits: WritingLimits;
  }): Promise<RunReservation>;
  finishRun(userId: string, run: WritingRun, now: string, report: DiagnosticReport | null): Promise<boolean>;
  getQuota(userId: string, now: string): Promise<WritingQuota>;
  deleteSubmission(userId: string, id: string, focus?: WritingFocusPrune): Promise<boolean>;
  deleteAll(userId: string): Promise<void>;
}
