import type { DiagnosticReport } from "./contracts";

export function hasDiagnosticTaskEvidence({ taskFulfillment }: Pick<DiagnosticReport, "taskFulfillment">): boolean {
  const { position, reasons } = taskFulfillment;
  return position.status === "met" && (reasons.status === "met" || reasons.status === "partly_met") &&
    position.evidence.some((choice) => reasons.evidence.some((reason) =>
      choice.exact !== reason.exact && (reason.start >= choice.end || choice.start >= reason.end),
    ));
}

// Use the anchored task checks for new reports and when displaying saved reports.
export function diagnosticReportState(
  report: Pick<DiagnosticReport, "findings" | "skills" | "taskFulfillment" | "issueFirstObservations">,
): DiagnosticReport["status"] {
  const { findings, skills } = report;
  if (findings.length || report.issueFirstObservations?.length) return "observed";
  return hasDiagnosticTaskEvidence(report) && Object.values(skills).some(({ opportunity }) => opportunity === "adequate")
    ? "no_actionable_findings" : "insufficient_evidence";
}
