import type { DiagnosticOutput, DiagnosticSubmission } from "./contracts";
import { validateWritingDiagnostic } from "./evidence";

type MockDiagnosticFixture = {
  promptId: string;
  text: string;
  output: DiagnosticOutput;
};

const noEvidence: DiagnosticOutput = {
  opportunities: {
    "ARG.SUPPORT": "limited",
    "ORG.PROGRESSION": "limited",
    "LEX.PRECISION": "limited",
    "GRAM.ACCURACY": "limited",
  },
  taskFulfillment: {
    position: { status: "undetermined", evidence: [] },
    reasons: { status: "undetermined", evidence: [] },
    trade_off: { status: "undetermined", evidence: [] },
  },
  findings: [],
};

export function createMockWritingEvaluator(fixtures: readonly MockDiagnosticFixture[] = []) {
  return (submission: DiagnosticSubmission) => {
    const fixture = fixtures.find(({ promptId, text }) =>
      promptId === submission.promptId && text === submission.text,
    );
    return validateWritingDiagnostic(submission, fixture?.output ?? noEvidence);
  };
}
