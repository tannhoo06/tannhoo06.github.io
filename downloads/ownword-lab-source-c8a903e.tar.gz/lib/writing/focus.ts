import { validSource } from "../domain/anchors";
import type { SourceAnchor } from "../domain/types";
import { getExpandedPracticeObjective } from "./practice-library";
import { practiceEdit } from "./practice-objective";
import { getWritingFeedbackEvidence, getWritingProfileSessions, validatedReport, type WritingProfileEvidence, type WritingProfileRecord } from "./profile";
import { getWritingEvidenceSkillTarget } from "./skill-targets";

type Copy = WritingProfileEvidence["title"];
export const WRITING_FOCUS_PIN_LIMIT = 3;
export type WritingFocusStatus = "active" | "dismissed";
export const WRITING_FOCUS_RETURNED_PREFIX = "returned:";
export type WritingFocusState = WritingFocusStatus | "returned";
export type WritingFocusAction = "add" | "remove" | "dismiss" | "restore";
export type WritingFocusExcerpt = { before: string; exact: string; after: string };
export type WritingFocusCard = {
  key: string;
  title: Copy;
  sessionCount: number;
  example: WritingFocusExcerpt;
  coached?: boolean;
};
export type WritingFocusBoard = {
  active: WritingFocusCard[];
  suggestions: WritingFocusCard[];
  dismissed: Pick<WritingFocusCard, "key" | "title">[];
  pinCount: number;
  pinLimit: number;
  coachedCount: number;
  coachingAvailable?: boolean;
};
export type WritingFocusDetail = {
  title: Copy;
  evidence: {
    submissionId: string;
    sourceTitle: string;
    createdAt: string;
    explanation: Copy;
    cue: Copy | null;
    replacement: string | null;
    examples: WritingFocusExcerpt[];
  }[];
};

const topics = {
  "subject-verb-agreement": {
    title: { en: "Subject–verb agreement", vi: "Hòa hợp chủ ngữ và động từ" },
    guidance: "Check whether each finite verb agrees with its subject in person and number.",
  },
  "however-contrast": {
    title: { en: "Punctuation with ‘however’", vi: "Dấu câu với however" },
    guidance: "Check punctuation when conjunctive ‘however’ introduces a complete contrasting clause.",
  },
  "comma-splice": {
    title: { en: "Joining clauses with a comma", vi: "Nối hai vế bằng dấu phẩy" },
    guidance: "Check for independent clauses incorrectly joined with only a comma.",
  },
  "local:word-borrow-lend": {
    title: { en: "Borrow / lend", vi: "Borrow / lend" },
    guidance: "Check whether ‘borrow’ and ‘lend’ match the direction of a temporary transfer.",
  },
  "discuss-direct-object": {
    title: { en: "Using ‘discuss’ with a direct object", vi: "Dùng tân ngữ trực tiếp sau ‘discuss’" },
    guidance: "Check whether the verb ‘discuss’ is incorrectly followed by ‘about’ and then the topic being discussed. ‘Discuss the plan’ takes a direct object. Accept ‘talk about the plan’ and ‘a discussion about the plan’.",
  },
};
type Topic = keyof typeof topics;

const themes = {
  "theme:relevant-reasons": { en: "Giving reasons that support your claim", vi: "Đưa lý do phù hợp với quan điểm" },
  "theme:developed-examples": { en: "Developing reasons with concrete explanations and examples", vi: "Phát triển lý do bằng giải thích và ví dụ cụ thể" },
  "theme:idea-order": { en: "Putting related ideas in a clear order", vi: "Sắp xếp các ý liên quan theo trình tự rõ ràng" },
  "theme:consistent-claims": { en: "Keeping claims and plans consistent", vi: "Giữ các ý và kế hoạch nhất quán" },
  "theme:clear-references": { en: "Making it clear who or what you mean", vi: "Nêu rõ bạn đang nói đến ai hoặc điều gì" },
  "theme:contextual-wording": { en: "Choosing words that fit the context", vi: "Chọn từ đúng với ngữ cảnh" },
  "theme:clause-joins": { en: "Connecting complete thoughts", vi: "Nối các vế câu hoàn chỉnh" },
  "theme:articles-determiners": { en: "Using articles and determiners with nouns", vi: "Dùng mạo từ và từ hạn định với danh từ" },
  "theme:prepositions": { en: "Using prepositions that fit the phrase", vi: "Dùng giới từ phù hợp với cụm từ" },
  "theme:spelling-mechanics": { en: "Checking spelling carefully", vi: "Kiểm tra chính tả cẩn thận" },
  "theme:punctuation-mechanics": { en: "Using punctuation correctly", vi: "Dùng dấu câu đúng chỗ" },
  "theme:capitalization": { en: "Using capital letters correctly", vi: "Viết hoa đúng chỗ" },
};
type Theme = keyof typeof themes;
const issueThemes: Partial<Record<NonNullable<WritingProfileEvidence["issueKind"]>, Theme>> = {
  reason_link: "theme:relevant-reasons", explanation_gap: "theme:developed-examples",
  sequence_or_grouping: "theme:idea-order", plan_or_claim_consistency: "theme:consistent-claims",
  reference_or_signpost: "theme:clear-references", word_meaning_or_fit: "theme:contextual-wording",
  clause_connection: "theme:clause-joins", spelling: "theme:spelling-mechanics", punctuation: "theme:punctuation-mechanics",
};
const higherOrder = new Set<string>(["theme:relevant-reasons", "theme:developed-examples", "theme:idea-order",
  "theme:consistent-claims", "theme:clear-references", "theme:contextual-wording",
  "local:clarify-person-reference", "local:clarify-action-reference"]);
const foundational = new Set<string>(["theme:articles-determiners", "theme:prepositions", "theme:spelling-mechanics",
  "theme:punctuation-mechanics", "theme:capitalization", "local:article-sound", "local:count-plural",
  "local:depend-on", "local:interested-in", "local:listen-to", "local:wait-for", "local:word-make-decision"]);
const monitoredObjectives = new Set(["local:finished-past", "local:article-sound", "local:count-plural",
  "local:depend-on", "local:enjoy-gerund", "local:word-make-decision", "local:clarify-person-reference", "local:clarify-action-reference"]);
const changedMeaning = /\b(?:revers(?:e|es|ed|ing)\s+(?:\w+\s+){0,4}(?:meaning|purpose|intent|claim|direction)|(?:opposite|contrary)\s+(?:\w+\s+){0,3}(?:meaning|purpose|intent|effect)|(?:changes?|alters?)\s+the\s+(?:intended|original)\s+meaning)\b/iu;

function existingTopicKey(item: WritingProfileEvidence, text: string, replacement: string | null) {
  const edit = practiceEdit(item.anchors[0], replacement);
  const discuss = edit && /^about$/iu.test(edit.before) && edit.after === "" &&
    /\bdiscuss(?:es|ed|ing)?\s*$/iu.test(edit.left) &&
    /^\s*(?:the|a|an|this|that|these|those|our|your|their|my|his|her|its)\s+\p{L}/iu.test(edit.right);
  const borrow = /^borrow(?:s|ed|ing)?$/iu;
  const lend = /^(?:lend(?:s|ing)?|lent)$/iu;
  const transfer = item.issueKind === "word_meaning_or_fit" && edit &&
    (borrow.test(edit.before) && lend.test(edit.after) || lend.test(edit.before) && borrow.test(edit.after));
  return item.practice?.skill ?? getWritingEvidenceSkillTarget(item, text) ??
    (discuss ? "discuss-direct-object" : transfer ? "local:word-borrow-lend" : null);
}

function focusTopicKey(item: WritingProfileEvidence, replacement: string | null, existing: string | null) {
  const anchor = item.anchors[0];
  const edit = practiceEdit(anchor, replacement);
  if (item.issueKind === "grammar_construction" && edit && /\bthe one\s*$/iu.test(edit.left)) {
    const verb = edit.before.toLowerCase();
    const singular = { be: "is", are: "is", have: "has", do: "does" }[verb] ??
      (/[^aeiou]y$/u.test(verb) ? verb.slice(0, -1) + "ies" : verb + (/(?:[sxzo]|ch|sh)$/u.test(verb) ? "es" : "s"));
    const relativeVerb = edit.after.toLowerCase().match(/^(?:that|who|which)\s+([a-z]+)$/u)?.[1];
    if (/^[a-z]+$/u.test(verb) && relativeVerb === singular) return "subject-verb-agreement";
  }
  if (existing?.startsWith("local:spell-") || item.issueKind === "spelling") return "theme:spelling-mechanics";
  if (existing?.startsWith("local:punct-")) return "theme:punctuation-mechanics";
  if (existing?.startsWith("local:word-") && !["local:word-borrow-lend", "local:word-make-decision"].includes(existing)) {
    return "theme:contextual-wording";
  }
  if (existing) return existing;
  const description = `${item.title.en} ${item.description.en} ${item.cue?.en ?? ""}`;
  const mechanicalKind = ["punctuation", "grammar_construction", "other_or_uncertain"].includes(item.issueKind ?? "");
  if ((edit && edit.before.toLowerCase() === edit.after.toLowerCase()) ||
      (mechanicalKind && /\bcapitali[sz]\w*\b/iu.test(description))) {
    return "theme:capitalization";
  }
  if (mechanicalKind && /\bapostrophes?\b/iu.test(description)) return "theme:punctuation-mechanics";
  if (item.issueKind === "grammar_construction" || item.issueKind === "word_meaning_or_fit") {
    // Inserting or removing a sentence-initial word can also change the neighboring word's case.
    const lowerAscii = (value: string) => value.replace(/[A-Z]/gu, (letter) => letter.toLowerCase());
    const local = practiceEdit({ ...anchor, exact: lowerAscii(anchor.exact) }, replacement && lowerAscii(replacement));
    const targets = (tokens: RegExp) => local && (!local.before || tokens.test(local.before)) && (!local.after || tokens.test(local.after));
    if (targets(/^(?:a|an|the|my|your|his|her|its|our|their|this|that|these|those)$/iu) ||
      /\b(?:(?:definite|indefinite|missing) articles?|determiners?)\b/iu.test(description)) return "theme:articles-determiners";
    if (targets(/^(?:at|by|during|for|from|in|into|of|on|onto|over|since|through|to|under|until|upon|with|without)$/iu) ||
      /\bprepositions?\b/iu.test(description)) return "theme:prepositions";
  }
  return item.issueKind && issueThemes[item.issueKind] || null;
}

function focusTopicTitle(key: string) {
  if (Object.hasOwn(themes, key)) return themes[key as Theme];
  return Object.hasOwn(topics, key) ? topics[key as Topic].title : getExpandedPracticeObjective(key)?.title;
}

export function matchBaselineFocusKeys(record: WritingProfileRecord) {
  const report = validatedReport(record);
  return new Map(getWritingFeedbackEvidence(record).filter(({ kind, source }) => kind === "problem" && source === "observation")
    .map((item) => {
      const feedback = report?.issueFirstObservations?.[item.index]?.feedback;
      const replacement = feedback?.category === "mistake" ? feedback.replacement : null;
      const existing = existingTopicKey(item, record.submission.text, replacement);
      return [item.index, focusTopicKey(item, replacement, existing)] as const;
    }));
}

export function writingFocusTargets(keys: readonly string[]) {
  return [...new Set(keys)].sort().flatMap((key) => {
    if (Object.hasOwn(topics, key)) return [{ key, guidance: topics[key as Topic].guidance }];
    if (!monitoredObjectives.has(key)) return [];
    const objective = getExpandedPracticeObjective(key);
    return objective ? [{
      key, guidance: `Check the specific construction “${objective.title.en}”. ${objective.takeaway.en}`,
    }] : [];
  }).slice(0, 6);
}

function excerpt({ exact, sentence, start, end, sentenceStart }: SourceAnchor, preview: boolean): WritingFocusExcerpt {
  const left = start - sentenceStart;
  const right = end - sentenceStart;
  const context = preview ? 45 : 180;
  return {
    before: (left > context ? "…" : "") + sentence.slice(Math.max(0, left - context), left),
    exact: preview && exact.length > 100 ? exact.slice(0, 100) + "…" : exact,
    after: preview && exact.length > 100 ? "" : sentence.slice(right, right + context) + (right + context < sentence.length ? "…" : ""),
  };
}

type Occurrence = {
  item: Pick<WritingProfileEvidence, "submissionId" | "sessionTitle" | "createdAt" | "description" | "cue" | "anchors">;
  replacement: string | null;
  meaningful: boolean;
  consequentialWording?: boolean;
};
type Problem = { key: string; title: Copy; occurrences: Occurrence[]; canonicalKeys: Set<string>; historicalOnly?: boolean };

export function groupWritingFocusProblems(records: readonly WritingProfileRecord[], forRetention = false,
  savedKeys: ReadonlySet<string> = new Set()) {
  const groups = new Map<string, Problem>();
  // A duplicate can become the representative after its earlier copy is
  // deleted. Physical sources also keep saved state intact while filtered.
  const sessions = forRetention ? records.filter(({ submission }) => submission.parentSubmissionId === null &&
    (submission.assistance === "unassisted" || submission.assistance === "unknown"))
    .map((record) => ({ submission: record.submission, report: validatedReport(record), evidence: getWritingFeedbackEvidence(record), task: record.task }))
    : getWritingProfileSessions(records);
  function add(key: string, title: Copy, occurrence: Occurrence, canonical?: string | null) {
    let problem = groups.get(key);
    if (!problem) {
      problem = { key, title, occurrences: [], canonicalKeys: new Set() };
      groups.set(key, problem);
    }
    problem.occurrences.push(occurrence);
    if (canonical && canonical !== key) problem.canonicalKeys.add(canonical);
  }
  for (const { submission, report, evidence, task } of sessions) {
    for (const item of evidence) {
      if (item.kind !== "problem") continue;
      const feedback = item.source === "observation" ? report?.issueFirstObservations?.[item.index]?.feedback : null;
      const replacement = feedback?.category === "mistake" ? feedback.replacement?.trim() || null : null;
      const noteKey = `note:${item.submissionId}:${item.index}`;
      const existing = existingTopicKey(item, submission.text, replacement);
      const topicKey = focusTopicKey(item, replacement, existing);
      const relational = topicKey === "theme:idea-order" || topicKey === "theme:consistent-claims" || topicKey === "theme:clear-references";
      const meaningful = item.materiality === "meaningful" && (!relational || item.anchors.some((first, index) =>
        item.anchors.slice(index + 1).some((second) => first.end <= second.start || second.end <= first.start)));
      const consequentialWording = topicKey === "theme:contextual-wording" && changedMeaning.test(`${item.title.en} ${item.description.en}`);
      const occurrence = { item, replacement, meaningful, consequentialWording };
      if (!topicKey || forRetention || savedKeys.has(noteKey)) add(noteKey, item.title, occurrence, topicKey);
      if (topicKey) add(topicKey, focusTopicTitle(topicKey) ?? item.title, occurrence);
      if (existing && existing !== topicKey && (forRetention || savedKeys.has(existing))) {
        add(existing, focusTopicTitle(existing) ?? item.title, occurrence, topicKey);
      }
    }
    const check = report?.focusCheck;
    if (check?.version !== 1) continue;
    for (const item of check.observations) {
      const { focusTopicKey: key, feedback, evidence: anchors } = item;
      const title = focusTopicTitle(key);
      if (!title || !check.checkedTopicKeys.includes(key) || item.kind !== "problem" || item.profileEvidenceCandidate !== false ||
        !anchors.length || !anchors.every((anchor) => validSource(submission.text, submission.id, anchor))) continue;
      add(key, title, {
        item: { submissionId: submission.id, sessionTitle: task.snapshot.prompt.title || task.snapshot.prompt.scenario,
          createdAt: submission.createdAt, description: { en: item.readerImpact, vi: feedback?.vi.readerImpact ?? null },
          cue: item.revisionCue ? { en: item.revisionCue, vi: feedback?.vi.revisionCue ?? null } : null, anchors },
        replacement: feedback?.category === "mistake" ? feedback.replacement : null,
        meaningful: item.materiality === "meaningful",
      });
    }
  }
  return groups;
}

export function writingFocusBoardProblems(records: readonly WritingProfileRecord[], savedKeys: ReadonlySet<string>) {
  const problems = groupWritingFocusProblems(records, false, savedKeys);
  if ([...savedKeys].some((key) => !problems.has(key))) {
    const physical = groupWritingFocusProblems(records, true);
    for (const key of savedKeys) {
      const problem = physical.get(key);
      if (problem && !problems.has(key)) problems.set(key, { ...problem, historicalOnly: true });
    }
  }
  return problems;
}

function recommendation(problem: Problem) {
  const { key, occurrences, canonicalKeys } = problem;
  if (key.startsWith("note:") || key.startsWith("local:spell-") || canonicalKeys.size) return null;
  const sessions = new Set(occurrences.map(({ item }) => item.submissionId)).size;
  const meaningful = occurrences.filter((occurrence) => occurrence.meaningful);
  const tier = higherOrder.has(key) ? 1 : foundational.has(key) ? 3 : 2;
  if (key === "theme:spelling-mechanics") {
    if (sessions < 3 && new Set(meaningful.map(({ item }) => item.submissionId)).size < 2) return null;
  } else if (tier === 3) {
    if (sessions < 2) return null;
  } else if (key === "theme:contextual-wording") {
    const distinctInstances = meaningful.some(({ item }, index) => meaningful.slice(index + 1).some(({ item: other }) =>
      item.submissionId !== other.submissionId || item.anchors[0].end <= other.anchors[0].start || other.anchors[0].end <= item.anchors[0].start));
    const recurrentWording = sessions >= 2 && meaningful.length > 0;
    if (!recurrentWording && !distinctInstances && !meaningful.some(({ consequentialWording }) => consequentialWording)) return null;
  } else if (!meaningful.length) return null;
  const latest = occurrences.reduce((date, { item }) => item.createdAt > date ? item.createdAt : date, "");
  return { problem, tier, sessions, recurrent: Number(sessions >= 2 && meaningful.length > 0), latest };
}

export function selectWritingFocusSuggestions(problems: ReadonlyMap<string, Problem>, savedKeys: ReadonlySet<string> = new Set()) {
  const represented = new Set(savedKeys);
  for (const key of savedKeys) {
    for (const canonical of problems.get(key)?.canonicalKeys ?? []) represented.add(canonical);
  }
  return [...problems.values()].flatMap((problem) => {
    const candidate = represented.has(problem.key) ? null : recommendation(problem);
    return candidate ? [candidate] : [];
  }).sort((a, b) => b.recurrent - a.recurrent || a.tier - b.tier || b.sessions - a.sessions ||
    b.latest.localeCompare(a.latest) || a.problem.key.localeCompare(b.problem.key))
    .slice(0, 6).map(({ problem }) => summarizeWritingFocus(problem));
}

export function writingFocusHistoryKey(records: readonly WritingProfileRecord[]) {
  return records.map(({ submission, run }) => `${submission.id}:${run?.status === "succeeded" ? run.id : ""}`).sort().join(",");
}

export function summarizeWritingFocus(problem: Problem): WritingFocusCard {
  const { key, title, occurrences } = problem;
  const example = occurrences.find(({ meaningful }) => meaningful) ?? occurrences[0];
  return {
    key, title,
    sessionCount: new Set(occurrences.map(({ item }) => item.submissionId)).size,
    example: excerpt(example.item.anchors[0], true),
  };
}

export function detailWritingFocus(problem: Problem): WritingFocusDetail {
  return {
    title: problem.title,
    evidence: problem.occurrences.map(({ item, replacement }) => ({
      submissionId: item.submissionId, sourceTitle: item.sessionTitle, createdAt: item.createdAt,
      explanation: item.description, cue: item.cue, replacement, examples: item.anchors.map((anchor) => excerpt(anchor, false)),
    })),
  };
}
