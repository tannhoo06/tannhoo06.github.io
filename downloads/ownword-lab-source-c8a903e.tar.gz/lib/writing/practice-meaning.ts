import type { PracticeObjective } from "./practice-objective";

type Copy = PracticeObjective["title"];
type Question = { context: string; lead: string; tail: string; answers: readonly string[]; incorrect: readonly string[] };
type RepairQuestion = Omit<Question, "lead" | "tail"> & { lead: readonly string[]; tail: readonly string[] };
type Scenario = PracticeObjective["scenarios"][number];

const ambiguity = /\b(?:ambiguous|unclear|vague|could refer to|could mean|not clear|hard to tell|can[’']t tell|cannot tell|which.{0,35}(?:means|refers))\b/iu;
const reference = /\b(?:pronoun|reference|refer(?:s|ring)? to|antecedent)\b/iu;
const personPronoun = /\b(?:he|she|they)\b/giu;
const ideaPronoun = /\b(?:this|that)\b/giu;
const ideaSubject = /^\s+(?:is|was|will|would|could|can|might|may|means|makes|made|helps|helped|allows|allowed|lets|led)\b/iu;
const action = /\b(?:add|build|deliver|extend|fund|hold|keep|mail|offer|open|order|pay|post|print|send|shorten|start|switch|visit|work)(?:s|ed|ing)?\b|\b(?:choose|choosing|give|giving|hire|hiring|move|moving|remove|removing|replace|replacing|run|running|share|sharing|stop|stopping|take|taking|use|using)\b/iu;
const personRole = /^(?:the|my|your|his|her|our|their)\s+(assistant|captain|coach|cousin|driver|father|guide|manager|mother|organizer|organiser|partner|receptionist|sister|brother|student|teacher|volunteer|worker)(?=\b)/iu;
const properName = /^\p{Lu}\p{Ll}+(?:\s+\p{Lu}\p{Ll}+)*(?!\p{L})/u;
const personRelation = /\b(?:and|or|asked|called|met(?: with)?|told|talked to|spoke to)\b/iu;
const notNames = new Set("a after also although an and as at because both but by dr each either first for from he her here his however i if in instead it its later mr mrs ms neither no on one only or our she since so some that the their then there these they this those to today tomorrow two we when while yesterday you your".split(" "));

function getReferenceEvidence({ observation, source }: Parameters<PracticeObjective["matches"]>[0], pronoun: RegExp, isIdea = false) {
  const { evidence, feedback, issueKind, kind, problem, readerImpact, revisionCue } = observation;
  if (kind !== "problem" || feedback?.category !== "clarity" || issueKind !== "reference_or_signpost" || feedback.replacement) return null;
  const description = [problem, readerImpact, revisionCue].filter(Boolean).join(" ");
  const mentioned = [...description.matchAll(/[‘“"'](he|she|they|this|that)[’”"']/giu)].map((match) => match[1].toLowerCase());
  if (!ambiguity.test(description) || (!reference.test(description) && !mentioned.length)) return null;

  const tokens = [...source.exact.matchAll(pronoun)].filter((match) => !mentioned.length || mentioned.includes(match[0].toLowerCase()));
  if (tokens.length !== 1) return null;
  const token = tokens[0];
  if (isIdea) {
    const at = source.start - source.sentenceStart + token.index;
    const leading = source.sentence.slice(0, at);
    const following = source.sentence.slice(at + token[0].length);
    if (!/^\s*[“"']?$/u.test(leading) || !ideaSubject.test(following)) return null;
  }

  // Require a nearby second span with no separate paragraph between the cues.
  const clues = evidence.filter((anchor) => {
    const gap = source.start - anchor.end;
    return gap >= 0 && gap <= 80 && (gap === 0 || (!/\n\s*\n/u.test(anchor.after.slice(0, gap)) &&
      !/\n\s*\n/u.test(source.before.slice(-gap))));
  });
  return clues.length ? clues : null;
}

function personAtStart(text: string) {
  const phrase = text.trimStart();
  const role = phrase.match(personRole);
  if (role) return { key: role[1].toLowerCase(), end: role[0].length };
  const name = phrase.match(properName)?.[0];
  if (!name || notNames.has(name.split(/\s+/u)[0].toLowerCase())) return null;
  return { key: name.toLowerCase(), end: name.length };
}

function standalonePerson(text: string) {
  const phrase = text.trim();
  const person = personAtStart(phrase);
  return person?.end === phrase.length ? person.key : null;
}

function namesTwoPeople(input: Parameters<PracticeObjective["matches"]>[0]) {
  const clues = getReferenceEvidence(input, personPronoun);
  if (!clues) return false;
  if (clues.some(({ exact }) => {
    const relation = personRelation.exec(exact);
    if (!relation) return false;
    const first = standalonePerson(exact.slice(0, relation.index));
    const second = personAtStart(exact.slice(relation.index + relation[0].length));
    return first && second && first !== second.key;
  })) return true;
  if (!/\b(?:either|both|two|or)\b/iu.test(input.observation.readerImpact)) return false;
  const individuals = clues.flatMap((clue) => {
    const key = standalonePerson(clue.exact);
    return key ? [{ ...clue, key }] : [];
  });
  return individuals.some((first) => individuals.some((second) => first.end <= second.start && first.key !== second.key));
}

function namesTwoActions(input: Parameters<PracticeObjective["matches"]>[0]) {
  const clues = getReferenceEvidence(input, ideaPronoun, true);
  if (!clues) return false;
  const independent = clues.filter(({ exact }) => action.test(exact));
  return independent.some((first) => independent.some((second) => first.end <= second.start &&
    first.exact.toLowerCase() !== second.exact.toLowerCase())) || clues.some(({ exact }) => {
    const alternatives = exact.split(/\b(?:and|or|versus)\b/iu)
      .map((part) => part.toLowerCase().trim().replace(/\p{P}+$/u, ""));
    return new Set(alternatives.filter((part) => action.test(part))).size >= 2;
  });
}

function referenceScenario(guided: Question, repair: RepairQuestion, pronoun: string, guidance: {
  prompt: Copy; hint: Copy; guidedExplanation: Copy; repairExplanation: Copy;
}): Scenario {
  return {
    guided: {
      context: guided.context, before: guided.lead, after: guided.tail,
      answers: guided.answers, incorrect: guided.incorrect, prompt: guidance.prompt,
      hint: guidance.hint, explanation: guidance.guidedExplanation,
    },
    repair: {
      context: repair.context, parts: [...repair.lead, ` ${pronoun}`, ...repair.tail], target: repair.lead.length,
      answers: repair.answers, incorrect: [pronoun, ...repair.incorrect],
      hint: guidance.hint, explanation: guidance.repairExplanation,
    },
  };
}

function personScenario(guided: Question, repair: RepairQuestion, pronoun: string) {
  return referenceScenario(guided, repair, pronoun, {
    prompt: { en: "Name the person who does this. Use the note to tell who it is.", vi: "Dựa vào ghi chú, điền tên hoặc vai trò của người thực hiện việc này." },
    hint: { en: "Check the note for who has this job. A name or a clear role makes it easier to follow.",
      vi: "Xem ghi chú để biết ai làm việc này. Dùng tên hoặc vai trò cụ thể để người đọc dễ theo dõi." },
    guidedExplanation: { en: "The completed sentence identifies one person, so readers know who does the action.",
      vi: "Câu đã điền nêu rõ một người, nên người đọc biết ai thực hiện việc đó." },
    repairExplanation: { en: "The note tells us who does the action. Naming that person removes the ambiguity.",
      vi: "Ghi chú cho biết ai thực hiện việc đó. Khi gọi tên người này, câu trở nên rõ nghĩa hơn." },
  });
}

function actionScenario(guided: Question, repair: RepairQuestion, pronoun: string) {
  return referenceScenario(guided, repair, pronoun, {
    prompt: { en: "Name the action that leads to this result.", vi: "Điền việc dẫn đến kết quả trong câu." },
    hint: { en: "Use the note to check which action has this effect. Name the action so the reader can follow.",
      vi: "Đọc ghi chú để xem việc nào dẫn đến kết quả này. Nêu rõ việc đó để người đọc dễ theo dõi." },
    guidedExplanation: { en: "Naming the action makes the link to its result clear.",
      vi: "Khi nêu rõ việc cần làm, bạn giúp người đọc hiểu vì sao có kết quả này." },
    repairExplanation: { en: "This names the action in the note, so readers can see what leads to the result.",
      vi: "Cách sửa nhắc đúng việc trong ghi chú, nên người đọc biết kết quả đến từ đâu." },
  });
}

export const meaningPracticeObjectives: readonly PracticeObjective[] = [
  {
    id: "clarify-person-reference",
    title: { en: "Make it clear who you mean", vi: "Nêu rõ bạn đang nói đến ai" },
    label: { en: "Clarify a pronoun", vi: "Làm rõ đại từ" },
    matches: namesTwoPeople,
    takeaway: { en: "When two people could fit a pronoun, name the person you mean.",
      vi: "Khi một đại từ có thể chỉ hai người khác nhau, hãy nêu tên người bạn muốn nói tới." },
    scenarios: [
      personScenario({
        context: "Nina, the caretaker, is collecting the keys. Ava is checking the room.", lead: "Ava met Nina before the event.", tail: "will collect the keys.",
        answers: ["Nina", "The caretaker", "Nina, the caretaker,"], incorrect: ["Ava", "She", "They", "Ava and Nina"],
      }, {
        context: "Maya handles publicity and prints the flyers. Lucy books the hall.",
        lead: ["Maya and Lucy", " reviewed", " the job list."], tail: [" will print", " the flyers."],
        answers: ["Maya", "The person handling publicity"], incorrect: ["Lucy", "Maya and Lucy", "They"],
      }, "She"),
      personScenario({
        context: "Samir is the technical lead. Leo is the organizer. The technical lead must restart the equipment.",
        lead: "Samir and Leo saw the projector stop working.", tail: "will restart the equipment.",
        answers: ["Samir", "The technical lead"], incorrect: ["Leo", "The organizer", "He", "They"],
      }, {
        context: "Daniel is the captain, and Noah keeps score. The captain will email the schedule.",
        lead: ["Daniel and Noah", " discussed", " tomorrow’s game."], tail: [" will email", " the schedule."],
        answers: ["Daniel", "The captain", "The team captain"], incorrect: ["Noah", "The scorekeeper", "They"],
      }, "He"),
      personScenario({
        context: "Alex, the builder, measured the window. Jo, the designer, sketched the plan.",
        lead: "Alex and Jo worked in the same room.", tail: "measured the window.",
        answers: ["Alex", "The builder"], incorrect: ["Jo", "The designer", "They", "Alex and Jo"],
      }, {
        context: "Mina is the lead guide and hands out maps. Leah signs visitors in.",
        lead: ["Mina and Leah", " welcomed a group."], tail: [" handed out", " maps."],
        answers: ["Mina", "The lead guide", "The guide"], incorrect: ["Leah", "They", "Mina and Leah"],
      }, "She"),
    ],
  },
  {
    id: "clarify-action-reference",
    title: { en: "Name the idea behind ‘this’ or ‘that’", vi: "Nói rõ ‘this’ hoặc ‘that’ chỉ việc gì" },
    label: { en: "Clarify ‘this’ or ‘that’", vi: "Làm rõ ‘this’ hoặc ‘that’" },
    matches: namesTwoActions,
    takeaway: { en: "After presenting more than one action, name the action you mean before explaining its effect.",
      vi: "Sau khi nêu nhiều việc, hãy nói rõ việc nào trước khi giải thích kết quả của nó." },
    scenarios: [
      actionScenario({
        context: "Posting online would avoid printing costs. Mailing flyers still requires printing.",
        lead: "The team considered mailing flyers or posting the details online.", tail: "would save the team money on printing.",
        answers: ["Posting the details online", "Posting online", "Sharing the details online", "Publishing the details online", "An online announcement"],
        incorrect: ["Mailing flyers", "Both options", "This", "That", "It"],
      }, {
        context: "Only the library has step-free access.",
        lead: ["We considered", " staying where we are", " or moving the event", " to the library."],
        tail: [" would make the event", " easier to access."],
        answers: ["Moving the event to the library", "Moving to the library", "Using the library"],
        incorrect: ["Staying where we are", "This", "It"],
      }, "That"),
      actionScenario({
        context: "A van would keep the whole team together. Individual cars would split the group.",
        lead: "We could hire a van or drive separately.", tail: "would let everyone travel together.",
        answers: ["Hiring a van", "Taking a van", "Traveling in one van", "Travelling in one van", "A van", "The van"],
        incorrect: ["Driving separately", "This", "That", "It"],
      }, {
        context: "Unlike new menus, reusable trays can replace the cafeteria’s single-use containers.",
        lead: ["The cafeteria", " is considering", " reusable trays", " and new menus."], tail: [" would reduce", " single-use containers."],
        answers: ["Introducing reusable trays", "Using reusable trays", "Switching to reusable trays", "Reusable trays"],
        incorrect: ["Printing new menus", "New menus", "That", "It"],
      }, "This"),
      actionScenario({
        context: "Visitors can collect tickets at the entrance or get them by email. Email delivery saves them a trip.",
        lead: "The museum considered in-person pickup and email delivery.", tail: "would spare visitors an extra trip.",
        answers: ["Email delivery", "Sending tickets by email", "Emailing the tickets"],
        incorrect: ["In-person pickup", "Collecting tickets", "This", "That", "It"],
      }, {
        context: "Adding chairs would give everyone a seat in the usual room.",
        lead: ["The club could", " order extra chairs", " or move to a larger room."], tail: [" would let us meet", " in our usual space."],
        answers: ["Ordering extra chairs", "Ordering more chairs", "Getting extra chairs", "Adding chairs"],
        incorrect: ["Moving to a larger room", "This", "It"],
      }, "That"),
    ],
  },
];
