import type { PracticeObjective } from "./practice-objective";

type Copy = PracticeObjective["title"];
type Context = Parameters<PracticeObjective["matches"]>[0];
type Edit = NonNullable<Context["edit"]>;
type Scenario = PracticeObjective["scenarios"][number];
type GuidedSlot = readonly [before: string, after: string, answers: readonly string[], incorrect?: readonly string[], context?: string];
type RepairSlot = readonly [parts: readonly string[], target: number, answers: readonly string[], incorrect?: readonly string[]];

const copy = (en: string, vi: string): Copy => ({ en, vi });
const normalize = (text: string) => text.trim().toLowerCase().replace(/[’‘]/gu, "'").replace(/\s+/gu, " ");

function transfers(
  edit: Edit, candidates: Readonly<Record<string, readonly string[]>>, right: RegExp,
) {
  const before = normalize(edit.before);
  return Object.hasOwn(candidates, before) && candidates[before].includes(normalize(edit.after)) && right.test(edit.right);
}

function wordChoice(
  id: string, title: Copy, label: Copy, matches: (edit: Edit) => boolean, prompt: Copy, hint: Copy, rule: Copy,
  pairs: readonly (readonly [GuidedSlot, RepairSlot])[],
  options: { additionalIssue?: "grammar_construction" | "spelling"; verifiesUnattributedEdit?: true } = {},
): PracticeObjective {
  return {
    id, title, label, takeaway: rule, verifiesUnattributedEdit: options.verifiesUnattributedEdit,
    matches: ({ observation, edit }) => !!edit && (
      observation.issueKind === "word_meaning_or_fit" || observation.issueKind === options.additionalIssue
    ) && matches(edit),
    scenarios: pairs.map(([[before, after, answers, incorrect, context], [parts, target, repairs, badRepairs]]) => ({
      guided: { before, after, context, prompt, hint, answers, incorrect, explanation: rule },
      repair: { parts, target, answers: repairs, incorrect: badRepairs, hint, explanation: rule },
    })),
  };
}

const words = [
  wordChoice(
    "word-mask-sound", copy("Choose words for making a sound harder to hear", "Chọn từ diễn tả việc át tiếng ồn"),
    copy("Masking a sound", "Diễn đạt việc át tiếng ồn"),
    (edit) => transfers(edit, {
      overwrite: ["mask", "cover", "cover up", "drown out"], overwrites: ["masks", "covers", "covers up", "drowns out"],
      overwrote: ["masked", "covered", "covered up", "drowned out"], overwriting: ["masking", "covering", "covering up", "drowning out"],
    }, /^\s+(?:(?:the|some|any|much of the)\s+)?(?:[\w-]+\s+){0,2}(?:sound|noise)\b(?!\s+(?:data|files?|tracks?|recordings?|samples?|settings?|presets?|clips?|buffers?)\b)/iu) &&
      /\b(?:music|playlist|song|fan|rain|drums?|fountain|engine|radio|static|noise)(?:\s+(?:can|could|will|would|might|does|did|to|often|usually|sometimes|completely|partly))*\s*$/iu.test(edit.left),
    copy("Choose an expression for one sound that makes another harder to hear.", "Điền từ hoặc cụm từ diễn tả việc một âm thanh át đi âm thanh khác."),
    copy("The louder sound makes the other harder to notice. Both sounds are still there.", "Âm thanh lớn hơn khiến âm thanh kia khó nghe. Cả hai vẫn cùng phát ra."),
    copy("To mask a sound is to make it harder to hear. To overwrite something is to replace stored information.",
      "‘Mask a sound’ là làm âm thanh đó khó nghe hơn. ‘Overwrite’ thường là ghi đè lên thông tin đã lưu."),
    [
      [["At night, I turn on a fan to", "the street noise.", ["mask", "cover", "cover up", "drown out"], ["overwrite", "delete"]],
        [["At the park, the fountain", " overwrote", " the sound of passing cars."], 1, ["masked", "covered", "covered up", "drowned out"], ["overwrote", "deleted", "masked out"]]],
      [["During the parade, the drums", "the announcer’s voice so completely that we missed the welcome.",
        ["masked", "drowned out", "covered", "covered up"], ["overwrote", "erased"]],
        [["The steady rain", " overwrites", " the sound of the traffic outside."], 1, ["masks", "covers", "covers up", "drowns out"], ["overwrites", "erases"]]],
    ],
  ),
  wordChoice(
    "word-borrow-lend", copy("Choose borrow or lend by who receives", "Phân biệt ‘borrow’ và ‘lend’"),
    copy("Borrowing and lending", "Mượn và cho mượn"),
    (edit) => transfers(edit, { lend: ["borrow"], lends: ["borrows"], lent: ["borrowed"], lending: ["borrowing"] },
      /^\s+(?:a|an|the|his|her|their|your|some)\s+(?:[\w-]+\s+){1,3}from\s+(?:me|you|him|her|us|them|(?:my|our|his|her|a|the)\s+(?:friend|neighbor|neighbour|classmate|library))\b/iu) ||
      transfers(edit, { borrow: ["lend", "loan"], borrows: ["lends", "loans"], borrowed: ["lent", "loaned"], borrowing: ["lending", "loaning"] },
        /^\s+(?:me|you|him|her|us|them)\s+(?:a|an|the|my|your|his|her|our|their|some)\s+\p{L}/iu),
    copy("Choose the verb for the direction the object goes.", "Chọn động từ theo hướng món đồ được chuyển từ ai sang ai."),
    copy("Who receives the thing and who expects to get it back?", "Ai nhận món đồ để dùng tạm, và ai sẽ nhận lại món đồ đó?"),
    copy("The person who takes an item temporarily borrows it. The person who gives it temporarily lends it.",
      "Người nhận đồ để dùng tạm thì ‘borrow’. Người đưa đồ cho người khác dùng tạm thì ‘lend’."),
    [
      [["May I", "a book from the library until Friday?", ["borrow", "check out", "take out"], ["lend", "loan", "buy"]],
        [["Could you", " borrow", " me your spare key until tomorrow?"], 1, ["lend", "loan"], ["borrow", "sell", "lent"]]],
      [["I can", "you a spare umbrella for the afternoon.", ["lend", "loan"], ["borrow", "sell"], "I have a spare umbrella you can use."],
        [["Could I", " lend", " a charger from you until lunch?"], 1, ["borrow"], ["lend", "loan", "borrowed"]]],
    ],
  ),
  wordChoice(
    "word-make-decision", copy("Use a verb that goes with ‘decision’", "Chọn động từ đi với ‘decision’"),
    copy("Making a decision", "Diễn đạt việc đưa ra quyết định"),
    (edit) => transfers(edit, { do: ["make", "reach"], does: ["makes", "reaches"], did: ["made", "reached"], doing: ["making", "reaching"] },
      /^\s+(?:a|the|this|that|my|our|your|his|her|their)\s+(?:(?:final|difficult|big|quick|important)\s+)?decision(?=\s*[,.;:!?]|\s*$|\s+(?:about|on|at|by|before|after|for|with|without)\b)/iu),
    copy("Complete the expression for deciding.", "Điền động từ hoặc cụm từ diễn tả việc đưa ra quyết định."),
    copy("Think of a verb that expresses reaching a choice rather than carrying out a task.", "Hãy nghĩ đến động từ diễn tả việc đi đến một lựa chọn, thay vì thực hiện một nhiệm vụ."),
    copy("English commonly uses ‘make a decision’ or ‘reach a decision’. ‘Do’ does not pair with ‘decision’ in this sense.",
      "Khi nói ‘đưa ra quyết định’, bạn có thể dùng ‘make a decision’ hoặc ‘reach a decision’. ‘Do’ không đi với ‘decision’ theo nghĩa này."),
    [
      [["After trying both apartments, we finally", "a decision about where to live.", ["made", "reached", "came to", "arrived at"], ["did", "do", "maked"]],
        [["Neither train is ideal, so we need to", " do", " a decision by noon."], 1, ["make", "reach", "come to", "arrive at"], ["do", "made", "reached"]]],
      [["We should", "a decision about the dates before we book anything.", ["make", "reach", "come to", "arrive at"], ["do", "did", "made"]],
        [["Yesterday the panel finally", " did", " a decision about which project to fund."], 1, ["made", "reached", "came to", "arrived at"], ["did", "make", "maked"]]],
    ], { verifiesUnattributedEdit: true },
  ),
  wordChoice(
    "word-do-homework", copy("Use an expression for doing assigned work", "Chọn từ diễn tả việc làm bài tập"),
    copy("Doing homework", "Diễn đạt việc làm bài tập"),
    (edit) => transfers(edit, { make: ["do", "finish", "complete"], makes: ["does", "finishes", "completes"],
      made: ["did", "finished", "completed"], making: ["doing", "finishing", "completing"] },
    /^\s+(?:my|our|your|his|her|their)\s+(?:(?:math|maths|science|history|english|assigned)\s+)?homework(?:\s+(?:before|after|at|in|on|as|when|while|with|every|today|yesterday)\b|\s*[,.;!?]|\s*$)/iu),
    copy("Choose a verb for working through a school assignment.", "Điền động từ diễn tả việc làm bài tập được giao."),
    copy("The teacher created the assignment. The learner needs a verb for working through it.", "Giáo viên đã soạn đề bài. Hãy chọn động từ diễn tả việc người học làm bài đó."),
    copy("A learner does, completes, or finishes homework. ‘Make’ would suggest creating the task itself.",
      "Người học dùng ‘do’, ‘complete’ hoặc ‘finish’ khi nói về việc làm bài tập. ‘Make’ dễ khiến người đọc hiểu là bạn tự soạn đề bài."),
    [
      [["Before I can go out, I have to", "the homework my physics teacher assigned.", ["do", "complete", "finish"], ["make", "create"]],
        [["Every afternoon I", " make", " my maths homework before dinner."], 1, ["do", "complete", "finish"], ["make", "create", "does"]]],
      [["My sister", "her homework as soon as she got home from school yesterday.", ["did", "finished", "completed"], ["made", "makes", "do"]],
        [["On Friday we", " made", " our history homework together in the school library."], 1, ["did", "finished", "completed"], ["made", "make", "do"]]],
    ],
  ),
  wordChoice(
    "word-say-tell", copy("Include the listener with say or tell", "Nói rõ người nghe khi dùng ‘say’ và ‘tell’"),
    copy("Say and tell", "Phân biệt ‘say’ và ‘tell’"),
    (edit) => transfers(edit, { say: ["tell"], says: ["tells"], said: ["told"], saying: ["telling"] },
      /^\s+(?:me|us|him|her|you|them)\s+(?:that|i|she|he|you|we|they|it)\b/iu) ||
      (!normalize(edit.before) && normalize(edit.after) === "to" && /\b(?:say|says|said|saying)\s*$/iu.test(edit.left) &&
        /^\s*(?:me|us|him|her|you|them)\s+(?:that|i|she|he|you|we|they|it)\b/iu.test(edit.right)),
    copy("Report what was said and keep the listener in the sentence.", "Tường thuật lời nói và giữ nguyên người nghe trong câu."),
    copy("Check whether the reporting verb needs ‘to’ before the listener.", "Xem động từ tường thuật có cần ‘to’ đứng trước người nghe không."),
    copy("Use ‘tell’ directly before the listener. With ‘say’, use ‘to’ before the listener.",
      "‘Tell’ đứng ngay trước người nghe. Với ‘say’, hãy thêm ‘to’ trước người nghe."),
    [
      [["The receptionist", "that my appointment was at three.", ["told me", "said to me", "informed me"], ["said me", "told to me", "told us"], "I was the listener."],
        [["My teammate", " said me", " that the venue had changed."], 1, ["told me", "said to me", "informed me"], ["said me", "told to me", "told us"]]],
      [["The guide should", "that the museum closes at six.", ["tell us", "say to us", "inform us"], ["say us", "tell to us", "tell them"], "We are the listeners."],
        [["Yesterday our bus driver", " said us", " that the next stop was closed."], 1, ["told us", "said to us", "informed us"], ["said us", "said to me", "tell us"]]],
    ], { additionalIssue: "grammar_construction" },
  ),
  wordChoice(
    "word-raise-rise", copy("Choose raise when someone makes a price go up", "Dùng ‘raise’ khi có người tăng giá"),
    copy("Raising a price", "Diễn đạt việc tăng giá"),
    (edit) => transfers(edit, {
      rise: ["raise", "increase", "put up"], rises: ["raises", "increases", "puts up"],
      rose: ["raised", "increased", "put up"], rising: ["raising", "increasing", "putting up"],
    }, /^\s+(?:(?:the|a|its|their|our|my|his|her|your)\s+)?(?:(?:parking|membership|ticket|food|fuel|monthly|annual)\s+)?(?:rent|prices?|fees?|rates?)\b/iu),
    copy("Choose an expression for someone causing a price to go up.", "Điền từ hoặc cụm từ diễn tả việc ai đó chủ động tăng giá."),
    copy("Someone causes the change. The price is the direct object of the verb.", "Có người chủ động làm giá tăng. Cụm từ chỉ giá ở đây là tân ngữ của động từ."),
    copy("A shop raises prices. Prices themselves rise. ‘Raise’ can take a direct object in this sense.",
      "Cửa hàng ‘raises prices’, còn giá tự tăng là ‘prices rise’. ‘Raise’ đi được với tân ngữ khi dùng theo nghĩa này."),
    [
      [["The bakery may", "its prices next month to cover higher flour costs.", ["raise", "increase", "put up"], ["rise", "raises", "reduce"]],
        [["The landlord plans to", " rise", " the rent in June."], 1, ["raise", "increase", "put up"], ["rise", "rises", "lower"]]],
      [["The council", "the parking fees last summer to pay for repairs.", ["raised", "increased", "put up"], ["rose", "rise", "raises"]],
        [["Last week the gym", " rose", " its membership fees by ten dollars."], 1, ["raised", "increased", "put up"], ["rose", "rise", "raises"]]],
    ],
  ),
  wordChoice(
    "word-make-mistake", copy("Use the expression ‘make a mistake’", "Dùng cụm từ ‘make a mistake’"),
    copy("Making a mistake", "Diễn đạt việc mắc lỗi"),
    (edit) => transfers(edit, { do: ["make"], does: ["makes"], did: ["made"], doing: ["making"] },
      /^\s+(?:a|the)\s+(?:(?:big|small|serious|same|common)\s+)?mistake\b/iu),
    copy("Fill in the verb for making an error.", "Điền động từ diễn tả việc mắc lỗi."),
    copy("Use the verb that expresses producing an error rather than carrying out a task.", "Chọn động từ chỉ việc gây ra lỗi, thay vì thực hiện một công việc."),
    copy("The usual expression is ‘make a mistake’. It describes causing an error.", "Cụm từ thường dùng là ‘make a mistake’, nghĩa là mắc lỗi."),
    [
      [["I think I", "a mistake when I entered my phone number.", ["made"], ["did", "maked"]],
        [["Anyone can", " do", " a small mistake when they are in a hurry."], 1, ["make"], ["do", "made"]]],
      [["It’s easy to", "a mistake when both addresses look alike.", ["make"], ["do", "made"]],
        [["The cashier", " did", " a mistake on my receipt yesterday."], 1, ["made"], ["did", "maked"]]],
    ],
  ),
  wordChoice(
    "word-than-then", copy("Use ‘than’ to compare two things", "Dùng ‘than’ khi so sánh"),
    copy("Than and then", "Phân biệt ‘than’ và ‘then’"),
    (edit) => transfers(edit, { then: ["than"] },
      /^\s+(?:usual|expected|before|yesterday|I expected|last\s+(?:week|month|year)|the\s+(?:first|second|other|old)(?:\s+one)?|(?:my|your|his|her|our|their)\s+usual\s+\p{L}[\p{L}-]*)(?=\s*(?:[,.;:!?]|$))/iu) &&
      /\b(?:earlier|later|cheaper|clearer|better|worse|faster|slower|quicker|higher|lower|warmer|colder|softer|quieter|longer|(?:more|less|fewer)(?:\s+[\w-]+){0,2})\s*$/iu.test(edit.left),
    copy("Choose the word that introduces the comparison.", "Điền từ đứng trước đối tượng được đem ra so sánh."),
    copy("Are the two parts being compared, or are events happening in sequence?", "Câu này đang so sánh hai điều hay kể các việc xảy ra lần lượt?"),
    copy("Use ‘than’ in a comparison. ‘Then’ can mean ‘after that’.", "Dùng ‘than’ để so sánh. ‘Then’ có thể mang nghĩa ‘sau đó’."),
    [
      [["The journey took longer", "I expected.", ["than"], ["then"]],
        [["The second recipe uses less sugar", " then", " the first."], 1, ["than"], ["then"]]],
      [["The second room is quieter", "the first one.", ["than"], ["then"]],
        [["This winter feels colder", " then", " last year."], 1, ["than"], ["then"]]],
    ], { additionalIssue: "spelling", verifiesUnattributedEdit: true },
  ),
];

type SpellingContext = readonly [before: string, after: string];
type SpellingRepair = readonly [before: string, after: string];

function spell(
  id: string, wrong: string, right: string, label: Copy, prompt: Copy, hint: Copy, rule: Copy,
  pairs: readonly (readonly [SpellingContext, SpellingRepair])[], forms: Readonly<Record<string, string>> = {},
): PracticeObjective {
  const answers = [right];
  const incorrect = [wrong];
  const spellingPairs = new Map([[wrong, right], ...Object.entries(forms)]);
  return {
    id, label, title: label, takeaway: rule, verifiesUnattributedEdit: true,
    matches: ({ observation, edit }) => !!edit && observation.issueKind === "spelling" &&
      spellingPairs.get(normalize(edit.before)) === normalize(edit.after),
    scenarios: pairs.map(([[before, after], [repairBefore, repairAfter]]) => ({
      guided: { before, after, prompt, hint, answers, incorrect, explanation: rule },
      repair: { parts: [repairBefore, ` ${wrong}`, repairAfter], target: 1, answers, incorrect, hint, explanation: rule },
    })),
  };
}

const spellings = [
  spell(
    "spell-peaceful", "peacful", "peaceful", copy("Spelling ‘peaceful’", "Viết đúng ‘peaceful’"),
    copy("Write the adjective built from ‘peace’ and ‘-ful’.", "Điền tính từ tạo từ ‘peace’ và đuôi ‘-ful’."),
    copy("Which letter comes at the end of ‘peace’? Keep it before ‘-ful’.", "Chữ cuối của ‘peace’ là chữ nào? Hãy giữ chữ đó trước ‘-ful’."),
    copy("Keep the final ‘e’ in ‘peace’ when you add ‘-ful’.", "Khi thêm ‘-ful’, giữ chữ ‘e’ cuối của ‘peace’."),
    [[ ["The park felt", "in the early morning."], ["They found a", " spot by the river to read."] ],
      [ ["It was a", "evening with no traffic or loud neighbors."], ["The guesthouse was usually", " after sunset."] ]],
  ),
  spell(
    "spell-receive", "recieve", "receive", copy("Spelling ‘receive’", "Viết đúng ‘receive’"),
    copy("Write the verb meaning ‘get’ that starts with ‘rec-’.", "Điền động từ có nghĩa là ‘nhận’, bắt đầu bằng ‘rec-’."),
    copy("Check the order of the two vowels after ‘c’.", "Kiểm tra thứ tự hai nguyên âm sau ‘c’."),
    copy("In ‘receive’, the letters after ‘c’ are ‘ei’.", "Trong ‘receive’, liền sau ‘c’ là hai chữ ‘ei’."),
    [[ ["You will", "your ticket by email."], ["New members", " a welcome pack when they register."] ],
      [ ["I hope to", "the test results by Friday."], ["Did you", " my message about the new address?"] ]],
    { recieved: "received", recieving: "receiving", recieves: "receives" },
  ),
  spell(
    "spell-definitely", "definately", "definitely", copy("Spelling ‘definitely’", "Viết đúng ‘definitely’"),
    copy("Write the adverb built from ‘definite’ and ‘-ly’.", "Điền trạng từ tạo từ ‘definite’ và đuôi ‘-ly’."),
    copy("Keep the vowels of the adjective when you add the ending.", "Hãy giữ cách viết các nguyên âm của tính từ khi thêm đuôi."),
    copy("‘Definitely’ keeps the spelling of ‘definite’ and adds ‘-ly’.", "‘Definitely’ giữ nguyên cách viết của ‘definite’ rồi thêm ‘-ly’."),
    [[ ["I’ll", "bring extra water for the hike."], ["I would", " take that cooking class again."] ],
      [ ["We", "need a bigger table for twelve people."], ["This route is", " quicker before the morning rush."] ]],
    { definetly: "definitely" },
  ),
  spell(
    "spell-separate", "seperate", "separate", copy("Spelling ‘separate’", "Viết đúng ‘separate’"),
    copy("Write the adjective meaning ‘kept apart’ that starts with ‘sep-’.", "Điền tính từ có nghĩa là ‘riêng biệt’, bắt đầu bằng ‘sep-’."),
    copy("Look at the first vowel after ‘sep’.", "Hãy xem lại nguyên âm đầu tiên sau ‘sep’."),
    copy("‘Separate’ has an ‘a’ immediately after ‘sep’.", "Trong ‘separate’, ngay sau ‘sep’ là chữ ‘a’."),
    [[ ["We booked", "rooms because we work different shifts."], ["The café has a", " entrance for deliveries."] ],
      [ ["Please put the receipts in a", "envelope."], ["The two groups used", " buses on the trip."] ]],
    { seperated: "separated", seperately: "separately", seperating: "separating" },
  ),
  spell(
    "spell-a-bit", "abit", "a bit", copy("Spacing in ‘a bit’", "Tách đúng hai từ trong ‘a bit’"),
    copy("Write the short expression for ‘a little’ that uses ‘bit’.", "Điền cụm từ dùng ‘bit’ để diễn tả ‘một chút’."),
    copy("Write it as two words, like ‘a little’.", "Hãy viết thành hai từ, giống như ‘a little’."),
    copy("Write ‘a bit’ as two words, just like ‘a little’.", "Viết ‘a bit’ thành hai từ, giống như ‘a little’."),
    [[ ["Could you turn the volume down", "while I take this call?"], ["The second bus arrived", " later than the first."] ],
      [ ["My bag feels", "heavier with the laptop in it."], ["This sauce tastes", " sweeter than the one we made yesterday."] ]],
  ),
  spell(
    "spell-a-lot", "alot", "a lot", copy("Spacing in ‘a lot’", "Tách đúng hai từ trong ‘a lot’"),
    copy("Write the common expression for ‘very much’ that uses ‘lot’.", "Điền cụm từ dùng ‘lot’ để diễn tả ‘rất nhiều’."),
    copy("Think about whether the article and the noun are one word or two.", "Hãy xem mạo từ và danh từ cần viết liền hay tách thành hai từ."),
    copy("Write ‘a lot’ as two words. ‘Allot’ is a different verb meaning to distribute or assign.",
      "Viết ‘a lot’ thành hai từ. ‘Allot’ là một động từ khác, có nghĩa là phân bổ hoặc phân chia."),
    [[ ["I learned", "from talking with the volunteers."], ["We travel", " during the summer holidays."] ],
      [ ["This recipe leaves", "of sauce for the next day."], ["The door opens", " more easily after the repair."] ]],
  ),
];

const contractionRule = copy(
  "An apostrophe shows where letters have been left out, as in ‘do not’ becoming ‘don’t’.",
  "Dấu nháy chỉ chỗ lược bỏ chữ, chẳng hạn ‘do not’ thành ‘don’t’.",
);
const contractionHint = copy("Which letters disappear when the two words are shortened? Mark that spot with an apostrophe.",
  "Khi rút gọn hai từ, chữ nào bị lược bỏ? Hãy đặt dấu nháy vào chỗ đó.");
const contractions = new Map([
  ["dont", "don't"], ["doesnt", "doesn't"], ["didnt", "didn't"], ["isnt", "isn't"],
  ["arent", "aren't"], ["couldnt", "couldn't"], ["shouldnt", "shouldn't"], ["wouldnt", "wouldn't"],
  ["havent", "haven't"], ["hasnt", "hasn't"], ["hadnt", "hadn't"], ["werent", "weren't"], ["wasnt", "wasn't"],
]);

function contract(
  full: string, right: string, wrong: string, before: string, after: string, parts: readonly string[],
): Scenario {
  return {
    guided: { before, after, prompt: copy(`Write the short form of ‘${full}’.`, `Điền dạng rút gọn của ‘${full}’.`),
      hint: contractionHint, answers: [right], incorrect: [wrong], explanation: contractionRule },
    repair: { parts, target: 1, answers: [right], incorrect: [wrong], hint: contractionHint, explanation: contractionRule },
  };
}

const contraction: PracticeObjective = {
  id: "punct-contraction-apostrophe",
  title: copy("Show omitted letters with an apostrophe", "Dùng dấu nháy ở dạng rút gọn"),
  label: copy("Apostrophes in contractions", "Dấu nháy trong dạng rút gọn"),
  takeaway: contractionRule,
  verifiesUnattributedEdit: true,
  matches: ({ observation, edit }) => !!edit && ["spelling", "punctuation", "grammar_construction"].includes(observation.issueKind) &&
    contractions.get(normalize(edit.before)) === normalize(edit.after),
  scenarios: [
    contract("do not", "don't", "dont", "We", "usually take the bus on Sundays.", ["Please", " dont", " leave the gate open."]),
    contract("does not", "doesn't", "doesnt", "This key", "fit the back door.", ["My cousin", " doesnt", " eat meat."]),
    contract("did not", "didn't", "didnt", "We", "hear the announcement.", ["I", " didnt", " expect to see you here."]),
  ],
};

const possessiveRule = copy(
  "Put ’s after the singular owner. In ‘the watch’s alarm’, the watch is the owner.",
  "Thêm ’s sau danh từ chỉ một chủ sở hữu. Chẳng hạn, ‘the watch’s alarm’ là chuông báo của chiếc đồng hồ.",
);
const singularOwners = new Map([
  ["phones", "phone"], ["laptops", "laptop"], ["tablets", "tablet"], ["cameras", "camera"], ["watches", "watch"],
]);
const possessive: PracticeObjective = {
  id: "punct-singular-device-possessive",
  title: copy("Show who owns something with ’s", "Dùng ’s để chỉ sự sở hữu"),
  label: copy("Apostrophes for possession", "Dấu nháy chỉ sự sở hữu"),
  takeaway: possessiveRule,
  matches: ({ observation, edit }) => {
    if (!edit || !["spelling", "punctuation", "grammar_construction"].includes(observation.issueKind)) return false;
    const owner = singularOwners.get(normalize(edit.before));
    return !!owner && normalize(edit.after) === owner + "'s" &&
      /\b(?:(?:my|your|his|her|their|our|the)\s+(?:only|single|one)|one)\s*$/iu.test(edit.left) &&
      /^\s+(?:alarm|battery|screen|lens|notification(?:s| sounds?)?|charger|keyboard)\b/iu.test(edit.right);
  },
  scenarios: [
    {
      guided: { before: "My", after: "battery died on the way home.", prompt: copy("The battery belongs to one phone. Fill in the owner.",
        "Pin thuộc về một chiếc điện thoại. Điền từ chỉ chủ sở hữu."), hint: possessiveRule,
        answers: ["phone's"], incorrect: ["phones", "phones'"], explanation: possessiveRule },
      repair: { parts: ["My", " cameras", " lens needs cleaning."], target: 1,
        context: "There is just one camera.", answers: ["camera's"], incorrect: ["cameras", "cameras'"], hint: possessiveRule, explanation: possessiveRule },
    },
    {
      guided: { before: "The", after: "screen cracked when I dropped it.", prompt: copy("The screen belongs to one tablet. Fill in the owner.",
        "Màn hình thuộc về một chiếc máy tính bảng. Điền từ chỉ chủ sở hữu."), hint: possessiveRule,
        answers: ["tablet's"], incorrect: ["tablets", "tablets'"], explanation: possessiveRule },
      repair: { parts: ["I forgot my", " laptops", " charger at home."], target: 1,
        context: "The writer has one laptop.", answers: ["laptop's"], incorrect: ["laptops", "laptops'"], hint: possessiveRule, explanation: possessiveRule },
    },
  ],
};

export const wordPracticeObjectives: readonly PracticeObjective[] = [...words, ...spellings, contraction, possessive];
