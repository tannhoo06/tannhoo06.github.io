import type { SourceAnchor } from "../domain/types";
import type { IssueFirstReportObservation } from "./contracts";

type Copy = { en: string; vi: string };
export type ExpandedPracticeSkill = `local:${string}`;

export type PracticeEdit = {
  before: string;
  after: string;
  left: string;
  right: string;
  revisedSentence: string;
};

type AnswerSet = {
  answers: readonly string[];
  incorrect?: readonly string[];
  hint: Copy;
  explanation: Copy;
};

export type PracticeScenario = {
  guided: AnswerSet & { before: string; after: string; prompt: Copy; context?: string };
  repair: AnswerSet & { parts: readonly string[]; target: number; context?: string };
};

export type PracticeObjective = {
  id: string;
  title: Copy;
  label: Copy;
  takeaway: Copy;
  /** This matcher independently verifies the localized edit without rubric attribution. */
  verifiesUnattributedEdit?: true;
  matches: (input: { observation: IssueFirstReportObservation; source: SourceAnchor; edit: PracticeEdit | null }) => boolean;
  scenarios: readonly PracticeScenario[];
};

export const practiceEntryLimit = 64;

/** Preserve the selected words and their offsets when extracting a local suggested edit. */
export function practiceEdit(source: SourceAnchor, replacement: string | null | undefined): PracticeEdit | null {
  if (!replacement || replacement === source.exact) return null;
  const at = source.start - source.sentenceStart;
  const beforeAnchor = source.sentence.slice(0, at);
  const afterAnchor = source.sentence.slice(at + source.exact.length);
  // A highlight can be an exact substring without covering the whole word it claims to fix.
  const wordEnd = /[\p{L}\p{N}][’'–-]?$/u;
  const wordStart = /^[’'–-]?[\p{L}\p{N}]/u;
  if ((wordEnd.test(beforeAnchor) && wordStart.test(source.exact)) ||
    (wordEnd.test(source.exact) && wordStart.test(afterAnchor))) return null;
  const tokenize = (text: string) => [...text.matchAll(/[\p{L}\p{N}]+(?:[’'–-][\p{L}\p{N}]+)*|[^\s]/gu)];
  const original = tokenize(source.exact);
  const suggestion = tokenize(replacement);
  let prefix = 0;
  while (prefix < original.length && prefix < suggestion.length && original[prefix][0] === suggestion[prefix][0]) prefix++;
  let suffix = 0;
  while (suffix < original.length - prefix && suffix < suggestion.length - prefix &&
    original[original.length - 1 - suffix][0] === suggestion[suggestion.length - 1 - suffix][0]) suffix++;
  if (prefix + suffix === original.length && prefix + suffix === suggestion.length) return null;

  function changedRange(tokens: RegExpExecArray[], length: number) {
    const start = tokens[prefix]?.index ?? length;
    const last = tokens[tokens.length - 1 - suffix];
    return { start, end: prefix + suffix < tokens.length ? last.index + last[0].length : start };
  }

  const originalRange = changedRange(original, source.exact.length);
  const suggestedRange = changedRange(suggestion, replacement.length);
  return {
    before: source.exact.slice(originalRange.start, originalRange.end),
    after: replacement.slice(suggestedRange.start, suggestedRange.end),
    left: source.sentence.slice(0, at + originalRange.start),
    right: source.sentence.slice(at + originalRange.end),
    revisedSentence: beforeAnchor + replacement + afterAnchor,
  };
}

const normalizeAnswer = (text: string) => text.normalize("NFC").trim().replace(/[‘’]/gu, "'").replace(/\s+/gu, " ");

export function checkPracticeChoice(exercise: AnswerSet, attempt: string) {
  const value = normalizeAnswer(attempt);
  const answer = exercise.answers.find((option) => normalizeAnswer(option).toLowerCase() === value.toLowerCase());
  if (answer) return { status: "successful" as const, answer, feedback: exercise.explanation };
  const knownWrong = exercise.incorrect?.some((option) => normalizeAnswer(option).toLowerCase() === value.toLowerCase());
  return knownWrong ? { status: "revise" as const, feedback: exercise.hint } : {
    status: "unverified" as const,
    feedback: {
      en: "This exercise can only verify some answers for this context. Your wording may still work.",
      vi: "Bài luyện chỉ kiểm tra được một số cách trả lời trong ngữ cảnh này. Cách viết của bạn vẫn có thể phù hợp.",
    },
  };
}

/** Structural checks are separate from answer grading. Authors still review the English and intended meaning. */
export function validatePracticeObjectives(objectives: readonly PracticeObjective[]): string[] {
  const errors: string[] = [];
  const seen = new Set<string>();
  const validCopy = (copy: Copy) => Boolean(copy.en.trim() && copy.vi.trim());
  function validAnswers(task: AnswerSet) {
    const accepted = task.answers.map((answer) => normalizeAnswer(answer).toLowerCase());
    return accepted.length > 0 && task.answers.every((answer) => answer === answer.trim()) &&
      accepted.every((answer) => answer.length > 0 && answer.length <= practiceEntryLimit) &&
      !task.incorrect?.some((answer) => accepted.includes(normalizeAnswer(answer).toLowerCase())) &&
      validCopy(task.hint) && validCopy(task.explanation);
  }
  for (const objective of objectives) {
    const { id, label, title, scenarios, takeaway } = objective;
    if (seen.has(id) || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id) || !validCopy(label) || !validCopy(title) ||
      !validCopy(takeaway) || scenarios.length < 2) errors.push(id);
    seen.add(id);
    const contexts = new Set<string>();
    scenarios.forEach(({ guided, repair }, index) => {
      const original = repair.parts.join("");
      const selected = repair.parts[repair.target]?.trim();
      const prompt = `${guided.before} ___ ${guided.after}`;
      if ((!guided.before.trim() && !guided.after.trim()) || !validCopy(guided.prompt) || !validAnswers(guided) ||
        repair.parts.length < 2 || !Number.isInteger(repair.target) || !selected ||
        !repair.parts.every((part) => part.trim() && part === part.trimEnd()) ||
        !validAnswers(repair) || repair.answers.some((answer) => normalizeAnswer(answer).toLowerCase() === normalizeAnswer(selected).toLowerCase()) ||
        contexts.has(prompt) || contexts.has(original)) errors.push(`${id}:${index}`);
      contexts.add(prompt);
      contexts.add(original);
    });
  }
  return errors;
}
