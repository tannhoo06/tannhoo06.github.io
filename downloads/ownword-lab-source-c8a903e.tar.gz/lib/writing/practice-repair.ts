import { formatCoreClauseJunction, type CoreWritingPracticeSkill, type WritingPracticeSkill } from "./personalized-practice";
import { expandedPracticeId, getExpandedPracticeObjective, getExpandedPracticeScenario } from "./practice-library";
import { checkPracticeChoice, practiceEntryLimit } from "./practice-objective";
import { formatWritingHoweverJunction, writingHoweverTakeaway } from "./practice-however";

type Copy = { en: string; vi: string };

export type WritingPracticeRepair = {
  id: string;
  context?: string;
  segments: readonly { id: string; text: string; before: string }[];
};

export type WritingPracticeRepairResult =
  | { status: "wrong-selection" | "wrong-correction" | "unverified"; feedback: Copy }
  | {
    status: "successful";
    feedback: Copy;
    takeaway: Copy;
    sentence: string;
    correctedParts: { before: string; replacement: string; after: string };
  };

export const writingPracticeRepairLimit = practiceEntryLimit;

type AgreementRepair = {
  skill: "subject-verb-agreement";
  exercise: WritingPracticeRepair;
  target: "verb";
  answers: readonly string[];
  incorrect: readonly string[];
  explanation: Copy;
};

type ClauseRepair = {
  skill: "comma-splice";
  exercise: WritingPracticeRepair;
  target: "junction";
  nextSubject: string;
};

type HoweverRepair = {
  skill: "however-contrast";
  exercise: WritingPracticeRepair;
  target: "junction";
  trailingComma: boolean;
};

function agreementRepair(id: string, subject: string, verb: string, detail: readonly string[],
  answers: readonly string[], incorrect: readonly string[], explanation: Copy): AgreementRepair {
  return {
    skill: "subject-verb-agreement",
    target: "verb",
    answers,
    incorrect: [verb, ...incorrect],
    explanation,
    exercise: {
      id,
      segments: [
        { id: "subject", text: subject, before: "" },
        { id: "verb", text: verb, before: " " },
        ...detail.map((phrase, index) => ({ id: `detail-${index}`, text: phrase, before: " " })),
      ],
    },
  };
}

function clauseRepair(id: string, firstSubject: string, firstPredicate: string, nextSubject: string,
  secondVerb: string, end: string): ClauseRepair {
  return {
    skill: "comma-splice",
    target: "junction",
    nextSubject,
    exercise: {
      id,
      segments: [
        { id: "first-subject", text: firstSubject, before: "" },
        { id: "first-predicate", text: firstPredicate, before: " " },
        { id: "junction", text: `, ${nextSubject}`, before: "" },
        { id: "second-verb", text: secondVerb, before: " " },
        { id: "detail", text: end, before: " " },
      ],
    },
  };
}

function howeverRepair(id: string, firstSubject: string, firstPredicate: string, trailingComma: boolean,
  secondSubject: string, secondPredicate: string): HoweverRepair {
  return {
    skill: "however-contrast",
    target: "junction",
    trailingComma,
    exercise: {
      id,
      segments: [
        { id: "first-subject", text: firstSubject, before: "" },
        { id: "first-predicate", text: firstPredicate, before: " " },
        { id: "junction", text: trailingComma ? ", however," : ", however", before: "" },
        { id: "second-subject", text: secondSubject, before: " " },
        { id: "second-predicate", text: secondPredicate, before: " " },
      ],
    },
  };
}

const agreements = [
  agreementRepair("early-start", "My dad", "leave", ["for work", "before sunrise."],
    ["leaves", "does leave", "heads off", "sets off"], ["do leave", "leaving", "doesn't leave", "does not leave"], {
      en: "‘My dad’ is one person. Use a verb form that agrees with a singular subject in the simple present.",
      vi: "‘My dad’ chỉ một người. Ở thì hiện tại đơn, bạn dùng dạng động từ đi với chủ ngữ số ít.",
    }),
  agreementRepair("spare-keys", "My keys", "does not fit", ["this lock."],
    ["do not fit", "don't fit", "do not work in", "don't work in"], ["fit", "do fit", "fits", "doesn't fit"], {
      en: "‘My keys’ is plural, so the negative uses ‘do not’ or ‘don’t’ before the main verb.",
      vi: "‘My keys’ là chủ ngữ số nhiều, nên trong câu phủ định bạn dùng ‘do not’ hoặc ‘don’t’ trước động từ chính.",
    }),
  agreementRepair("mailbox", "My apartment", "have", ["a mailbox", "by the door."],
    ["has", "does have", "has got", "comes with"], ["do have", "have got", "doesn't have", "does not have"], {
      en: "‘My apartment’ is singular. The verb that follows has to agree with that one apartment.",
      vi: "‘My apartment’ chỉ một căn hộ, nên động từ phải đi với chủ ngữ số ít.",
    }),
] as const;

const clauses = [
  clauseRepair("busy-cafe", "The café", "was full", "we", "ordered our coffee", "to go."),
  clauseRepair("dead-battery", "My phone battery", "died", "I", "borrowed a charger", "from my sister."),
  clauseRepair("school-show", "The school play", "sold out", "we", "added a second show", "on Friday."),
] as const;

const howeverClauses = [
  howeverRepair("however-soup", "The soup", "smelled wonderful", false, "it", "tasted too salty."),
  howeverRepair("however-forecast", "The forecast", "looked promising", true, "the game", "was canceled."),
  howeverRepair("however-seat", "I", "saved a seat", false, "my friend", "decided to stand."),
] as const;

const problemsBySkill = {
  "subject-verb-agreement": agreements,
  "comma-splice": clauses,
  "however-contrast": howeverClauses,
};
const problems = [...agreements, ...clauses, ...howeverClauses];

const wrongSelection: Record<CoreWritingPracticeSkill, Copy> = {
  "subject-verb-agreement": {
    en: "This part can stay. Find who or what is doing the action, then check which verb goes with it.",
    vi: "Phần này có thể giữ nguyên. Tìm chủ ngữ rồi đọc lại động từ đi với chủ ngữ đó.",
  },
  "comma-splice": {
    en: "This part can stay. Look for where one complete thought ends and the next begins.",
    vi: "Phần này có thể giữ nguyên. Hãy tìm chỗ kết thúc ý thứ nhất và bắt đầu ý tiếp theo.",
  },
  "however-contrast": {
    en: "This part can stay. Find the spot that joins the two contrasting ideas.",
    vi: "Phần này có thể giữ nguyên. Hãy tìm chỗ nối hai ý đối lập trong câu.",
  },
};

const wrongCorrection: Record<CoreWritingPracticeSkill, Copy> = {
  "subject-verb-agreement": {
    en: "Read the subject with your replacement. Does the verb agree with one person or thing, or with more than one? Keep the original meaning.",
    vi: "Đọc chủ ngữ cùng với phần bạn vừa sửa. Chủ ngữ chỉ một hay nhiều người, vật? Hãy thử đổi dạng động từ và giữ nguyên ý câu.",
  },
  "comma-splice": {
    en: "Read each side on its own. If each can stand as a sentence, a comma alone won’t join them. Keep the same subject in the second part.",
    vi: "Đọc riêng từng vế. Nếu mỗi vế đều đứng được thành câu, chỉ dùng dấu phẩy là chưa đủ. Hãy giữ nguyên chủ ngữ ở vế sau.",
  },
  "however-contrast": {
    en: "Keep ‘however’ as the link. Look for a stronger break before it and a short pause after it.",
    vi: "Hãy giữ từ nối ‘however’. Thử đặt dấu ngắt mạnh hơn trước từ này và dấu ngắt nhẹ ngay sau nó.",
  },
};

const takeaway: Record<CoreWritingPracticeSkill, Copy> = {
  "subject-verb-agreement": {
    en: "When you read over your next piece of writing, pair each main verb with its subject. Check whether the subject refers to one or more than one.",
    vi: "Khi đọc lại bài tiếp theo, hãy ghép động từ chính với chủ ngữ của nó rồi kiểm tra xem chủ ngữ là số ít hay số nhiều.",
  },
  "comma-splice": {
    en: "The next time you use a comma, check whether both parts could stand alone. If they can, give them a stronger break or a connecting word.",
    vi: "Lần tới khi dùng dấu phẩy, thử xem mỗi vế có đứng riêng thành câu được không. Nếu có, hãy dùng dấu câu để tách hai vế hoặc thêm từ nối.",
  },
  "however-contrast": writingHoweverTakeaway,
};

export function getWritingPracticeRepairTakeaway(skill: WritingPracticeSkill) {
  if (skill === "subject-verb-agreement" || skill === "comma-splice" || skill === "however-contrast") return takeaway[skill];
  return expandedObjective(skill).takeaway;
}

export function getWritingPracticeRepair(skill: WritingPracticeSkill, contextIndex: number): WritingPracticeRepair {
  if (skill === "subject-verb-agreement" || skill === "comma-splice" || skill === "however-contrast") {
    const variants = problemsBySkill[skill];
    return (variants[contextIndex] ?? variants[0]).exercise;
  }
  const objective = expandedObjective(skill);
  const index = objective.scenarios[contextIndex] ? contextIndex : 0;
  const { repair } = objective.scenarios[index];
  return {
    id: expandedPracticeId(skill, index), context: repair.context,
    segments: repair.parts.map((part, partIndex) => ({ id: String(partIndex), before: part.match(/^\s*/u)![0], text: part.trim() })),
  };
}

function expandedObjective(skill: WritingPracticeSkill) {
  const objective = getExpandedPracticeObjective(skill);
  if (!objective) throw new Error("Unknown Writing practice objective.");
  return objective;
}

function resolveReplacement(problem: (typeof problems)[number], answer: string): string | null {
  switch (problem.skill) {
    case "subject-verb-agreement":
      return problem.answers.includes(answer) ? answer : null;
    case "comma-splice":
      return formatCoreClauseJunction(answer, problem.nextSubject);
    case "however-contrast": {
      const match = /^([.;])\s*(?:however\s*)?(,?)$/u.exec(answer);
      if (!match) return null;
      const [, boundary, comma] = match;
      // A one-character edit can preserve a comma that was already correct.
      const trailing = answer === boundary && problem.trailingComma ? "," : comma;
      return formatWritingHoweverJunction(boundary, trailing);
    }
  }
}

export function checkWritingPracticeRepair(
  exercise: WritingPracticeRepair,
  segmentId: string,
  replacement: string,
): WritingPracticeRepairResult {
  const assigned = getExpandedPracticeScenario(exercise.id);
  if (assigned) {
    const { objective, scenario: { repair } } = assigned;
    if (segmentId !== String(repair.target)) return { status: "wrong-selection", feedback: {
      en: `That part can stay. ${repair.hint.en}`, vi: `Phần này có thể giữ nguyên. ${repair.hint.vi}`,
    } };
    const result = checkPracticeChoice(repair, replacement);
    if (result.status === "revise" || replacement.length > writingPracticeRepairLimit) {
      return { status: "wrong-correction", feedback: repair.hint };
    }
    if (result.status === "unverified") return { status: "unverified", feedback: {
      en: `${result.feedback.en} ${repair.hint.en}`, vi: `${result.feedback.vi} ${repair.hint.vi}`,
    } };
    const before = repair.parts.slice(0, repair.target).join("") + repair.parts[repair.target].match(/^\s*/u)![0];
    const after = repair.parts.slice(repair.target + 1).join("");
    return { status: "successful", feedback: result.feedback, takeaway: objective.takeaway,
      sentence: before + result.answer + after, correctedParts: { before, replacement: result.answer, after } };
  }
  const problem = problems.find(({ exercise: candidate }) => candidate.id === exercise.id);
  if (!problem) throw new Error("Unknown writing repair exercise.");
  if (segmentId !== problem.target) return { status: "wrong-selection", feedback: wrongSelection[problem.skill] };
  if (replacement.length > writingPracticeRepairLimit) return { status: "wrong-correction", feedback: wrongCorrection[problem.skill] };
  const answer = replacement.trim().toLowerCase().replace(/[’‘]/gu, "'").replace(/\s+/gu, " ");
  const changed = resolveReplacement(problem, answer);
  if (!changed) {
    const possibleAlternative = (problem.skill === "subject-verb-agreement" && /^[a-z]+(?:[ ’'][a-z]+){0,4}$/u.test(answer) &&
      !problem.incorrect.includes(answer)) || (problem.skill === "comma-splice" &&
      /^(?:[.;,–—]\s*)?(?:but|yet|however,?|thus,?|hence,?)(?:\s+[a-z]+)?$/u.test(answer));
    return possibleAlternative ? { status: "unverified", feedback: {
      en: `This exercise cannot verify that wording. ${wrongCorrection[problem.skill].en}`,
      vi: `Bài luyện chưa kiểm tra được cách viết này. ${wrongCorrection[problem.skill].vi}`,
    } } : { status: "wrong-correction", feedback: wrongCorrection[problem.skill] };
  }

  const { segments } = problem.exercise;
  const index = segments.findIndex(({ id }) => id === segmentId);
  const join = (parts: typeof segments) => parts.map(({ before, text }) => before + text).join("");
  const before = join(segments.slice(0, index)) + segments[index].before;
  const after = join(segments.slice(index + 1));
  return {
    status: "successful",
    feedback: successFeedback(problem),
    takeaway: takeaway[problem.skill],
    sentence: before + changed + after,
    correctedParts: { before, replacement: changed, after },
  };
}

function successFeedback(problem: (typeof problems)[number]): Copy {
  switch (problem.skill) {
    case "subject-verb-agreement":
      return problem.explanation;
    case "comma-splice":
      return {
        en: "Both clauses can stand on their own. Your edit gives them a clearer connection or a distinct break.",
        vi: "Mỗi vế đều có thể đứng riêng thành câu. Cách sửa của bạn nối hai ý rõ hơn hoặc tách chúng ra.",
      };
    case "however-contrast":
      return {
        en: "Your punctuation separates the two complete thoughts and keeps the contrast clear.",
        vi: "Bạn đã dùng dấu câu để tách hai ý hoàn chỉnh mà vẫn giữ rõ sự đối lập giữa chúng.",
      };
  }
}
