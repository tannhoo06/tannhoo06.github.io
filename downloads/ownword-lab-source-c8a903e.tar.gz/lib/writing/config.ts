import { z } from "zod";

const count = z.coerce.number().int().min(1).max(100);

export function isWritingEnabled(environment: Record<string, unknown>) {
  return environment.WRITING_MODULE_ENABLED === "true";
}

export function readWritingConfig(environment: Record<string, unknown>) {
  if (!isWritingEnabled(environment)) return null;
  const successes = count.parse(environment.WRITING_DIAGNOSTIC_DAILY_LIMIT ?? 8);
  const attempts = count.min(successes).parse(environment.WRITING_DIAGNOSTIC_ATTEMPT_LIMIT ?? Math.max(12, successes));
  return { successes, attempts };
}

export function readHostedWritingRuntime(environment: Record<string, unknown>) {
  const key = typeof environment.WRITING_TERRA_OPENROUTER_API_KEY === "string"
    ? environment.WRITING_TERRA_OPENROUTER_API_KEY.trim() : "";
  const terra = isWritingEnabled(environment) && environment.WRITING_TERRA_ENABLED === "true" && !!key;
  return { key, terra, trends: terra && environment.WRITING_TRENDS_ENABLED === "true" };
}

/** Off keeps the ordinary assessment and historical notes. It never restores coached Pass 1. */
export function writingFocusTwoPassEnabled(environment: Record<string, unknown>) {
  return environment.WRITING_FOCUS_TWO_PASS_ENABLED !== "false";
}
