export type LearningStreak = {
  day: string;
  count: number;
  todayIndex: number;
  week: boolean[];
};

export const streakAwardHeader = "X-Ownword-Streak";

const localDay = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Asia/Ho_Chi_Minh", year: "numeric", month: "2-digit", day: "2-digit",
});

export function learningDay(now: Date) {
  const parts = localDay.formatToParts(now);
  const part = (type: Intl.DateTimeFormatPartTypes) => parts.find((item) => item.type === type)?.value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}

const dayMs = 86_400_000;

export function summarizeStreak(days: readonly { day: string }[], today: string): LearningStreak {
  const todayMs = Date.parse(today);
  const todayIndex = (new Date(todayMs).getUTCDay() + 6) % 7;
  const dateAt = (offset: number) => new Date(todayMs + offset * dayMs).toISOString().slice(0, 10);
  const completed = new Set(days.map(({ day }) => day));
  const week = Array.from({ length: 7 }, (_, index) => index <= todayIndex && completed.has(dateAt(index - todayIndex)));
  let offset = week[todayIndex] ? 0 : -1;
  let count = 0;
  while (completed.has(dateAt(offset))) {
    count++;
    offset--;
  }
  return { day: today, count, todayIndex, week };
}
