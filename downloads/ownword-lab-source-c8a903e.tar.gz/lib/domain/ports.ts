import type {
  AppState,
  Attempt,
  Evaluation,
  Exercise,
  ExerciseKind,
  Identity,
  Insight,
  Lexeme,
  ConceptDiscovery,
  Profile,
  Suggestion,
  UserWord,
  WritingAnalysis,
  WritingReview,
  WordCheck,
} from "./types";

export interface LlmProvider {
  readonly mode: string;
  checkWord(word: string): Promise<WordCheck>;
  defineWord(word: string): Promise<Pick<Lexeme, "partOfSpeech" | "definition" | "nuance" | "collocations" | "examples">>;
  translateLexeme(word: Lexeme): Promise<string>;
  discoverConcept(concept: string): Promise<Lexeme[]>;
  analyzeWriting(text: string, words: UserWord[]): Promise<WritingAnalysis>;
  suggestVocabulary(text: string): Promise<WritingAnalysis["suggestions"]>;
  generateExercise(
    word: UserWord,
    kind: ExerciseKind,
    context: string,
  ): Promise<Pick<Exercise, "prompt" | "semanticHint">>;
  evaluateUsage(
    word: Lexeme,
    text: string,
    context: string,
  ): Promise<Evaluation>;
  evaluateRecall(
    word: Lexeme,
    exercise: Exercise,
    answer: string,
  ): Promise<Evaluation>;
}
export interface Repository {
  ensureUser(identity: Identity, now: string): Promise<Profile>;
  setProfile(
    userId: string,
    changes: { dailyLimit?: number; onboarded?: boolean; name?: string },
  ): Promise<void>;
  listWords(userId: string): Promise<UserWord[]>;
  getManualWordCheck(userId: string, word: string, after: string): Promise<WordCheck | null>;
  saveManualWordCheck(userId: string, word: string, check: WordCheck, now: string): Promise<void>;
  enrichWord(word: Lexeme): Promise<void>;
  saveConceptDiscovery(userId: string, discovery: ConceptDiscovery): Promise<void>;
  getConceptDiscovery(userId: string, id: string): Promise<ConceptDiscovery | null>;
  latestConceptDiscovery(userId: string): Promise<ConceptDiscovery | null>;
  recentConceptDiscovery(userId: string, concept: string, after: string): Promise<ConceptDiscovery | null>;
  saveConceptCandidateTranslation(userId: string, discoveryId: string, candidateId: string, meaning: string): Promise<void>;
  addWord(
    userId: string,
    word: Lexeme,
    options: {
      source: string;
      sourceText: string;
      now: string;
      introduced: boolean;
      demo?: boolean;
      stage?: UserWord["stage"];
      nextReviewAt?: string;
    },
  ): Promise<string>;
  introduce(userId: string, wordIds: string[], now: string): Promise<void>;
  saveWriting(
    userId: string,
    text: string,
    prompt: string,
    now: string,
  ): Promise<string>;
  listWriting(
    userId: string,
  ): Promise<{ id: string; text: string; createdAt: string }[]>;
  saveSuggestions(
    userId: string,
    sampleId: string,
    suggestions: WritingAnalysis["suggestions"],
  ): Promise<Suggestion[]>;
  getSuggestion(userId: string, id: string): Promise<Suggestion | null>;
  saveReview(userId: string, review: WritingReview): Promise<void>;
  getReview(userId: string, sampleId: string): Promise<WritingReview | null>;
  recentWritingReview(userId: string, text: string, prompt: string, signature: string, after: string): Promise<WritingReview | null>;
  saveDecision(
    userId: string,
    id: string,
    decision: Pick<
      Suggestion,
      "status" | "savedWordId" | "queued" | "ownsSavedWord"
    >,
  ): Promise<void>;
  removeUnpracticedWord(
    userId: string,
    id: string,
    source: string,
  ): Promise<boolean>;
  removeWord(userId: string, id: string, now: string): Promise<boolean>;
  decideSuggestion(
    userId: string,
    id: string,
    decision: Suggestion["status"],
  ): Promise<void>;
  saveInsights(userId: string, insights: Insight[], now: string): Promise<void>;
  createSession(
    userId: string,
    exercises: Exercise[],
    now: string,
  ): Promise<string>;
  getExercise(userId: string, id: string): Promise<Exercise | null>;
  getSession(userId: string, sessionId: string): Promise<Exercise[]>;
  setHint(
    userId: string,
    exerciseId: string,
    hint: Exercise["hint"],
  ): Promise<void>;
  setSentencePending(userId: string, exerciseId: string): Promise<boolean>;
  recordAttempt(
    userId: string,
    attempt: Attempt,
    stage: UserWord["stage"],
    nextReviewAt: string,
  ): Promise<boolean>;
  removeDemo(userId: string): Promise<void>;
  consumeRateLimit(
    userId: string,
    now: string,
    maximum: number,
  ): Promise<boolean>;
  discoveryCount(userId: string, day: string, kind: "concept" | "writing"): Promise<number>;
  consumeDiscovery(userId: string, day: string, kind: "concept" | "writing", maximum: number): Promise<boolean>;
}
export interface AuthProvider {
  currentIdentity(): Promise<Identity | null>;
}
export interface AppServices {
  state(): Promise<AppState>;
}
