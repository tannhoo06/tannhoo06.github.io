import type { HintLevel } from "./types";

/** Keep a granted spelling hint in the answer itself, including after a reload. */
export function applySpellingHint(answer: string, hint: HintLevel, word: string): string {
  if (!word) return answer;
  const count = hint === "letter" ? 1 : hint === "partial" ? Math.min(3, word.length) : 0;
  if (!count) return answer;
  return (word.slice(0, count) + answer.slice(count)).slice(0, word.length);
}
