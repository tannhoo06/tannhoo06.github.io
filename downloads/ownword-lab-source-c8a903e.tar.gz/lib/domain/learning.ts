import type {
  Attempt,
  ExerciseKind,
  HintLevel,
  Stage,
  UserWord,
} from "./types";

export interface LearningPolicy {
  minOccasionHours: number;
  practicingSuccesses: number;
  activeSuccesses: number;
  activeSpanDays: number;
  activeContexts: number;
  recentWindow: number;
  recentRecall: number;
  activeIndependent: number;
  demotionFailures: number;
  sessionSize: number;
  maintenanceDays: number[];
  newPerDay: number;
}
export const DEFAULT_POLICY: LearningPolicy = {
  minOccasionHours: 6,
  practicingSuccesses: 2,
  activeSuccesses: 5,
  activeSpanDays: 7,
  activeContexts: 3,
  recentWindow: 5,
  recentRecall: 0.8,
  activeIndependent: 1,
  demotionFailures: 2,
  sessionSize: 6,
  maintenanceDays: [7, 21, 45, 90],
  newPerDay: 3,
};
export const DAY = 86_400_000;
const kindWeight: Record<ExerciseKind, number> = {
  strong: 0.55,
  completion: 0.75,
  rewrite: 0.85,
  contrast: 0.75,
  open: 1,
  free: 1.1,
  spontaneous: 1.4,
};
const hintWeight: Record<HintLevel, number> = {
  none: 1,
  semantic: 0.75,
  letter: 0.4,
  partial: 0.2,
  revealed: 0,
};
export function credit(a: Attempt) {
  return a.context !== "quick-review" && a.retrieved && !a.majorMisuse
    ? kindWeight[a.kind] * hintWeight[a.hint]
    : 0;
}
export function independent(a: Attempt) {
  return (
    ["open", "free", "spontaneous"].includes(a.kind) &&
    a.hint === "none" &&
    a.retrieved &&
    a.precise
  );
}
export function occasions(attempts: Attempt[], policy = DEFAULT_POLICY) {
  const out: Attempt[] = [];
  for (const a of [...attempts].sort((a, b) => a.at.localeCompare(b.at))) {
    if (credit(a) < 0.5) continue;
    const previous = out.at(-1);
    if (
      !previous ||
      (Date.parse(a.at) - Date.parse(previous.at) >=
        policy.minOccasionHours * 3_600_000 &&
        a.at.slice(0, 10) !== previous.at.slice(0, 10))
    )
      out.push(a);
  }
  return out;
}
export function evidence(attempts: Attempt[], policy = DEFAULT_POLICY) {
  const sorted = attempts
    .filter((a) => a.context !== "quick-review")
    .sort((a, b) => a.at.localeCompare(b.at));
  const meaningful = occasions(sorted, policy);
  // Revealing the answer is useful practice, but still evidence that recall needed help.
  const tests = sorted;
  const recent = tests.slice(-policy.recentWindow);
  const correct = meaningful.filter((a) => a.precise);
  const spanDays =
    meaningful.length > 1
      ? (Date.parse(meaningful.at(-1)!.at) - Date.parse(meaningful[0].at)) / DAY
      : 0;
  return {
    successes: meaningful.length,
    precise: sorted.filter((a) => a.precise && !a.majorMisuse).length,
    contexts: new Set(correct.map((a) => a.context)).size,
    spanDays,
    recall: recent.length
      ? recent.filter(
          (a) => a.retrieved && !a.majorMisuse && a.hint !== "revealed",
        ).length / recent.length
      : 0,
    independent: meaningful.filter(independent).length,
    spontaneous: meaningful.filter((a) => a.kind === "spontaneous" && a.precise)
      .length,
    hintDependence: tests.length
      ? tests.filter((a) => a.hint !== "none").length / tests.length
      : 0,
    recentMajorMisuses: recent.filter((a) => a.majorMisuse).length,
    failed: tests.filter(
      (a) => !a.retrieved || a.majorMisuse || a.hint === "revealed",
    ).length,
  };
}
export function qualifiesForActive(attempts: Attempt[], p = DEFAULT_POLICY) {
  const e = evidence(attempts, p);
  return (
    e.successes >= p.activeSuccesses &&
    e.spanDays >= p.activeSpanDays &&
    e.contexts >= p.activeContexts &&
    e.recall >= p.recentRecall &&
    e.independent >= p.activeIndependent &&
    e.recentMajorMisuses < 2
  );
}
export function progress(
  current: Stage,
  attempts: Attempt[],
  p = DEFAULT_POLICY,
): Stage {
  const sorted = attempts
    .filter((a) => a.context !== "quick-review")
    .sort((a, b) => a.at.localeCompare(b.at));
  if (current === "active") {
    const distinctFailures: Attempt[] = [];
    for (const a of sorted.reverse()) {
      if (a.retrieved && a.precise && !a.majorMisuse && a.hint !== "revealed")
        break;
      if (
        !distinctFailures.some((f) => f.at.slice(0, 10) === a.at.slice(0, 10))
      )
        distinctFailures.push(a);
    }
    return distinctFailures.length >= p.demotionFailures
      ? "practicing"
      : "active";
  }
  if (qualifiesForActive(sorted, p)) return "active";
  const e = evidence(sorted, p);
  if (
    current === "practicing" ||
    (e.successes >= p.practicingSuccesses && e.precise > 0)
  )
    return "practicing";
  return "new";
}
export function nextReview(
  stage: Stage,
  attempts: Attempt[],
  now: Date,
  policy = DEFAULT_POLICY,
) {
  const last = attempts.at(-1);
  let days = 1;
  if (last?.retrieved && !last.majorMisuse && last.hint !== "revealed") {
    if (stage === "active") {
      const successes = Math.max(
        0,
        occasions(attempts, policy).length - policy.activeSuccesses,
      );
      days =
        policy.maintenanceDays[
          Math.min(successes, policy.maintenanceDays.length - 1)
        ];
    } else
      days =
        stage === "new"
          ? 1
          : [2, 4, 7][
              Math.min(Math.max(evidence(attempts, policy).successes - 2, 0), 2)
            ];
  }
  return new Date(now.getTime() + days * DAY).toISOString();
}
export function exerciseKind(word: UserWord): ExerciseKind {
  const e = evidence(word.attempts);
  if (word.stage === "active")
    return word.attempts.length % 2 ? "free" : "open";
  if (!e.successes) return "strong";
  if (e.successes === 1) return "completion";
  if (e.successes === 2) return "rewrite";
  if (e.successes === 3) return "contrast";
  return word.attempts.length % 2 ? "free" : "open";
}
export function dueWords(
  words: UserWord[],
  now: Date,
  limit = DEFAULT_POLICY.sessionSize,
) {
  return words
    .filter(
      (w) => w.definition.trim() && w.introducedAt && Date.parse(w.nextReviewAt) <= now.getTime(),
    )
    .sort((a, b) => a.nextReviewAt.localeCompare(b.nextReviewAt))
    .slice(0, limit);
}

export function introductionQueue(
  words: UserWord[],
  now: Date,
  policy = DEFAULT_POLICY,
) {
  const today = now.toISOString().slice(0, 10);
  const introducedToday = words.filter(
    (w) => w.introducedAt?.slice(0, 10) === today,
  ).length;
  return words
    .filter((w) => !w.introducedAt && !!w.definition.trim())
    .sort((a, b) => a.addedAt.localeCompare(b.addedAt))
    .slice(0, Math.max(0, policy.newPerDay - introducedToday));
}

/** Due dates recommend order; they never deny access to saved vocabulary. */
export function practiceCandidates(
  words: UserWord[],
  now: Date,
  limit = DEFAULT_POLICY.sessionSize,
) {
  const last = (w: UserWord) => w.attempts.at(-1);
  const group = (w: UserWord) =>
    Date.parse(w.nextReviewAt) <= now.getTime()
      ? 0
      : last(w) && !last(w)!.retrieved
        ? 1
        : 2;
  return words.filter((w) => !!w.definition.trim())
    .sort(
      (a, b) =>
        group(a) - group(b) ||
        (last(a)?.at ?? "").localeCompare(last(b)?.at ?? "") ||
        a.nextReviewAt.localeCompare(b.nextReviewAt),
    )
    .slice(0, limit);
}
export function practiceReviewDate(
  word: UserWord,
  stage: Stage,
  history: Attempt[],
  now: Date,
  policy = DEFAULT_POLICY,
) {
  return Date.parse(word.nextReviewAt) > now.getTime()
    ? word.nextReviewAt
    : nextReview(stage, history, now, policy);
}
