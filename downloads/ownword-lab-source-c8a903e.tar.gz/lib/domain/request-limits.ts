export const requestLimitCodes = ["daily_limit", "service_daily_limit"] as const;
export type RequestLimitCode = typeof requestLimitCodes[number];

export function isRequestLimitCode(value: unknown): value is RequestLimitCode {
  return value === "daily_limit" || value === "service_daily_limit";
}

export function nextUtcDay(now: Date) {
  return new Date(Date.parse(now.toISOString().slice(0, 10) + "T00:00:00Z") + 86_400_000).toISOString();
}
