import type { SourceAnchor } from "./types";

export type AnchorHint = {
  start?: number;
  end?: number;
  sentence?: string;
  before?: string;
  after?: string;
};
const boundary = (text: string, at: number) =>
  at === 0 ||
  at === text.length ||
  !(
    text.charCodeAt(at - 1) >= 0xd800 &&
    text.charCodeAt(at - 1) <= 0xdbff &&
    text.charCodeAt(at) >= 0xdc00 &&
    text.charCodeAt(at) <= 0xdfff
  );

/** Exact matching only: normalization/case folding can change UTF-16 offsets. */
export function resolveSource(
  text: string,
  exact: string,
  version: string,
  hint: AnchorHint = {},
): SourceAnchor | null {
  if (!exact) return null;
  const matches: number[] = [];
  for (let from = 0; from <= text.length - exact.length; ) {
    const start = text.indexOf(exact, from);
    if (start < 0) break;
    if (boundary(text, start) && boundary(text, start + exact.length))
      matches.push(start);
    from = start + 1;
  }
  let candidates = matches;
  // A supplied range must be correct; never silently relocate a stale/invalid range.
  if (hint.start !== undefined || hint.end !== undefined) {
    if (
      !Number.isInteger(hint.start) ||
      hint.end !== hint.start! + exact.length ||
      !matches.includes(hint.start!)
    )
      return null;
    candidates = [hint.start!];
  }
  if (hint.before)
    candidates = candidates.filter((start) =>
      text.slice(0, start).endsWith(hint.before!),
    );
  if (hint.after)
    candidates = candidates.filter((start) =>
      text.slice(start + exact.length).startsWith(hint.after!),
    );
  if (hint.sentence)
    candidates = candidates.filter((start) => {
      const at = text.lastIndexOf(hint.sentence!, start);
      return at >= 0 && start + exact.length <= at + hint.sentence!.length;
    });
  if (candidates.length !== 1) return null;
  const start = candidates[0],
    end = start + exact.length;
  let sentenceStart = start,
    sentenceEnd = end;
  while (sentenceStart > 0 && !/[.!?\n]/.test(text[sentenceStart - 1]))
    sentenceStart--;
  while (sentenceStart < start && /\s/.test(text[sentenceStart]))
    sentenceStart++;
  while (sentenceEnd < text.length && !/[.!?\n]/.test(text[sentenceEnd]))
    sentenceEnd++;
  if (sentenceEnd < text.length && text[sentenceEnd] !== "\n") sentenceEnd++;
  return {
    version,
    exact,
    start,
    end,
    sentence: text.slice(sentenceStart, sentenceEnd),
    sentenceStart,
    sentenceEnd,
    before: text.slice(Math.max(0, start - 40), start),
    after: text.slice(end, end + 40),
  };
}

export function validSource(
  text: string,
  version: string,
  source?: SourceAnchor | null,
): source is SourceAnchor {
  if (!source || source.version !== version) return false;
  const resolved = resolveSource(text, source.exact, version, source);
  return (
    !!resolved &&
    resolved.sentenceStart === source.sentenceStart &&
    resolved.sentenceEnd === source.sentenceEnd &&
    resolved.sentence === source.sentence
  );
}
