export type Stage = "new" | "practicing" | "active";
export type ExerciseKind =
  | "strong"
  | "completion"
  | "rewrite"
  | "open"
  | "free"
  | "contrast"
  | "spontaneous";
export type HintLevel = "none" | "semantic" | "letter" | "partial" | "revealed";
export interface Lexeme {
  id: string;
  word: string;
  partOfSpeech: string;
  definition: string;
  nuance: string;
  collocations: string[];
  examples: string[];
  /** Included with new concept discoveries; older saved results omit it. */
  vietnameseMeaning?: string;
}
export interface ConceptDiscovery {
  id: string;
  concept: string;
  candidates: Lexeme[];
  createdAt: string;
}
export interface WordCheck {
  status: "valid" | "correction" | "invalid" | "uncertain";
  suggestion: string | null;
}
export interface UserWord extends Lexeme {
  userWordId: string;
  addedAt: string;
  introducedAt: string | null;
  source: string;
  sourceText: string;
  demo: boolean;
  stage: Stage;
  nextReviewAt: string;
  attempts: Attempt[];
}
export interface Attempt {
  id: string;
  userWordId: string;
  exerciseId: string;
  at: string;
  kind: ExerciseKind;
  hint: HintLevel;
  answer: string;
  retrieved: boolean;
  precise: boolean;
  majorMisuse: boolean;
  context: string;
  feedback: string;
  spellingCorrection: string | null;
}
export interface Evaluation {
  retrieved: boolean;
  precise: boolean;
  majorMisuse: boolean;
  validAlternative: boolean;
  spellingCorrection: string | null;
  feedback: string;
  nuance: string;
}
/** Offsets are UTF-16 code units in the immutable writing sample, never the draft. */
export interface SourceAnchor {
  version: string;
  exact: string;
  start: number;
  end: number;
  sentence: string;
  sentenceStart: number;
  sentenceEnd: number;
  before: string;
  after: string;
}
export interface Suggestion extends Omit<Lexeme, "id"> {
  id: string;
  sampleId: string;
  originalText: string;
  reason: string;
  confidence: number;
  status: "pending" | "added" | "dismissed" | "already";
  source?: SourceAnchor | null;
  suggestedSentence?: string | null;
  savedWordId?: string | null;
  queued?: boolean | null;
  ownsSavedWord?: boolean | null;
}
export interface Opportunity {
  userWordId: string;
  originalText: string;
  prompt: string;
  source?: SourceAnchor | null;
}
export interface WritingReview {
  sampleId: string;
  text: string;
  suggestions: Suggestion[];
  opportunities: Opportunity[];
  usages: { word: string; feedback: string; correct: boolean }[];
  summary: string;
  /** Server-side cache key for the board state used during analysis. */
  analysisSignature?: string;
}
export interface WritingAnalysis {
  suggestions: Omit<Suggestion, "id" | "sampleId" | "status">[];
  opportunities: Opportunity[];
  usages: { userWordId: string; evaluation: Evaluation }[];
  summary: string;
}
export interface Exercise {
  id: string;
  sessionId: string;
  userWordId: string;
  kind: ExerciseKind;
  prompt: string;
  context: string;
  semanticHint: string;
  hint: HintLevel;
  sentencePending: boolean;
  answeredAt: string | null;
}
export interface PublicExercise {
  id: string;
  kind: ExerciseKind;
  prompt: string;
  hint: HintLevel;
  hintText?: string;
  sentencePending: boolean;
  position: number;
  total: number;
  definition?: string;
}
export interface PracticeOutcome {
  userWordId: string;
  word: string;
  outcome: "recalled-used" | "hinted-used" | "recalled-skipped" | "reviewed";
}
export interface PracticeSession {
  complete: boolean;
  total: number;
  exercise: PublicExercise | null;
  words: { userWordId: string; word: string; exerciseId?: string }[];
  results: PracticeOutcome[];
}
export interface PracticeSetupOptions {
  wordIds: string[];
  includeWriting: boolean;
}
export interface Insight {
  phrase: string;
  count: number;
  alternatives: { word: string; meaning: string }[];
  sources?: {
    sampleId?: string;
    sentence: string;
    text: string;
    start: number;
    end: number;
  }[];
}
export interface Profile {
  id: string;
  name: string;
  createdAt: string;
  dailyLimit: number;
  onboarded: boolean;
}
export interface AppState {
  profile: Profile;
  words: UserWord[];
  cloudWords?: CloudWord[];
  dueCount: number;
  practicedToday?: boolean;
  queuedCount: number;
  writingCount: number;
  insights: Insight[];
  mockMode: boolean;
}
export interface LearningJourneySummary {
  dueCount: number;
  practicedToday: boolean;
}
export interface CloudWord {
  word: string;
  stage: Stage;
  counts: [number, number, number];
}
export interface Identity {
  id: string;
  name: string;
  email: string;
}
export interface Clock {
  now(): Date;
}
export interface IdGenerator {
  next(): string;
}
