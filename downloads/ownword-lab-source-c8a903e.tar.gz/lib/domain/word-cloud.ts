import type { CloudWord, UserWord } from "./types";
export type { CloudWord } from "./types";

const DAY = 24 * 60 * 60 * 1000;

function occurrences(text: string, word: string): number {
  const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return Array.from(text.matchAll(new RegExp(`(?<![a-z])${escaped}(?![a-z])`, "gi"))).length;
}

/** Counts contextual uses recorded for each learner word, excluding sample data. */
export function wordCloud(words: UserWord[], now: number, writings: { text: string; createdAt: string }[] = []): CloudWord[] {
  return words
    .filter((word) => !word.demo)
    .map((word) => {
      const counts: CloudWord["counts"] = [0, 0, 0];
      for (const writing of writings) {
        const uses = occurrences(writing.text, word.word);
        if (!uses) continue;
        counts[0] += uses;
        const at = Date.parse(writing.createdAt);
        if (Number.isFinite(at) && at <= now && at >= now - 30 * DAY) counts[1] += uses;
        if (Number.isFinite(at) && at <= now && at >= now - 7 * DAY) counts[2] += uses;
      }
      for (const attempt of word.attempts) {
        const answer = attempt.answer.trim();
        const contextual = attempt.kind === "spontaneous" ||
          answer.split(/\s+/).length > word.word.trim().split(/\s+/).length;
        if (!contextual) continue;
        const uses = occurrences(answer, word.word);
        if (!uses) continue;
        counts[0] += uses;
        const at = Date.parse(attempt.at);
        if (Number.isFinite(at) && at <= now && at >= now - 30 * DAY) counts[1] += uses;
        if (Number.isFinite(at) && at <= now && at >= now - 7 * DAY) counts[2] += uses;
      }
      return { word: word.word, stage: word.stage, counts };
    })
    .sort((a, b) => b.counts[0] - a.counts[0] || a.word.localeCompare(b.word))
    .slice(0, 24);
}
