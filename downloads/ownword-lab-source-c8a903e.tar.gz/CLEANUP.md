# Retire the Ownword AWS pilot

Use this when Ownword should stop running on AWS. **Do not run these deletion steps while the site is still needed.** Emptying buckets, deleting Cognito, and deleting the Lightsail instance permanently remove data. Run the commands in AWS CloudShell signed into account `378600556289`; select **Singapore (`ap-southeast-1`)** except for Cognito, which is in **Ohio (`us-east-2`)**.

## 1. Save anything you want to keep

- Download the latest verified PostgreSQL dump from `s3://ownword-pilot-backups-378600556289-ap-southeast-1-an/daily/` to storage outside AWS. The archive contains learner data. The restore command is `deploy/lightsail/verify-restore.sh` while the instance is still running.
- Save any Cognito user information you need before deleting its pool. Save any code or deployment configuration you need; the GitHub repository itself is separate from AWS.
- A retained manual Lightsail snapshot continues to cost money. Download/export needed data instead if the goal is to remove **all** AWS hosting charges.

## 2. Verify the account and find the Lightsail static IP name

```bash
aws sts get-caller-identity --query Account --output text
aws lightsail get-static-ips --region ap-southeast-1 --query 'staticIps[].[name,ipAddress,attachedTo]' --output table
aws lightsail get-instance-snapshots --region ap-southeast-1 --query 'instanceSnapshots[].[name,fromInstanceName]' --output table
```

Continue only when the account is `378600556289`. Record the static IP **name** corresponding to `3.1.163.210`. Review manual snapshot names before deleting any; automatic instance snapshots are removed with the instance.

## 3. Delete live compute and its public IP

```bash
aws lightsail delete-instance --instance-name ownword-pilot --region ap-southeast-1
aws lightsail get-static-ips --region ap-southeast-1 --query 'staticIps[].[name,ipAddress,attachedTo]' --output table
aws lightsail release-static-ip --static-ip-name 'REPLACE_WITH_RECORDED_NAME' --region ap-southeast-1
```

The instance's attached volumes and automatic snapshots are deleted with it. **Stopping an instance does not stop its bundle charge.** If step 2 found manual snapshots specifically for Ownword, delete each by its reviewed exact name with `aws lightsail delete-instance-snapshot --instance-snapshot-name 'NAME' --region ap-southeast-1`. Do not delete unrelated snapshots.

## 4. Delete the backup alarm, SNS topics, IAM identity, and KMS key

```bash
aws cloudwatch delete-alarms --alarm-names ownword-pilot-backup-stale --region ap-southeast-1
aws sns delete-topic --topic-arn arn:aws:sns:ap-southeast-1:378600556289:ownword-pilot-operator-alerts --region ap-southeast-1
aws sns delete-topic --topic-arn arn:aws:sns:ap-southeast-1:378600556289:ownword-pilot-learner-reminders --region ap-southeast-1
aws iam list-access-keys --user-name ownword-pilot-vm --query 'AccessKeyMetadata[].AccessKeyId' --output table
```

For **each** access key ID listed for `ownword-pilot-vm`, run `aws iam delete-access-key --user-name ownword-pilot-vm --access-key-id 'ID'`. Then:

```bash
aws iam delete-user-policy --user-name ownword-pilot-vm --policy-name OwnwordPilotScopedAccess
aws iam delete-user --user-name ownword-pilot-vm
aws kms describe-key --key-id alias/ownword-pilot-operator-alerts --region ap-southeast-1 --query 'KeyMetadata.[Arn,KeyState]' --output table
aws kms schedule-key-deletion --key-id alias/ownword-pilot-operator-alerts --pending-window-in-days 7 --region ap-southeast-1
```

The KMS key is dedicated to the operator topic. Confirm no other resource uses it before scheduling deletion. AWS does not charge the monthly key fee while a customer-managed key is pending deletion. Do not schedule deletion of `alias/aws/sns`, which is an AWS-managed key and is also used by the reminder topic.

The `Ownword/Pilot` custom CloudWatch metric has no manual delete API. It stops receiving data when the VM is gone; removing the alarm avoids ongoing alarm charges.

## 5. Empty and delete both S3 buckets

Both buckets have **versioning enabled**. In the [S3 console](https://console.aws.amazon.com/s3/), open the Singapore region and find:

1. `ownword-pilot-backups-378600556289-ap-southeast-1-an`
2. `ownword-pilot-access-logs-378600556289-ap-southeast-1-an`

On the backup bucket, turn off **server access logging** first. Then use **Empty** on the backup bucket, confirm deletion of all object versions and delete markers, and delete the bucket. Repeat **Empty** and **Delete** on the access-log bucket. `aws s3 rm --recursive` alone is insufficient for versioned buckets: old versions can remain billed. If either bucket will not delete, inspect its object versions and delete markers, empty it again, and retry.

## 6. Delete the Ohio Cognito user pool

This removes all pilot accounts and breaks sign-in permanently.

```bash
aws cognito-idp delete-user-pool-domain --domain us-east-2juorywql3 --user-pool-id us-east-2_JuOrYwql3 --region us-east-2
aws cognito-idp delete-user-pool --user-pool-id us-east-2_JuOrYwql3 --region us-east-2
```

If the domain is already absent, continue with the pool. The SPA client `7t6jnh0bpkdl4ao5nc8ud7t0m9` is removed with its pool.

## 7. Verify charges stop

Review Lightsail instances, static IPs, manual snapshots, S3 buckets, SNS topics, CloudWatch alarms, and customer-managed KMS keys in **Singapore**, and Cognito user pools in **Ohio**. Check AWS Billing/Cost Explorer again after billing data catches up. The temporary `sslip.io` hostname has no purchased-domain renewal. Revoke the OpenRouter key or spending limit separately if you also want to stop that vendor's charges. Delete any remaining `ownword-pilot-vm-key.json` download from CloudShell and local Downloads.

AWS references: [Lightsail instance deletion](https://docs.aws.amazon.com/lightsail/latest/userguide/delete-an-amazon-lightsail-instance.html), [static IP release](https://docs.aws.amazon.com/lightsail/latest/userguide/how-to-delete-static-ip.html), [S3 version deletion](https://docs.aws.amazon.com/AmazonS3/latest/userguide/DeletingObjectVersions.html), [KMS key deletion](https://docs.aws.amazon.com/kms/latest/developerguide/deleting-keys.html), [KMS pricing](https://aws.amazon.com/kms/pricing/).
