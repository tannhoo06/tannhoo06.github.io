# Vietnamese and English interface

Implemented 26 October 2026. Vietnamese is the default for new visitors, independent of browser language. Both the public landing page and every workspace page expose the language control. The interface updates immediately; an explicit choice persists for one year in a first-party preference cookie. The server reads that preference for initial HTML and `<html lang>`, avoiding an initial English interface for Vietnamese users.

The translation layer has no new package dependency and does not modify learner records, the database schema, mastery rules, English writing, dictionary entries, examples or generated feedback. English learning content remains English in either interface. Common application errors and all static interface copy have Vietnamese equivalents; unknown provider-specific error text falls back to the original rather than inventing a translation. Dates use `vi-VN` or `en-US`.

Switching does not perform navigation, reload the page, or change component keys, so active drafts, annotations and review decisions remain intact. Native language names, pressed-state semantics, visible keyboard focus and 44px language-button targets support discoverability and access. Vietnamese headings use DM Sans for consistent diacritics.

## Verification

- TypeScript checks passed.
- All 35 automated tests passed, including preference validation, interpolation integrity and preservation of dynamic English vocabulary.
- Isolated D1 integration checks passed for the preceding UX migration and persistence behavior.
- Chrome checks confirmed default Vietnamese, English persistence after reload, server-rendered locale, and in-place draft/review preservation.
- All six workspace routes were inspected at 1440, 768, 390 and 320px with Vietnamese labels and no horizontal overflow. English switching was exercised on landing, writing and review.
- Screenshots and the local browser harness are in ignored `outputs/i18n/`. The stateful browser walkthrough uses intercepted API fixtures and does not change saved learner data. This is not a claim of live Gemini translation or representative usability research.

The localization requires no database migration. The existing additive UX migration remains part of the accumulated Site update and is applied by Sites before the Worker is deployed.
