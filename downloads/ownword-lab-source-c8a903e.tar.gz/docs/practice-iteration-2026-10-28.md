# Practice iteration — October 28, 2026

## Implemented
- Practice entry offers Quick Review and Full Practice within the existing navigation.
- Shared candidate ranking selects due words first, then words whose latest attempt was unsuccessful, then other saved words. Within each group, older practice comes first. The session limit still applies.
- Full Practice and the WordBoard drawer can start practice even when words are not due, including queued words.
- Non-due Full Practice records evidence but preserves the existing future review date. Scheduled attempts retain the existing interval calculation. Existing spaced-occasion and contextual-use gates remain in force.
- Quick Review uses five WordBoard words, meaning-first cards, reveal, Forgot/Got it, skip and recap. Ratings are persisted through the authenticated API as attempts with context `quick-review` and rating stored in `answer`. They do not change stages or scheduled dates and are excluded from mastery evidence.
- The recap starts Full Practice from all Forgot ratings in that completed Quick Review, in card order and capped by the profile's session size. The server validates ownership and completion and derives the set from persisted ratings. Normal candidate ranking cannot replace this explicit set. Ratings outside the cap remain saved and those words remain available for future practice.
- With zero forgotten words, the recap offers Review again as its primary action and Back to Practice; it does not offer Continue to Full Practice.
- Recall uses a single-line input with Enter submission and a desktop Check button to the right. On small screens Check stacks beneath it. Sentence production still uses the existing textarea.
- Existing Vietnamese meaning disclosures remain, with coverage limited to the built-in exact demo definitions. New mode labels have Vietnamese translations.

## Main files
- `components/quick-review.tsx`: cards, self-rating and recap; passes the completed session ID for the handoff.
- `components/studio.tsx`: forwards the explicit source through the Practice callback and API request, bypassing unfinished-session resumption for that handoff.
- `components/practice.tsx`: mode selection, repeat practice and input split.
- `components/wordboard.tsx`: remove queued-word practice restriction.
- `app/mvp-v2.css`: mode/cards styling and responsive recall form.
- `lib/domain/learning.ts`: candidate ranking, future-date preservation and exclusion of quick ratings from mastery evidence.
- `lib/services/vocabulary.ts`: flexible sessions and authenticated Quick Review rating persistence.
- `app/api/[...path]/route.ts`: validated quick session/rating endpoints.
- `lib/i18n/messages.ts`: bilingual labels.
- `tests/learning.test.ts` and `tests/d1-ux.integration.ts`: new regression checks.

## Validation
46 unit tests and isolated D1 integration checks passed. Checks cover future/queued candidate inclusion, future schedule preservation through completed manual practice, quick ratings not promoting or demoting mastery, ownership isolation, duplicate rating rejection, rating persistence, repeat practice, the explicit forgotten set, incomplete source rejection, zero-forgotten rejection and deterministic capping. The cap test uses an isolated profile with a limit of two to exercise overflow; normal supported limits are 5/7/10 and Quick Review contains at most five cards.

Type checking, targeted Prettier checks and the production build passed after the final callback fix. ESLint completed with no errors and two existing internal-navigation warnings in `components/studio.tsx`. D1 tests required local-loopback permission; they passed when rerun with that access.

## Stabilization browser QA

- Verified mode choices, meaning-first cards, reveal, Forgot, Got it, skip, advancing positions, five-row recap and Review again in the running local app.
- Browser testing caught a callback that discarded the explicit Quick Review session ID. Fixed `begin={() => practice()}` to forward the actual callback, then repeated the bridge test successfully.
- Mixed results: negligible Forgot, nuanced Got it, deliberate Forgot, tentative Skip, substantial Forgot. Full Practice contained exactly negligible, deliberate and substantial, in that order, with a three-word progress count and matching completion recap. The first two completed recall and sentence use; the third completed via sentence skip after the demo evaluator rejected a valid sentence.
- Repeated in Vietnamese with tentative as the only Forgot word and four skipped words. The bridge opened exactly one word, with tentative's English definition. A zero-Forgot session showed Review again and no Full Practice transition.
- Verified due-word Full Practice and, before loading the sample board, Quick Review and Full Practice with zero due words. Completing a session allows another session.
- Opened compelling from WordBoard while its review was Tomorrow, started manual practice and completed recall and sentence use. Exact future-date preservation is also asserted in D1 integration tests.
- Recall accepts Enter and a padded uppercase answer (`  COMPELLING  `). Wrong answers and hints retain the compact single-line field. Sentence use retains a textarea.
- Checked desktop recall with Check beside the input and narrow 390 x 844 layout with Check stacked below. Mode cards, Quick Review cards and recap remain usable at that width. The pre-existing WordBoard navigation label wraps awkwardly; no navigation redesign was made. Temporary viewport overrides were reset.
- Verified EN and VI mode, card, rating, recap and practice labels. Target words, English definitions, examples and learner answers remain English. Vietnamese meaning remains an optional disclosure.
- Submitted a Quick Review rating, advanced to the next card, then refreshed. The page returned to the mode chooser without resubmitting. Persistence and duplicate rejection are covered by the D1 tests; no session-resume system was added.
- Loaded the app's sample WordBoard for multiword QA. Sample records and the resulting local practice history remain in the local demo account.

## Files touched in the stabilization pass

`components/quick-review.tsx`, `components/practice.tsx`, `components/studio.tsx`, `lib/services/vocabulary.ts`, `app/api/[...path]/route.ts`, `tests/d1-ux.integration.ts`, this document and `docs/session-changes-2026-10-28.md`. Other working-tree changes belong to the preceding copy/UI and Practice V3 implementation.

## Current limitations
- Quick Review's in-progress card position and recap are held in component state; ratings already submitted persist on the server, but reloading does not restore that card session UI.
- Quick Review does not change the recommended date even when a word is due. Full Practice remains responsible for scheduled review updates.
- The mock evaluator uses a conservative collocation heuristic: it rejected valid sentences with “substantial reduction” during QA. This existing evaluation behavior was preserved. Live-provider sentence quality was not assessed in this pass.
- Vietnamese definition disclosures still cover the built-in exact demo definitions only.
- Overflow capping was verified in isolated D1 tests, not by changing the live user's session limit below the supported range.
- All changes remain local, not deployed.

## Deployment assessment

The build and Practice stabilization checks pass, so this is ready for a preview deployment. It is not an unconditional production-quality sign-off: the demo evaluator limitation above and live-provider behavior still need product validation. No deployment was performed.
