# Architecture and a future AWS capstone

## Smallest complete application

```text
React screens
   │ same-origin JSON
Next.js route adapter — validation, origin check, sanitized errors
   │ authenticated Identity
VocabularyService
   ├── Learning rules + review schedule (pure functions, injected clock)
   ├── Repository interface → D1Repository → Drizzle → D1
   └── LlmProvider → MockLlm or GeminiLlm

SitesAuth → AuthProvider → Identity
Environment → readConfig → validated configuration
```

`lib/server/composition.ts` is the deployment composition root. It is the one place that selects the database, authentication, LLM implementation, clock and ID generator. Core domain types and services do not depend on Cloudflare, Supabase, Cognito, Next.js requests or browser storage. The repository implementation has a type-only database dependency; its public interface is domain-shaped.

Provider construction is delegated to `lib/llm/provider-factory.ts`. `LLM_PROVIDER` chooses one active adapter; `LLM_MODE` remains a legacy alias. Gemini supports either a fixed key or a pool. The pool reserves each outgoing call's slot through the separate `KeyRotationStore` infrastructure port, implemented by an atomic D1 upsert with `RETURNING`. This avoids per-process counters restarting on every request. Only an ordered-pool digest and a bounded position are persisted. Single-key mode skips this store. Other providers, including a future Bedrock implementation, need not use Gemini key rotation. Registering another provider requires its adapter plus factory/config wiring; no learning-service or frontend changes are needed.

## Data model

- `app_user`: stable identity, display name, session preferences.
- `word`: canonical lexical entry, definition, nuance, collocations and examples.
- `user_word`: user-owned relation, New/Practicing/Active stage, introduction queue, source, review date and sample-data marker.
- `writing_sample`: original writing and prompt, owned by the authenticated user.
- `vocabulary_suggestion`: structured candidate tied to a writing sample and an explicit decision.
- `practice_session` and `exercise`: server-stored target, context, prompt, authoritative hint level and completion.
- `practice_attempt`: append-only evidence, including spelling correction, precision, recall, context and hint use. A unique exercise key prevents duplicate credit.
- `insight`: derived recurring phrase counts and nuanced alternatives.
- `request_limit`: hourly per-user LLM request budgets.

The three board stages are a constrained domain union; no additional internal stage is exposed. Metrics such as retrieval strength, context diversity, hint dependence and retention span are derived from attempts, avoiding counters that drift from their evidence. Review dates and stages are persisted for efficient due-word lookup.

Every repository read/write carries the server-derived owner ID. A client cannot choose an owner ID, progression stage, evaluation result, hint credit or timestamp. Prompts and target words for exercises are stored server-side; the exercise response omits the target until needed. Hints never decrease, and duplicate submission is idempotent at the database boundary. Session completion and attempt insertion are batched with the board update.

## Why D1 in this version

Sites supplies D1, migrations and private hosting as one integrated runtime. D1 is the only persistence implementation in this MVP. It does **not** pretend to be PostgreSQL. No Supabase-specific client or business logic is present. The domain-shaped `Repository` interface is the migration seam; the SQLite schema and driver live in infrastructure files.

For PostgreSQL, create a PostgreSQL schema using the same logical entities and implement `Repository` with `pg`/Drizzle or Prisma. Use UUID/text identifiers, timestamp columns, JSONB for lexical arrays, Boolean flags and equivalent unique/foreign-key constraints. Convert exported UTC ISO timestamps and JSON text during a deliberate data migration. Run the same service tests against the new adapter, plus transaction and concurrency integration tests. Do not reuse SQLite migrations as PostgreSQL migrations.

## AWS mappings, when there is a reason to implement them

| Concern           | Current boundary                                     | Possible AWS implementation                                                                                                                     |
| ----------------- | ---------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| Frontend          | React screens and Next.js routes                     | Amplify Hosting for supported Next.js SSR; S3 + CloudFront only after extracting/static-exporting the frontend and deploying its API separately |
| API               | Thin HTTP route around `VocabularyService`           | Lambda + API Gateway handler, or a Node/container deployment                                                                                    |
| Database          | `Repository` interface                               | RDS/Aurora PostgreSQL repository with connection pooling or RDS Proxy as appropriate                                                            |
| Identity          | `AuthProvider` returns `Identity`                    | Cognito adapter that validates token signature, issuer, audience and expiry; never merely decode a client-supplied token                        |
| Files             | No current use case                                  | S3 adapter only when a real file feature is introduced                                                                                          |
| Scheduled reviews | Pure `dueWords`/`nextReview`, on-demand introduction | EventBridge → Lambda calling an extracted application job if reminders/maintenance later require it                                             |
| Logs              | Structured server logs without writing or secrets    | CloudWatch ingestion; add correlation IDs and metrics at the route adapter                                                                      |
| Secrets           | Validated runtime environment                        | Secrets Manager/SSM resolved in the AWS composition root and cached appropriately                                                               |
| Async work        | Synchronous, bounded LLM tasks                       | SQS workers only if actual latency/workload requires queues; use idempotency keys                                                               |
| LLM               | `LlmProvider`                                        | Keep Gemini, add another provider, or implement a Bedrock adapter with the same validated domain outputs                                        |

Deploying the React app to S3 alone would not provide authentication, persistence or LLM APIs. Preserve an API deployment if choosing that mapping. Vinext build scripts, Worker entry point, D1 binding and Sites auth are replaceable deployment infrastructure, not business logic to carry into AWS.

## Operational boundaries

- Mock mode is intentionally limited and labelled; it is suitable for UI development, not evidence of real model grading quality.
- A valid JSON response is not proof of pedagogical correctness. Before broader release, evaluate Gemini suggestions and grading on a curated learner corpus and monitor false positives/negatives.
- Reads derive metrics from the user's attempt history. An MVP is small enough for this; add pagination and aggregate projections when data volume warrants them.
- The repository batches attempt insertion and the stored projection update. Concurrent independent submissions can temporarily leave a conservative/stale stage projection because progression is computed before the transaction; a future high-concurrency version should serialize per-word grading or use optimistic version checks. The unique exercise key still prevents double credit.
- Introduction limits are checked in the service. A multi-tab race could admit an extra word; move admission to a transactional daily-budget reservation if that becomes material.
- Hourly rate-limit rows, abandoned sessions and old derived insight snapshots currently have no retention job. Add a bounded maintenance job before operating at scale.
- Stable owner IDs differ by identity provider. An AWS migration needs an explicit account mapping; do not equate users solely by matching email addresses.
- No AWS resources, credentials, SDK clients, queues, buckets or background jobs are needed or provisioned for this version.
