# Ownword MVP V2 — implementation and verification

The subsequent [targeted polish pass](mvp-v2-polish-verification.md) records the smaller Practice feedback/hints, sentence-disclosure cleanup, compact transient autosave notification, and production demo-control guards. The original V2 implementation record below is retained for context.

Implemented in the existing checkout on 27 October 2026, using `OWNWORD_MVP_V2_IMPLEMENTATION_SPEC.md` as the product and acceptance authority. The project-root copy matches the supplied `D:/Downloads2/` specification byte for byte. No hosted deployment was performed.

## Reference mapping and precedence

| Reference | Supplied image | Implemented surfaces and visual comparison |
| --- | --- | --- |
| A | `reference_images/practice_flow_states.jpg` | Intro, meaning recall, wrong recall, progressive hint, correct recall → sentence, reveal → sentence. Compared page measure, progress placement, field sizes, feedback weight, and action hierarchy. |
| B | `reference_images/write_suggestion_review_v2.jpg` | Initial editor and two-panel suggestion review. Compared prompt block, writing field, original/context panel, phrase/word/meaning/example hierarchy, progress, and stacked Add/Skip actions. |
| C | `reference_images/settings_v2.jpg` | Two-item overflow menu, four Settings groups, dropdown, autosave feedback, and concise practice explanation. Compared group borders, icon gutters, field placement, and help hierarchy. |
| D | `reference_images/insights_patterns_cards.jpg` | Compact patterns and one expanded evidence card. Compared phrase/alternative split, inline actions, excerpt list, contextual guidance, and compact neighboring cards. |
| E | `reference_images/wordboard_v2_triptych.jpg` | Empty board and word drawer; botanical motif. Its middle populated panel did not override F. |
| F | `reference_images/wordboard_populated_refined.jpg` | Final populated board: New / Practicing / Active / All counts, search/sort, two-column cards, timing/stage metadata, botanical footer. |
| G | No separate deprecated image was supplied | The specification's permanent-column concept was explicitly excluded. The old three-column Board renderer was removed; inactive legacy CSS does not render a Kanban board. |
| H | `reference_images/practice_completion_screen.jpg` | Centered completion heading, compact per-word recap, reinforcement note, primary WordBoard action, secondary writing action. |

Screens were compared after their implementation groups, then reviewed again during the responsive/final visual pass. Captures and machine-readable browser results are under the ignored `outputs/mvp-v2/` directory. The comparisons are visual reviews, not a claim of pixel-identical reconstruction from raster sketches.

## What changed

- Writing opens directly into a short instruction, a large field, optional prompt chips, and one primary Review suggestions action. Draft and review recovery remain user-scoped.
- Suggestion review keeps the immutable original beside the current suggestion. Add to practice and Skip save their decisions and advance automatically. Nuance, collocations, revision preview/apply/undo, and decision undo remain optional disclosures. Legacy already-know/use decisions are absent from the main flow.
- Practice has an intro before questions. Every scheduled exercise begins with meaning recall, then sentence use after recall/reveal. Existing exercise kinds, context prompts, server-owned hints, attempt storage, scheduling, and progression thresholds are preserved. Sentence completion/skip advances automatically; there is no normal Saving or Next word screen.
- A sentence skip now preserves successful recall while recording no precise sentence use. Revealed answers still receive no recall evidence. The recap is derived from persisted attempts and can recover through a completed-session URL after reload.
- WordBoard uses a compact two-column grid and stage counts. An empty board has one central file-icon state and one Write something CTA. The drawer shows source, collocations, example, next-step guidance, review timing, practice/removal actions, and optional history without diagnostic score panels.
- Your patterns has one repetition notice, compact phrase/alternative cards, single-card evidence expansion, highlighted source excerpts, word-specific fit guidance, explicit addition, and View on WordBoard for owned alternatives. Duplicate additions preserve existing records and source history; newly added alternatives retain a real source sentence when available.
- Settings has Profile, Practice, About & Support, and Account. Name saves on blur/Enter; practice length autosaves through a dropdown. Writes are serialized, failures retain the edited choice, and retry is supported. Demo seeding/cleanup lives in an isolated mock-only disclosure. Normal workspace content has no floating demo badge.
- New profiles default to seven words. Existing six/eight-word values are not rewritten; the approximate Standard label represents them until the preference is changed. The API accepts the new 5/7/10 choices and retains compatibility with stored six/eight-word settings.

## Acceptance criteria review

| Specification | Result and evidence |
| --- | --- |
| §5 Write | Passed implementation/manual review: clear heading and short instruction without help/setup; one obvious enabled primary action after sufficient text; no learning-engine state; draft survives reload. Browser `writing` and `responsive` groups. |
| §6 Suggestion Review | Passed: two core decisions only, one decision click advances, original/highlights remain, simple suggestion count, no already-know/use buttons, added words link/create the appropriate record. Browser `writing`; persisted decision/duplicate tests. |
| §7 Session entry | Passed: navigation shows an intro, explains recall then sentence use, and offers one Start practice action. Resuming also retains an explicit entry action. Browser `practice`, `board`, `mobile-flow`. |
| §8 Recall | Passed: one meaning-recall instruction, prominent input, secondary hint, Check control, no raw scoring. Visual comparison A and phone-state checks. |
| §9 Correct recall and skip | Passed: same exercise area changes to sentence use; stale recall controls disappear; Skip this step remains available and advances automatically. Recall evidence survives a sentence skip. Browser `practice`; service and D1 tests. |
| §10 Wrong recall | Passed: concise lightweight feedback and Try again / Hint / Reveal word recovery paths, without penalty language or a punitive panel. Browser `practice`; comparison A. |
| §11 Hint/reveal | Passed: progressive server-owned hints remain; reveal directly opens sentence use; authoritative hint survives reload and cannot be lowered; scoring consequences remain hidden. Browser `practice`; service/learning tests. |
| §12 Moving between words | Passed: successful sentence and sentence skip save and fetch the next exercise automatically. No separate normal save confirmation or Next word requirement. Browser `practice`, `mobile-flow`. |
| §13 Completion | Passed: nonempty per-word plain-language outcomes from stored attempts; reinforcement note; primary Go to WordBoard and secondary Continue writing; no XP/confetti. Completion recap survives reload. Service, D1, browser `practice`; comparison H. |
| §14 Populated board | Passed: four counts, stage filtering, All, search, sort, two-column desktop cards, one-column phone cards, no permanent columns. Active due timing remains independent of stage. Browser `board`, `responsive`; comparison F. |
| §14 Empty board | Passed: file icon, central explanation and one Write something action; no stage boxes, search, sort, counters, sample controls, or duplicate CTAs; botanical footer retained. Browser `board`; comparison E. |
| §15 Drawer | Passed: meaning, retained source, collocations, example, learner guidance, next review, targeted practice, and removal are visible; history is optional; Escape restores card focus. Missing legacy source/example data is described honestly. Browser `board`, `responsive`; D1 removal/history tests; comparison E. |
| §16 Your patterns | Passed: one repetition notice, compact default cards, contextual alternatives, a single expanded evidence card with three highlighted excerpts initially, explicit Add/View behavior, and no duplicate records. Browser `insights`; D1 source/duplicate tests; comparison D. |
| §17 Overflow | Passed: Your patterns and Settings are the two canonical items; descriptions follow C. Outside click/Escape close the menu. Browser `settings` and manual keyboard review. |
| §18 Settings | Passed: dropdown with exactly Short/Standard/Longer choices, four groups, autosave, saved confirmation, name blur/Enter, isolated logout, concise three-part help, isolated mock-only demo tools. Browser `settings`; integration session-length/legacy-profile tests; comparison C. |
| §19 Responsive | Passed: five main routes at 1024/768/390/375/320px in EN and VN; no horizontal page overflow. Full review/recall/sentence/reveal/completion/expanded-pattern/help states checked at 390/320px in both languages. Stage tabs scroll within their control; drawer fits the narrow viewport; review stacks with writing context retained. |
| §21 State coherence | Passed: additions use the existing word repository; duplicates are idempotent; UI never forces stages; skip retains recall; authoritative hint/reveal evidence remains; soft removal keeps unrelated writing and history. Unit/service/D1 evidence. |

The “understand without help” and visual-weight criteria were assessed through implementation and visual review; no new learner study or longitudinal learning claim is implied.

## Regression checklist results

| Area | Checks completed |
| --- | --- |
| Authentication / persistence | Actual loopback sign-in/sign-out; anonymous/forged identity rejected; cross-origin writes rejected; invalid preference rejected. Ephemeral D1 tests verify saved reviews/words, owner isolation, old preferences, and retained history. Production authentication adapters/routes are unchanged. |
| Writing | Draft entry/reload; actual deterministic mock suggestions; immutable anchors; review reload without reanalysis; a new draft produces a separate review without inheriting the previous source or decisions. |
| Suggestion review | Add, Skip, cursor advance and recovery; only two core decisions; no removed legacy decision buttons; existing service reversal/queue protections still pass. |
| Practice | Intro, recall, spelling/synonym behavior, correct transition, all three wrong-recall recovery paths, progressive hints/reveal, sentence skip and automatic advance, no normal save/next screen, per-word recap, unfinished sentence recovery, completion recovery, replay protection, all original exercise kinds preserved. |
| WordBoard | Accurate populated stage counts; nonempty Practicing/Active tabs; All; search; alphabetical/newest sorting; independent Active due state; clean empty state; card/drawer interaction; duplicate prevention. |
| Word detail | Retained source, collocations, example, next review and guidance; targeted practice request; confirmed soft removal; retained history and other users' records; keyboard focus restoration. |
| Your patterns | Compact cards; one selected evidence card; initially three highlighted excerpts; Add creates a word; owned alternatives show View; existing word/source is not overwritten by a duplicate add. |
| Settings | Three dropdown values; actual 5/7/10 session sizes; seven-word default for new profiles; existing six-word preference preserved; serialized autosave; name Enter/blur; failure retains choice, retry saves, reload retains selection; help; sign-out endpoint; mock tools isolated; sample cleanup retains personally added words and writing. |
| Responsive | Main surfaces in both locales across five widths, plus complete review/practice states on small phones. No horizontal document overflow; full-width narrow drawer. Reduced-motion styles and visible keyboard focus retained. |

## Verification commands and limits

- `npm run typecheck`
- `npm test`: 43 passing automated tests plus the separate ephemeral Miniflare D1 integration check. No real Gemini calls; no learner database used by this suite.
- `npm run lint`: no errors; two existing warnings concern full-document navigation to authentication endpoints in `components/studio.tsx`. Those endpoints intentionally require document navigation.
- `npm run build`: existing five-phase Vinext/Cloudflare build.
- `node tests/mvp-v2.browser.mjs <group>` with `writing`, `practice`, `board`, `insights`, `settings`, `responsive`, `mobile-flow`, or `auth`. The preview must be running. Uses an externally available Playwright installation like the existing browser checks; `PLAYWRIGHT_MODULE`, `BROWSER_EXECUTABLE`, or `BROWSER_CHANNEL` can select it. Main UI groups use isolated API fixtures; `auth` uses the actual loopback authentication/API guards.
- `git diff --check` and a source review confirmed no permanent-column board renderer, no legacy main-path suggestion decisions, and no new Gemini/AWS/landing implementation.

The fresh checkout-local preview database had no application tables before initialization. It was backed up and initialized using the existing committed migrations, without resetting any database or changing hosted data. No new migration is required for V2. Existing database column defaults remain untouched; the repository assigns seven only when creating a new profile.

Browser screenshots are evidence of local Chrome behavior, not an automated screen-reader certification, physical-device test, hosted-authentication test, or pixel-diff guarantee. External font loading may change exact rasterized glyph metrics; screenshot capture does not wait indefinitely for third-party font requests.

## Remaining differences from the raster sketches

1. The botanical hills/leaves are an original SVG approximation of the approved motif, with responsive proportions, rather than extracted artwork from the sketches.
2. The practice-length dropdown is a native semantic select. Its opened menu and font rendering vary with the browser/OS; it does not reproduce the sketch's two-line custom option descriptions.
3. Audio/pronunciation controls and the avatar dropdown appearing in some sketches are omitted because the existing product does not support those flows and the written scope calls for simplification. No inactive imitation controls were added. Card overflow is omitted where the whole card already opens the drawer, as permitted by §14.2.
4. Layouts adapt to available viewport width and translated labels. Phone screens stack the review/grid and scroll stage tabs. Counts, words, outcomes, and dates reflect state rather than the sketch's fixed sample values. Existing scheduled context prompts remain visible for mature-word sentence exercises to preserve their learning context.
5. A mock-only demo disclosure and optional saved-review/revision/history affordances remain where needed to preserve existing working functionality. They do not introduce extra core decisions.

There is no intentional deviation from the required product flow, terminology, learning thresholds, data-retention requirements, or final populated WordBoard layout. G did not override E/F.

## Files changed

| Purpose | Files |
| --- | --- |
| Screens/navigation/primitives | `components/studio.tsx`, `components/shared.tsx`, `components/writing.tsx`, `components/practice.tsx`, `components/wordboard.tsx`, `components/preferences.tsx` |
| V2 presentation | `app/mvp-v2.css` (new), `app/layout.tsx` |
| Practice DTOs/compatibility and persistence | `lib/domain/types.ts`, `lib/services/vocabulary.ts`, `lib/adapters/d1-repository.ts`, `app/api/[...path]/route.ts` |
| Interface translations | `lib/i18n/mvp-v2.ts` (new), `lib/i18n/messages.ts` |
| Regression coverage | `tests/mvp-v2.browser.mjs` (new), `tests/service.test.ts`, `tests/d1-ux.integration.ts` |
| Documentation | `README.md`, `docs/mvp-v2-verification.md` (new) |

User-supplied specification and `reference_images/` were preserved. Authentication implementation, domain learning thresholds, database schema/migrations, real-provider implementation, hosting identity/configuration, and landing-page components were not changed.
