# Ownword — Website and System Report

This report describes the website as implemented in the current codebase. It covers the product idea, learner journey, visible sections and controls, application behavior, and the supporting system. It is intended as a reference for an agent who needs to understand Ownword before doing further work.

## 1. What Ownword is

Ownword is a personal English vocabulary learning website. Its central idea is to start with something the learner actually wants to say. The learner writes a short passage, reviews vocabulary suggestions tied to phrases in that passage, chooses useful words, and then practices recalling and using those words over time. The product phrase in the repository is **“Turn words you know into words you own.”**

The target learner can already write a passage in English and wants a more precise, natural vocabulary. The interface defaults to Vietnamese and can be switched to English. The English writing, target words, examples, exercise prompts, and generated language explanations remain in English. The public website says the service is currently free and that paid features may be introduced later.

The main learning loop is **write → discover → choose → practice → retrieve → activate**. A saved word appears on the learner's **My words** board in one of three stages: **New**, **Practicing**, or **Active**. The stages reflect evidence from spaced recall and use, not simply the number of times a word has been viewed. Active words continue to receive later reviews.

Sources: [README](../README.md), [product design](design.md), [landing page](../components/landing.tsx), [learning rules](../lib/domain/learning.ts).

## 2. How a learner uses the website

1. **Visit the public page.** Read the introduction and four-step explanation. A visitor can interact with a sample sentence and a separate sample exercise without signing in. These public examples do not create learner records.
2. **Sign in and write.** Selecting **Start writing** routes the visitor through ChatGPT sign-in and opens the writing workspace. The learner enters 10–5,000 characters, optionally starts from a prompt, and submits the passage for analysis.
3. **Review suggestions.** The original passage is shown with numbered, selectable phrases. Each suggestion shows the source sentence, proposed word, definition, reason, and, when available, a suggested sentence. The learner can save the word, keep the original, say they already use the word, or undo a decision. Trying a suggested sentence changes the editable draft only after the learner previews and applies it; the analyzed original is retained.
4. **Practice.** The learner can start a due-word session, practice a particular word, or follow a recall opportunity found in writing. Exercises ask for a word or its use in context. The learner types an answer, receives feedback, can request increasingly explicit hints, and can continue to a sentence step after recalling or revealing a word.
5. **Return over time.** The board shows words by stage and whether a review is due. Spaced attempts and independent use can move a word through the stages. Writing insights highlight a small set of recurring phrases in the learner's saved writing and offer alternatives.

Signed-in users have a personal workspace. A first-time user can enter through `/start`; after onboarding, opening `/` redirects in the client to **My words**. The application loads and stores state for the authenticated user. Source: [workspace controller](../components/studio.tsx), [writing screen](../components/writing.tsx), [practice screen](../components/practice.tsx).

## 3. Site map and common interface

| Route | Audience | Purpose |
| --- | --- | --- |
| `/` | Public; also accessible when signed in | Introduction, interactive sample, explanation, FAQ, and links. An onboarded signed-in user is taken to the board. |
| `/start` | Signed in | First-writing/onboarding form with a three-step indicator. |
| `/write` | Signed in | Write, analyze, review suggestions, and revise a draft. |
| `/board` | Signed in | **My words** collection and word details. |
| `/practice` | Signed in | Due-word or targeted practice and session completion. |
| `/insights` | Signed in | Recurring phrase observations from saved writing. |
| `/settings` | Signed in | Profile/session preferences, sign-out, and sample collection management. |
| `/privacy`, `/terms` | Public | Bilingual draft legal pages. |

The signed-in header contains the Ownword brand button, **Write**, **Practice**, **My words**, a **More** menu with **Writing insights** and **Settings**, and a compact **VN / EN** language switch. The brand button takes the learner to the board. A skip-to-content link, page heading focus on route changes, loading and error states, and temporary dismissible notifications are also part of the shared workspace. The board search and filter state is reflected in the URL. Source: [workspace controller](../components/studio.tsx), [shared components](../components/shared.tsx).

## 4. Screen specifications and controls

### 4.1 Public landing page (`/`)

**Sections.** The header links to **How it works** and **FAQ** and contains the language switch. The hero explains the writing-to-practice loop and contains an interactive sample workbench. The **How learning works** section illustrates writing, seeing suggestions in context, choosing a word, and recalling/using it, followed by a review-when-due explanation. The audience section describes whom Ownword is for. The FAQ covers audience, sign-in, price, suggestion quality, and treatment of writing. The final invitation repeats the start action and offers a feedback email link. The footer has Contact, Privacy, and Terms links.

**Hero and sample controls.**

| Control | Action |
| --- | --- |
| **Start writing** / **Start now** | Begin the authenticated writing flow; an unsigned visitor is sent to ChatGPT sign-in. |
| **Try a sample sentence** | Scroll to and focus the sample workbench. |
| **1. Write**, **2. Choose**, **3. Practice** tabs | Switch between the three illustrated steps. |
| **Skip animation** | Stop the introductory workbench animation. |
| **See the suggestion** | Advance from the sample writing tab to the suggestion tab. |
| **Try this wording** / **Keep original** | Toggle the revised wording inside the illustrative sentence. |
| **Save sample word** | Mark the sample word as saved inside the public example only. |
| **Open sample exercise** / **Try the sample exercise** | Open an isolated practice dialog. |
| **Skip word** | Mark the word as skipped inside the illustrated four-step section. |
| FAQ question buttons | Expand or collapse one answer. |
| **Share feedback with Ownword**, **Contact** | Open an email to `ownword_support@gmail.com`. |
| **Privacy**, **Terms** | Open the draft legal pages. |

The example changes “very small difference” to “negligible difference.” Sample saving and skipping are temporary page state, not account saves. The public practice dialog first checks whether the visitor typed `negligible`, can show that word as a hint, and then offers a self-directed sentence-writing step with a show/hide model sentence. Its controls are **Close sample exercise**, **Check word**, **Show hint**, **Continue to sentence writing**, **Show/Hide model sentence**, **Back to recall**, and **Finish example**. Answers are not stored in a learner account and the sample sentence is not graded by AI. Sources: [landing](../components/landing.tsx), [public sections](../components/landing-public.tsx), [sample exercise](../components/landing-practice.tsx).

### 4.2 Writing and onboarding (`/start`, `/write`)

**Writing form.** The onboarding version shows **1. Write → 2. Choose words → 3. Try one**. Both versions provide a starting-prompt disclosure with three rotating prompts, a free-text English editor, a character requirement, a tab-local draft status, and an analysis submit button. In mock mode, **Use an example** fills a curated sample passage and a notice explains that demo analysis supports limited patterns. **Skip for now** appears during onboarding.

**Writing-form controls.** **Need a starting prompt?** expands the current prompt; **Another prompt** rotates it. **Use an example** can replace the draft after confirmation. **Review word suggestions** submits a new passage, while **Analyze this draft** or **Retry analysis** appears in the corresponding later state. **Continue reviewing** reopens a saved review. A writing-intent panel reached from insights can offer **Use this passage** and **Dismiss context**.

**Review layout.** The reviewed, immutable original passage contains clickable numbered source phrases. Numbered suggestion tabs select the corresponding note. Each note contains the original sentence, the proposed word and definition, why it is suggested, and a suggested sentence when there is a validated source location. An expandable **Meaning and more examples** area shows part of speech, nuance, collocations, and examples. Existing known-word opportunities can instead prompt the learner to retrieve a word already on the board. The review summary shows counts for saved, ready, queued, kept-original, and already-used suggestions. A disclosure lists words used from the learner's collection when writing analysis found them.

**Review controls.** **Save word** saves a proposed word to My words. **Keep original**, **I already use this word**, and **Undo decision** manage the suggestion decision. **Try this wording** opens a draft-revision preview; **Cancel preview**, **Apply to draft**, and **Undo revision** manage that draft edit. **Previous** and **Next suggestion** move through the notes. **Try retrieving it** starts targeted practice for an existing word. **Edit writing**, **Return to writing**, and **Start a new draft** return to the editor. **View current draft** discloses a revised draft while the original review remains visible. Once ready words exist, **Practice all ready words** starts a practice session, even while other suggestions remain undecided. **My words** goes to the board. In mock mode, **Try another demo example** loads the second curated sample.

Submitted writing, analysis, suggestions, and decisions are stored on the server. The unsent draft, current review position, and working revision state are also kept in browser `sessionStorage` for the tab. An analysis may return no suggestions. Source: [writing implementation](../components/writing.tsx), [analysis service](../lib/services/vocabulary.ts).

### 4.3 My words / WordBoard (`/board`)

The board begins with a due-status banner. It shows how many words are ready to practice, whether reviews are up to date, or how to start an empty collection. The main collection displays the visible/total count, search field, due-only toggle, newest/alphabetical sort, and **All / New / Practicing / Active** stage filters. Words are grouped into stage sections. Each card shows its word, part of speech, definition, sample badge if applicable, and queued/due/next-review status. A note explains queued words and a disclosure explains stage progression.

**Board controls.** **Write something new** starts a clean draft. The banner's **Practice _n_ words** begins a due-word session; when nothing is due it instead offers writing. **Find a word** searches word and definition. **Only due words** toggles a due-only view. **Sort words** selects newest first or alphabetical. The four stage buttons filter by learning stage. Each word card opens its details. An empty result offers **Clear filters**; an empty board offers **Start writing**. The footer offers **Explore a sample collection** when the collection is empty, or **Manage sample words** when sample data is present. A new-stage empty prompt can offer **Find your first word**.

**Word detail dialog.** Clicking a card opens the stage, word, part of speech, definition, review status, and original source writing when present. **Examples and usage** expands nuance, collocations, and an example. **Practice history** expands evidence for retrieval, precision, flexibility of contexts, retention, and up to four recent attempts. Sample histories are labelled illustrative. **Practice this word** starts a targeted session when the word has been introduced. **Remove from My words** asks for confirmation and removes that word from the collection; the dialog has a close button and can also be dismissed with Escape. Source: [board and detail dialog](../components/wordboard.tsx).

### 4.4 Practice (`/practice`)

With no open session, the screen shows the number of due words or the next review, then offers **Start practice** or **Write something new**. An active session displays the question number, progress bar, exercise type and prompt, answer textarea, hint area, feedback, and next action. Current exercise types are word recall, sentence completion, sentence rewrite, open sentence writing, free writing about an idea, and choosing a precise meaning. A session normally contains the due words up to the learner's configured per-session limit; a targeted session contains one selected word. The current session ID and unfinished answer state are retained in browser session storage so the tab can resume.

**Practice controls.** **Save and exit practice** returns to the board while preserving the session. **Check my answer** submits the typed response. **Show a hint** and **Another hint** advance through semantic meaning, first letter, partial spelling, and finally **Reveal the word**. Feedback can ask the learner to retry, acknowledge a valid alternative, correct spelling, or require a complete sentence after recalling the word. Once a question is finished, **Next word** or **Finish this session** advances. After a reveal or a pending sentence step, **Skip the sentence for now** records a skipped attempt. A **Your previous attempt** disclosure can show the last response. The completed-session screen offers **Practice _n_ remaining words** when applicable, **Back to my words**, and **Continue writing**.

The server owns the correct target, hint level, evaluation, attempt record, stage, and next review. Revealing the answer removes independent recall credit. Source: [practice interface](../components/practice.tsx), [practice service](../lib/services/vocabulary.ts).

### 4.5 Writing insights (`/insights`)

Insights count occurrences of selected recurring phrases across saved writing, show up to five source excerpts per phrase, and offer alternatives with their meaning. The heading calls them **Potential patterns** when fewer than five writing samples exist and **Frequent choices** thereafter. Current tracked phrases are `important`, `very big`/`very large`, `very small`, and `interesting`.

Controls include **Start with a few sentences** in the empty state, **Examples from your writing** to expand source excerpts, and **View in writing** to carry a passage back to the writing screen. For an alternative already saved, **View word** opens its board detail. For a supported catalog alternative, **Save word** adds it to the collection. Other alternatives offer **Try in writing**, which passes the chosen word and source context to the editor. Sources: [insights interface](../components/preferences.tsx), [insight calculation](../lib/services/insights.ts).

### 4.6 Settings (`/settings`)

Settings contains a **Name** text field and **Words per session** selector with choices of 5, 6, 7, or 8 words. **Save changes** persists edits, and the screen shows saving/saved/unsaved status. Navigating away with unsaved edits prompts the learner. **Sign out** uses the platform's full-page sign-out route. **How practice works** expands a short explanation of progression. Mock mode shows a demo-analysis notice. If sample words exist, **Remove sample collection** opens an inline confirmation with **Keep them** and **Remove sample collection** actions; removal preserves personally added words. Source: [settings interface](../components/preferences.tsx).

### 4.7 Privacy and Terms (`/privacy`, `/terms`)

These public bilingual pages have a link back to Ownword, a language switch, a draft-status label, and the support email link. The page text explicitly states that the owner has not yet supplied official policy or terms. Source: [legal page component](../components/legal-draft.tsx).

## 5. Learning and scheduling rules

The default policy introduces at most **three new words per UTC day**; additional saved words stay queued on the board. The user's session-size setting is 5–8 words, with six as the default. Due words are ordered by their next review time. A learner can separately request practice for an introduced word.

An attempt records the exercise type, answer, hint used, whether the target was retrieved, whether usage was precise, major misuse, context, feedback, and time. Hints and exercise types carry different learning weight. A revealed target receives no retrieval credit. Meaningful spaced recalls must be on different UTC dates and at least six hours apart.

| Stage change | Default evidence required |
| --- | --- |
| New → Practicing | Two meaningful recalls on separate UTC dates, at least six hours apart, plus at least one precise use. |
| Practicing → Active | Five meaningful spaced recalls spanning at least seven days; precise use in three contexts; at least 80% recall in the recent five attempts; at least one independent use; fewer than two recent major misuses. |
| Active → Practicing | Two consecutive failed review dates, with a successful precise review breaking the failure sequence. |

Successful New words are reviewed again after about one day. Practicing intervals progress through 2, 4, and 7 days. Active maintenance intervals are 7, 21, 45, and 90 days. A failure, major misuse, or revealed answer schedules a nearer review. Correct spontaneous use detected in new writing may contribute an attempt. The thresholds have validated server-side environment overrides. Source: [learning domain](../lib/domain/learning.ts), [configuration](../lib/config.ts), [vocabulary service](../lib/services/vocabulary.ts).

## 6. Technical system specification

**Frontend and runtime.** The application uses Next.js App Router, React, TypeScript, and Tailwind CSS. Vinext builds it for the Cloudflare/Sites Worker runtime. Screens are client-side React components, while route files perform initial routing and authentication checks. The main JSON API is a catch-all route under `/api/`. Source: [package manifest](../package.json), [route files](../app/page.tsx), [API route](../app/api/[...path]/route.ts).

**Identity and privacy boundary.** Workspace routes require a ChatGPT-authenticated user. The server reads the platform-provided user identity and derives ownership from that identity; the browser does not submit an owner ID. Local development can use the loopback-only test identity described in the README. The language choice is stored in a one-year cookie and read during server rendering. Source: [auth](../app/chatgpt-auth.ts), [auth adapter](../lib/adapters/sites-auth.ts), [language provider](../components/language-provider.tsx).

**Application layers.** `VocabularyService` orchestrates user state, writing analysis, suggestion decisions, word saves/removal, sessions, hints, answers, settings, and sample data. Pure functions in `lib/domain/learning.ts` calculate evidence, progression, exercise selection, due words, and scheduling. The repository interface separates those rules from persistence. A D1/SQLite adapter uses Drizzle ORM. Source: [architecture](architecture.md), [service](../lib/services/vocabulary.ts), [repository interface](../lib/domain/ports.ts), [schema](../db/schema.ts).

**Analysis providers.** The default `mock` provider uses a curated vocabulary catalog and pattern-based analysis and evaluation. It returns no new suggestions outside its supported patterns. The optional `gemini` provider uses server-side Gemini credentials for writing analysis, exercise generation, and answer evaluation. The provider is selected with `LLM_MODE`; `GEMINI_API_KEY` and `GEMINI_MODEL` configure Gemini. Source: [mock provider](../lib/llm/mock.ts), [Gemini provider](../lib/llm/gemini.ts), [configuration](../lib/config.ts).

**Stored entities.** The database schema contains `app_user` (profile/preferences), `word` (lexical entries), `user_word` (ownership, stage, source, review state, and sample marker), `writing_sample`, `vocabulary_suggestion`, `writing_review`, `practice_session`, `exercise`, `practice_attempt`, `insight`, and `request_limit`. Each owner-specific read and write uses the authenticated user ID. Practice attempts provide the evidence for derived learning metrics. Source: [database schema](../db/schema.ts), [domain types](../lib/domain/types.ts).

### API route inventory

| Method and path | Function |
| --- | --- |
| `GET /api/state` | Return profile, board words and attempts, due/queued counts, writing count, insights, and mock-mode flag. |
| `POST /api/analyze` | Analyze a passage and store the writing and review. |
| `GET /api/writing/review?sampleId=…` | Retrieve a saved review and current suggestion decisions. |
| `POST /api/suggestions/decide` | Save, dismiss, mark already-used, or reset a suggestion decision. |
| `POST /api/insights/add` | Save a supported insight alternative as a word. |
| `POST /api/words/remove` | Remove a word from My words. |
| `POST /api/practice/start` | Create a due-word session or a session for one specified word. |
| `GET /api/practice?sessionId=…` | Return the next open exercise or a completed-session result. |
| `POST /api/practice/hint` | Advance and store an exercise hint. |
| `POST /api/practice/answer` | Evaluate an answer, return feedback, and record a finished attempt. |
| `POST /api/practice/skip` | Skip the required sentence step after recall or reveal. |
| `POST /api/settings` | Save name and per-session word limit. |
| `POST /api/demo/seed` | Add a labelled illustrative collection. |
| `POST /api/demo/clear` | Remove the illustrative collection. |

The API validates inputs, requires same-origin JSON for writes, returns non-cacheable JSON, and limits analysis/practice requests per authenticated user. Source: [API route](../app/api/[...path]/route.ts).

## 7. Persistence and state boundaries

- **Server-side learner records:** profile, saved words, source writing, suggestion decisions, practice sessions and exercises, attempt history, and insight data.
- **Browser tab/session state:** unsent writing draft, review position and working revision, writing context passed from Insights, current practice session ID, and current exercise answer/result. This supports resuming within the tab's browser session.
- **Language preference:** a cookie persists the Vietnamese/English interface choice for one year.
- **Public example:** its tab, saved/skipped state, answer, and sentence are local component state; it does not use the learner API.
- **Sample collection:** unlike the public example, **Explore a sample collection** creates labelled, authenticated sample word records with illustrative practice history. Settings can remove them.

Sources: [workspace controller](../components/studio.tsx), [writing screen](../components/writing.tsx), [practice screen](../components/practice.tsx), [language provider](../components/language-provider.tsx), [sample collection service](../lib/services/vocabulary.ts).
