# MVP verification

Verified locally on 25 October 2026 with deterministic mock LLM mode.

- 23 automated domain, provider-contract, and service tests cover spaced occasions, advancement and maintenance, hint weighting, revealed answers, synonym retries, typo handling, queued introductions, and duplicate submissions.
- 9 local API smoke checks cover authentication, forged identity headers, ownership, input validation, cross-origin rejection, duplicate submissions, and unchanged attempt counts after rejected requests.
- Browser walkthrough: onboarding writing, four contextual suggestions, explicit selection of one word, early practice, synonym retry, typo feedback, persistent board after reload, sample collection, word details, and revealed-answer contextual follow-up with zero recall credit.
- Responsive board inspected at 1440px and 375px. Columns stack on phones and no horizontal overflow was observed. Reduced-motion and visible-focus styles are included.

Run `npm test` and `npm run typecheck`. With the local preview running, `node scripts/smoke.mjs` checks the local API. The smoke script assumes the walkthrough's seeded local development data; it is not a production test harness.

## Limits

Live Gemini quality and latency are unverified without a configured server-side API key. Mock evaluation uses curated examples and conservative heuristics, not general semantic understanding. Hosted authentication and database provisioning are separate from the local mocked sign-in tests. No load test, comprehensive assistive-technology audit, or PostgreSQL migration has been performed. See architecture.md for operational and migration boundaries.
