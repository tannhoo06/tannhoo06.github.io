# Ownword changes: copy, language and interface

These changes were made locally during the October 28, 2026 session. They require a deployment before they appear on the hosted site.

## Writing and translation

- Installed the Humanizer Codex skill and used its editing guidance to simplify English and Vietnamese copy on the landing page, audience section, FAQ and sample exercise. The website already had an English/Vietnamese language switch.
- Translated the Vietnamese interface labels for usage patterns and vocabulary stages: Mới học, Đang luyện and Đã vận dụng. Updated the related explanations and a few action labels.
- Replaced the Remote work writing prompt with A favorite animal and changed its English sentence starter to “My favorite animal is ”. All four prompt buttons now have Vietnamese labels when Vietnamese is selected; the English labels remain in English.
- Kept English learning examples, learner writing and target vocabulary in English.

## Visuals and typography

- Removed the decorative botanical landscape from WordBoard.
- Replaced the previous display font and the main interface font with Be Vietnam Pro to improve Vietnamese diacritics while keeping a clean sans-serif style. The font is loaded from Google Fonts, so availability depends on the browser's network access.
- Adjusted primary, accent and secondary button hover styles. Green buttons retain light text; lime and pale buttons retain dark text. Calculated text contrast for these hover color pairs exceeds 4.5:1.

## Word suggestions and practice

- Fixed example sentence highlighting: the suggested word is highlighted as a whole rather than being compared character by character against the original sentence. If the word is absent from the suggested sentence, the sentence displays without highlighting.
- Added a subdued, collapsed-by-default “Hiện nghĩa tiếng Việt” disclosure below the English meaning in writing suggestions and in the recall step of practice. In the English interface its label is “Show Vietnamese meaning”.
- Vietnamese definitions are provided for the fixed built-in demo vocabulary only, matched to the exact English definition. The disclosure is omitted when no matching translation exists, including for arbitrary Gemini-generated definitions. The translation does not reveal the target word or change practice scoring.

## Verification and local preview

- Type checking and the project test suite passed after the earlier changes. Hover colors were also checked by calculating contrast ratios.
- The local preview runs at http://127.0.0.1:5173/ when the development server is active. An earlier stale server lock was cleared after it pointed to a browser process rather than a running preview.
- Humanizer is installed in the user's Codex skills folder and is available for future turns.

## Practice V3 and stabilization

- Added Quick Review alongside Full Practice, flexible access to non-due words, repeat sessions, and compact recall inputs while retaining sentence textareas.
- Quick Review records self-ratings without changing mastery or scheduled dates. Voluntary Full Practice preserves an existing future review date.
- Fixed the recap handoff to practice the complete forgotten set within the session limit, including the page callback that previously dropped the explicit source. Zero-forgotten recaps offer Review again.
- Full implementation notes, changed files, browser/responsive/language QA, test results and deployment assessment are in [Practice iteration](practice-iteration-2026-10-28.md).
