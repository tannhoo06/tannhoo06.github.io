# Public landing extension — 27 October 2026

Local implementation only; not deployed. Built on the existing uncommitted hero, practice, and scrolling refinements.

## Implemented

- Compact ivory audience introduction with the exact Vietnamese copy and complete English translation.
- Two-column FAQ, five button/region accordion rows, visible keyboard focus, initial audience answer expanded; stacked on mobile.
- Header FAQ anchor, sage closing invitation using the existing start callback, feedback email, compact footer and current year.
- Owner confirmed free access now and intended future paid features. Interim feedback/contact address: ownword_support@gmail.com.
- Owner requested draft legal destinations: /privacy and /terms explicitly state that their content is unfinished and not official policy. Both support the persistent language preference.
- Native opening-section proximity scrolling is preserved where sections fit; snapping is disabled after the learning-section start so lower content uses ordinary scrolling.

## Factual basis

- components/studio.tsx: start uses ChatGPT sign-in for anonymous visitors; signed-in visitors navigate to start.
- lib/server/composition.ts and lib/adapters/sites-auth.ts: authenticated identity required for personal learning services.
- lib/services/vocabulary.ts and db/schema.ts: submitted writing and analysis are stored against the user; words and practice records persist.
- components/writing.tsx: browser-session draft persistence.
- lib/config.ts, lib/llm/mock.ts, lib/llm/gemini.ts: curated demo mode or configured server-side Gemini processing. FAQ states conditional processing without guessing deployment mode, retention, training use, or guarantees.

## Verification

- TypeScript and targeted ESLint: passed.
- Existing 35 unit/service tests: passed.
- Production build: passed. Vinext reports its existing static-classification limitation for the new legal routes; live routes were checked.
- Existing landing browser suite: passed, covering normal/reduced motion in both languages, native scrolling and keyboard/anchor/history behavior, mobile touch emulation, practice dialog focus confinement/Escape/restoration, persisted sample answers, stable cards, independent hero, and existing start boundaries. Updated old end-of-document assertions for the longer page.
- Public browser suite: both languages at 1440×900, 1280×720, 1069×930 and 390×844; keyboard accordion Enter/Space and visible focus, no horizontal overflow, FAQ anchor, lower-page normal scrolling, footer End access, reduced motion, persisted language, legal routes, email hrefs and all three start buttons.
- Sign-in requests intercepted at the boundary: no account sign-in or learner-data writes. Email destinations inspected without sending email; mailbox delivery not tested.
- git diff --check: passed.

## Independent critic

A separate critic inspected the approved reference, screenshots and live Edge preview. It identified an observable desktop hierarchy discrepancy: audience and FAQ headings were undersized relative to the reference. Increased desktop audience heading to 48px maximum, FAQ heading to 40px maximum and audience body to 20px; kept mobile sizes. Critic rechecked the rendered result: introduction remained compact (about 304px at 1440px), mobile/English remained coherent, and no material discrepancies remained. It judged the composition close enough to the reference.

## Evidence and limitations

Screenshots: outputs/landing-public/{vi,en}-{1440,1280,1069,390}-{full,support,footer}.png. Independent evidence: critic-desktop.png and critic-mobile.png. Browser scripts: tests/landing.browser.mjs and tests/landing-public.browser.mjs, with PLAYWRIGHT_MODULE pointing to an installed Playwright module when necessary.

Legal text awaits owner completion and the interim support address can be replaced later. No policies were fabricated. Browser verification used Chromium/Edge and emulated input, not physical mobile hardware or Safari/Firefox. No deployment was performed.
