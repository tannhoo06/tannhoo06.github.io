# UX improvements implementation

Implemented 26 October 2026 against `docs/ux-audit.md`. The audit itself was preserved.

## Preview and operation

Run `npm run dev` and open http://127.0.0.1:5173/write. The current local preview is running on that address. Use **Use an example**, then **Review word suggestions**. This is the real application in its existing demo-analysis mode, backed by the local D1 database.

The additive migration `drizzle/0001_sloppy_goblin_queen.sql` adds review storage and suggestion anchor/decision metadata. It was applied to the local preview database only, after an online SQLite backup at `.sites-runtime/pre-ux-migration.sqlite`. Apply this migration through the normal deployment migration process before deploying the new application code. No hosted deployment was performed. Existing writing, words, attempts, authentication, scheduling and mastery policies were retained.

## Audit tracking

| Finding | Implemented behavior | Evidence |
| --- | --- | --- |
| F01 | Exact UTF-16 source anchors validated on the server and again against the immutable sample in the UI. Numbered annotation and note selection are synchronized; overlapping ranges split at boundaries without nested buttons. Ambiguous/stale locations have an explicit fallback. | `tests/writing.test.ts`, writing browser checks |
| F02 | Original sentence and complete proposed sentence appear together. Demo adjective frames retain nouns and fix the article; unsafe verb rewrites are unavailable. Gemini supplies a full sentence under its structured contract. | Rewrite tests and example walkthrough |
| F03 | Current source sentence, explanation and actions share one note on phones; the full paragraph is below. Selecting a paragraph annotation brings its note into view on narrow layouts. | Writing screenshots at 390/320 |
| F04 | Learning text uses 16–18px; secondary text and controls have a 14px floor. Tablet collection reflows into readable rows rather than tiny three-column cards. | Four-width screenshots, computed text sizes |
| F05 | Source writing uses dark ink; rendered core text pairs exceed 4.5:1. | `access-checks.json` |
| F06 | Write / Practice / My words / More fits at 320px; Insights and Settings are accessible in More. | Navigation and overflow assertions |
| F07 | Completion counts ready, queued, kept-original and already-used choices separately. Queued-only saves receive an explicit successful result and collection action. | Service, D1 and browser queue tests |
| F08 | Server stores immutable analysis; user-scoped tab storage retains draft, review identifier/cache, cursor, edits and revision undo. Navigation/reload restores the review without analysis. Completed requests also publish results after soft navigation. Practice retains session, draft, hints, feedback and pre-reveal attempt. | Review and practice reload/navigation tests |
| F09 | Detail Close/Escape restore the originating word card; deep-linked details fall back to the page heading. | Keyboard browser assertions |
| F10 | Removed sidebar/topbar/footer slogans and reduced repeated task copy. | Workspace screenshots |
| F11 | Literal Write, Word suggestions, My words, Writing insights and Settings labels. | All route screenshots |
| F12 | Navigable suggestion decisions, Previous/Next, Undo decision, independent revision preview/apply/undo. Server undo removes only a newly saved, unpracticed word. | Reversal tests including existing/practiced-word protection |
| F13 | Matched counts agree with cards; one no-results message and Clear filters. | Collection browser assertions |
| F14 | Due status is independent of stage, including Active words. | Active-due fixture |
| F15 | Removed false three-dot menu cue; word card consistently opens detail. | Collection/detail walkthrough |
| F16 | Compact top navigation, URL-backed stage/search/due filters and responsive list/grid collection. | Tablet/phone/320 and doubled-text walkthrough |
| F17 | Practice answer, feedback, then next action; retry feedback remains visible while editing. | Practice fixture checks |
| F18 | Visible question count plus progressbar values and status feedback. | Practice DOM/browser checks |
| F19 | Visible writing label, actual 10-character/5,000-character requirements, tab-storage scope and retry with retained text. | Writing form and error walkthrough |
| F20 | Insights include source sample identity, occurrence offsets and sentence, with View in writing. | Insights tests and browser walkthrough |
| F21 | Context/word intent is carried into writing without silently replacing the draft; owned words link to detail; saves report queue state. | Insights intent walkthrough |
| F22 | Demo limitations appear beside analysis; empty results say no matching demo suggestions, not that writing was comprehensively assessed. | Empty/error screenshots |
| F23 | Main actions are 48px; supporting targets aim for 44px. Inline source annotations retain inline reading behavior rather than forcing oversized line boxes. | Responsive/control review |
| F24 | Semantic destination links, descriptive titles and page-heading focus; browser navigation retains view state. | Keyboard/title/navigation assertions |
| F25 | Settings exposes essential fields and saved/unsaved state, warns only for dirty edits, moves policy to disclosure and retains sample-removal confirmation. Details disclose usage/history. | Settings and detail walkthrough |

Supporting page recommendations are included: explicit onboarding steps and optional starter/example, landing-page sentence example with sample label, accurate practice completion, persistent context and literal collection/detail controls. `docs/design.md` now describes the approved Hum-inspired adaptation.

## Verification

- `npm run typecheck`: passed.
- `npm run lint`: passed with two existing-pattern warnings for full-document navigation to authentication endpoints in `studio.tsx`; no errors. These endpoints intentionally perform full-document authentication navigation.
- `npm test`: 32 tests passed, including source anchors (repeats, overlap, Unicode/surrogates, punctuation, apostrophes, line breaks, stale versions), sentence rewrite safety, review persistence, reversal, queue state and Insights source context. Existing learning-policy tests still pass.
- `node scripts/test-d1-ux.mjs`: passed using a separate ephemeral Miniflare D1 database and the actual migrations, Drizzle repository and vocabulary service. Verified persisted review reload, owner isolation, add/undo, queue state and protection after practice starts. No learner records are used or changed by this test.
- `node scripts/smoke.mjs`: passed against the actual local preview/authentication/D1 API, including unauthorized/forged identity rejection, cross-origin rejection and replay protection.
- `npm run build`: passed all five Vinext build phases.
- Headless Chrome with intercepted API fixtures: all six workspace destinations inspected at 1440, 768, 390 and 320px. Exercised writing analysis/revisions/save/undo/resume/empty/error/queue, practice draft/retry/hints/reveal/feedback/completion, collection filters/Active-due/detail focus and Settings/Insights transitions. Fixtures do not write learner content to the local database.
- Keyboard: semantic links, annotation buttons, dialog Tab containment, Close/Escape focus restoration and route-heading focus verified. Reduced motion checked. Tablet text was doubled to check reflow. Core rendered text contrast pairs were measured (for example, collection definitions 14.37:1, review status 6.56:1 and primary-action text 11.41:1).
- Hallmark static app-scope sweep: zero Floor failures and zero Reflex findings; 18 warnings reviewed. The render tier could not run because Puppeteer is absent; the separate Chrome/Playwright walkthrough is the browser evidence, not a claimed Hallmark render pass. Warnings about earlier CSS color declarations are superseded by the measured final cascade; inactive legacy suggestion selectors are unused. Wrapped card/action labels are intentional at phone widths; the sentence comparison rule groups before/after content; annotated text is not a success message (the scanner's warning 70 is a false positive). Remaining icon and menu-border warnings are house-style preferences retained for consistent controls.

Screenshots, assertions and local harnesses: `outputs/ux-implementation/`. This directory is intentionally ignored by Git, following the project's existing output policy.

## Boundaries and remaining limitations

- Drafts, revision undo, review position and practice answer context recover within the current browser tab, including reload; there is no cross-device draft/version-history interface. Immutable analyzed originals and decisions are stored server-side. A hard reload before an analysis request returns retains the draft; a request that never completed must be retried.
- Undo cannot remove a word once a practice exercise or attempt references it. The server returns an explicit explanation and preserves its learning history. Pre-existing words saved elsewhere are never deleted by suggestion reversal.
- The demo is deliberately limited. Live Gemini wording quality and real hosted authentication were not exercised. Source validation establishes location integrity, not a guarantee that every model rewrite preserves nuance; revisions require preview and explicit application. Unresolved locations and unsupported demo rewrites are honest fallbacks.
- Existing older words may have only the original phrase stored in `sourceText`; the new detail view displays the retained evidence without inventing missing sentences. New anchored saves store the complete original sentence.
- Browser checks are not representative learner research, physical mobile-keyboard tests or screen-reader speech tests. No claim of longitudinal learning impact or comprehensive WCAG certification is made.
