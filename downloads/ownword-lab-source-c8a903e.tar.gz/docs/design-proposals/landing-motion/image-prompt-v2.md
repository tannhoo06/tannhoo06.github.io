# Revision 2 image-edit prompt

**Tool:** built-in ImageGen.  
**Reference:** `ownword-motion-concept.png`, the clean first concept. The user's annotated image supplied the requested corrections.  
**Selected output:** `ownword-motion-concept-v2.png`.  
**Transparent background:** false.

## Prompt

Edit the supplied Ownword landing-page concept image. Make ONLY these corrections, retaining the same tactile paper design, colors, layered sentence workbench, book/plant vignette, lower process section, typography character, and overall desktop composition. This is a corrected design proposal, not implementation.

1. Replace the two-line hero headline "Biết từ rồi. Giờ dùng thật tự nhiên." with this exact, plain, natural and professional Vietnamese headline: "Luyện từ vựng" on the first line and "qua bài viết tiếng Anh." on the second line. Use slightly smaller bold dark navy rounded sans typography if needed to fit comfortably within the LEFT column. Keep adequate distance from the example workbench; no overlap. No italic, accented or highlighted word in the headline. No red annotations or marks.

2. Replace the hero description "Viết vài câu. Tìm từ đúng ý. Luyện để dùng tự nhiên." with the exact concrete Vietnamese sentence: "Nhận gợi ý ngay trong đoạn bạn viết và ôn lại những từ bạn muốn sử dụng." Set it in readable regular sans, wrapping into two short lines beneath the headline.

3. Remove the TOP-RIGHT HEADER yellow "Bắt đầu viết" button completely. Keep exactly ONE main "Bắt đầu viết" CTA: the existing large yellow button BELOW the hero description. Keep the quieter "Thử với câu mẫu" text action beside it. Do not add a replacement sign-up, sign-in, or start button anywhere in the header. Move the language switch to the far right to use the vacated space. Header should contain the ownword brand, the "Cách học" section link, and the Tiếng Việt / English language switch. Remove the redundant header "Thử một câu" section link since the hero already has the sample action. Retain the small coral paper label on the example workbench.

4. In the LOWER FIRST STEP card under "1 Viết", replace the ENGLISH instruction "Write a few sentences about what you’re thinking." with this exact VIETNAMESE instruction: "Viết vài câu bằng tiếng Anh về một chủ đề bạn quan tâm." This is interface guidance, so it must match the selected Vietnamese interface. Retain the notebook/rule lines; use clear readable type. The actual English example sentences in the workbench and second process card MUST remain English, since they are the learning material, not interface instructions.

Preserve the original source sentence "There was a very small difference in productivity." and the proposed sentence "There was a negligible difference in productivity." Retain phrase highlights, numbered marker, note, save/replay controls, and the yellow negligible vocabulary tile. Retain the lower headline "Từ bài viết đến cách dùng." and the rest of the composition. All Vietnamese diacritics and English spelling must be correct. Deliver a crisp single high-fidelity screenshot-style concept with no browser chrome, no watermark and no annotation marks.

