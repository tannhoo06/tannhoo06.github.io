# Compact audience introduction

Built-in ImageGen edit of the public-facing concept based on the current website screenshot. Image proposal only; no website changes.

## Exact prompt

Edit the attached full-page Ownword website mockup. Change ONLY the audience/value section immediately below the pale sage "Cách học với Ownword" area and above the FAQ.

REMOVE the existing two-column block headed "Học từ gắn với điều bạn muốn nói.", including all three numbered benefits, their separators, and its short audience paragraph and green-rule tagline. Replace that whole block with a compact, restrained audience introduction, on the SAME ivory background as the FAQ. It must feel like a short introductory block leading into FAQ, NOT a standalone full-screen section. No cards, no numbered points, no colored backing, no illustrations. Use the current website's dark blue-green sans-serif typography. Align within the same main content margins, readable text measure, modest vertical padding. Heading medium size, paragraph readable, qualification quieter italic. Exact replacement copy:

Heading: "Ownword phù hợp với ai?"
Paragraph: "Bạn đã có thể viết một đoạn tiếng Anh, nhưng đôi lúc vẫn khó tìm được từ diễn đạt đúng ý? Ownword giúp bạn học thêm từ ngay từ bài viết của mình, rồi luyện nhớ và dùng chúng trong câu mới."
Quiet italic line: "Không phải lúc nào từ khó hơn cũng là lựa chọn tốt hơn. Điều quan trọng là từ phù hợp với điều bạn muốn nói."

Follow this compact introduction with a subtle thin divider and the existing "Câu hỏi thường gặp" FAQ layout. Reduce the removed section's height if needed so the page flows naturally without a large blank gap.

Preserve everything else in the image as faithfully as possible: entire header and hero, exact current typography and colors, current small book/plant cutout, sentence workbench with downward arrow and no replay, four how-it-works cards and review loop, yellow Bắt đầu ngay action, FAQ accordion contents, bottom sage CTA and footer. Do not redesign other sections. No red annotations. Do not add claims, testimonials, prices, new graphics, or new sections. Keep all Vietnamese accents correct. Return complete full-page updated mockup.
