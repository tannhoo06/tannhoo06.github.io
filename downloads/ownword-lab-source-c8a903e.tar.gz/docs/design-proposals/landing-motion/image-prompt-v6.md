# Revision 6: downward hero arrow and replay removal

Input: `ownword-motion-concept-v5.png`.

Tool: built-in ImageGen, opaque background.

Exact editing prompt:

Use case: precise-object-edit.
Asset type: high-fidelity Ownword landing-page mockup.
Input image: edit target, the existing full-page mockup.

Make exactly two corrections to the LARGE HERO demo card at the upper right:
1. REVERSE THE DIRECTION of its green curved connector. The tail starts immediately beneath the highlighted ORIGINAL phrase "very small difference". It curves DOWN into the pale green LOWER suggestion board. The ONLY arrowhead must be at its LOWER END, pointing downward toward the "Thử dùng “negligible”" suggestion area. No arrowhead at the upper end. Keep the current compact right-bowing curvature, but flow is SOURCE PHRASE -> LOWER SUGGESTION BOARD. Keep the line away from all text.
2. Completely remove the circular replay icon button AND its "Xem lại" label at the right side of that lower suggestion board. Restore the clean pale green background in that area. Do not replace it with any control.

Preserve everything else exactly: all Vietnamese and English text, headline, header, language selector, source sentence, numbered yellow highlight, revised sentence, hero actions, card tabs, paper layers, colors, illustrations, two-section page composition, entire lower four-step learning section and its existing small arrows and recurrence loop, bottom "Bắt đầu ngay" button. Only the LARGE HERO arrow and replay control change. Do not alter the lower step-two arrow. No red annotations.
