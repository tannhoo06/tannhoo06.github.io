# Revision 4 image-edit prompt

**Tool:** built-in ImageGen.  
**Reference:** `ownword-motion-concept-v3.png`.  
**Selected output:** `ownword-motion-concept-v4.png`.  
**Transparent background:** false.  
**Intent:** a full-page preview of two consecutive viewport-led sections, with a start action below the explanation.

## Prompt

Edit the supplied Ownword concept into a TALL FULL-PAGE WEBSITE MOCKUP with TWO DISTINCT VERTICALLY STACKED SCREEN-HEIGHT SECTIONS. This is a long-page design preview, not two browser windows or two side-by-side variants. Preserve the existing approved paper-and-sage visual style, ownword feather branding, exact Vietnamese copy, English learning examples, upward annotation arrow and four-step explanation. No browser chrome, no watermark, no reviewer annotations. Target portrait page proportions approximately 1500 wide x 2000 high: the TOP HALF represents the first desktop viewport; the BOTTOM HALF represents the next viewport after scrolling.

CRITICAL PAGE STRUCTURE:
SECTION 1 fills the ENTIRE FIRST VIEWPORT from navigation through the bottom of the hero. The title "Cách học với Ownword" MUST NOT be visible anywhere in the top half. The transition to the sage second section begins exactly below the first screen's bottom boundary. Give the hero more comfortable breathing room and intentional vertical centering instead of simply stretching text.
Header at the top of section 1: ownword logo at left, "Cách học" anchor link, Tiếng Việt / English control at right. No top header start button. The header is not repeated in section 2.

SECTION 1 CONTENT:
Hero left: headline EXACTLY "Học đúng từ," then "dùng đúng nơi."
Description EXACTLY "Viết một đoạn tiếng Anh để nhận gợi ý từ theo ngữ cảnh. Chọn từ cần học, rồi luyện nhớ và đặt câu qua các buổi ôn tập."
One yellow primary button "Bắt đầu viết" and quiet "Thử với câu mẫu" link. Keep the small static book/plant vignette tucked along the lower-left edge, subordinate to the text.
Hero right: retain the large layered paper workbench with sage backing and tabs "1. Viết", "2. Chọn từ", "3. Luyện". Include "Ví dụ minh họa", original English "There was a very small difference in productivity." with exact phrase "very small difference" highlighted, the numbered marker, suggestion "Thử dùng “negligible”", meaning "Nhỏ đến mức không đáng kể.", and English rewrite "There was a negligible difference in productivity." The curved arrow MUST point upward from the suggestion back to the highlighted original phrase. Keep the "Xem lại" replay control, small "Thử cách viết này" and "Lưu từ" controls, and attached yellow negligible word tile. All of this fits COMFORTABLY in the first screen with no next-section title peeking into it.

SECTION 2:
Begins ONLY BELOW THE FIRST VIEWPORT, on a spacious soft sage background with a subtle paper-edge transition. Top heading EXACTLY "Cách học với Ownword". Supporting line EXACTLY "Từ ý bạn muốn diễn đạt đến từ bạn tự dùng được."
Place the same FOUR readable explanatory activity previews across the full section width below that heading, in order with left-to-right connectors:
1 "Viết đoạn văn" with caption "Bắt đầu từ điều bạn muốn nói." and a small writing-sheet sample labelled "Bài viết của bạn"; actual sample English "There was a very small difference in productivity."
2 "Xem gợi ý trong câu" with caption "Hiểu nghĩa và cách dùng theo ngữ cảnh." and an exact-phrase highlight plus connected negligible note.
3 "Chọn từ muốn học" with caption "Chỉ lưu những từ bạn thấy hữu ích." and yellow negligible word tile, "Lưu từ" and "Bỏ qua".
4 "Luyện nhớ và đặt câu" with caption "Nhớ lại từ và thử dùng trong ngữ cảnh mới.", empty field labelled "Câu trả lời của bạn", and "Kiểm tra" button.
Use differentiated activity previews with generous text sizes. Keep the compact return loop attached ONLY TO STEP 4, labelled "Ôn lại khi đến hạn", plus note "Lịch ôn điều chỉnh theo kết quả luyện tập." It must NOT point back to new writing at step 1.

NEW REQUIRED SECOND-SECTION ACTION:
Below the COMPLETE learning explanation and recurrence loop, add a prominent centered pear-yellow primary button labelled EXACTLY "Bắt đầu ngay" with a small separate arrow icon. This is a deliberate end-of-section CTA. It must be below "Cách học với Ownword" and the full four-step flow, with clear vertical space. Do not place it beside the section heading or in the header. It should be visible within the second screen in this desktop concept. Keep the first hero's separate "Bắt đầu viết" button: one start action per screen is intentional.

Final result should unmistakably read as a real scrollable website: first screen is header + hero, second screen explains the mechanism and ends in "Bắt đầu ngay". No section-2 content visible in the first viewport. Keep the site friendly and lively through paper composition, not oversized empty zones or tiny compressed text. Keep Vietnamese instructions Vietnamese and actual English learning content English.

