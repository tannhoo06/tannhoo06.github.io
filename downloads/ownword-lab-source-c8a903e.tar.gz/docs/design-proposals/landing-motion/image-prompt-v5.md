# Revision 5: hero reference-arrow correction

Input: `ownword-motion-concept-v4.png`.

Tool: built-in ImageGen, opaque background.

Exact editing prompt:

Edit this existing Ownword landing page mockup with one precise correction only: the curved green reference arrow in the large HERO demonstration card, between the original English sentence and the pale green suggestion note.

Mirror the curve horizontally and reposition it toward the RIGHT of that gap. The curve should bow toward the RIGHT, like a right parenthesis, with its tail lower near the right side of the suggestion note and its arrowhead pointing UP and LEFT back toward the yellow highlighted phrase "very small difference" in the original sentence. This is an upward reference arrow from the suggestion to the source phrase. Keep it thin, hand-drawn, dark green, and compact, in clear whitespace. Do not overlap the sentence or the circular replay / "Xem lại" control. Remove the old connector so there is only one main hero reference arrow. Do not reverse the arrowhead downwards. Do not draw any red annotations.

Preserve EVERYTHING else exactly: the tall two-section page, header, hero headline "Học đúng từ, dùng đúng nơi.", all Vietnamese and English text, all card contents and actions, books and plants, colors, proportions, spacing, lower "Cách học với Ownword" section with four cards, its existing small connectors and review loop, and bottom "Bắt đầu ngay" button. Do not change the lower step-two arrow. This is a local correction to the main hero arrow only.
