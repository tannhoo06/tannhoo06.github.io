# Ownword: a landing page with more life

**Status:** revised proposal for approval, 26 October 2026.  
**Scope:** the public landing page first; selected working-app interactions are optional later work.  
**No implementation or deployment is authorized by this document.** The live site, application code, dependencies, data and access settings have not been changed for this proposal.

## Recommendation

Keep Ownword's Vietnamese-first identity and the Hum/Sprout direction, but bring back the theme's tactile character. Replace the static example box with a small interactive sentence workbench. Give the page a more expressive composition, a few well-placed paper layers, stronger accent color and a short sequence that demonstrates the product.

The goal is a welcoming learning tool with personality. Someone should understand both **what Ownword does** and **what they can try** within the first screen.

A new component library by itself will not deliver that result. The useful change is a distinctive product demonstration, composed with existing components and a deliberate motion sequence.

## Concept image

![Revision 6 Ownword full-page concept with a downward hero connector and no replay button](ownword-motion-concept-v6.png)

### Revision 6: source-to-suggestion arrow and no replay button

The main hero connector starts beneath **very small difference** and curves down into the lower suggestion panel, with its arrowhead at the lower end. Remove both the circular replay button and its **Xem lại** label. This supersedes revision 5's upward connector and replay control. The two-section structure and lower explanation remain as in revision 4; the small connector within the lower second activity is unchanged.

### Revision 4: two sections with a clear scroll boundary

- **First screen:** navigation plus the complete hero. It ends immediately before **Cách học với Ownword**; that heading is below the initial desktop fold.
- **After scrolling:** the separate **Cách học với Ownword** section presents the four activities and scheduled-practice loop.
- **End of the second section:** a prominent centered **Bắt đầu ngay** action follows the complete explanation. In English, this action reads **Start now**.
- Keep **Bắt đầu viết** in the hero and no start button in the header. One start action per section is deliberate; the rejected duplication was two start actions within the same first screen.

### Retained mechanism and copy decisions

- Use the user's preferred headline: **Học đúng từ, dùng đúng nơi.**
- Explain the actual mechanism: **Viết một đoạn tiếng Anh để nhận gợi ý từ theo ngữ cảnh. Chọn từ cần học, rồi luyện nhớ và đặt câu qua các buổi ôn tập.**
- Direct the main workbench connector from the highlighted source phrase down to the suggestion panel. Omit the replay button.
- Redesign the entire lower band as four explicit activities: writing, examining contextual suggestions, choosing what to save, and practicing recall/sentence use. A return connector shows that review continues when due.
- Keep one **Bắt đầu viết** action in the hero. Remove the duplicate header action and its redundant sample link.
- Translate the first process card's instruction into the selected interface language. In Vietnamese: **Viết vài câu bằng tiếng Anh về một chủ đề bạn quan tâm.**
- Retain English sentences and vocabulary as learning content; instructions, labels and helper text follow the interface language.

Earlier concepts remain available as [revision 1](ownword-motion-concept.png), [revision 2](ownword-motion-concept-v2.png), [revision 3](ownword-motion-concept-v3.png), and [revision 4](ownword-motion-concept-v4.png) for comparison. These corrections change the proposal only.

This is an AI-generated **visual proposal**, not a browser screenshot or an implemented UI. It shows a representative animation keyframe. It cannot demonstrate timing, responsiveness, keyboard behavior or working language switching. Vietnamese copy and spacing would be typeset and checked in real HTML during implementation.

The small book/plant vignette in the generated concept is optional atmosphere. It is not a new learning feature or a requirement to add illustrations throughout the app. The sentence workbench remains the main visual object.

## Why the current page feels lifeless

The supplied screenshot and current `Landing` component show a sensible but very static composition:

- Most objects sit on the same flat background with similar weight and spacing.
- The example is a paragraph inside a bordered box. It explains an interaction without letting the visitor experience one.
- The three lower steps repeat the same text-column treatment. There is little visual contrast between writing, choosing and practicing.
- The pale action button has limited presence relative to the heading and empty space.
- The page does not show an observable transition between a phrase, a suggested word and a practice item.

These are composition and interaction issues. Simply adding a fade to each existing block would leave the page mostly unchanged. Conversely, moving every card continuously would make it busier without making the learning process clearer.

## The proposed composition

### Page structure and scroll behavior

The page is divided into **two consecutive sections**, not one composition that compresses the hero and explanation into the initial viewport.

| Section | What appears | Primary action |
| --- | --- | --- |
| **1. Introduction** | Header, headline, mechanism description, sample workbench and supporting artwork | **Bắt đầu viết** beneath the hero copy |
| **2. Cách học với Ownword** | Section heading, the complete four-activity explanation, and the recurrence loop on practice | **Bắt đầu ngay**, centered beneath the explanation |

At ordinary desktop sizes, size the **combined header and hero** to occupy the first viewport. Use a minimum viewport-based block size, such as `100svh`, for that combined introductory wrapper. Do not give the header and hero each their own full-screen height. The next section starts after that wrapper; its heading must not peek into the initial screen. Vertically balance the hero content rather than enlarging the type to fill the space.

Give the second section enough space for its heading, readable previews, review loop and bottom action. It can use a viewport-sized minimum at desktop sizes, but must grow when its content needs more room.

The image is a **full-page preview of the scroll sequence**: its upper screen is the arrival state, and its lower screen is reached by scrolling. It does not represent both sections simultaneously visible in one browser viewport.

The header's **Cách học** link targets the second section. Use ordinary anchor navigation, optionally with a brief smooth scroll when reduced motion is not requested. Preserve normal scrolling; no scroll hijacking, forced snapping, pinned scroll sequence or mandatory animation before the user can proceed.

On narrow or short screens and with enlarged text, content may exceed one viewport. Let the introduction grow naturally and keep every control readable. Never crop the workbench, hide text, shrink the font, or lock scrolling to enforce an exact two-screen height. Section 2 still follows the complete introduction.

### 1. A compact, useful header

Retain the ownword mark, a **Cách học** section link and the persistent **Tiếng Việt / English** control. Do not repeat **Bắt đầu viết** in the header; the hero contains the first section's single primary action. Keep the sample action beside the hero action rather than duplicating it in the header. Do not repeat the entire header above the second section.

The header is immediately usable; it does not wait for an entrance animation. On phones, retain the language control in the header and the primary action in the hero, with the secondary section link collapsed or omitted when redundant.

### 2. A confident, approachable hero

Suggested Vietnamese copy:

> **Học đúng từ, dùng đúng nơi.**  
> Viết một đoạn tiếng Anh để nhận gợi ý từ theo ngữ cảnh. Chọn từ cần học, rồi luyện nhớ và đặt câu qua các buổi ôn tập.

The headline is the user's requested phrasing. The description supplies its concrete meaning: suggestions arise from the learner's writing; the learner chooses vocabulary; later work includes productive recall and sentence use. Avoid implying that Ownword merely replaces simple words with impressive ones or automatically corrects every sentence.

Primary action: **Bắt đầu viết**.  
Secondary action: **Thử với câu mẫu**.

The primary action enters the existing authenticated writing flow. The sample action operates on the public page without requiring sign-in. It should not seed a real vocabulary collection or change learner records merely because someone wants to see an example.

Use dark, rounded Vietnamese-capable type, a more definite pear-yellow button, and stronger grouping between the short explanation and its actions. The headline stays still and readable. Do not rotate important words in the headline or reveal it character by character.

### 3. An interactive sentence workbench

This is the central component: a broad reading sheet on a soft sage backing, with modest offset layers and an attached vocabulary tile. It should look tangible without resembling a screenshot of a browser or a pile of unrelated floating widgets.

Use the existing, clearly labelled sample:

**Original:** There was a **very small difference** in productivity.  
**Suggestion:** There was a **negligible** difference in productivity.

The original phrase receives a numbered highlight. Its explanation appears nearby: **Thử dùng “negligible”**, with the meaning **Nhỏ đến mức không đáng kể.**

The main hero arrow starts beneath the highlighted source phrase, bows to the right, and points down into the suggestion panel. It shows the progression from the learner's wording to its contextual suggestion. Keep it clear of text. The number and text continue to identify the relationship when the connector is hidden on small screens.

The meaning qualification matters: *negligible* means too small to matter, not simply small. The example should explain that nuance rather than sell every advanced word as an automatic improvement.

Provide **1. Viết / 2. Chọn từ / 3. Luyện** controls that change the visible example state. Reuse the same sentence throughout. Do not include a replay icon or **Xem lại** button. The source text stays legible while its connected suggestion changes.

In the sample, **Lưu từ** demonstrates where a vocabulary tile goes and says **Đã lưu trong ví dụ**. It does not silently claim the visitor saved a real word. Actual saving belongs to the authenticated learning flow. This distinction should be clear in both languages.

The image is a visual exploration; final button labels must make this demo boundary unambiguous. Where showing two sets of actions would compete, the hero's main call to action wins.

### 4. A lower section that explains the mechanism

Use the full width of the soft sage band rather than giving a third of it to a large slogan. The heading is **Cách học với Ownword**, followed by **Từ ý bạn muốn diễn đạt đến từ bạn tự dùng được.** Four numbered activities show what happens and what the learner controls:

| Activity | Visible explanation | Product preview |
| --- | --- | --- |
| **1. Viết đoạn văn** | Bắt đầu từ điều bạn muốn nói. | A writing sheet labelled **Bài viết của bạn**, with a short actual English example |
| **2. Xem gợi ý trong câu** | Hiểu nghĩa và cách dùng theo ngữ cảnh. | The exact original phrase, its numbered highlight, and a connected **negligible** note |
| **3. Chọn từ muốn học** | Chỉ lưu những từ bạn thấy hữu ích. | One vocabulary tile with distinct **Lưu từ** and **Bỏ qua** actions |
| **4. Luyện nhớ và đặt câu** | Nhớ lại từ và thử dùng trong ngữ cảnh mới. | A recall/usage task, an empty **Câu trả lời của bạn** field, and **Kiểm tra** |

Use one coherent connected strip with differentiated activity previews, not four identical feature boxes or skeleton placeholders. A compact recurrence connector attached to **step 4 only** reads **Ôn lại khi đến hạn**, with **Lịch ôn điều chỉnh theo kết quả luyện tập.** It returns to practice of the saved words, not to writing a new paragraph. This reflects the existing scheduling mechanism without inventing fixed intervals, promising reminders, or claiming mastery after a single attempt.

These four explanatory milestones are not four new app modes. The existing three workbench tabs remain **Viết / Chọn từ / Luyện**; examining the suggestion and deciding whether to save are both part of Chọn từ. The lower previews refer to the same example and do not each run an independent animation.

The practice sample must hide the target before someone answers. If a visitor starts an actual demo recall task, switch away from the visible word tile and suggestion, so the answer is not sitting beside the input. Show a brief, explicit result when they check it. Any answer checking here uses a bounded illustrative example; it must not imply general AI evaluation. The generated image summarizes stages and is not a valid independent-recall test by itself.

### 5. A start action after the explanation

Place a substantial **Bắt đầu ngay** button below the four activities and the **Ôn lại khi đến hạn** loop, centered with clear space around it. Its English label is **Start now**. This gives someone who scrolls through the explanation an immediate next step without returning to the hero.

It invokes the same existing start-writing flow as **Bắt đầu viết**, including the required sign-in for personal learning. It does not register an account automatically, seed sample words, start a new session silently or bypass authentication. Only its position and label differ.

## What the installed skills actually provide

| Source inspected | Useful material | Application to this concept |
| --- | --- | --- |
| Hallmark `references/themes/hum.md` and its Sprout reference image | Warm paper, rounded typography, pear/mint/coral roles, card-stock controls, material and motion recipes | The primary visual direction, with restrained layering and one tactile primary button |
| Hallmark `references/microinteractions.md` | Button press, tabs, menus, disclosure, motion character and reduced-motion recipes | State transitions, visible selection and immediate keyboard focus |
| Hallmark `references/craft.md`, motion section | Short entrance sequences, shared easing/duration tokens and limited motion primitives | A short coordinated arrival and functional workbench transitions |
| UI/UX Pro Max `motion.csv`, exposed by `--domain gsap` | Verified subtle/standard stagger presets, trigger/duration guidance and framework cleanup notes | Timing reference for the first reveal; not a requirement to install GSAP |
| UI/UX Pro Max animation UX guidance | Respect reduced motion, avoid excessive simultaneous animation, tune duration to purpose | Keep the main paragraph stable and limit motion to the learning example and active control |
| Existing `components/ui/tabs.tsx` | Radix-backed tab primitives | Accessible three-step demonstration control |
| Existing `components/ui/accordion.tsx` | Radix-backed disclosure primitives | Optional explanation of why a word fits |
| Existing buttons, current `LanguageSwitch`, Lucide icons | Local controls and visual vocabulary | Preserve existing language behavior and use consistent control styling |

**These skills are not a bundle of ready-made animated landing-page templates.** Hallmark supplies theme specifications and recipes; UI/UX Pro Max supplies searchable recommendations and motion snippets. The workbench and its choreography would be custom components assembled from those resources.

The initial UI/UX Pro Max design-system search mixed a generic Swiss layout with child-oriented font recommendations. A narrower style search returned paper, claymorphism and neubrutalism. Those results do not establish a suitable complete Ownword theme, so they were not adopted. The independently verified motion guidance is useful; Hallmark Hum and the user's chosen Sprout direction remain the design basis.

## Proposed motion specification

Times below are starting values for a prototype, not measured performance or universal rules.

| Interaction | Trigger and movement | Approximate timing | Purpose and stopping behavior |
| --- | --- | --- | --- |
| Workbench arrival | The backing and sheet settle upward by 8–16px with opacity; brief ordered stagger | 320–480ms total, once | Establish the main object; the heading, navigation and CTA remain available immediately |
| Phrase-to-suggestion sequence | Highlight the exact phrase, reveal the nearby note, then show the complete proposed sentence | One roughly 3.2–3.8s demonstration | Explain the product, then stop on the readable final state; no automatic repetition or replay button |
| Step selection | Indicator translates; outgoing content fades and incoming content takes its place | 180–240ms | Show a real state change; preserve the source sentence and keyboard orientation |
| Vocabulary tile | On demo Save, the tile travels a short distance toward the collection slot and settles | 280–360ms | Make the save destination tangible; confirm only the sample action |
| Primary button | A small downward press with a shallow edge; a restrained release easing | 100–180ms | Give the action physical feedback; never move away from the pointer |
| Lower process section | One reveal-on-entry, using the same arrival treatment | About 350ms with a short stagger | Lead attention once; no repeated motion as the user scrolls back |

### Sequence detail

1. Show the entire original sentence immediately. Do not simulate a long typing delay.
2. Draw attention to **very small difference** using a highlight overlay and numbered marker.
3. Bring in its short connected explanation.
4. Show the suggested complete sentence while keeping the original available.
5. Let the attached word tile settle into place. Do not imply a real account save happened automatically.
6. End in a still, usable state with the step controls and no replay button.

The on-load demonstration runs once, with a pause/skip affordance while it is active. It ends in the readable final state without a replay control or continuous loop. Entering the sample input, focusing its controls or changing steps stops automation. Pause it when off-screen or the document is hidden.

Use three shared motion families: arrival, functional state transition and tactile press. The workbench's note/tile movements belong to the same functional sequence. Avoid independent bouncing or drifting objects elsewhere on the screen.

## Motion and visual boundaries

- No constant floating cards, parallax backgrounds, pointer followers, magnetic buttons or custom cursors.
- No scrolling text ticker as background decoration, fake live activity, invented testimonials or fabricated progress counts.
- No large 3D scene or WebGL dependency for this direction.
- Keep reading and writing areas steady. Do not animate a learner's actual draft as if the AI is rewriting it without permission.
- Preserve the distinction between a suggestion and an error; a selected phrase is not automatically incorrect.
- Use only a little coral and mint around the main yellow action/highlight. Do not introduce a competing accent for every card.
- Paper texture belongs to backing/decorative material. The reading surface stays clean, with no contrast-reducing grain over text.
- Any book/plant artwork is a static supporting asset, not a separate animated scene.

## Accessibility, Vietnamese typography and phones

The proposed version should remain friendly to people who prefer a still interface:

- Under `prefers-reduced-motion`, show the complete static example immediately. No automatic travel, sweep, spring, stagger or rotating content is needed; manual step selection still works.
- Buttons and tabs work through keyboard and touch. Hover effects have a focus equivalent. Focus indicators appear immediately.
- Number and text identify each annotation in addition to color. Decorative layers are excluded from the accessibility tree.
- Keep the example's original and revised sentences associated in reading order. Do not announce an animation frame by frame.
- Use 16–18px body text, sufficient contrast, and approximately 44–48px main touch targets. Verify Vietnamese diacritics in the real chosen font; retain the current dependable DM Sans treatment if necessary.
- On phones, put the headline and CTA first, followed by a flat, readable workbench. Reduce layer offsets and decorative rotation; don't shrink its sentence or hide actions.
- Stack the four explanatory milestones into a compact vertical sequence on phones. The separate three-tab workbench can remain a selector and content area. Preserve all activities at 320px without tiny text.
- Keep the language preference, English exercise content, and in-place language switching behavior already implemented.
- Localize all instructional copy, including text embedded in process previews. Do not accidentally leave an English instruction in an otherwise Vietnamese interface. Actual source sentences and vocabulary remain in English.

## Implementation approach if approved

Start with React, CSS transforms/opacity and the Web Animations API or a small controlled sequence. The app already has React and Radix primitives. GSAP and Motion are not present as direct dependencies in the current package manifest; neither needs to be installed for this proposal or the basic effect.

If a prototype demonstrates that a coordinated timeline is substantially easier to maintain with GSAP, evaluate that addition then. Do not add multiple animation libraries for isolated effects. The GSAP snippets in the skill are guidance, not installed runtime functionality.

The generated mockup is a reference, not an image to place over the page. Rebuild text, buttons, annotations, language control and panels as accessible HTML/CSS. A decorative backing or optional vignette can be a separate lightweight asset.

Potential future files, **not created as implementation here**:

- `components/landing/landing-hero.tsx`: layout, copy and existing start action.
- `components/landing/sentence-demo.tsx`: one example, three stages, playback state and local-only sample behavior.
- `components/landing/learning-steps.tsx`: synchronized process previews.
- A scoped landing stylesheet and additions to both language dictionaries.

Keep database adapters, authentication, review scheduling, learner records and current writing-review logic out of this presentation change. Existing `docs/design.md` excludes spring/texture; revise that brief deliberately only after this proposal is approved, with the new treatment limited to appropriate landing components.

## Optional working-app follow-up

After the landing direction is accepted, a few effects could make the app feel related without distracting from learning:

- Selecting a phrase gently transitions the corresponding feedback note; the source paragraph remains steady.
- Saving a real word changes the local action to a clear saved state after a confirmed result, with a short icon/word-tile response. Do not hide failures or assume a save succeeded.
- A hint opens with a short fade; it never moves the answer field while the learner types.
- Finishing practice gets one brief settling/check transition, with actual session data.

These are optional scope, not part of the proposed landing-page approval by default.

## Acceptance checks before any future publication

1. A first-time visitor can describe the write → choose → practice loop after seeing the example.
2. They can start real writing immediately or try the illustrative example without signing in.
3. The original phrase and its proposed sentence remain readable throughout the animation.
4. All actions work with animation disabled, keyboard navigation and touch.
5. English and Vietnamese labels fit at desktop, tablet and 320px widths.
6. Rapidly changing steps, switching language and leaving the page do not produce stale animation callbacks or clear drafts.
7. The page loads usable content before animation assets or scripts finish. No large decorative payload blocks the first screen.
8. No fake statistics, real-data writes, new AI capability claims or surprise account changes are introduced by the demonstration.
9. At representative desktop viewport sizes, the initial view contains the complete header/hero and no **Cách học với Ownword** heading. Scrolling reveals that heading and its distinct section.
10. The **Cách học** anchor reaches the explanation without obscuring its heading, and ordinary scrolling remains available in both directions.
11. **Bắt đầu ngay** is reachable after the full explanation, fits in both languages, and starts the same authenticated writing flow as the hero action.

## Approval requested

Approve or redirect the **two-section structure**, **visual character**, **sentence workbench**, and **motion intensity** shown here. Recommended implementation scope is the public landing page only, followed by review before any app-wide extension.

The image provides the intended visual feel. The motion table defines the proposed behavior. Neither should be treated as permission to deploy changes before the user's decision.

## Artifacts and provenance

- [Latest full-page concept image, revision 6](ownword-motion-concept-v6.png), edited with the built-in ImageGen tool to point the hero arrow down from the original phrase and remove the replay button.
- [Revision 6 generation prompt](image-prompt-v6.md).
- [Revision 5 concept](ownword-motion-concept-v5.png), the previous upward hero connector.
- [Revision 5 generation prompt](image-prompt-v5.md).
- [Revision 4 full-page concept](ownword-motion-concept-v4.png), separating the introduction and explanation into two scroll sections and adding the bottom start action.
- [Revision 4 generation prompt](image-prompt-v4.md).
- [Revision 3 concept](ownword-motion-concept-v3.png), the previous mechanism-focused layout.
- [Revision 3 generation prompt](image-prompt-v3.md).
- [Revision 2 concept](ownword-motion-concept-v2.png) and [revision 2 generation prompt](image-prompt-v2.md).
- [Original concept](ownword-motion-concept.png) and [original generation prompt](image-prompt.md), retained for comparison.
- Source reviewed: current `components/wordboard.tsx` landing component, `docs/design.md`, local UI primitives, installed Hallmark theme/motion references and UI/UX Pro Max searches described above.
- This proposal does not depend on external template purchases or represent measured usability improvements.
