# Revision 3 image-edit prompt

**Tool:** built-in ImageGen.  
**Reference:** `ownword-motion-concept-v2.png`, the clean second concept. The user's latest annotated image supplies the requested changes.  
**Selected output:** `ownword-motion-concept-v3.png`.  
**Transparent background:** false.

## Precision refinement after inspecting the first frame

The saved revision 3 includes this additional edit so review returns to practice, rather than new writing.

Make one precise correction to the supplied Ownword revision-3 concept. Preserve ALL headline text, body copy, hero, upward source-reference arrow, language selector, single main CTA, colors, typography, paper materials and FOUR lower activity cards exactly as they are. Do not redraw the page into a different design.

In the lower section, the long green return arrow currently goes from step 4 all the way back to step 1. This incorrectly implies that learners must write a new paragraph for every scheduled review. Remove that long return arrow and replace it with a compact recurrence loop attached ONLY to the fourth card "Luyện nhớ và đặt câu". The curved arrow should leave the bottom of step 4, loop gently under that card, and point back into step 4. No arrowhead should point at step 1, step 2 or the writing input. Keep the left-to-right arrows BETWEEN steps 1, 2, 3 and 4 unchanged.

Keep the label "Ôn lại khi đến hạn", positioned beside or inside the compact step-4 recurrence loop in the available space below the third/fourth cards. Keep the supporting note "Lịch ôn điều chỉnh theo kết quả luyện tập." readable below the process. The result should show the one-time discovery/selection sequence followed by repeated practice of SAVED words. No invented fixed interval dates or new notification feature.

Everything else remains unchanged, with correct Vietnamese diacritics and English learning sentences. No red annotations, no watermark.

## Initial generation prompt

Edit the supplied Ownword revision-2 website concept to create revision 3, incorporating the following specific user corrections. Preserve the warm Hum/Sprout paper aesthetic, green feather ownword branding, rounded dark navy typography, pear-yellow action/highlights, restrained sage backing, small book/plant vignette, and the single main hero CTA. No browser frame, no watermark, no red reviewer annotations. Keep the Vietnamese interface and English learning examples. This is a proposal, not a deployed screenshot.

HERO HEADLINE: Replace the current headline with the user's preferred exact Vietnamese copy, clearly typeset in two lines: "Học đúng từ," on line 1 and "dùng đúng nơi." on line 2. All words in the same dark ink and weight. Readable complete Vietnamese diacritics. Keep the left column balanced and professional.

HERO DESCRIPTION: Replace the current description with this exact, specific explanation of the mechanism: "Viết một đoạn tiếng Anh để nhận gợi ý từ theo ngữ cảnh. Chọn từ cần học, rồi luyện nhớ và đặt câu qua các buổi ôn tập." Use regular, comfortably readable sans typography across three short lines beneath the headline, without overflowing into the workbench. This explains contextual vocabulary selection plus productive recall and subsequent review, not simply generic AI writing improvement.

Keep ONE "Bắt đầu viết" button beneath the description and the quieter "Thử với câu mẫu" text action. Header must remain ownword brand, "Cách học" section link and Tiếng Việt / English selector only, with NO duplicated start button.

WORKBENCH ARROW: Reverse the curved green connecting arrow that currently points down from the source phrase toward the suggestion. The arrow must now point UPWARD, from the suggestion note BACK TO the highlighted phrase "very small difference". Put the ARROWHEAD nearest the highlighted original phrase and the TAIL near the suggestion note. Do not merely mirror it sideways. It should visibly communicate which phrase the note refers to. Keep the numbered source marker and all existing workbench content, including English original "There was a very small difference in productivity.", the note "Thử dùng “negligible”", explanation "Nhỏ đến mức không đáng kể.", English suggestion "There was a negligible difference in productivity.", the replay control and vocabulary tile.

REDESIGN THE ENTIRE LOWER PROCESS AREA: Replace the existing vague three-card row and large left-side slogan with a clearer FULL-WIDTH FOUR-STAGE VISUAL WALKTHROUGH on the sage paper band. The section heading across the top should be "Cách học với Ownword", followed by one small, useful line: "Từ ý bạn muốn diễn đạt đến từ bạn tự dùng được." Below it, use four generous sequential steps with numbered circles and subtle left-to-right connectors. Use one coherent strip with differentiated activity previews rather than four identical decorative feature boxes. Since this area must be readable, extend the image downward if necessary; keep approximately the same width and preserve the hero. Target a landscape 5:4 composition around 1600 x 1280, not a compressed thumbnail.

Step 1 heading EXACT: "Viết đoạn văn". Caption EXACT: "Bắt đầu từ điều bạn muốn nói." Preview: a small lined writing sheet labelled "Bài viết của bạn" containing a short English LEARNING SAMPLE such as "There was a very small difference in productivity." This sample remains English. All instructional labels remain Vietnamese.

Step 2 heading EXACT: "Xem gợi ý trong câu". Caption EXACT: "Hiểu nghĩa và cách dùng theo ngữ cảnh." Preview: an actual source phrase with a yellow highlight and numbered marker, connected to a short suggestion note "negligible". Show the location relationship; no meaningless skeleton bars.

Step 3 heading EXACT: "Chọn từ muốn học". Caption EXACT: "Chỉ lưu những từ bạn thấy hữu ích." Preview: one yellow vocabulary card "negligible" with a visible small "Lưu từ" control and a quieter "Bỏ qua" control. This shows learner choice, not automatic correction.

Step 4 heading EXACT: "Luyện nhớ và đặt câu". Caption EXACT: "Nhớ lại từ và thử dùng trong ngữ cảnh mới." Preview: a simple recall/answer field labelled "Câu trả lời của bạn" and a compact "Kiểm tra" button. The input is blank, without the answer exposed. Under the FOUR steps, show one elegant return-loop connector with the exact Vietnamese label "Ôn lại khi đến hạn" and a short supporting note "Lịch ôn điều chỉnh theo kết quả luyện tập." Do NOT show invented fixed day counts, success percentages, streaks, points, notifications, or guaranteed mastery.

Make the full lower sequence spacious enough to read, with each heading, caption and micro-preview correctly spelled and clearly associated. Reduce ornamental doodles if they compete with the explanatory flow. No untranslated English instructions anywhere. The actual English vocabulary and example sentences must remain English. Preserve professional friendliness and a visual sense of purposeful movement through the connected states.

