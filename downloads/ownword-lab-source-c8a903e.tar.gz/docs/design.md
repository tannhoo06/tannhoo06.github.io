# Hum-inspired Ownword

Ownword is a working vocabulary learning application for independent readers who can write a paragraph, including younger learners and advanced English learners. Its central object is the learner's writing, followed by contextual discovery, selection, productive practice and spaced review. Scheduling and mastery safeguards are unchanged by the visual design.

## Material and typography

The approved direction adapts Hallmark Hum / Sprout with restraint: warm paper (`--paper`), strong blue-black ink (`--ink`), rounded Chillax headings with DM Sans reading text, and soft 12–16px controls and surfaces. Both web fonts have system fallbacks; no learning interaction depends on font loading. Pear is the primary action and annotation color, green supports learning status, and blue identifies keyboard focus. All new colors and font roles are root tokens in `app/globals.css`.

Working text is 16–18px, controls 14–16px, and secondary information normally 14px. Text reflows instead of shrinking at narrow widths. There are no marketing word limits on writing, definitions, explanations or practice feedback. Torn edges, heavy textures, spring animation, mascots, XP and streaks are excluded from this calmer adaptation.

## Task layout

- Compact navigation provides Write, Practice, My words, and More (Writing insights and Settings). Destinations are semantic links; the menu and all destinations remain reachable at 320px. Route changes update the title and focus the task heading.
- Writing review pairs numbered, validated annotations with the source sentence, explanation, complete suggested sentence and distinct revision/save actions. Original analyzed writing is retained. Mobile review keeps the current source and feedback together.
- The collection leads with accurate due status, searchable vocabulary and stage filters. Filters are represented in the URL. Desktop can show stage columns; tablet uses two-card rows within stage sections and phones use one readable list. Counts reflect visible results. Active is a mastery stage, not a promise that review is finished.
- Each word card opens details. Sample records are labelled individually. Details prioritize meaning, review status and original writing, with usage and practice history in disclosure sections. Escape and Close restore the originating card's focus.
- Practice emphasizes the typed answer, then feedback, then the next action. Hints and revealed answers retain their different learning meaning. Completion reports activity rather than inferred mastery.
- Settings keeps name/session controls and saving state visible, with optional policy explanation disclosed. Insights preserves context when opening writing or a known word.

## Access and recovery

Primary actions have 48px minimum height and supporting touch targets aim for 44px. Every control has a visible focus indicator; decorative color is never the sole meaning carrier. Paragraph text uses primary ink. Reduced-motion preferences disable nonessential transitions. Demo language-analysis limits remain explicit. Drafts, unfinished review and practice context describe their actual storage scope; no cross-device recovery is implied by local browser storage.

The user-requested learning behaviors override Hallmark's cosmetic-only redesign restrictions. Existing routes, authentication, learner records and learning policy are preserved. The audit implementation and verification notes record remaining limitations independently of this design specification.

## Interface language

The primary audience is Vietnamese. New visits default to Vietnamese, with a persistent **Tiếng Việt / English** switch in the public header and workspace navigation. The preference is stored in the `ownword-language` cookie for one year and read during server rendering, so the initial HTML and document language match the selected interface. Switching updates labels in place without remounting the learning activity or clearing drafts.

Interface copy, instructions, navigation, controls, status labels, common application errors and dates are localized. English writing, vocabulary, examples, exercise prompts and generated language explanations retain their original content. The interface language does not change analysis requests or learning policy. DM Sans is used for Vietnamese headings to keep diacritics consistent. Translation strings live in `lib/i18n/messages.ts`.
