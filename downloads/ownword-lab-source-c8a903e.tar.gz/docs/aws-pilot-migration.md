# AWS pilot migration (local preparation)

> This Fargate/RDS plan has been superseded by the [Lightsail pilot](../deploy/lightsail/README.md). It remains as an earlier design record.

This plan targets an empty pilot. Preparing code and infrastructure definitions locally does not create AWS resources or incur AWS usage charges. Provisioning is a separate step.

## Target

- Keep Gemini 3.6 Flash as the model. The existing OpenRouter adapter can remain during the AWS hosting migration; its usage is billed outside AWS.
- Replace Sites/Cloudflare hosting with a Node.js deployment on ECS Fargate behind an Application Load Balancer.
- Replace D1 with a small, single-AZ RDS PostgreSQL database. Create PostgreSQL migrations and a repository implementation; start with an empty database.
- Replace Sites-provided ChatGPT identity with Cognito User Pools. Pilot users create new accounts, so no identity or learner-data transfer is needed.
- Offer Google sign-in through Cognito federation, using the same application session and user ownership rules. Google OAuth client credentials are configured as secrets, not committed to the repository.
- Store runtime secrets in AWS Secrets Manager, serve static assets with the app, and send application logs to CloudWatch.
- Keep infrastructure, migrations, and deployment instructions in this repository so another workstation can reproduce the deployment.

## Local implementation order

1. Add a PostgreSQL schema and repository adapter behind the existing `Repository` port, including the LLM call budget currently stored in D1.
2. Add Cognito sign-in, sign-out, session validation, and an `AuthProvider` adapter. Keep the current ownership rule: the server derives the user ID from a verified session.
3. Replace the Cloudflare composition root and Vinext/Worker build with a standard Node.js Next.js build and container entry point.
4. Add infrastructure as code for networking, ECS, RDS, Cognito, Secrets Manager, logs, and DNS/TLS configuration. Use one environment and small pilot capacities.
5. Document local setup, secret injection, deployment, rollback, and resource removal.

## Current local implementation

The AWS Node build uses `npm run build:aws` and `npm run start:aws` (or `Dockerfile.aws`). Set `AUTH_PROVIDER=cognito`, `COGNITO_ISSUER`, `COGNITO_DOMAIN`, `COGNITO_CLIENT_ID`, `DATABASE_URL` (or separate `DB_*` variables), `LLM_PROVIDER=openrouter`, `OPENROUTER_MODEL=google/gemini-3.6-flash`, and `OPENROUTER_API_KEY` at runtime. Set a pilot-sized `LLM_DAILY_CALL_LIMIT`. The Cognito app client must be public (no client secret) with authorization-code grant and PKCE. Register `<app-origin>/auth/callback` as a callback URL and `<app-origin>/` as a sign-out URL. The ID token is verified against Cognito's issuer keys, audience, and `token_use` before its subject is used as the database owner ID. Sessions currently last until the ID token expires, so users may need to sign in again after an hour; automatic refresh is not implemented.

`db/schema.pg.ts` and `drizzle-pg/` define the empty PostgreSQL database. With `DATABASE_URL` pointing to that database, run `npm run db:migrate:pg` once before serving traffic. The PostgreSQL adapter uses transactions for session creation, attempt recording, and removal. A local PostgreSQL server is still needed to exercise those paths end to end; the Docker CLI is installed here but its engine is not running.

For Google sign-in, register a Web OAuth client in Google Auth Platform, set its redirect URI to `<cognito-domain>/oauth2/idpresponse`, add Google as a Cognito identity provider, map `email` and `email_verified`, and enable it on the app client. Cognito's hosted sign-in page and Ownword's direct Google link then use the same application session. Cognito does not automatically merge a Google account with another account that uses the same email; pilot users should choose one sign-in method consistently. See [AWS's Google setup guide](https://docs.aws.amazon.com/cognito/latest/developerguide/cognito-user-pools-social-idp-google.html).

## Provisioning boundary

Before applying infrastructure, review the generated resource list and a region-specific AWS Pricing Calculator estimate. AWS charges begin as billable resources are created or used. A running load balancer, ECS task, and RDS instance can accrue charges even with no visitors. Set AWS budget alerts, and set a lower application LLM daily call limit for the pilot. An AWS budget alert is not a hard spending cap.

Do not commit AWS credentials, database passwords, OpenRouter keys, `.env` files, or state files. Each development computer needs its own AWS access; the deployed database remains in AWS.
