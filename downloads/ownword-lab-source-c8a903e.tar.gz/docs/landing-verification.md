# Landing redesign verification — 26 October 2026

Implemented revision 6 as responsive components in `components/landing.tsx` and scoped styles in `app/landing.css`. The existing Studio start callback is shared by both start buttons. The public sample uses component state only, with no API or storage writes. No authentication, data, scheduling, or personal-learning implementation changed. No deployment performed.

## Checks

- Production build, TypeScript, all 35 existing tests: passed.
- Targeted ESLint for landing and wordboard: passed.
- Browser checks in headless Edge: Vietnamese and English at 1440×900, 1280×720, 768×1024, 375×812, 320×640, and 812×375. No horizontal overflow. Both normal desktop introductions fit the viewport; the explanation starts below it.
- Visually reviewed desktop and 320px screenshots, including corrected source-to-suggestion arrow and mobile stacking.
- Persistent language switch, keyboard arrow navigation between tabs, section anchor, sample save/revise/recall/new sentence, and both start buttons: passed. Sign-in requests intercepted at the existing authentication boundary; no real login or learner data changes.
- Reduced-motion and 200% root text size: passed.
- Public sample: zero API writes and no browser errors.
- `git diff --check`: passed.

## Known limitations

Repository-wide lint still reports four existing rules-of-hooks errors in `components/preferences.tsx` and `components/writing.tsx`, plus existing warnings in Studio/writing. These unrelated learning/settings files were left unchanged. Browser verification used Edge; no Safari or Firefox run. The public recall checker deliberately accepts only the example word, and the sample sentence field does not claim AI evaluation or persistence.

## Repeat browser checks

Start `npm run dev` on port 5173, then run `node tests/landing.browser.mjs` with Playwright available. `PLAYWRIGHT_MODULE` may point to an existing installation's module URL; `BROWSER_CHANNEL` defaults to `msedge`. Screenshots are written to ignored `.sites-runtime/`. The script checks public sample network isolation and intercepts both sign-in navigations.
