# Ownword Lightsail pilot audit

> **Implementation update, 2026-11-05:** The findings below describe the original audit snapshot at `e056236`. The dependency update, S3 backup, downloaded-S3 restore, CloudWatch/SNS operator alert, per-user model-call quota, and SSH firewall restriction have since been implemented and verified. See [SYSTEM_ARCHITECTURE.md](SYSTEM_ARCHITECTURE.md) for the current deployment and [CLEANUP.md](../CLEANUP.md) for retirement. Learner reminder sending, a two-account isolation test, and session-expiry UX remain open.

**Date:** 2026-11-05. **Scope:** reviewed local branch `codex/lightsail-pilot` (`HEAD e056236`) and made read-only SSH/HTTP checks of the current VM. No production configuration, data, or code was changed. This is a focused pilot audit, not a penetration test. Git worktree status was unavailable because the sandbox denied Git access to its working-tree metadata; the checked files were read directly.

## Findings, ordered by impact

### 1. Critical advisory on the deployed Next.js/Sharp dependency chain — high priority

The running app container reports `next@16.3.4` and `sharp@0.35.4` via `npm ls`, confirming that the audited versions are deployed.

`package.json` pins Next.js `16.3.4`; `npm ls` shows `sharp@0.35.4`. A production-only `npm audit --omit=dev --json` returned **1 critical, 3 high, 2 moderate** vulnerable packages. The [Next.js image-optimization advisory](https://github.com/advisories/GHSA-2464-fhr4-w9xw) covers Next `16.0.0–16.4.0` on glibc Linux when the affected Sharp path processes SVG; the runtime image is `node:22-bookworm-slim` (glibc), and Sharp is below the advisory's `0.35.5` workaround. Another [Next.js `next/og` RCE advisory](https://github.com/advisories/GHSA-vcvr-r3jv-pc5j) covers 16.3.4, although a source search found no `next/og` or `ImageResponse` use. Source search also found no explicit `next/image` use, so reachability of the image-optimization issue in this app is **not proven**. The version exposure is real; do not assume the unused feature search makes the runtime safe. The audit also flagged [Zod memory exhaustion](https://github.com/advisories/GHSA-mrhx-c7xc-m3w5) at `3.25.76`; the public JSON API limits raw bodies to 32,000 characters, which reduces that route's exposure, but this is not a complete exploitability analysis. `source-map-js` and transitive moderate advisories were also reported. **Improvement:** prioritize a tested Next/Sharp update, then review remaining advisories and rerun the audit before redeploying. No upgrade was applied here.

### 2. Backups have no tested restore and no dump retention — high priority

`deploy/lightsail/backup-postgres.sh` creates timestamped `pg_dump -Fc` files on the VM and never removes or exports them. The live crontab schedules it daily at 23:00 UTC; one 27,329-byte dump existed, and `pg_restore --list` read its table of contents. This confirms archive readability, **not** data restoration. Instance snapshots at 00:00 UTC were reported in the handoff but could not be independently verified. The same-VM dumps do not protect against loss of that instance or account. **Improvement:** test a restore into a disposable database, confirm snapshot status, set retention and an off-instance copy policy, and monitor dump age/disk use.

### 3. Public signup shares one model-call quota — medium priority

Compose defaults `LLM_DAILY_CALL_LIMIT` to 20, and `lib/adapters/pg-llm-budget.ts` uses one `llm:global:<UTC date>` counter. `lib/llm/call-budget.ts` reserves one count before each external model method. This reliably blocks calls after the configured count, but it is **not a dollar or token ceiling**, and one self-registered user can consume the quota for all pilot users. The previous key check reported a separate $50 OpenRouter spending cap; current cap/billing and the configured model's paid completion were not verified here. **Improvement:** add per-user model quotas and cost monitoring, and verify the model with a deliberate small test before relying on AI workflows.

### 4. SSH cloud-firewall scope is unverified — medium priority

On the VM, `ss -lnt` shows SSH listening on `0.0.0.0:22` and `[::]:22`; Compose publishes Caddy 80/443 only, with no database port published. Host listening does **not** establish the Lightsail firewall's source rule. AWS CLI was unavailable in this environment, so the cloud firewall's SSH CIDR and snapshot settings remain unverified. **Improvement:** inspect the Lightsail networking page or API and limit SSH to the administrator's current IP; keep 5432 closed publicly.

### 5. Sessions expire without refresh — medium operational impact

`app/auth/callback/route.ts` stores the Cognito ID token in an HttpOnly, Secure, SameSite=Lax cookie with age capped at one day; `lib/auth/cognito.ts` validates it on each protected request. There is no refresh-token storage or refresh flow in the reviewed code. Users must sign in again after expiry, potentially during a learning session. The signed-in user's earlier successful Add Word test is handoff evidence; a new signup/expiry test was not performed. **Improvement:** document the expected session length in the UI or add a carefully designed refresh flow if pilot feedback calls for it.

### 6. Single VM and external dependencies constrain availability — medium operational impact

The app, PostgreSQL, Caddy, and local dumps share one 2 GB VM. A live check showed approximately 1,010 MB available memory and 235 MB swap used, with no immediate memory pressure in the running containers. `sslip.io` DNS, Let's Encrypt, Cognito in `us-east-2`, and OpenRouter are separate dependencies; a hostname or Cognito outage can interrupt login. **Improvement:** monitor container restarts, free disk, swap, certificate renewal, and dependency failures; plan a controlled hostname change as documented in `SYSTEM_ARCHITECTURE.md`.

## Confirmed controls and review limits

- `app/api/[...path]/route.ts` derives identity from the server composition before any API operation. It compares write `Origin` with configured `APP_ORIGIN`, requires JSON, and rejects bodies over 32,000 characters. The origin fix is in `e056236`. GET endpoints are read-only in the reviewed route. A live cross-site request was not attempted.
- `next.config.ts` aliases the AWS build's composition import to `composition-aws.ts`; Compose sets `AUTH_PROVIDER=cognito`. The live API uses `PgRepository`, not D1. Source review of `lib/adapters/pg-repository.ts` found owner filters on user-owned reads and mutations, including ID-based access. The global `word` lexeme table is intentionally shared. There is no PostgreSQL row-level security, and a two-account adversarial test was not run. Account isolation is therefore **code-reviewed, not end-to-end verified**.
- Cognito sign-in uses authorization code with S256 PKCE and state; the callback verifies the ID JWT using issuer JWKS, audience, and token type (`app/auth/*`, `lib/auth/cognito.ts`). Actual pool settings and a new public registration were not inspected.
- `.dockerignore` excludes nested private `.env`, `.secrets`, and backups. The live server `.env` was mode `600`. Its contents and secret values were neither printed nor copied. Docker log rotation is configured in Compose. There is no evidence here that secrets were committed.
- The app validates OpenRouter responses against a schema and task-specific guards (`lib/llm/openrouter.ts`, `lib/llm/gemini.ts`, `lib/llm/*-guards.ts`). The audit did not make a billable model call.

## Read-only tests and results

| Check | Result |
|---|---|
| Git branch/HEAD | `codex/lightsail-pilot`, `e056236`; status unavailable in sandbox |
| Live Compose `ps` | `app` and `web` running; `db` running and healthy; private network; only Caddy ports published |
| HTTP home | `308` redirect to HTTPS |
| HTTPS home | `200` |
| Protected `/board` without session | `307` redirect |
| Cron and backup | Daily 23:00 UTC job; one dump present; `pg_restore --list` succeeded; full restore untested |
| VM resources | 58 GB root, 44 GB free; 1,906 MB RAM, about 1,010 MB available; 235 MB swap used |
| Server `.env` mode | `600`, owned by `ubuntu` |
| Dependency audit | `npm audit --omit=dev --json`: 1 critical, 3 high, 2 moderate; advisory applicability varies |
| Live app package versions | `next@16.3.4`, `sharp@0.35.4` via `npm ls` inside the container |
| External model call | Not run; model availability and spend unverified |
| Lightsail firewall/snapshots/billing | Not verified; AWS CLI unavailable here |

## AWS service count and proposed third service

The live pilot uses **two distinct AWS services**: Amazon Lightsail for the VM and its instance snapshots, and Amazon Cognito for sign-in. PostgreSQL 16 runs in a Docker container on that Lightsail VM; it is not Amazon RDS. Caddy, OpenRouter, Let's Encrypt, and `sslip.io` are not additional AWS services. The `infra/` RDS/CDK design is superseded and was not deployed for this pilot. Counting snapshots as a third service would count a Lightsail feature twice.

**Recommendation: add Amazon S3 as the third AWS service for off-VM PostgreSQL dumps.** This directly addresses finding 2 while keeping the existing application and database design. Upload each successful custom-format dump to a private S3 Standard bucket in Singapore (`ap-southeast-1`), retain 30 daily dumps with a lifecycle rule, and verify both the uploaded object and a restore into a disposable database. Keep the bucket's public access blocked, use server-side encryption and HTTPS, and scope upload credentials to that bucket. The exact credential method and restore procedure need review before deployment. The backup script currently writes only to the VM: **S3 is proposed, not deployed**, and the service count remains two until an upload is operating. S3 access from Lightsail does not require connecting to an RDS VPC. See [S3 security practices](https://docs.aws.amazon.com/AmazonS3/latest/userguide/security-best-practices.html) and the [Lightsail VPC-peering guide](https://docs.aws.amazon.com/lightsail/latest/userguide/lightsail-how-to-set-up-vpc-peering-with-aws-resources.html).

RDS for PostgreSQL would be a valid third service only if the database were migrated to it. It adds separately billed database instance and storage capacity, plus a database migration and private connectivity work. For this small pilot, the existing PostgreSQL container is cheaper in direct AWS charges because it shares the $12/month Lightsail VM; it also leaves database administration and recovery with the project. S3 provides a useful third service at a much smaller incremental cost. See [RDS for PostgreSQL pricing](https://aws.amazon.com/rds/postgresql/pricing/).

### Planning cost, not observed billing

The known Lightsail plan is **$12/month**. For S3 Standard in Singapore, the [AWS price list](https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonS3/current/ap-southeast-1/index.json) listed **$0.025/GB-month** for the first storage tier and **$0.005 per 1,000 PUT requests** when checked on 2026-11-05. The estimates below assume one full-size dump daily, 30 retained objects at steady state, 30 uploads/month, and no downloads, free-tier credit, or tax. They exclude snapshot storage, outbound-transfer overage, and other AWS usage.

| Daily dump size | Approximate S3 storage + upload cost/month | Lightsail + estimated S3/month |
|---|---:|---:|
| Observed 27,329-byte archive, if size stayed constant | Less than $0.01 | About $12.00 |
| 10 MiB | $0.0075 | About $12.01 |
| 100 MiB | $0.0734 | About $12.07 |
| 1 GiB | $0.7502 | About $12.75 |

The observed archive is only one point in time, not a forecast of future database size. [Lightsail snapshots](https://docs.aws.amazon.com/lightsail/latest/userguide/amazon-lightsail-faq-snapshots.html) are separately billed at $0.05 per stored GB-month, and their actual billed size was not verified. [Lightsail data transfer](https://docs.aws.amazon.com/lightsail/latest/userguide/amazon-lightsail-faq-data-transfer-allowance.html) includes an allowance; S3 uploads over the instance's public IP can count as outbound transfer and may add overage if that allowance is exceeded. Cognito usage for 2–3 expected monthly active users should fall within its [published free tier](https://aws.amazon.com/cognito/pricing/), but email/SMS, unexpected public signups, and account-specific billing may change the total. OpenRouter is separately billed. **No S3 bucket was created, and no actual AWS bill or trial-credit balance was inspected.**

## Agreed five-service target and revision email

The user selected **Lightsail + Cognito + S3 + CloudWatch + SNS** as the target architecture. Only Lightsail and Cognito are currently in use; S3, CloudWatch, and SNS remain proposed. CloudWatch would watch a custom backup-freshness signal after the S3 upload, and a CloudWatch alarm would publish failures to an operator-only SNS topic. [CloudWatch alarm actions](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Notify_Users_Alarm_Changes.html) use SNS for email notification.

SNS can also send a simple “Your words are ready to be reviewed” email. Use a **separate learner-reminder SNS Standard topic** so learners never receive operator alarms. A Lightsail scheduled job would query non-removed `user_word` rows whose `next_review_at` is due, send at most one reminder per opted-in learner per day, and link to the practice page. Each learner's email subscription must be confirmed. An SNS [subscription filter](https://docs.aws.amazon.com/sns/latest/dg/sns-message-filtering.html), keyed by a stable opaque learner ID, can route a published reminder to the intended learner; test this with two accounts before real use. A single unfiltered topic would send every reminder to every subscriber. SNS's [email documentation](https://docs.aws.amazon.com/sns/latest/dg/sns-email-notifications.html) notes limited email customization and describes the channel as suited to system alerts. Amazon SES is the better later choice for branded, personalized customer email, but adding SES alongside these five would make **six** AWS services.

The existing PostgreSQL `user_word.next_review_at` field supports due-word detection. `app_user` does **not** store an email address or reminder preference, and no reminder job exists. The implementation therefore needs opt-in/unsubscribe state, a reliable link between Cognito identity and a confirmed SNS email subscription, one-send-per-day tracking, and a job that does not expose one user's words to another. Do not send reminders to all registered accounts by default.

At three users and a maximum of one daily reminder each over a 30-day month, the upper-bound planning case is **90 reminder email deliveries/month**, plus rare operator alarms. The [SNS FAQ](https://aws.amazon.com/sns/faqs/) lists 1,000 email deliveries and 1 million requests in its monthly free tier; this pilot may fit if the account has available allowance. [CloudWatch pricing](https://aws.amazon.com/cloudwatch/pricing/) lists 10 custom metrics and 10 directly referenced standard-resolution alarm metrics in its free tier. These are account-wide allowances, not a verified $0 bill; region, other usage, transfer, credits, and taxes may change charges. No CloudWatch metric/alarm or SNS topic/subscription was created in this audit.

## Follow-up decisions

1. Schedule a dependency update and regression check before broader use. The advisory versions warrant attention even though affected feature reachability has not been established.
2. Verify the Lightsail SSH CIDR and automatic snapshot settings in the AWS account; record an actual backup restore result. If adopting S3, implement a private 30-day backup destination, upload verification, and a tested restore.
3. Decide whether the pilot should cap model calls per user as well as globally, then verify a paid model call and current OpenRouter cap with explicit cost awareness.
4. Have two independent accounts exercise ID-based endpoints to validate isolation and a new user verify email registration and session expiry.
5. For the agreed five-service plan, implement and verify S3 upload first, then CloudWatch backup monitoring and SNS operator alerts. Add learner reminders only after opt-in, confirmed subscriptions, per-user routing, and duplicate-send checks are working.

No production changes or billable model calls were made during this audit.
