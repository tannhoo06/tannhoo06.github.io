# Ownword UX audit and proposed redesign

**Reviewed:** 26 October 2026  
**Deliverable:** findings and implementation recommendations; application code has not been redesigned.  
**Agreed visual direction:** a calmer version of Sprout, the example site for Hallmark's Hum theme, suitable for younger audiences and advanced English learners.

## 1. Design verdict

Ownword has a useful learning loop: write something meaningful, discover vocabulary, choose words, retrieve them, and use them again over time. The interface is sympathetic to learners and avoids punitive scoring. Preserve that foundation.

The main problem is attention allocation. The site devotes its strongest typography and much of its space to motivational language, while the learner's text, instructions, review dates, and feedback relationships receive less emphasis. It looks calm, but using it requires interpretation and searching.

**The highest-priority change is anchored feedback:** keep the writing as the primary object, highlight the exact phrase under discussion, and show an explanation and proposed sentence beside that phrase. A learner should immediately understand **where**, **why**, and **what to do next**.

The current cream, sage, Lora, and DM Sans system is not fundamentally inappropriate. It suits reflective adult writing. However, its literary presentation, faint secondary text, frequent italic headings, and indirect wording make it less approachable and less useful as a cross-age learning interface. A restrained Hum-inspired system is a better direction for the audience you described, provided the learning workflow is redesigned alongside it.

## 2. What was examined and what the evidence means

### Scope and method

- Read the application routes, all six main workspace components, global styling, design brief, relevant vocabulary services, data types, and mock/Gemini response contracts.
- Ran the existing app locally at `http://127.0.0.1:5173` and inspected the rendered interface in headless Chrome.
- Captured `/start`, `/board`, `/write`, `/practice`, `/insights`, and `/settings` at **1440 × 1000**, **768 × 1024**, and **390 × 844**. Also inspected the public landing page at desktop size.
- Checked all six workspace routes at **320 × 800** for reflow and navigation availability.
- Walked through writing analysis, selecting/skipping suggestions, completion, a queued-only addition, an analysis error, no suggestions, word details, practice, hints, reveal, answer feedback, session completion, and sample-removal confirmation.
- Used browser-intercepted API fixtures for state-changing walkthroughs. Fixtures used the app's vocabulary catalog and mock provider where applicable. They render the real components without saving test writing, decisions, or practice attempts into the learner's database. These walkthroughs validate interface behavior, not live backend correctness.
- Compared the installed Hallmark **Hum**, **Coral**, and **Garden** theme specifications and their reference images. Consulted the installed UI/UX Pro Max skill. Its initial education search returned child-oriented typography that did not fit the adult brief; that result was rejected. Its progressive-disclosure searches also did not produce a verified match, so the disclosure recommendations below use design judgment and the GOV.UK reference instead.
- Ran Hallmark's static linter against the six main components and global CSS in app scope. Its requested render tier did not execute because the source inputs are TSX/CSS, without a render URL. The Chrome walkthrough above provides the visual evidence; there is no claimed Hallmark browser-lint pass.

### Evidence labels

**Observed** means seen in rendered screens or exercised UI. **Source-confirmed** means supported directly by implementation. **Proposed** means a design recommendation, not a feature that already exists. **Needs validation** means a risk or hypothesis that requires further testing.

This is an expert review, not research with representative learners. Live Gemini response quality, hosted authentication, real mobile keyboards, screen-reader speech output, and longitudinal learning outcomes were not tested. The local app reports **demo mode**. Browser fixtures cannot establish the quality of AI wording.

### Evidence files

Screenshots and observations are in [`../outputs/ux-audit/`](../outputs/ux-audit/). Useful starting points:

| Evidence | What it shows |
| --- | --- |
| [Desktop board](../outputs/ux-audit/board-1440.png) | Large editorial header, motivational banner, three card columns |
| [Tablet board](../outputs/ux-audit/board-768.png) | Three narrow columns and very small status text |
| [Phone writing](../outputs/ux-audit/write-390.png) | Prompt and page chrome push the editor action below the initial viewport |
| [Desktop feedback](../outputs/ux-audit/feedback-1440.png) | Original paragraph detached from a vocabulary card |
| [Phone feedback](../outputs/ux-audit/feedback-390.png) | Entire paragraph precedes the separate suggestion and actions |
| [Queued completion](../outputs/ux-audit/queued-only-finish.png) | Successful queue addition followed by an inappropriate empty-style message |
| [320px board](../outputs/ux-audit/board-320.png) | Main navigation extends beyond the viewport |
| [Phone word detail](../outputs/ux-audit/word-detail-phone-viewport.png) | Real viewport view of the detail sheet; its content scrolls internally |

## 3. Preserve these strengths

1. **Personal context starts the learning.** The learner writes about their own ideas rather than memorizing an arbitrary list.
2. **Vocabulary suggestions are optional.** Keeping a simple expression can be a good decision. Preserve the distinction between an alternative and an error.
3. **Practice asks for production.** Typed recall and sentence use should remain central. Do not replace this with recognition-only multiple choice just to make the interface easier.
4. **Spaced progression is substantive.** Keep the New / Practicing / Active learning model and its safeguards. A visual redesign should not silently alter the scheduling policy.
5. **Forgetting is treated kindly.** Retain supportive feedback, valid-synonym handling, hints, and the distinction between spelling and recall.
6. **Several accessibility foundations exist.** There is a skip link, visible focus styling, form labels in markup, reduced-motion CSS, and a dialog that closes with Escape. These are foundations to complete, not reasons to rebuild every control.
7. **The brand can remain Ownword.** The name, feather mark, and growth metaphor can survive the new direction. A literal garden game is not necessary.

## 4. Priority findings

Priority definitions: **P1** materially obstructs learning, understanding, or access; **P2** creates recurring friction; **P3** is secondary polish. No production-outage claim is being made.

| ID | Priority | Finding and evidence | Proposed improvement | Acceptance condition |
| --- | --- | --- | --- | --- |
| F01 | P1 | Feedback has no anchor in the paragraph. `writing.tsx:244` renders plain text; the card separately quotes `originalText`. Observed on desktop and phone. | Link each suggestion to its exact source span, with an active highlight and a nearby explanation. | Selecting a suggestion identifies the intended occurrence without manual searching. |
| F02 | P1 | The main example changes topic: the remote-work paragraph receives a battery-life example through `current.examples[0]`, `writing.tsx:275`. | Show the learner's own sentence with a proposed rewrite first; generic examples are optional detail. | Learner can compare before and after in their original context. |
| F03 | P1 | At 390px the original paragraph and suggestion are vertically separated; the current card begins around y=614 and its decision buttons are much farther down. | On phones, place the relevant sentence, explanation, and action together. Full paragraph remains available. | No repeated scrolling between source and explanation for a short passage. |
| F04 | P1 | Meaningful text is too small. Tablet card status is 8px; phone navigation is 10px. See `globals.css:2948` and `:2995`, plus computed-style observations. | Reflow the layout instead of shrinking the reading task. Use 16–18px learning text, 14–16px controls, and a considered secondary scale. | Definitions, instructions, and status remain readable at tablet width without zoom. |
| F05 | P1 | The original writing uses `#7c8174` on `#faf9f6`: approximately **3.80:1**, below the normal-text 4.5:1 benchmark. `globals.css:1381`. | Render learner writing in the primary ink color; reserve muted color for nonessential metadata. | Paragraph text meets contrast requirements in each supported surface/state. |
| F06 | P1 | At 320px all six workspace routes overflow horizontally. The last navigation item ends around x=363. | Replace the crowded mobile navigation row with an accessible compact menu or a genuinely fitting navigation layout. | All destinations remain reachable at 320px without horizontal page scrolling. |
| F07 | P1 | A queued-only save is excluded from `added`, `writing.tsx:100`, so completion can say “Nothing to force.” despite saving a word. | Track saved-now, queued, skipped, and already-known decisions separately. | Completion acknowledges queued words and gives the appropriate next step. |
| F08 | P1 | Feedback/review state exists only inside the mounted Writing component. Navigation or reload loses the analysis view, although the draft survives in session storage. `writing.tsx:54–57`; `studio.tsx` conditionally mounts views. | Save a resumable review identifier, decisions, and current item; distinguish draft from analyzed version. | Leaving and returning offers “Continue reviewing” without reanalyzing the same paragraph. |
| F09 | P1 | Word detail closes with Escape, but focus did **not** return to the opening word card after animation completed. Controlled dialog has no associated trigger in `wordboard.tsx:395`. | Record the opener or connect an appropriate dialog trigger and restore focus on close. | Escape and Close return keyboard focus to the originating card. |
| F10 | P2 | Repeated slogans appear in the sidebar, header, footer, page subtitle, and support panels. `studio.tsx:201`, `:258`, `:321`. | Remove persistent motivational furniture from task screens; use encouragement at meaningful outcomes. | The learner can identify the page's task and next action in a brief scan. |
| F11 | P2 | Labels require interpretation: “Find possibilities,” “Already somewhere in you,” and “What's taking root.” | Use task language such as “Review word suggestions,” “Words to recall,” and “Practice history.” | Labels explain the consequence of clicking or the content of a section. |
| F12 | P2 | Suggestion review is a forward-only cursor. Add/skip advances immediately, with no visible back or undo control. `writing.tsx:107`. | Provide a navigable suggestion list, persistent decision state, and Undo. | A learner can revisit and reverse an accidental decision. |
| F13 | P2 | Board stage counts use all words while filtering affects only cards. Searching for no match leaves “3 / 3 / 3” above zero visible cards. `wordboard.tsx:267`. | Display matched counts, optionally “0 of 3,” and a single clear no-results state with Clear filters. | Counts and visible results agree. |
| F14 | P2 | Active cards always say “Within reach,” even if their review date becomes due. `wordboard.tsx:307` precedes the due-date condition. | Separate mastery stage from scheduling status; show due status for every stage. | An Active word due today is visibly ready to review. |
| F15 | P2 | Word cards show a three-dot symbol, but the entire button opens word details. There is no separate overflow menu. `wordboard.tsx:295`. | Remove the false menu cue; use a consistent detail affordance or provide a real menu with its own action. | Clicking an affordance performs the action its appearance implies. |
| F16 | P2 | Tablet keeps a 175px sidebar and three squeezed columns. Phone stacks every stage and all cards into a long page. | Use compact top navigation at intermediate widths and a list/stage-filter view on smaller screens. | The board remains scannable without tiny typography or a long hunt for a stage. |
| F17 | P2 | Practice navigation appears before the feedback block. `practice.tsx:306–352`. | Present answer → feedback → next action in reading order. | Learners encounter the explanation before the next-word action. |
| F18 | P2 | Exercise progress is a visual span collection with an `aria-label`, not an explicit progress/status pattern. `practice.tsx:245`. | Pair “Question 2 of 4” with appropriate progress semantics and separate completion announcements. | Assistive technology can determine position and updates. |
| F19 | P2 | Writing input has only a screen-reader label and a placeholder. Disabled analysis needs 10 trimmed characters but the threshold is not explained. `writing.tsx:178–192`. | Add visible “Your writing,” concise requirements, and an explanatory validation state. | Learners know what to enter and why an action is unavailable. |
| F20 | P2 | Insights has counts and alternative words but no path to the original writing occurrence. `preferences.tsx:87–155`; `insights.ts` returns aggregated phrases. | Include an expandable source sentence and a “View in writing” destination. | A learner can verify what the pattern refers to. |
| F21 | P2 | Some Insights alternatives use Add while others use “Explore in writing”; that action navigates without carrying the selected word into the task. `preferences.tsx:100–143`. | Preserve word/context intent when opening writing, and make saving behavior consistent with the queue. | The destination clearly continues the action the learner chose. |
| F22 | P2 | Demo disclosure is visually quiet, while arbitrary writing can receive a reassuring no-suggestion message from a limited mock evaluator. `mock.ts:90–94`. | State the demo limitation beside analysis and distinguish “no matching demo examples” from a language-quality judgment. | No-suggestions copy does not imply a comprehensive AI review took place. |
| F23 | P2 | Small interactive targets include a roughly 38 × 33px phone Settings button and 40px navigation rows. | Aim for 44–48px primary touch targets while preserving visual compactness. | Touch interactions are comfortable; formal minimum/spacing exceptions are checked separately. |
| F24 | P2 | Navigation changes views through local state and `pushState` without a deliberate page-heading focus handoff; tab title is static. `studio.tsx:49–53`; `layout.tsx:5`. | Give route transitions a meaningful focus destination, descriptive titles, and semantic links for destinations. | Keyboard and screen-reader users can identify the new page; open-in-new-tab works for navigation. |
| F25 | P3 | Settings and detail content use many poetic miniheadings and explanation blocks for a small set of controls. | Keep important controls visible; disclose optional learning-policy details. | Essential settings fit in a short scan without reading product philosophy. |

## 5. Recommended information architecture and learning flow

Keep the existing capabilities. Establish a stable vocabulary for destinations and actions:

| Destination | User-facing purpose | First visual priority | Main action |
| --- | --- | --- | --- |
| Write | Express an idea and find useful vocabulary | Writing area, then annotated paragraph | Review word suggestions |
| Practice | Retrieve and use chosen words | Current exercise and answer | Check answer; then Next word |
| My words | Browse the personal collection | Due status and searchable vocabulary | Practice due words |
| Writing insights | Examine recurring choices | One pattern in context | View example or try an alternative |
| Settings | Adjust the experience | Name and session-size fields | Save changes |

“My words” is a proposed visible label for WordBoard, not a requirement to rename internal routes or data. It is easier to interpret than a new product term. Retain WordBoard as a feature name if it has value to you.

### First visit

`Understand the promise → write 2–3 sentences or try an example → review suggestions in context → save a useful word → optional immediate practice → collection`

Show this sequence through the interface. Do not require learners to read a separate explanation of every learning stage. During onboarding use clear progress such as **Write / Choose words / Try one**. Do not display “01 / 03” and “02 / 03” without an equally understandable third stage.

### Returning learner

`Resume unfinished writing/review/practice, if present → otherwise practice due words → see a brief outcome → return later or write again`

If reviews are due, the collection's main action can say **Practice 4 words**. If none are due, show the actual next date when available and offer **Write something new**. Avoid manufacturing urgency, session time estimates, or progress percentages.

### Navigation proposal

With four main destinations, prefer a simple compact top navigation for desktop/tablet over a permanent inspirational sidebar. On phones, use **Write / Practice / My words** plus a clearly labelled **More** control containing Insights and Settings. Prototype this before committing: adding taps is acceptable only if it produces a clearer, accessible layout. Preserve destination access in focus mode; do not trap the learner in a session.

Route-level state should be recoverable. Browser Back must restore the relevant view and review state rather than simply recreating a blank writing screen. Saving the draft and saving the analyzed review are separate responsibilities.

## 6. The critical redesign: feedback attached to writing

### Current experience

The learner sees an entire unmarked paragraph in a narrow, muted column. A separate large card introduces a word, a definition, a rationale, and an unrelated example. They must find the phrase, infer the grammatical change, remember their original meaning, decide whether it fits, and save it. The interface gives the explanation but leaves the connection work to the learner.

### Proposed desktop layout

```text
Write                         Write   Practice   My words   More

Your writing                             Word suggestion 1 of 4
                                         [Previous] [Next]
I read a very interesting story ...
There was a [very small difference] [1]   [1] “very small difference”
in productivity, but ...                  Try “negligible”

                                         Too small to matter here.
                                         Your original wording can work too.

                                         Original sentence
                                         There was a very small difference
                                         in productivity.

                                         Suggested sentence
                                         There was a negligible difference
                                         in productivity.

[Edit writing]                           [Try this wording] [Save word]
                                         [Keep original] [Why this fits]
```

This is a proposed wireframe, not a screenshot or implemented feature. The writing should take roughly 60–65% of the available content width and the explanation 35–40%, with a capped reading measure. Select a phrase or suggestion to synchronize the two panels. The active phrase is clearly outlined/underlined and numbered; inactive suggestions stay quieter.

Do not make a thin original-text column subordinate to a giant vocabulary heading. The learner's meaning is the central object. The suggested word needs emphasis, but not more space than the sentence that gives it meaning.

### Proposed phone behavior

Use a single reading flow: relevant sentence → active phrase → explanation → try/save actions. An expanded note can appear directly beneath its sentence. Other notes remain compact. The full paragraph can be expanded without losing the active suggestion.

Do not default to putting the complete paragraph above a full-height dictionary card. Avoid a feedback sheet that permanently obscures the source sentence. If a bottom sheet is prototyped, make it dismissible, keyboard accessible, and test it with the software keyboard open.

### Interaction contract

1. Analysis preserves an immutable version of the submitted text. Show “Reviewing this version” if the draft changes afterward.
2. The first suggestion is identified, but do not unexpectedly steal focus while someone is still editing. On an explicit analysis submission, announce the result count and provide a predictable focus destination.
3. Activating a numbered annotation opens the corresponding note. The note identifies the original phrase in text, so color is never its only identifier.
4. Show the learner's original sentence and a grammatically complete proposed sentence. Highlight the actual changed words, not the entire paragraph.
5. **Try this wording** previews a revision; **Save word** adds vocabulary to practice. These are different actions with different outcomes. Neither silently performs the other.
6. Applying a preview requires an explicit action and has Undo. Preserve the original text. Never automatically rewrite the whole paragraph.
7. Save/keep decisions are visibly persistent. A learner can revisit a previous suggestion and change their mind.
8. At the end, show a factual summary: for example, “2 words saved. 1 will be introduced later.” Values come from actual decisions.
9. Known-word recall opportunities use the same location anchors but do not reveal the target before the learner chooses to retrieve or request a hint.
10. Correct known-word usage gets an optional, quiet acknowledgment. Do not mark every successful phrase and overwhelm the page.

### Data requirements and important edge cases

The existing suggestion data has `originalText` but no source offsets or replacement sentence (`lib/domain/types.ts:55–68`). Gemini validates that the phrase occurs somewhere in the passage (`gemini.ts:174–181`), which does not identify a specific occurrence.

For implementation, add a validated source anchor: analyzed-text version, exact phrase, surrounding context, and a range resolved against the original text. Define offset units explicitly; JavaScript UTF-16 offsets differ from some model/code-point offsets. Resolve and validate anchors server-side, then render the same text version client-side.

Handle repeated phrases, case differences, punctuation, line breaks, apostrophes, overlapping suggestions, emoji, and edits after analysis. If a range is ambiguous or invalid, show the quoted sentence with a clear “Location unavailable” fallback instead of highlighting the wrong occurrence. Do not trust an AI-provided index without checking it.

**Do not implement naive string replacement.** In the sample, the original span is “very small difference,” but the proposed word is “negligible.” Replacing the entire span with the word would remove the noun. A sentence rewrite must preserve grammar and meaning. Keep vocabulary sense, register, and uncertainty visible when the difference matters.

The product currently focuses on vocabulary. The new feedback presentation should not imply comprehensive grammar correction or essay assessment unless those capabilities are separately implemented and verified.

## 7. Page-by-page recommendations

### Public landing page `/`

**Works:** a clear central promise, one primary starting action, and a concrete word example. It is already calmer than many marketing sites.

**Change:** make the example demonstrate the product's main value: a highlighted phrase inside a sentence and a useful alternative next to it. The current overlapping cards explain vocabulary progression but do not show how feedback works. Remove tiny floating annotations, repeated “words already in you” copy, and competing slogans. Use a short literal explanation such as **Write a few sentences. Find useful words. Practice using them.** Keep example data labelled.

The sample-board action should open a clearly separated sample experience, not make it easy to confuse illustrative history with personal achievement. Explain sign-in at the moment it becomes necessary. Hosted sign-in was not tested, so this is a proposed flow rather than a claim about production behavior.

### First-writing page `/start`

**Works:** a low entry requirement and an optional prompt.

**Change:** use **Write a few sentences** as the heading and show the three understandable steps. Put the visible writing label above the editor. Reduce the prompt to a compact optional starter. Keep **Use an example** near the editor in demo mode; avoid duplicating help in a second column. The first screen should look like a place to write.

Continue to choice and practice without switching the learner into a different metaphor at each step. Allow **Skip for now** where onboarding is optional, with a clear route back.

### Free-writing page `/write`, before analysis

**Works:** a generous editor and a saved local-tab draft.

**Change:** title it **Write**. Keep the optional prompt, editor, and analysis action as one visual group. Remove the permanent explanatory sidebar and motivational header/footer furniture. Let experienced users dismiss the starter prompt. Show requirements in language learners understand, aligned with the actual server validation.

Make saving status accurate: **Draft saved in this tab** is more honest than **Saved** if the draft remains in session storage. Avoid a promise of cross-device recovery until implemented. When analysis fails, retain the text, keep the error near the action, and offer Retry. Distinguish a demo limitation from a network or provider error.

### Writing review, choices, and completion

Implement the annotated flow in section 6. Replace tiny “POSSIBILITY 1 OF 4” and decorative progress bars with a readable count and navigable notes. Keep **Keep original** visible and neutral; a useful alternative is not a red-marked mistake.

Completion needs separate states: words saved and ready to practice; words saved but queued; all suggestions kept/skipped; no suggestions; only known-word opportunities; and analysis unavailable. The queued-only bug demonstrates why one generic finish screen is insufficient.

An early practice action should preserve unfinished review. Make it explicit: **Practice this word now** followed by a way back to **Continue reviewing your writing**.

### Word collection `/board`

**Works:** recognizable stages, concise card meanings, search, and a review invitation.

**Change:** lead with **My words** and **Practice 4 words**, using real due data. Put the collection immediately below. Replace three equally prominent empty columns with one helpful empty state for a new learner. Offer a quieter sample-preview action separately.

Desktop may retain three columns when there is sufficient width. Tablet/phone should use a readable list with **All / New / Practicing / Active** filters. Keep due status independent of stage; do not suggest that Active means permanently learned. Make filter state visible and recoverable in the URL where appropriate. After filtering, provide matching counts and Clear filters.

Retain a small explanation of stages under **How words progress**, rather than repeating it under every column. Mark sample vocabulary at the record level when mixed with personal words, not solely through a footer notice.

### Word details

**Works:** accessible dialog structure, definition, nuance, collocations, and history. Escape closes it.

**Change:** show word, concise meaning, the learner's original source sentence, and the next review status first. `sourceText` is stored but not displayed in the current detail view. Keep **Practice this word** available with an honest explanation for queued words.

Group optional content into **Examples and usage** and **Practice history**. Do not remove nuance; reveal it when wanted. Replace metaphorical labels with literal ones. Make the sheet scroll independently with visible Close and a reachable action area. Restore opener focus on dismissal. A full-page detail route on phones may be easier to resume and link to than a large sheet; prototype before choosing.

### Practice introduction `/practice`

**Works:** one main action, short-session intent, and no punishment language.

**Change:** title it **Practice 4 words** or **Your words are up to date**, according to state. Keep one sentence about the activity. Remove the second full-page persuasion step when a learner already selected **Practice** on the board: start or resume the session directly. The standalone destination can still offer a short introduction when no session exists.

Do not invent a precise time estimate. When the next review date exists, show it instead of repeatedly inviting new writing as the only alternative.

### Exercise, hints, and answer feedback

**Works:** one typed answer, progressive hints, and a distinct reveal-to-sentence-use transition.

**Change:** put a plain instruction above the exercise, the input below it, then feedback, then **Next word**. Keep **Show a hint** as the visible secondary action. Before reveal, explain that the next action shows the answer; do not clear a learner's attempt without preserving it in the review context.

Use specific feedback headings: **Correct use**, **Right word; check the spelling**, **Another word also works**, or **Let's try it in a sentence**. Preserve kindness without making correctness ambiguous. A failed recall must not look identical to a successful independent recall, and a revealed answer must not appear to earn the same evidence. The server already distinguishes revealed attempts; the presentation should explain that distinction briefly.

On retries, keep the useful explanation available while the learner edits, rather than clearing it at the first keystroke (`practice.tsx:295`). Announce feedback concisely and keep keyboard focus predictable. Session Exit should preserve progress and make Resume visible.

### Session completion

**Works:** a definite end and a return path.

**Change:** lead with **Session complete**, show the actual number practiced, and optionally list words that need another try. Avoid implying mastery from one session. Prefer **Done** or **Back to my words** as the main action, with writing as an optional secondary choice. Show the next review date only when supported by scheduling data.

### Insights `/insights`

**Works:** frequency is framed as observation, not evidence that a learner's language is bad. Early-sample uncertainty is acknowledged.

**Change:** title it **Writing insights**. Show one useful pattern with a source sentence and a clear opportunity first. Make further patterns expandable. Keep uncertainty visible near the finding, with the full explanation available on demand.

An existing word should offer **View word** or **Practice word** rather than a dead-end “On your board” label. Selecting **Try in writing** should carry the target and a suitable prompt into the editor. Do not reveal the target automatically if that destination is intended as a retrieval exercise. Do not present phrase frequency as a vocabulary score.

### Settings `/settings`

**Works:** small core settings set, a save action, and confirmation before removing sample data.

**Change:** use **Settings**, **Name**, **Words per session**, and **Save changes**. The screen-reader-only Name label should also be visible. Show saved/unsaved status clearly and warn on navigation only when there are unsaved edits.

Move the learning philosophy under **How practice works**. Keep demo status understandable without requiring learners to know what server configuration or Gemini is. Keep sample removal in a separate management section, stating exactly what is removed and preserved; retain confirmation. Make Sign out easy to find without scrolling through several prose sections.

## 8. Theme recommendation: calmer Sprout / Hum

### Theme comparison

| Direction | Fit | Decision |
| --- | --- | --- |
| Current Ownword editorial system | Reflective, coherent, adult; increasingly formal when repeated on every task screen | Preserve useful brand warmth, replace weak hierarchy and overly literary interface copy |
| Hallmark Hum, shown as Sprout | Friendly rounded type, paper warmth, tactile actions; strong educational association | **Preferred foundation**, adapted for cross-age use per your direction |
| Hallmark Coral | Warm, direct product typography; less playful and easy to keep restrained | Useful reference for clarity and restraint; not the chosen emotional direction |
| Hallmark Garden | Growth metaphor and green warmth connect to the existing system | Too close to the current editorial problem; its orchard-oriented material does not improve the learning interaction |

This is an expert fit assessment from the theme files and reference images, not a tested comparison of three implemented Ownword designs.

### What to take from Hum

- Rounded, approachable heading shapes; evaluate **Chillax** for headings in a small prototype.
- Warm off-white surfaces with strong dark ink.
- Soft 12–16px grouping surfaces and clear, comfortable controls.
- A gentle tactile response to a meaningful click, disabled under reduced motion.
- A small amount of growth language and warmth at completion points.

### What to restrain

- Do not carry Hum's torn edges, paper grain, stacked shadows, bright full-width bands, and spring motion into every working surface.
- Do not scatter alphabet plants or decorative letterforms around the editor.
- Do not make the app look like an early-reading game. Younger users and advanced learners both need clear language and respectful presentation.
- Do not introduce XP, streaks, timed tasks, mascots, or a garden-management mechanic as part of a theme change.
- Keep a stable sans-serif face for long paragraphs and explanations. Retaining DM Sans is a practical starting point; test the pairing with Chillax rather than replacing every font automatically.

Call the result **Hum-inspired Ownword**, not an unmodified Hum theme. The existing `docs/design.md` describes the old direction; update that document deliberately during a future implementation so two conflicting design briefs do not coexist.

### Proposed visual roles

| Role | Direction | Application |
| --- | --- | --- |
| Page background | Warm near-white | Quiet frame for reading |
| Main ink | Dark blue-black or the existing deep ink | Writing, instructions, definitions |
| Primary action | One well-contrasted warm yellow or retained deep olive; choose one in prototype | Current task action only |
| Active annotation | Pale warm highlight plus numbered marker and underline/outline | The phrase currently being discussed |
| Focus | Strong distinct ring | All interactive controls |
| Successful outcome | Restrained mint/green plus explicit text | Saved word or successful use |
| Feedback needing attention | Warm amber plus explicit text | A suggestion or retry; not automatically an error |
| Actual error | Clear error treatment and recovery instruction | Network, save, or validation failure |

These are roles, not approved production swatches. Test text/fill pairs before locking tokens. Do not use white text on a bright yellow button by assumption. Keep highlight selection separate from correctness so a selected phrase does not appear wrong merely because it is selected.

### Scale and layout

- Learning text and editable writing: **16–18px**, line-height **1.5–1.7**.
- Controls: **14–16px** with **44–48px** touch areas as a product target.
- Metadata: generally **13–14px**, with essential due status still easily readable.
- Task headings: around **24–32px**, restrained and literal. Large display type belongs mainly on the public introduction.
- Paragraph measure: approximately **55–75 characters** where the layout permits; avoid the current narrow source column.
- Use a consistent spacing scale. Group the instruction with its input and feedback with its source before adding whitespace between larger regions.
- Avoid solving narrow layouts through smaller type or hiding overflow. Reflow controls and preserve every destination.

## 9. Copy reduction plan

Reduce repeated explanation, not the learner's meaningful writing or useful feedback.

| Current | Proposed | Reason |
| --- | --- | --- |
| “What's on your mind?” plus an eyebrow and subtitle | “Write” plus one optional starter | Establishes a task immediately |
| “Find possibilities” | “Review word suggestions” | Explains what the action returns |
| “Find a word that fits.” | “Word suggestions” | Clear review state |
| “A possibility, not a correction…” under every card | One concise note on the first review, with optional detail | Preserves the important meaning without repetition |
| “Words, becoming yours.” | “My words” | Easy destination recognition |
| “A little practice. A lasting difference.” | “4 words ready to practice” when accurate | Prioritizes actionable information |
| “A little help” | “Show a hint” | Describes the action |
| “What's taking root” | “Your practice so far” | Explains the evidence section |
| “Your space. Your pace.” | “Settings” | Makes controls easy to locate |
| “Nothing to force.” after queueing | “Word saved for later practice” | Acknowledges the actual result |

Remove the repeated sidebar quote, topbar motto, profile slogan, and task-screen footer slogans. Put optional rationale in **Why this word?**, **More examples**, and **How practice works**. Do not hide source text, the reason for the current suggestion, a destructive consequence, or an essential instruction. GOV.UK's details guidance supports disclosure for information only some people need, not material most users need to complete the task.

## 10. Accessibility and responsive requirements

### Confirmed concerns

- Original-writing text has insufficient normal-text contrast in the current pair.
- 320px navigation overflows on every workspace route tested.
- Functional text becomes unusually small at phone/tablet widths.
- Closing word details does not return focus to the opening card in the tested flow.

At 1440px, 768px, and 390px, the six initial workspace screens had no document-width overflow in the captured states. That does not establish full responsive correctness: the 320px check exposed a shared navigation failure.

### Requirements for the redesigned flow

1. Annotation meaning must survive color blindness and monochrome: number, source phrase, text label, and visible selection boundary accompany color.
2. Every annotation and corresponding explanation must work by keyboard. Set a sensible navigation model for many annotations; do not make the reader tab through dozens of decorative fragments.
3. Use proper input labels and connect instructions/errors programmatically. Placeholder text is not the only visible instruction.
4. Announce concise result counts, saving status, and practice feedback. Avoid repeatedly announcing the full paragraph.
5. Restore focus after dialogs; choose a deliberate focus destination after page transitions. Do not move focus on every selection if it interrupts reading.
6. Meet normal text contrast and check non-text control/focus contrast separately. The existing muted token is about **4.59:1** on paper, so not all muted text is failing; tiny size remains a separate issue.
7. Use 44–48px touch areas as the design target. WCAG 2.2 AA's target-size minimum is **24 × 24 CSS px with exceptions**, not a blanket 44px requirement.
8. Test 320px reflow, 200% text resizing, zoom, long passages, large text settings, reduced motion, and touch keyboards. A 320px viewport check alone is not a complete zoom/accessibility audit.
9. Sticky headers or actions must not cover the active sentence, feedback, focus indicator, or input when the keyboard opens.
10. Error and offline states retain the learner's draft and pending decisions. A destructive operation needs confirmation or a real undo, not a reassuring toast alone.

## 11. Hallmark assessment in context

The current pages contain patterns Hallmark explicitly discourages: inert eyebrows, small tracked-cap labels, a highlighted italic fragment inside many headings, very small functional text, and punctuation/decorative status conventions. These align with several readability and attention findings, but they are not all equivalent to accessibility failures.

The static scan produced **188 Floor findings, 261 Reflex findings, and 17 warnings across seven source files**. These are overlapping source occurrences, include strict house-style preferences, and are **not 466 distinct UX problems** or a website quality score. No changes were made to satisfy the linter.

| Hallmark tier | Relevant finding | Treatment |
| --- | --- | --- |
| Floor: access/correctness | Contrast and accurate states, including queued saves | Required fixes regardless of theme |
| Floor: house style | Eyebrows, tracked capitals, isolated italic words, decorative punctuation | Simplify as part of the new direction; do not present these as universal WCAG violations |
| Reflex | Text strain, over-decoration, unnecessary presentation conventions | Fix where the rendered screen interferes with learning |
| Finish | Spacing, rhythm, control consistency, typography details | Refine after the main tasks and feedback relationships are clear |

Use **app-screen scope** for Ownword's learning interface. Hallmark's marketing hero, page-section, and screen-word-budget rules should not limit a learner's paragraph or force a dashboard into a landing-page composition. The most useful Hum inheritance is material, typography, and control character; task layout must follow the learning activity.

## 12. Implementation sequence

### Phase 1: make the core feedback understandable

Implement F01–F03 first: validated source anchors, connected annotations, and learner-context sentence comparisons. Include all-new/known-word/empty/error states, keyboard behavior, and phone placement. Fix queued completion and preserve review state. These are the highest-value changes even if the palette initially stays the same.

Likely owners: `components/writing.tsx`, `lib/domain/types.ts`, provider contracts in `lib/llm/`, vocabulary service/repository persistence, and targeted writing styles. Anchor data and resumability need backend work; they are not a CSS-only polish.

### Phase 2: remove competition and repair navigation

Simplify headings/copy, remove repeated task-screen slogans, correct contrast and text scale, fix 320px navigation, and establish readable tablet/phone collection layouts. Repair filter counts, Active due status, and dialog focus restoration.

Likely owners: `components/studio.tsx`, `shared.tsx`, `wordboard.tsx`, `app/globals.css`, and route metadata/navigation behavior.

### Phase 3: apply the agreed visual direction

Prototype Hum-inspired writing review, one practice screen, and the collection. Review those together at phone and desktop sizes before rolling the system across all pages. Confirm font availability, final color roles, and readable control sizing. Update `docs/design.md` to record the approved adapted system.

### Phase 4: complete supporting flows

Connect Insights to source examples and preserve intent when entering writing. Reorder practice feedback/actions, improve resume and completion, and simplify Settings/detail disclosure. Keep the core learning policy unchanged unless a separate product decision calls for it.

**Do not begin by globally replacing CSS colors and fonts.** That would leave the user's central problem intact and risk spending effort on a new appearance without a clearer learning experience.

## 13. Validation plan and proposed success criteria

These are proposed checks, not measured outcomes or promised improvements.

| Task | What to observe | Proposed acceptance condition |
| --- | --- | --- |
| Start writing | Can a first-time learner locate the editor and primary action? | Understands what to do without reading an explanatory panel |
| Understand feedback | Can they identify the exact phrase the suggestion refers to? | Finds it within 5 seconds without manual search; validate this target in testing |
| Judge a suggestion | Can they explain what changes in their sentence? | Uses the before/after comparison and can keep the original confidently |
| Save a word | Do they distinguish saving vocabulary from editing the paragraph? | Correctly predicts the result of each action |
| Recover a decision | Can they undo or revisit an accidental save/skip? | Completes without restarting analysis |
| Resume review | Can they leave for practice and return? | Returns to the correct passage and unresolved suggestion |
| Complete a queued save | Does the finish state acknowledge the save? | Shows actual saved/queued counts and the correct next action |
| Find practice | Can they tell what is due and start/resume it? | No need to inspect all three learning stages |
| Use hints | Can they tell a hint from revealing the answer? | Understands the transition and sees appropriate feedback |
| Close details by keyboard | Is orientation preserved? | Focus returns to the opening card |
| Use phone/tablet | Can they read and act without hunting or shrinking text? | Source and feedback remain associated; no offscreen navigation at 320px |

Recruit younger independent readers and advanced learners for a small formative round; report their results separately before generalizing across ages. Use realistic passages, including repeated phrases, long paragraphs, multiple equally valid alternatives, no useful suggestion, and a failed analysis. Observe task completion, misclicks, rereading, and source/feedback scrolling. Test on real touch devices and at least one screen reader.

## 14. Remaining product questions

The visual preference is settled: **calmer Sprout-inspired, suitable for younger audiences and advanced learners**. The report can proceed on that basis. Before implementation or a child-facing launch, clarify:

1. **Which younger ages?** A young child learning to read and a teenage advanced writer need different input, prompt, and reading support. This report assumes independent readers who can write a short paragraph; it does not prescribe an early-literacy product.
2. **Is the goal vocabulary growth only, or also grammar/essay correction?** The current core is vocabulary. The annotation design supports that scope without promising unsupported assessment.
3. **Should a revised paragraph be retained as a new writing version?** The proposal preserves the original and allows explicit preview; cross-device version history is new work.
4. **What is the intended first production analysis mode?** Until live analysis is ready, demo limitations must remain visible at the point of use.

These decisions should shape later implementation. They do not block the findings or the recommendations in this audit.

## 15. References

### Project evidence

- `README.md`: intended advanced-learner loop, local demo limits, and persistence boundaries.
- `docs/design.md`: current visual brief and learning-interface intentions.
- `components/studio.tsx`: shell, navigation, view state, session entry, notifications.
- `components/writing.tsx`: editor, unanchored review, decision flow, queue/completion handling.
- `components/wordboard.tsx`: landing page, collection, filter counts, word detail.
- `components/practice.tsx`: exercise, hints, feedback, and completion.
- `components/preferences.tsx`: Insights and Settings.
- `app/globals.css`: rendered typography, contrast pairs, and responsive behavior.
- `lib/domain/types.ts`, `lib/llm/gemini.ts`, `lib/llm/mock.ts`, `lib/services/vocabulary.ts`, `lib/services/insights.ts`: data capabilities and behavior behind the interface.
- `outputs/ux-audit/observations.json`, `state-observations.json`, and `quality-observations.json`: route, fixture-state, and narrow-screen observations.

### Design and access references

- [W3C: Use of color](https://www.w3.org/WAI/WCAG22/Understanding/use-of-color.html): annotation meaning needs cues beyond color.
- [W3C: Contrast minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html): normal/large text contrast requirements.
- [W3C: Target size minimum](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html): 24px AA minimum and its exceptions, distinct from this report's larger design target.
- [W3C: Reflow](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html): content/function availability at a 320 CSS pixel equivalent width, with specified exceptions.
- [W3C: Status messages](https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html): programmatically available updates without unnecessary interruption.
- [GOV.UK: Details](https://design-system.service.gov.uk/components/details/): disclose secondary information while retaining essential task information.
- Installed Hallmark v2.0.0: `references/themes/hum.md`, `coral.md`, `garden.md`, their reference JPGs, `references/flow.md` app-screen section, and `references/gates.md`.

**Recommended outcome:** Ownword should feel like a friendly place to write, notice a useful word exactly where it belongs, and practice it with confidence. The main redesign object is the learner's sentence and its connected feedback. The calmer Sprout direction should make that interaction more inviting and easier to read.
