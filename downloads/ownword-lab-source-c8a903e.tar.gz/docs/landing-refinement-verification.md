# Landing refinement and native scrolling verification

> Follow-up fixes and current verification: [Landing fixes](landing-fixes-verification.md).

Date: 27 October 2026. Local changes only; this revision has not been deployed.

## Implemented

- Closer alignment between hero copy and workbench, less space below the header, circular CTA arrows, and removal of the isolated leaf decoration.
- A compact sentence workbench with larger learning text, softer paper offsets/shadows, an organic textured sage backing, and a deliberately attached vocabulary tile. The downward source-to-suggestion arrow remains; replay is absent.
- A text-free, transparent book/plant vignette generated with the built-in ImageGen tool and optimized to a 92 KB WebP at `public/images/ownword-reading-vignette.webp`. All page text and controls remain HTML.
- Content-sized activity previews with distinct writing, annotation, vocabulary, and editable recall treatments. The review connector forms a loop around step 4 only.
- A directly editable lower practice sample with explicit checking, feedback, and a new-sentence field. Starting recall hides the adjacent hints and the hero's target. Entering hero recall clears an old lower answer so it cannot reveal the target.
- One quiet sample-only explanation in the workbench. Public sample state remains in memory and makes no learner-record writes.

## Native scroll behavior

`components/use-landing-scroll.ts` measures the actual sections and toggles a class on `document.scrollingElement`. CSS applies `scroll-snap-type: y proximity`, `scroll-snap-align: start`, and `scroll-snap-stop: normal`. Smooth anchor navigation uses the document's `scroll-behavior`.

Snapping is eligible only at desktop widths of at least 1100px, heights of at least 760px, a fine pointer, a root text size of at most 18px, and when both measured sections fit in the visual viewport. ResizeObserver, font readiness, viewport resizing, and language/text-size changes recheck eligibility. Expanding practice content can disable snapping. Mobile, short screens, enlarged text, and oversized sections use normal scrolling. Reduced motion changes document scroll behavior to `auto`.

There is no sticky header to offset. No wheel/touch/key interception, artificial delay, nested scroll container, forced snap stop, animation library, or history manipulation was introduced. The hook removes its document classes and observers when leaving the landing page.

## Verification

See `tests/landing.browser.mjs` for repeatable browser checks. Run a local server on port 5173, then run the script with Playwright available. `PLAYWRIGHT_MODULE` may point to an existing installation's module URL; `BROWSER_CHANNEL` defaults to `msedge`. Screenshots are saved under ignored `outputs/landing-refinement/`.

- Production build and TypeScript: passed.
- All 35 existing unit/service tests: passed.
- Targeted ESLint for the landing component, scroll hook, and browser script: passed.
- Browser checks in headless Edge: passed across Vietnamese and English at 1440×900, 1280×800, 1280×720, 768×1024, 375×812, 320×640, and 812×375.
- Native mouse-wheel movement in both directions; PageDown, PageUp, Home, and End; anchor navigation and browser history: passed. A separate isolated Back-navigation check confirmed return to the introduction.
- Small-delta wheel bursts were allowed to rest between sections (approximately 586px in the final run), confirming proximity behavior rather than forced one-section movement.
- Emulated mobile touch swipes reached the bottom CTA. Both CTA sign-in boundaries were intercepted and verified without signing in.
- Root text at 200%, short/mobile viewports, and an expanded 900px practice field disabled snapping and retained CTA access.
- Reduced motion removed smooth travel and introduction animations. Actual animation events confirmed phrase highlighting and save feedback; interaction stopped the introduction and it did not restart.
- Both recall samples, sample save/revision, persistent language switching, and answer hiding: passed. No public-sample API writes or browser errors.
- Rendered desktop and mobile screenshots were visually compared with revision 6. Screenshots of both Vietnamese sections are `outputs/landing-refinement/introduction-vi.png` and `outputs/landing-refinement/how-it-works-vi.png`.
- Hallmark static sweep: zero failures; its render helper could not run because Puppeteer was unavailable, so the rendered QA above used the existing Playwright/Edge runtime. One source-level shadow/border warning refers to an earlier rule overridden by the final borderless sheet style. Optical spacing from the reference is retained.
- `git diff --check`: passed.

Limitations: physical mouse/trackpad/touch hardware and Safari/Firefox were unavailable; input checks used browser automation and Chromium touch emulation. Existing repository-wide lint errors in unrelated writing/settings hook usage remain outside this change. No deployment was performed.

## Illustration provenance

Built-in ImageGen prompt:

> Create a polished decorative illustration asset for the lower-left edge of a warm ivory English-learning website. A compact asymmetrical still life: three worn clothbound books in muted sage and forest green, one closed cream notebook leaning gently, a small warm ivory ceramic pot holding broad graceful green leaves, resting on a thin irregular sheet of warm ochre paper. Tactile hand-crafted paper and softly painted botanical illustration with subtle realistic fibers, gentle daylight and shallow soft shadow. Mature, welcoming, quiet Sprout-inspired editorial feel, not childish clipart. Landscape composition, objects clustered lower left with foliage arching upward, no cropped objects. Isolated on genuinely transparent background. Absolutely NO letters, text, logos, symbols, UI, frame or background scene. This is a supporting vignette, not a full page. Use warm cream, olive/sage/forest green, subtle ochre; no bright colors.


