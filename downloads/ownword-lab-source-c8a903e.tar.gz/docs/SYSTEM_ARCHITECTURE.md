# Ownword pilot system architecture

**Updated:** 2026-11-05 UTC. **Source:** local `codex/lightsail-pilot`, the deployed VM, and AWS CloudShell output provided by the account owner. The initial findings remain in [SYSTEM_AUDIT.md](SYSTEM_AUDIT.md); its pre-remediation observations are historical.

## Purpose and user journeys

Ownword is a personal English vocabulary and writing practice application. A visitor can read the public landing page, register or sign in through Cognito, then use WordBoard, manual word and concept discovery, writing analysis, practice exercises, insights, and settings. The pilot expects 2–3 users but permits public self-registration; the configured Cognito email-verification setting was reported in the handoff, not independently inspected in this audit.

1. A browser resolves `ownword.3.1.163.210.sslip.io`, opens HTTPS, and reaches Caddy on the Lightsail static IP. Caddy obtains/renews the certificate and proxies to Next.js on container port 3000. HTTP redirects to HTTPS.
2. `/auth/signin` constructs a Cognito authorization-code request with PKCE, state, and `openid email profile`. `/auth/callback` exchanges the code, verifies the ID token's issuer, audience, signature, and `token_use`, and sets an HttpOnly, Secure, SameSite=Lax session cookie. The token's `sub` is the database owner ID. Logout clears the app cookie and redirects to Cognito.
3. Protected views use `requireChatGPTUser`. The JSON API obtains identity on the server, validates same-origin JSON writes, and calls `VocabularyService`. The service uses the PostgreSQL repository and, for model tasks, OpenRouter. Response schemas and local output guards constrain model output.

## Live deployment and boundaries

The live path is **browser → sslip.io DNS → Lightsail static IP → Caddy → Next.js app → PostgreSQL**, with outbound Cognito and OpenRouter HTTPS calls. The VM is Ubuntu 24.04 in Singapore `ap-southeast-1a`, with 2 GB RAM and 2 GB swap. Docker Compose runs `web` (Caddy 2), `app` (Node 22 / Next.js 16), and `db` (PostgreSQL 16 Alpine) on `ownword_private`. Compose publishes only TCP 80/443 and UDP 443; app 3000 and database 5432 are private. Lightsail permits public HTTP/HTTPS; SSH is limited to `146.70.199.232/32` and the Lightsail browser SSH alias, with a successful SSH check after the change. There is one VM and one database volume, so this is a single-failure-domain pilot.

Trust boundaries are the public browser/Internet, the Caddy ingress, the private Docker network, the VM filesystem/volumes, Cognito in Ohio `us-east-2`, and OpenRouter. TLS terminates at Caddy; traffic to `app:3000` and `db:5432` is inside the local Docker network without TLS. Writing and learning text may be sent from the app to OpenRouter over HTTPS. Cognito is a cross-region authentication dependency. The `sslip.io` hostname and Let's Encrypt issuance depend on third parties outside AWS.

The older Sites/Cloudflare D1 implementation remains in `lib/adapters/d1-*`, `worker/`, and the default branch of `lib/server/composition.ts`. The AWS build aliases that composition import to `lib/server/composition-aws.ts` in `next.config.ts`; Compose also sets `AUTH_PROVIDER=cognito`. The `infra/` CDK Fargate/RDS stack is superseded and is **not** part of the pilot. No RDS, load balancer, NAT gateway, or purchased domain was observed for this deployment.

## Code and runtime components

| Component | Role | Source |
|---|---|---|
| Public and protected pages | Landing page; `/[view]` gates board, start, write, discover, idea, practice, insights, settings | `app/page.tsx`, `app/[view]/page.tsx` |
| Identity | PKCE sign-in/callback/logout, JWT validation, session cookie | `app/auth/*`, `lib/auth/cognito.ts`, `app/chatgpt-auth.ts` |
| API | JSON routing, request validation, origin and request limits | `app/api/[...path]/route.ts` |
| Application/domain | Vocabulary and practice use cases, domain types and learning rules | `lib/services/vocabulary.ts`, `lib/domain/*` |
| Persistence | PostgreSQL connection pool (max 5), owner-scoped repository and rate counters | `db/pg.ts`, `lib/adapters/pg-*` |
| Model | OpenRouter chat completions, schemas and output guards; global and per-user daily call budgets | `lib/llm/*`, `lib/adapters/pg-llm-budget.ts` |
| Deployment | Docker image, Compose, Caddy, migrations, database dump | `Dockerfile.aws`, `deploy/lightsail/*`, `drizzle-pg/*` |

## Data and controls

`db/schema.pg.ts` defines `app_user`, global `word` lexemes, per-user `user_word` and `manual_word_check`, writing samples/reviews/suggestions, concept discoveries, practice sessions/exercises/attempts, insights, `request_limit`, and `llm_key_rotation`. User-owned tables carry `user_id`; the global `word` table intentionally shares lexeme content. Repository methods reviewed in this audit filter reads and mutations by `userId`, but there is no database row-level security and no live two-account isolation test. Foreign keys do not all enforce same-owner relationships, so application checks are the ownership boundary.

The live environment selects OpenRouter model `google/gemini-3.6-flash`. Each provider method atomically reserves a call in **global** and **per-user** PostgreSQL daily counters; Compose defaults are 20 and 8 calls/day respectively. These count calls, not tokens or dollars. The API also limits selected actions to 80 requests per user/hour and discovery to 8 concepts and 5 writing analyses per user/day by default. A previous read-only OpenRouter key check confirmed authentication and a $50 key spending cap; actual current spend and a paid completion have not been rechecked.

Manual word validation saves the word promptly. A post-response task requests an English definition, part of speech, nuance, collocations, and examples from OpenRouter, with no context field. A once-per-minute VM cron retries unfinished entries, including older words with blank definitions; PostgreSQL holds claim leases and retry times. WordBoard marks those entries as pending and practice excludes them until the definition arrives. Recall and sentence grading send only the headword, part of speech, definition, practice state, and learner's response. They do not send a preset domain, exercise prompt, stored examples, or collocations to the grader. Practice prompts invite examples from any topic. The stored exercise context still supports the existing learning evidence ledger, but does not constrain the learner's sentence.

## Deploy, backups, and operations

`deploy/lightsail/deploy.sh` validates Compose, builds the app image, starts the database, runs the one-off Drizzle migration service, then starts app and web. The deployed source was transferred as a Git archive rather than cloned on the VM. Server-only `deploy/lightsail/.env` is mode 600 and supplies database, Cognito, and model settings; its values were not read for this audit. `.dockerignore` excludes nested `.env`, `.secrets`, and backups from the build context.

Cron runs `backup-postgres.sh` at 23:00 UTC. It creates a custom-format `pg_dump`, verifies its table of contents, uploads it to the private Singapore S3 backup bucket, verifies the remote size, and retains local dumps for 14 days after a successful upload. S3 lifecycle expires daily backup versions after 30 days and noncurrent versions after 7 days. A downloaded S3 dump was restored into a disposable PostgreSQL database and queried successfully. The separate private S3 access-log bucket retains logs for 30 days. An hourly `backup-health.sh` publishes `Ownword/Pilot/BackupFresh` (1 only when the latest local archive is under 26 hours old and matches S3). A CloudWatch alarm treats missing or zero data as breaching and sends an operator email through an encrypted SNS topic; a test alarm email was received. The operator topic uses a dedicated customer-managed KMS key. A separate learner-reminder topic exists but has no subscribers or sending job; learner reminders are not live. Automatic Lightsail snapshots are enabled at 00:00 UTC, though no snapshot had appeared at the last check. Named Docker volumes hold PostgreSQL data and Caddy certificate/config data. Logs use Docker JSON-file rotation (`10m` × 3 per service).

For a hostname change, update DNS, `APP_DOMAIN` in the server environment, and Cognito callback and logout URLs together, then redeploy and verify sign-in, HTTPS, and origin-protected writes. Preserve a backup before schema changes. Inspect `docker compose ps`, app/web logs, disk, dump age, and certificate renewal as routine pilot checks.

## Capacity and cost envelope

The 2 GB Lightsail bundle is **$12/month**; snapshot storage is **$0.05/GB-month**. The dedicated KMS key adds **$1/month**, prorated, plus small request charges if outside its free tier. S3 storage and writes, CloudWatch, SNS, and OpenRouter can also add usage costs. These are planning estimates, **not observed charges**; current AWS billing, credit, and snapshot storage were not inspected. Public registration means actual load may exceed the expected 2–3 users. See [CLEANUP.md](../CLEANUP.md) for retirement steps that remove charging resources.

## Unverified claims

- Actual first Lightsail automatic snapshot, snapshot storage size, and account billing.
- Cognito pool settings for public signup/email verification and a fresh end-to-end registration.
- A paid call to the configured OpenRouter model and its actual cost/availability.
- Cross-account isolation using two live accounts. A real S3 dump restore into a disposable database was completed.
- Exact parity between every file on the VM and the local commit; the VM is an archive copy, not a Git checkout.

Open the three-page AWS diagram [ownword-aws-architecture.drawio](ownword-aws-architecture.drawio), or the separate three-page detailed [ownword-architecture.drawio](ownword-architecture.drawio), in [diagrams.net](https://app.diagrams.net/) with **File → Open From → Device**. The first AWS page shows every deployed AWS service together: Lightsail, Cognito, S3, CloudWatch, SNS, IAM, and KMS. Outer boxes separate Singapore, Ohio, global IAM, public/external systems, and setup-only CloudShell. Both files remain editable. Run `node scripts/generate-aws-architecture.mjs` from the repository root to regenerate the AWS diagram from code.
