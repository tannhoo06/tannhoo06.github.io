# Ownword MVP V2 — targeted polish

27 October 2026. This pass changes only the five requested polish items; it does not introduce another layout or design direction.

## Changes

1. Wrong recall retains **Not quite.** and **Try again, get a hint, or reveal the word.** The container now has a neutral, lighter fill, less padding, and smaller heading/body text.
2. The previous-attempt disclosure is not rendered during either correct-recall sentence use or revealed-answer sentence use. The cached attempt data, server attempts, and WordBoard history remain unchanged.
3. Demo examples, Demo tools, and the empty-review demo-example shortcut require both the existing mock flag and a non-production `NODE_ENV`. Mock analysis itself is unchanged. No backend data/demo endpoints or authentication behavior were changed.
4. Recall hints retain their content and progressive behavior. Padding, heading size, icon size, and spacing are reduced so the question remains primary.
5. Settings retains its serialized autosave, error/retry behavior, name blur/Enter saving, and practice-length dropdown. Success now appears as a compact fixed-position **Changes saved** notification, with a dismiss button and automatic dismissal after 3 seconds. It does not insert another full-width section or move the settings fields.

## Verification

- Practice browser flow passed: wrong-answer copy and all recovery paths; compact feedback/hint panels; correct recall → sentence; revealed answer → sentence; no previous-attempt disclosure in either sentence state; skip and automatic next word; unfinished-sentence reload; completion recap and reload.
- Settings browser flow passed: four original groups and three original practice-length options; compact notification; automatic dismissal; name save; autosave failure retains the choice; retry; reload persistence; existing help/logout/menu behavior.
- Writing browser flow passed: draft/review recovery, Add/Skip, source anchors, and new-review isolation. Demo examples remain available in the development preview.
- Mobile flow passed at 320px and 390px in English and Vietnamese, including sentence/reveal/completion, review, expanded patterns, and help.
- Production-mode component render passed with mock mode both on and off: Demo examples, Demo tools, and the empty-review demo shortcut are absent. Development render exposes all three only with mock mode enabled. This uses the actual Writing and Settings components compiled separately with production/development environment values, independent of authentication or learner data.
- `npm run typecheck` passed.
- `npm run lint` passed with no errors; two pre-existing authentication-navigation warnings remain in `components/studio.tsx`.
- The final production build passed. All existing 43 automated tests and the separate ephemeral D1 integration check passed. No real Gemini calls or hosted deployment are part of this pass.

Fresh affected-state screenshots and the production/development visibility results are in `outputs/mvp-v2-polish/` (ignored, consistent with the existing artifact policy). Browser checks use isolated sample data.

## Files changed in this pass

- `components/practice.tsx` — smaller hint icon; hide previous attempt in sentence states.
- `components/preferences.tsx` — compact saved notification, auto-dismiss timer, production demo guard.
- `components/writing.tsx` — production guard for demo examples and the empty-review demo shortcut; no layout changes.
- `app/mvp-v2.css` — only the wrong-recall, hint, and Settings saved-notification styles.
- `tests/mvp-v2.browser.mjs` — affected-state assertions, development demo visibility, compact/transient toast checks.
- `tests/mvp-v2-polish.browser.mjs` — development/production component-render checks for demo-control visibility.
- This verification note and links/copy in the existing verification report and README.

Write/review layout, WordBoard and its drawer, Your patterns, Practice intro/completion, main navigation, and practice-length behavior were retained. No schema, repository, learning engine, scheduling, or authentication implementation changed in this pass.
