# Landing fixes verified — 27 October 2026

Local changes only. No deployment or publication was performed.

## Diagnosed behavior

The page scrolls on `HTML` (`document.scrollingElement`), and the header is static. Before these fixes:

| Viewport | Introduction | Learning section | Snapping |
| --- | ---: | ---: | --- |
| 1440×900 | 900px | 900px | Proximity, both sections aligned at start |
| 1280×720 | 720px | 774px | Disabled |
| 1069×930 | 930px | 1075px | Disabled by width cutoff; also too tall |
| 375×812 | 1403px | 1946px | Disabled |

At 1440×900, isolated downward wheel inputs of 60, 120, and 240 pixels each settled back at 0. Both the departure and destination were snap candidates, so the browser selected the closer departure point.

## Fixes

- Native document proximity snapping now targets the approached section only. One passive `scroll` listener observes direction and changes CSS eligibility; it does not intercept input, prevent defaults, set scroll position, delay events, or force one section per wheel event. Endpoint handling prepares the opposite destination before leaving either section. Small movements can accumulate naturally, while CSS settles near a destination.
- Eligibility uses measured section sizes and root text size at widths of at least 900px with a fine pointer, rather than the previous 1100px/760px cutoff. Oversized sections, enlarged text, and mobile use normal scrolling. Reduced motion disables smooth travel. Anchors and browser history remain native.
- Lower practice has independent dialog state and never modifies the hero tab or hides explanation cards. Both practice launch controls open the same sample dialog. Its opaque backdrop and native modal inertness keep surrounding answers out of view.
- The exercise has a labelled recall stage, explicit hint action, bounded word checking, and a sentence-writing stage with an illustrative model answer. Sentence writing is explicitly ungraded. Entered answers, sentence text, hint state, and stage persist across close/reopen within the current page session. No learner API or storage writes occur.
- Initial focus goes to the exercise field. Tab/Shift+Tab cycle within the dialog; Escape and the close button return focus to the actual launcher. The dialog scrolls on small viewports.
- Four readable columns are used at 1200px and above. Below that, one vertical sequence and downward connectors show the complete reading order. The annotation connector is repositioned at medium widths. The review loop remains attached to step 4 only.
- Hero copy and demonstration share a visual center. Artwork scales down through medium desktop widths; below 900px it is omitted together with the viewport minimum and excess spacing so the layout grows naturally.

## Verification

- Browser tests passed in headless Edge at 1440×900, 1280×720, 1069×930, and 375×812 in both languages, with normal and reduced motion (16 combinations).
- Small downward departure inputs now rest at approximately 60, 120, and 240 pixels. Small upward departure input leaves the second section. Larger and repeated small inputs settle on the approached section. PageDown, PageUp, Home, End, smooth anchors, and browser Back passed.
- All content and the bottom CTA remained reachable, including by Chromium-emulated mobile touch swipes. Root text at 200% disabled snapping without horizontal overflow.
- Opening, hints, incorrect/correct answers, both practice stages, model answer, closing, reopening, answer persistence, Tab confinement, Escape, and focus return passed.
- Card geometry and visibility remained unchanged through practice. The hero selected tab remained unchanged through lower practice. Both existing start actions retained the original sign-in destination.
- Sample interactions produced no API writes or browser errors.
- TypeScript, targeted ESLint, all 35 existing unit/service tests, production build, and `git diff --check` passed.

Screenshots: ignored `outputs/landing-fixes/` contains all four sizes in both languages, separate desktop introduction/explanation captures, and recall/sentence dialog captures. Repeat with the existing Playwright installation using `tests/landing.browser.mjs`; `PLAYWRIGHT_MODULE` can point at an existing module URL.

Physical mouse, trackpad, and touch hardware were unavailable. Input checks used browser automation and Chromium touch emulation. Safari/Firefox were not tested. Existing unrelated repository-wide lint errors remain outside this landing-page change.
