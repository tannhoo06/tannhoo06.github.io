import { defineConfig } from "drizzle-kit";

export default defineConfig({
  schema: "./db/schema.pg.ts",
  out: "./drizzle-pg",
  dialect: "postgresql",
  ...(process.env.DATABASE_URL
    ? { dbCredentials: { url: process.env.DATABASE_URL } }
    : process.env.DB_HOST
      ? { dbCredentials: {
          host: process.env.DB_HOST,
          port: Number(process.env.DB_PORT ?? 5432),
          user: process.env.DB_USER,
          password: process.env.DB_PASSWORD,
          database: process.env.DB_NAME ?? "ownword",
          ssl: process.env.PGSSLMODE === "disable" ? false : "verify-full" as const,
        } }
      : {}),
});
