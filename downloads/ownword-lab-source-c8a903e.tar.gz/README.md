# Ownword

**Turn words you know into words you own.**

A focused MVP for advanced English learners: write → discover → choose → practice → retrieve → activate. WordBoard is the personal vocabulary board inside Ownword, with New, Practicing and Active stages in a compact card grid.

For the latest workstation transfer and publication state, see [the 2026-11-03 handoff](docs/handoff-2026-11-03.md).

The current AWS pilot target is a single Lightsail instance with PostgreSQL on the same host. See [the Lightsail deployment guide](deploy/lightsail/README.md). The earlier Fargate/RDS CDK draft remains in `infra/` for reference and must not be deployed for the Lightsail pilot.

## Vì sao Ownword được tạo ra

Nhiều người học tiếng Anh ở trình độ khá hoặc nâng cao đã nhận biết được rất nhiều từ vựng, nhưng khi viết vẫn thường quay về những từ đơn giản và quen thuộc hơn. Vấn đề không phải lúc nào cũng là học thêm từ mới, mà là biến những từ mình đã biết một cách thụ động thành những từ có thể chủ động nhớ ra và sử dụng tự nhiên khi cần.

Ownword được tạo ra để giải quyết khoảng cách đó.

Thay vì hoạt động như một từ điển đồng nghĩa hoặc chỉ đưa ra các từ “nâng cao hơn”, Ownword bắt đầu từ chính phần viết của người học. Hệ thống tìm những chỗ mà một từ chính xác, tự nhiên hoặc hữu ích hơn có thể diễn đạt cùng ý nghĩa, sau đó để người học tự chọn những từ thực sự đáng ghi nhớ và tiếp tục luyện tập chúng qua truy hồi chủ động và các bài viết sau này.

Vòng lặp học tập chính của Ownword là:

**Viết → Khám phá → Chọn → Luyện tập → Truy hồi → Vận dụng**

Mục tiêu không phải là làm cho mọi câu văn trở nên “cao cấp” hơn. Mục tiêu là giúp những từ hữu ích xuất hiện trong đầu người học một cách tự nhiên khi họ thực sự cần dùng đến chúng.

## User Story

> **Là một người học tiếng Anh ở trình độ nâng cao, tôi muốn Ownword nhận ra những từ hữu ích mà tôi có thể đã dùng trong chính bài viết của mình, để tôi có thể luyện cách nhớ lại và sử dụng những từ đó cho đến khi có thể dùng chúng một cách tự nhiên mà không cần gợi ý.**

Một luồng sử dụng điển hình sẽ như sau:

1. Tôi viết vài câu về điều mà mình thực sự muốn diễn đạt.
2. Ownword tìm một số cơ hội từ vựng phù hợp mà vẫn giữ nguyên ý nghĩa ban đầu của tôi.
3. Tôi chọn những gợi ý thực sự hữu ích và thêm chúng vào WordBoard.
4. Tôi luyện cách nhớ lại và sử dụng các từ đó trong nhiều ngữ cảnh khác nhau.
5. Theo thời gian, việc truy hồi lặp lại và sử dụng độc lập sẽ giúp từ chuyển qua các giai đoạn **New → Practicing → Active**.
6. Cuối cùng, tôi có thể tự nhớ ra và sử dụng từ đó trong bài viết của mình mà không cần Ownword gợi ý nữa.

Vì vậy, thành công không chỉ có nghĩa là nhận biết được định nghĩa của một từ. Một từ thực sự trở thành từ mình “sở hữu” khi người học có thể tự nhớ ra, sử dụng chính xác và đưa nó vào bài viết của mình một cách độc lập.

## Run locally

Requirements: Node.js 22.13+ and npm. No Gemini key is needed for the default demo mode.

```sh
npm ci
npm run db:generate   # only after a schema change; initial migration is committed
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_square_leper_queen.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_sloppy_goblin_queen.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0002_removed_word.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0003_watery_tana_nile.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0004_sudden_mysterio.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0005_kind_hobgoblin.sql
npm run dev
```

Run each migration once, in order, for a new local database; do not rerun them on every start. Existing databases need only migrations they have not applied. Local preview is at the URL printed by the dev server (normally `http://127.0.0.1:5173`). The local sign-in uses the starter's loopback-only test identity. Production uses the hosting platform's authenticated identity, never the local cookie.

The current implementation is **Next.js App Router / React / TypeScript / Tailwind**, built by **Vinext** for the Sites Cloudflare runtime. Radix supplies the accessible detail dialog. Database access uses Drizzle behind a repository interface. The deployable MVP uses **D1 (SQLite)** rather than PostgreSQL because D1 is the integrated durable database for this hosting environment. This is an explicit infrastructure tradeoff, not a Supabase dependency. PostgreSQL migration requires implementing the repository adapter and generating PostgreSQL migrations; see [architecture](docs/architecture.md).

## OpenRouter configuration

For local use, add `OPENROUTER_API_KEY` to the ignored `.dev.vars` file and set `LLM_PROVIDER=openrouter`. `OPENROUTER_MODEL` defaults to `google/gemini-3.6-flash`. Keep the key server-side; restart the development server after changing local settings. `node scripts/check-llm.mjs` checks configuration without a model call; adding `--live` makes one paid test request. The adapter uses the same application prompts, response validation and guards as Gemini, with a single OpenRouter key and the existing call budget. OpenRouter can route the selected model among its providers; it does not select a different model. The live smoke test does not establish pilot readiness.

## Gemini configuration

Copy `.dev.vars.example` to the ignored `.dev.vars` for the local Worker environment. Set:

```dotenv
LLM_PROVIDER=gemini
GEMINI_MODEL=gemini-3.5-flash-lite
GEMINI_KEY_STRATEGY=round-robin
GEMINI_API_KEY=your-key-here
```

Restart the development server after changing environment values. For hosted use, configure these values using the hosting service's environment/secret settings and deploy a new version. Keep `GEMINI_API_KEY` secret. Never use a `NEXT_PUBLIC_` prefix or enter a key in the app UI. `.env.example` documents the equivalent variables for a future Node deployment.

For multiple Gemini keys, leave `GEMINI_API_KEY` empty and set `GEMINI_API_KEY_1` through `GEMINI_API_KEY_6` (or further numbered settings). Numbered keys are sorted numerically. Empty slots are ignored; duplicate values are rejected without printing them. `GEMINI_KEY_STRATEGY=round-robin` rotates once per outgoing LLM request using a shared atomic D1 counter, including across fresh Worker instances. The ordered pool is identified by a digest; API keys are never stored in D1. Consecutive reservations use different keys when the pool has at least two keys. Concurrent requests may start or finish in a different order from their reservations. Changing the configured pool starts its sequence again.

Set `GEMINI_KEY_STRATEGY=single` to always use the first configured key, or provide only `GEMINI_API_KEY`. Single-key mode does not access the rotation table. Rotation performs no automatic retries, provider fallback or quota bypass; existing rate-limit errors remain visible. Gemini quotas are per project, so keys in one project share quotas.

`LLM_PROVIDER` selects exactly one provider. The legacy `LLM_MODE` setting is still accepted when `LLM_PROVIDER` is absent. Unknown provider names fail explicitly. `lib/llm/provider-factory.ts` owns provider selection; Gemini credential selection lives behind its adapter, while the vocabulary service only depends on `LlmProvider`. A future Bedrock adapter can implement that port and be registered in the factory/config without changing learning rules, Practice or the UI. Bedrock is not implemented yet; setting `LLM_PROVIDER=bedrock` currently fails with a configuration error.

`LLM_MODE=mock` is the default and performs no external LLM calls. It offers context-sensitive curated suggestions, scenarios, valid-synonym handling and typo recognition. It intentionally returns no suggestions for writing outside its curated patterns. It is not a general semantic evaluator. Open **Demo examples → Use an example** on the writing screen to try the complete flow. Real Gemini behavior requires an API key and should be evaluated on representative learner writing before broader use. This build does not silently fall back from Gemini errors to mock feedback.

The only Gemini network implementation is `lib/llm/gemini.ts`. It uses the server-side `generateContent` API, structured output, runtime validation, a timeout, and a configurable model. The rest of the app consumes the `LlmProvider` interface (`analyzeWriting`, `suggestVocabulary`, `generateExercise`, `evaluateUsage`, `evaluateRecall`).

## Try the core loop

1. Write 2–3 sentences, or use **Demo examples → Use an example**. Choose **Review suggestions**.
2. Review each suggestion beside the original writing. **Add to practice** saves it to WordBoard; **Skip** advances without adding it.
3. Open Practice, review the short introduction, then choose **Start practice**.
4. Recall the word from its meaning, then use it in a sentence. Synonyms and spelling feedback remain supported. Hints are progressive; reveal opens sentence practice with zero recall credit.
5. **Check sentence** or **Skip this step** advances automatically. Skipping preserves a successful recall without inventing sentence-use evidence.
6. The completion recap summarizes each word. **Go to WordBoard** is primary; **Continue writing** is secondary.
7. WordBoard uses New / Practicing / Active / All and a two-column grid. Click a word for its source, collocations, example, next-step guidance, review timing, and optional history. **Your patterns** and **Settings** are in the overflow menu.

**Settings → Demo tools → Load sample WordBoard** explicitly seeds a small illustrative collection across all three stages. Sample records are labelled and can be removed there; personally added words remain. Demo controls are available in development/testing with mock mode enabled and hidden in production, including when the mock provider is used. An empty real board has one **Write something** action and is never auto-filled or shown fabricated progress. Seed records are created by an authenticated application service, not database migrations.

## Learning rules

Pure, independently testable scheduling and progression live in `lib/domain/learning.ts`. User-word metrics are derived from the immutable attempt ledger rather than redundant mutable counters.

- New → Practicing: two meaningful recalls on different UTC dates, at least six hours apart, and at least one contextually precise use.
- Practicing → Active: five meaningful spaced recalls across at least seven days, three genuinely different exercise domains, at least 80% recent recall, at least one independent use, and no repeated recent major misuse.
- Recognition is not used as a mastery signal. Strong cues carry less credit than contextual or independent production. Semantic, first-letter, partial-spelling and revealed hints reduce credit. Revealed answers receive zero retrieval credit.
- Maintenance intervals expand through 7, 21, 45 and 90 days. One failed Active review gets grace. Consecutive failures on two distinct dates move the word back to Practicing.
- New profiles default to **Standard (~7 words)**. Settings autosaves **Short (~5 words)**, **Standard (~7 words)**, or **Longer (~10 words)**. Existing six/eight-word preferences remain stored and are displayed under the approximate Standard label until changed. At most three new words are introduced per UTC day. A session may contain fewer words when fewer are due.
- Spontaneous correct use in free writing is a strong optional signal. Free writing counts as one context category rather than inflating context diversity from arbitrary user text.

Thresholds are configured through `DEFAULT_POLICY` and optional validated `LEARNING_POLICY_JSON` environment overrides. UTC boundaries are intentional in this MVP; a later timezone preference can be added without changing the learning-service API. Returning to a word multiple times immediately is allowed, but cannot manufacture spaced mastery.

## Verification

`node scripts/check-llm.mjs` checks local provider configuration without displaying keys or making model requests. `node scripts/check-llm.mjs --live` explicitly sends a small synthetic writing example once per selected key. `node scripts/evaluate-llm.mjs --live` runs a small task-fit/adversarial sample and saves a report under ignored `outputs/llm/`. These live diagnostics use an isolated in-memory selector and do not modify learner records; automated D1 integration tests verify the production selector and global budget separately. They are not a comprehensive quality or security certification.

The default model is `gemini-3.5-flash-lite`, the least expensive tested model that completed the small guarded task/adversarial sample successfully. The cheaper 3.1 Flash-Lite had repeated deadline failures and obeyed one forged grading instruction before the additional deterministic evidence guard was added. This is a small live sample, not a reliability benchmark or comprehensive security assessment. Model selection remains configurable. Gemini 2.5 Flash and Flash-Lite rejected new-user requests in the live compatibility check. Standard pricing checked on 2026-10-29: Gemini 3.1 Flash-Lite is $0.25 input / $1.50 output per million tokens; 3.5 Flash-Lite is $0.30 / $2.50. See https://ai.google.dev/gemini-api/docs/pricing for current pricing. Output is capped at 4096 tokens per request; there is no automatic escalation to a more expensive model.

`LLM_DAILY_CALL_LIMIT` defaults to 1000 attempted LLM operations across the whole site per UTC day, enforced atomically in D1 before key selection or any provider call. This is a request-count ceiling, not a dollar budget; costs vary by input/output tokens and model. Existing per-user API limits, authenticated ownership checks, and JSON-only same-origin writes remain in place. Keys are sent only in provider request headers, never in prompts, D1 or client responses. User text is JSON data under fixed system/task instructions. Strict response schemas reject unexpected fields, and code computes source offsets and prevents single-word definition recall from earning sentence precision. Model outputs remain untrusted: these layers reduce prompt-injection risk but cannot guarantee that every semantic grade resists every adversarial wording.

See [LLM security boundaries](docs/llm-security.md) for required provider controls and their limits. The evaluation guard checks lexical evidence, common inflections and minor spelling errors before accepting model recall/precision signals, and suppresses answer leakage from unrecalled-word feedback. It is a necessary evidence check, not proof of contextual correctness. Bedrock must preserve these boundaries when its adapter is implemented.

```sh
npm run typecheck
npm test
npm run build
```

Tests exercise learning gates, hint credit, active grace, maintenance intervals, queue selection, synonym and spelling handling, writing insights, and Gemini request/response contracts. The tests do not call Gemini. See [MVP V2 acceptance and regression verification](docs/mvp-v2-verification.md) for the current screen/reference mapping, checks, and remaining visual differences. Earlier verification records remain in `docs/verification.md`.

## Scope and limits

This is a single-person vocabulary product with per-user storage isolation. There are no streaks, scores, speech features, background notifications, file uploads, or chat interface. Reviews are calculated on demand; no cron infrastructure is needed. Writing samples, decisions, and progress are stored server-side. Browser session storage retains drafts, review position, and unfinished practice context; completed-session URLs can recover the recap after reload.

The production build and repository are portable in structure, but the deployed auth and database adapters remain platform-specific. AWS services have deliberately not been provisioned. See the migration map and known operational limits in [docs/architecture.md](docs/architecture.md).
