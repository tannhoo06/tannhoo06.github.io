import type { NextConfig } from "next";
import path from "node:path";

const nextConfig: NextConfig = {
  webpack(config, { webpack }) {
    config.resolve ??= {};
    config.resolve.alias = {
      ...config.resolve.alias,
      "@/lib/server/composition$": path.resolve(process.cwd(), "lib/server/composition-aws.ts"),
      "cloudflare:workers": path.resolve(process.cwd(), "lib/server/cloudflare-workers-node-stub.ts"),
    };
    config.plugins?.push(new webpack.NormalModuleReplacementPlugin(
      /^cloudflare:workers$/,
      path.resolve(process.cwd(), "lib/server/cloudflare-workers-node-stub.ts"),
    ));
    return config;
  },
};

export default nextConfig;
