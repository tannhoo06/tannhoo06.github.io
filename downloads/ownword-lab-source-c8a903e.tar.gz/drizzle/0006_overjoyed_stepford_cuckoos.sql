CREATE TABLE `manual_word_check` (
	`user_id` text NOT NULL,
	`word` text NOT NULL,
	`status` text NOT NULL,
	`suggestion` text,
	`checked_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `word`),
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action
);
