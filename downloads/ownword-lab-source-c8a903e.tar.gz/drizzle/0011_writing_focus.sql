CREATE TABLE `writing_focus_state` (
	`user_id` text NOT NULL,
	`problem_key` text NOT NULL,
	`status` text NOT NULL,
	PRIMARY KEY(`user_id`, `problem_key`),
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "writing_focus_status" CHECK("writing_focus_state"."status" in ('active', 'dismissed'))
);
