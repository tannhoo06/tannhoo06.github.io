ALTER TABLE `user_word` ADD `removed_at` text;
