CREATE TABLE `writing_review` (
	`sample_id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`review` text NOT NULL,
	FOREIGN KEY (`sample_id`) REFERENCES `writing_sample`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
ALTER TABLE `vocabulary_suggestion` ADD `source_anchor` text;--> statement-breakpoint
ALTER TABLE `vocabulary_suggestion` ADD `suggested_sentence` text;--> statement-breakpoint
ALTER TABLE `vocabulary_suggestion` ADD `saved_word_id` text;--> statement-breakpoint
ALTER TABLE `vocabulary_suggestion` ADD `queued` integer;--> statement-breakpoint
ALTER TABLE `vocabulary_suggestion` ADD `owns_saved_word` integer;