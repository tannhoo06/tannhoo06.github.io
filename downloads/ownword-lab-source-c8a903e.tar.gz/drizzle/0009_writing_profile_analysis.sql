CREATE TABLE `writing_profile_analysis` (
	`user_id` text PRIMARY KEY NOT NULL,
	`evidence_key` text NOT NULL,
	`lease_token` text,
	`next_attempt_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`result` text,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "writing_profile_analysis_result" CHECK("writing_profile_analysis"."lease_token" is null or "writing_profile_analysis"."result" is null)
);
--> statement-breakpoint
ALTER TABLE `writing_revision_check` ADD `checked_at` text;
