CREATE TABLE `practice_attempt` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`user_word_id` text NOT NULL,
	`exercise_id` text NOT NULL,
	`at` text NOT NULL,
	`kind` text NOT NULL,
	`hint` text NOT NULL,
	`answer` text NOT NULL,
	`retrieved` integer NOT NULL,
	`precise` integer NOT NULL,
	`major_misuse` integer NOT NULL,
	`context` text NOT NULL,
	`feedback` text NOT NULL,
	`spelling_correction` text,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`user_word_id`) REFERENCES `user_word`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `practice_attempt_exercise_id_unique` ON `practice_attempt` (`exercise_id`);--> statement-breakpoint
CREATE INDEX `attempt_word_time` ON `practice_attempt` (`user_word_id`,`at`);--> statement-breakpoint
CREATE TABLE `exercise` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`user_id` text NOT NULL,
	`user_word_id` text NOT NULL,
	`kind` text NOT NULL,
	`prompt` text NOT NULL,
	`context` text NOT NULL,
	`semantic_hint` text NOT NULL,
	`hint` text DEFAULT 'none' NOT NULL,
	`position` integer NOT NULL,
	`answered_at` text,
	FOREIGN KEY (`session_id`) REFERENCES `practice_session`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`user_word_id`) REFERENCES `user_word`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `insight` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`phrase` text NOT NULL,
	`count` integer NOT NULL,
	`alternatives` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `insight_owner_phrase` ON `insight` (`user_id`,`phrase`);--> statement-breakpoint
CREATE TABLE `request_limit` (
	`id` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `practice_session` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `vocabulary_suggestion` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`sample_id` text NOT NULL,
	`word` text NOT NULL,
	`part_of_speech` text NOT NULL,
	`definition` text NOT NULL,
	`nuance` text NOT NULL,
	`collocations` text NOT NULL,
	`examples` text NOT NULL,
	`original_text` text NOT NULL,
	`reason` text NOT NULL,
	`confidence` real NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`sample_id`) REFERENCES `writing_sample`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `user_word` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`word_id` text NOT NULL,
	`stage` text DEFAULT 'new' NOT NULL,
	`added_at` text NOT NULL,
	`introduced_at` text,
	`next_review_at` text NOT NULL,
	`source` text NOT NULL,
	`source_text` text NOT NULL,
	`demo` integer DEFAULT false NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`word_id`) REFERENCES `word`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `user_word_owner_lexeme` ON `user_word` (`user_id`,`word_id`);--> statement-breakpoint
CREATE INDEX `user_word_due` ON `user_word` (`user_id`,`next_review_at`);--> statement-breakpoint
CREATE TABLE `app_user` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`created_at` text NOT NULL,
	`daily_limit` integer DEFAULT 6 NOT NULL,
	`onboarded` integer DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE `word` (
	`id` text PRIMARY KEY NOT NULL,
	`word` text NOT NULL,
	`part_of_speech` text NOT NULL,
	`definition` text NOT NULL,
	`nuance` text NOT NULL,
	`collocations` text NOT NULL,
	`examples` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `word_word_unique` ON `word` (`word`);--> statement-breakpoint
CREATE TABLE `writing_sample` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`text` text NOT NULL,
	`prompt` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `writing_owner` ON `writing_sample` (`user_id`);