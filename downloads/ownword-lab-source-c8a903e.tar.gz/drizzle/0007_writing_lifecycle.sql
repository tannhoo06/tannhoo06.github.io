CREATE TABLE `writing_run` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`task_id` text NOT NULL,
	`submission_id` text NOT NULL,
	`idempotency_key` text NOT NULL,
	`purpose` text DEFAULT 'diagnostic' NOT NULL,
	`status` text NOT NULL,
	`quota_day` text NOT NULL,
	`lease_expires_at` text NOT NULL,
	`started_at` text NOT NULL,
	`finished_at` text,
	`report` text,
	FOREIGN KEY (`user_id`,`task_id`,`submission_id`) REFERENCES `writing_submission`(`user_id`,`task_id`,`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "writing_run_diagnostic" CHECK("writing_run"."purpose" = 'diagnostic'),
	CONSTRAINT "writing_run_state" CHECK(
    ("writing_run"."status" = 'pending' and "writing_run"."finished_at" is null and "writing_run"."report" is null)
    or ("writing_run"."status" in ('failed', 'expired') and "writing_run"."finished_at" is not null and "writing_run"."report" is null)
    or ("writing_run"."status" = 'succeeded' and "writing_run"."finished_at" is not null and "writing_run"."report" is not null)
  )
);
--> statement-breakpoint
CREATE UNIQUE INDEX `writing_run_owner_request` ON `writing_run` (`user_id`,`idempotency_key`);--> statement-breakpoint
CREATE UNIQUE INDEX `writing_run_one_active` ON `writing_run` (`user_id`,`submission_id`,`purpose`) WHERE "writing_run"."status" in ('pending', 'succeeded');--> statement-breakpoint
CREATE INDEX `writing_run_submission` ON `writing_run` (`user_id`,`task_id`,`submission_id`,`started_at`);--> statement-breakpoint
CREATE INDEX `writing_run_quota` ON `writing_run` (`user_id`,`purpose`,`quota_day`,`status`,`lease_expires_at`);--> statement-breakpoint
CREATE TABLE `writing_submission` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`task_id` text NOT NULL,
	`client_request_id` text NOT NULL,
	`parent_submission_id` text,
	`text` text NOT NULL,
	`word_count` integer NOT NULL,
	`assistance` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`user_id`,`task_id`) REFERENCES `writing_task`(`user_id`,`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`,`task_id`,`parent_submission_id`) REFERENCES `writing_submission`(`user_id`,`task_id`,`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "writing_submission_assistance" CHECK("writing_submission"."assistance" in ('unassisted', 'external_help', 'ownword_hint', 'unknown')),
	CONSTRAINT "writing_submission_word_count" CHECK("writing_submission"."word_count" >= 0),
	CONSTRAINT "writing_submission_parent_not_self" CHECK("writing_submission"."parent_submission_id" <> "writing_submission"."id")
);
--> statement-breakpoint
CREATE UNIQUE INDEX `writing_submission_owner_task_id` ON `writing_submission` (`user_id`,`task_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `writing_submission_owner_request` ON `writing_submission` (`user_id`,`client_request_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `writing_submission_one_original` ON `writing_submission` (`user_id`,`task_id`) WHERE "writing_submission"."parent_submission_id" is null;--> statement-breakpoint
CREATE INDEX `writing_submission_parent` ON `writing_submission` (`user_id`,`task_id`,`parent_submission_id`);--> statement-breakpoint
CREATE TABLE `writing_task` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`client_request_id` text NOT NULL,
	`prompt_id` text NOT NULL,
	`prompt_version` text NOT NULL,
	`snapshot` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `writing_task_owner_id` ON `writing_task` (`user_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `writing_task_owner_request` ON `writing_task` (`user_id`,`client_request_id`);