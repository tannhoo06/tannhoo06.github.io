CREATE TABLE `llm_key_rotation` (
	`id` text PRIMARY KEY NOT NULL,
	`position` integer NOT NULL
);
