CREATE TABLE `writing_revision_check` (
	`revision_id` text PRIMARY KEY NOT NULL,
	`lease_token` text,
	`lease_expires_at` text,
	`result` text,
	FOREIGN KEY (`revision_id`) REFERENCES `writing_submission`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "writing_revision_check_state" CHECK(
    ("writing_revision_check"."lease_token" is not null and "writing_revision_check"."lease_expires_at" is not null and "writing_revision_check"."result" is null)
    or ("writing_revision_check"."lease_token" is null and "writing_revision_check"."lease_expires_at" is null and "writing_revision_check"."result" is not null)
  )
);
