CREATE TABLE `concept_discovery` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`concept` text NOT NULL,
	`candidates` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `app_user`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `concept_discovery_owner_created` ON `concept_discovery` (`user_id`,`created_at`);--> statement-breakpoint
ALTER TABLE `user_word` ADD `lexeme_override` text;