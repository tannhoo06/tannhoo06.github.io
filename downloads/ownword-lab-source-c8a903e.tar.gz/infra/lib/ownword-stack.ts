import * as path from "node:path";
import {
  CfnOutput, CfnParameter, Duration, RemovalPolicy, SecretValue, Stack, StackProps,
  aws_certificatemanager as acm,
  aws_cognito as cognito,
  aws_ec2 as ec2,
  aws_ecs as ecs,
  aws_ecs_patterns as patterns,
  aws_logs as logs,
  aws_rds as rds,
  aws_route53 as route53,
  aws_secretsmanager as secretsmanager,
} from "aws-cdk-lib";
import { Construct } from "constructs";

export class OwnwordStack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    const appRecordName = new CfnParameter(this, "AppRecordName", { type: "String", description: "Record label in the hosted zone, such as app" }).valueAsString;
    const hostedZoneId = new CfnParameter(this, "HostedZoneId", { type: "String", description: "Route 53 hosted zone ID" }).valueAsString;
    const hostedZoneName = new CfnParameter(this, "HostedZoneName", { type: "String", description: "Route 53 hosted zone name, such as example.com" }).valueAsString;
    const appHost = `${appRecordName}.${hostedZoneName}`;
    const certificateArn = new CfnParameter(this, "CertificateArn", { type: "String", description: "ACM certificate ARN in this AWS region" }).valueAsString;
    const cognitoPrefix = new CfnParameter(this, "CognitoDomainPrefix", { type: "String", description: "Globally unique Cognito hosted UI prefix" }).valueAsString;
    const googleClientId = new CfnParameter(this, "GoogleClientId", { type: "String", description: "Google OAuth web client ID" }).valueAsString;
    const googleClientSecretArn = new CfnParameter(this, "GoogleClientSecretArn", { type: "String", noEcho: true, description: "Existing Secrets Manager secret ARN holding the Google OAuth client secret" }).valueAsString;
    const openRouterSecretArn = new CfnParameter(this, "OpenRouterSecretArn", { type: "String", noEcho: true, description: "Existing Secrets Manager secret ARN holding the OpenRouter API key" }).valueAsString;

    const vpc = new ec2.Vpc(this, "Vpc", {
      maxAzs: 2,
      natGateways: 0,
      subnetConfiguration: [
        { name: "public", subnetType: ec2.SubnetType.PUBLIC, cidrMask: 24 },
        { name: "database", subnetType: ec2.SubnetType.PRIVATE_ISOLATED, cidrMask: 24 },
      ],
    });
    const database = new rds.DatabaseInstance(this, "Database", {
      vpc,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
      engine: rds.DatabaseInstanceEngine.postgres({ version: rds.PostgresEngineVersion.VER_16_8 }),
      // The Free plan permits RDS PostgreSQL on db.t4g.micro. Usage consumes
      // trial credits; it is not an indefinitely free database instance.
      instanceType: ec2.InstanceType.of(ec2.InstanceClass.T4G, ec2.InstanceSize.MICRO),
      databaseName: "ownword",
      credentials: rds.Credentials.fromGeneratedSecret("ownword"),
      allocatedStorage: 20,
      storageType: rds.StorageType.GP3,
      storageEncrypted: true,
      multiAz: false,
      backupRetention: Duration.days(1),
      publiclyAccessible: false,
      deletionProtection: false,
      removalPolicy: RemovalPolicy.DESTROY,
    });

    const userPool = new cognito.UserPool(this, "Users", {
      selfSignUpEnabled: true,
      signInAliases: { email: true },
      autoVerify: { email: true },
      removalPolicy: RemovalPolicy.DESTROY,
    });
    userPool.addDomain("HostedUi", { cognitoDomain: { domainPrefix: cognitoPrefix } });
    const googleProvider = new cognito.UserPoolIdentityProviderGoogle(this, "Google", {
      userPool,
      clientId: googleClientId,
      clientSecretValue: SecretValue.secretsManager(googleClientSecretArn),
      scopes: ["openid", "email", "profile"],
      attributeMapping: {
        email: cognito.ProviderAttribute.GOOGLE_EMAIL,
        emailVerified: cognito.ProviderAttribute.GOOGLE_EMAIL_VERIFIED,
      },
    });
    const userPoolClient = userPool.addClient("WebClient", {
      generateSecret: false,
      authFlows: { userSrp: true },
      oAuth: {
        flows: { authorizationCodeGrant: true },
        scopes: [cognito.OAuthScope.OPENID, cognito.OAuthScope.EMAIL, cognito.OAuthScope.PROFILE],
        callbackUrls: [`https://${appHost}/auth/callback`],
        logoutUrls: [`https://${appHost}/`],
      },
      supportedIdentityProviders: [cognito.UserPoolClientIdentityProvider.COGNITO, cognito.UserPoolClientIdentityProvider.GOOGLE],
    });
    userPoolClient.node.addDependency(googleProvider);

    const zone = route53.HostedZone.fromHostedZoneAttributes(this, "Zone", { hostedZoneId, zoneName: hostedZoneName });
    const certificate = acm.Certificate.fromCertificateArn(this, "Certificate", certificateArn);
    const openRouterSecret = secretsmanager.Secret.fromSecretCompleteArn(this, "OpenRouterSecret", openRouterSecretArn);
    const logGroup = new logs.LogGroup(this, "AppLogs", { retention: logs.RetentionDays.ONE_WEEK, removalPolicy: RemovalPolicy.DESTROY });
    const app = new patterns.ApplicationLoadBalancedFargateService(this, "App", {
      vpc,
      assignPublicIp: true,
      publicLoadBalancer: true,
      domainName: appRecordName,
      domainZone: zone,
      certificate,
      redirectHTTP: true,
      cpu: 256,
      memoryLimitMiB: 1024,
      desiredCount: 1,
      circuitBreaker: { rollback: true },
      minHealthyPercent: 100,
      taskImageOptions: {
        image: ecs.ContainerImage.fromAsset(path.resolve(__dirname, "../.."), {
          file: "Dockerfile.aws",
          exclude: ["node_modules", "infra", ".next", "dist", ".npm-cache", ".wrangler", "outputs", "work", ".git"],
        }),
        containerPort: 3000,
        environment: {
          AUTH_PROVIDER: "cognito",
          COGNITO_ISSUER: `https://cognito-idp.${this.region}.amazonaws.com/${userPool.userPoolId}`,
          COGNITO_DOMAIN: `https://${cognitoPrefix}.auth.${this.region}.amazoncognito.com`,
          COGNITO_CLIENT_ID: userPoolClient.userPoolClientId,
          DB_HOST: database.dbInstanceEndpointAddress,
          DB_PORT: database.dbInstanceEndpointPort,
          DB_NAME: "ownword",
          LLM_PROVIDER: "openrouter",
          OPENROUTER_MODEL: "google/gemini-3.6-flash",
          LLM_DAILY_CALL_LIMIT: "100",
        },
        secrets: {
          DB_USER: ecs.Secret.fromSecretsManager(database.secret!, "username"),
          DB_PASSWORD: ecs.Secret.fromSecretsManager(database.secret!, "password"),
          OPENROUTER_API_KEY: ecs.Secret.fromSecretsManager(openRouterSecret),
        },
        logDriver: ecs.LogDrivers.awsLogs({ logGroup, streamPrefix: "ownword" }),
      },
    });
    app.targetGroup.configureHealthCheck({ path: "/", healthyHttpCodes: "200" });
    database.connections.allowDefaultPortFrom(app.service);

    new CfnOutput(this, "AppUrl", { value: `https://${appHost}` });
    new CfnOutput(this, "CognitoIssuer", { value: `https://cognito-idp.${this.region}.amazonaws.com/${userPool.userPoolId}` });
    new CfnOutput(this, "CognitoHostedDomain", { value: `https://${cognitoPrefix}.auth.${this.region}.amazoncognito.com` });
    new CfnOutput(this, "DatabaseEndpoint", { value: database.dbInstanceEndpointAddress });
  }
}
