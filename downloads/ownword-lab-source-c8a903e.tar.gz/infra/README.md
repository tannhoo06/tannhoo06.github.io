# Ownword AWS pilot infrastructure

> Historical Fargate/RDS draft. The selected pilot architecture is now the [Lightsail instance deployment](../deploy/lightsail/README.md). Do not deploy this CDK stack for the Lightsail pilot.

This CDK project describes one ECS Fargate task behind an HTTPS Application Load Balancer, private single-AZ RDS PostgreSQL, Cognito with Google federation, Route 53 DNS, and CloudWatch logs. The task receives the existing OpenRouter key and RDS credentials from Secrets Manager. NAT gateways are disabled; the ECS task has a public IP but accepts inbound traffic only from the load balancer. The database is not public.

`npm run typecheck` and `npx cdk synth --validation false --lookups false --staging false --quiet` inspect local definitions without creating resources. Do not run `cdk deploy` until the resource list and region-specific price estimate have been reviewed. The stack uses `RemovalPolicy.DESTROY` for the empty pilot database and user pool, so deleting the stack later deletes pilot data and accounts.

## Inputs required before deployment

- An AWS account with CDK bootstrap in the target region and permission to deploy the stack.
- A domain in a Route 53 hosted zone and an ACM certificate in the same region as the load balancer. Supply the app's record label (for example, `app`), hosted zone name/ID (for example, `example.com`), and certificate ARN as stack parameters. The app URL is `https://app.example.com` in that example.
- A globally unique Cognito domain prefix. Register `https://<prefix>.auth.<region>.amazoncognito.com/oauth2/idpresponse` as the Google OAuth Web client's redirect URI. Supply the Google client ID as a stack parameter and store its client secret in Secrets Manager; pass the secret ARN.
- Store the OpenRouter API key as a plain-text Secrets Manager secret; pass its ARN. Do not put either secret value in CDK context, source files, or CloudFormation parameters.

The stack defaults to AWS Singapore (`ap-southeast-1`); set `OWNWORD_AWS_REGION` before synthesis and deployment to use another region. It outputs the app URL, Cognito issuer and hosted domain, and database endpoint. `LLM_DAILY_CALL_LIMIT` is set to 100 for the pilot. The exact Gemini 3.6 Flash token bill is outside AWS.

## First release sequence

1. Review `cdk diff` and an AWS Pricing Calculator quote for the selected region. `cdk deploy` creates billable resources.
2. Run the committed PostgreSQL migrations from a one-off ECS task in the same VPC using `npm run db:migrate:pg` before letting pilot users sign in. The image includes the migration files and CLI.
3. Check the Cognito callback and logout URLs, then try native and Google sign-in with separate pilot accounts.
4. Verify the writing, discovery, practice, and WordBoard flows on the AWS URL. The PostgreSQL adapter has not yet been exercised against a live PostgreSQL server in this workspace.

The CDK template has been synthesized locally with asset staging and cloud validation disabled. Full AWS validation and deployment remain pending account access and provisioning approval.
